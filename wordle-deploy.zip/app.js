// Auto-detect hostname so it works on web browser, WiFi devices, and Tauri desktop
const isTauriHost = typeof window !== 'undefined' && (window.location.hostname === 'tauri.localhost' || !window.location.hostname || window.location.protocol === 'file:');
const socketHost = isTauriHost ? 'localhost' : (window.location.hostname || 'localhost');
const socketProto = (typeof window !== 'undefined' && window.location.protocol === 'https:') ? 'https:' : 'http:';
const SOCKET_URL = (typeof window !== 'undefined' && window.location.origin && !isTauriHost && window.location.protocol.startsWith('http'))
  ? window.location.origin
  : `${socketProto}//${socketHost}:3500`;
// Max visible rows on board — per mode, configurable via Settings
const DISPLAY_ROWS_DEFAULT = { wordle: 6, word500: 8, wordfit: 8 };
const DISPLAY_ROWS_MIN = 3;
const DISPLAY_ROWS_MAX = 12;
let displayRowsWordle  = parseInt(localStorage.getItem('displayRows_wordle'))  || DISPLAY_ROWS_DEFAULT.wordle;
let displayRowsWord500 = parseInt(localStorage.getItem('displayRows_word500')) || DISPLAY_ROWS_DEFAULT.word500;
let displayRowsWordfit = parseInt(localStorage.getItem('displayRows_wordfit')) || DISPLAY_ROWS_DEFAULT.wordfit;

function getDisplayRows() {
  if (currentGameMode === 'squareword') return 5;
  if (currentGameMode === 'fillblanks') return 6;
  if (currentGameMode === 'wordtango') return 4;
  if (currentGameMode === 'word500') return displayRowsWord500;
  if (currentGameMode === 'wordfit') return displayRowsWordfit;
  return displayRowsWordle;
}

function adjustWordleBoardRows(newRows) {
  document.documentElement.style.setProperty('--display-rows', newRows);
  const boardEl = document.getElementById('board');
  if (!boardEl) return;
  if (!guesses || guesses.length === 0) {
    if (typeof initBoard === 'function') initBoard();
    return;
  }
  // Sesuaikan jumlah baris tanpa menghapus tebakan yang sudah ada di papan
  while (boardEl.children.length < newRows) {
    boardEl.appendChild(createEmptyBoardRow(boardEl.children.length));
  }
  while (boardEl.children.length > newRows) {
    if (boardEl.lastChild) {
      boardEl.removeChild(boardEl.lastChild);
    } else {
      break;
    }
  }
}

function changeDisplayRows(delta, e) {
  if (e) e.stopPropagation();
  if (currentGameMode === 'word500') {
    displayRowsWord500 = Math.min(DISPLAY_ROWS_MAX, Math.max(DISPLAY_ROWS_MIN, displayRowsWord500 + delta));
    localStorage.setItem('displayRows_word500', displayRowsWord500);
  } else if (currentGameMode === 'wordfit') {
    displayRowsWordfit = Math.min(DISPLAY_ROWS_MAX, Math.max(DISPLAY_ROWS_MIN, displayRowsWordfit + delta));
    localStorage.setItem('displayRows_wordfit', displayRowsWordfit);
  } else {
    displayRowsWordle = Math.min(DISPLAY_ROWS_MAX, Math.max(DISPLAY_ROWS_MIN, displayRowsWordle + delta));
    localStorage.setItem('displayRows_wordle', displayRowsWordle);
  }
  updateDisplayRowsUI();
  // Re-render board immediately without wiping existing Wordle guesses
  if (currentGameMode === 'word500') {
    renderWord500Board();
  } else if (currentGameMode === 'wordfit') {
    renderWordFitBoard();
  } else {
    adjustWordleBoardRows(getDisplayRows());
  }
}

function updateDisplayRowsUI() {
  const label = document.getElementById('displayRowsLabel');
  if (label) label.textContent = getDisplayRows();
}

let boardScale = parseInt(localStorage.getItem('board_scale')) || 100;

function changeBoardScale(delta, e) {
  if (e) e.stopPropagation();
  boardScale = Math.min(140, Math.max(60, boardScale + delta));
  localStorage.setItem('board_scale', boardScale);
  updateBoardScaleUI();
}

function updateBoardScaleUI() {
  const label = document.getElementById('boardScaleLabel');
  if (label) label.textContent = boardScale + '%';

  let baseWidth = 420;
  if (currentGameMode === 'word500') {
    baseWidth = 540;
  } else if (currentGameMode === 'wordfit') {
    const baseWidths = { 3: 280, 4: 350, 5: 420, 6: 460, 7: 500, 8: 540 };
    baseWidth = (baseWidths[WORD_LENGTH] || 420) + 80; // slightly wider for the two indicators
  } else {
    const baseWidths = { 3: 280, 4: 350, 5: 420, 6: 460, 7: 500, 8: 540 };
    baseWidth = baseWidths[WORD_LENGTH] || 420;
  }
  const finalWidth = Math.round(baseWidth * (boardScale / 100));
  document.documentElement.style.setProperty('--board-max-width', finalWidth + 'px');
  document.documentElement.style.setProperty('--board-scale', (boardScale / 100));
}

const urlParams = new URLSearchParams(window.location.search);
const isObsMode = urlParams.get('obs') === '1' || urlParams.get('obs') === 'true' || urlParams.get('overlay') === '1';
const isObsTransparent = urlParams.get('transparent') === '1' || urlParams.get('transparent') === 'true';
const isObsCompact = urlParams.get('compact') === '1' || urlParams.get('compact') === 'true' || urlParams.get('boardOnly') === '1';
const urlInitialMode = urlParams.get('mode');
const urlBackend = urlParams.get('backend');
const urlIndofinityIp = urlParams.get('ip') || urlParams.get('indofinityIp');
const urlUsername = urlParams.get('user') || urlParams.get('username');
const urlLang = urlParams.get('lang');
const isObsHostControls = urlParams.get('hostControls') === '1' || urlParams.get('showHost') === '1' || urlParams.get('hostControls') === 'true';

if (isObsMode) {
  document.documentElement.classList.add('obs-mode');
  if (document.body) document.body.classList.add('obs-mode');
  else window.addEventListener('DOMContentLoaded', () => document.body.classList.add('obs-mode'));
}

if (isObsTransparent) {
  document.documentElement.classList.add('obs-transparent');
  if (document.body) document.body.classList.add('obs-transparent');
  else window.addEventListener('DOMContentLoaded', () => document.body.classList.add('obs-transparent'));
}

if (isObsCompact) {
  document.documentElement.classList.add('obs-compact');
  if (document.body) document.body.classList.add('obs-compact');
  else window.addEventListener('DOMContentLoaded', () => document.body.classList.add('obs-compact'));
}

if (isObsHostControls) {
  document.documentElement.classList.add('show-host-controls');
  if (document.body) document.body.classList.add('show-host-controls');
  else window.addEventListener('DOMContentLoaded', () => document.body.classList.add('show-host-controls'));
}

let WORD_LENGTH = 5;
document.documentElement.style.setProperty('--word-length', WORD_LENGTH);

// Game Mode State: 'wordle' or 'word500'

// ==================== SQUAREWORD 5x5 STATE ====================
let squarewordPuzzleIndex = 0;
let squarewordGrid = [];
let squarewordRevealed = [];
let squarewordGuesses = [];
let squarewordSolvedRows = [false, false, false, false, false];
let squarewordSolvedCols = [false, false, false, false, false];
let squarewordContributors = {};
let isSquarewordScanning = false;

// ==================== WORD LADDER (WEAVER) STATE ====================
let wordLadderIndex = 0;
let wordLadderStartWord = '';
let wordLadderTargetWord = '';
let wordLadderMinSteps = 4;
let wordLadderHistory = []; // array of { word, userData, changedIndex, stepNum, pts }
let wordLadderContributors = {}; // map by username -> { userData, points, steps, words }
let wordLadderPoolID = []; // Anti-duplicate pool for ID
let wordLadderPoolEN = []; // Anti-duplicate pool for EN

let currentGameMode = urlInitialMode || sessionStorage.getItem('wordle_gameMode') || '';
let isWgTakeoverMode = localStorage.getItem('wordle_wgTakeover') === 'true';
let wgHintDelay = parseInt(localStorage.getItem('wordle_wgHintDelay')) || 45; // in seconds
let wgDifficulty = localStorage.getItem('wordle_wgDifficulty') || 'easy'; // 'easy', 'medium', 'hard'
let wgHintInterval = null;

function getMaxGuesses() {
  return (currentGameMode === 'word500' || currentGameMode === 'wordfit') ? Infinity : 6;
}

class IndoFinitySocket {
  constructor(url) {
    this.ws = new WebSocket(url);
    this.listeners = {};
    this.connected = false;
    this._isIndoFinity = true;

    this.ws.onopen = () => {
      this.connected = true;
      console.log('[IndoFinity] WebSocket connected to', url);
      
      // Fire 'connect' listeners but skip any connect-tiktok emit (handled via emit override)
      if (this.listeners['connect']) this.listeners['connect'].forEach(cb => cb());
      
      // Simulate the statusUpdate 'connected' that setupSocketListeners expects
      setTimeout(() => {
        if (this.listeners['statusUpdate']) {
          this.listeners['statusUpdate'].forEach(cb => cb({
            status: 'connected',
            uniqueId: 'IndoFinity'
          }));
        }
        if (this.listeners['tiktokConnected']) {
          this.listeners['tiktokConnected'].forEach(cb => cb({ uniqueId: 'IndoFinity' }));
        }
      }, 100);
    };

    this.ws.onmessage = (msg) => {
      try {
        const payload = JSON.parse(msg.data);
        const event = payload.event;
        const data = payload.data;
        if (this.listeners[event]) {
          this.listeners[event].forEach(cb => cb(data));
        }
      } catch (e) {
        console.error('[IndoFinity] Error parsing message', e);
      }
    };

    this.ws.onclose = () => {
      this.connected = false;
      console.log('[IndoFinity] WebSocket closed');
      if (this.listeners['statusUpdate']) {
        this.listeners['statusUpdate'].forEach(cb => cb({ status: 'disconnected', error: 'IndoFinity WebSocket terputus' }));
      }
      if (this.listeners['tiktokDisconnected']) {
        this.listeners['tiktokDisconnected'].forEach(cb => cb('tiktok.disconnected'));
      }
    };
    
    this.ws.onerror = (err) => {
      console.error('[IndoFinity] WebSocket error:', err);
      if (this.listeners['statusUpdate']) {
        this.listeners['statusUpdate'].forEach(cb => cb({ status: 'disconnected', error: `Gagal terhubung ke IndoFinity (${url})` }));
      }
      if (this.listeners['tiktokDisconnected']) {
        this.listeners['tiktokDisconnected'].forEach(cb => cb('tiktok.disconnected'));
      }
    };
  }

  on(event, callback) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
  }

  emit(event, data) {
    // IndoFinity doesn't need connect-tiktok or any server emits, silently ignore
  }
}

// State
let socket = null;
let localSocket = null; // Dedicated connection to local node server for music features

let currentWord = "";
let lastRoundTargetWord = "";
let lastRoundWinner = null;
let isAutoStarterWinnerNickname = localStorage.getItem('wordle_autoStarterWinner') !== 'false';
let isAutoStarterPreviousTarget = localStorage.getItem('wordle_autoStarter') === 'true';
let isShowHintsDiscovered = localStorage.getItem('wordle_showHintsDiscovered') !== 'false';
let guesses = [];
let knownAbsentLetters = new Set();
// Word Grid state
let wgCluesRow = [];
let wgCluesCol = [];
let wgGrid = []; // 3x3 array of { word, username, profilePic }
let wgDictionaryCache = {}; // Cache of valid words per cell
let wgHints = {}; // Cache of hints
let wordUsageFreq = {};
try {
  const savedFreq = localStorage.getItem('wordle_wordUsageStats');
  if (savedFreq) wordUsageFreq = JSON.parse(savedFreq);
} catch(e) {}
let isGameOver = false;
let isProcessing = false;
let round = 1;
let currentBg = 'nature'; // 'nature' or 'city'
let isDynamicBg = localStorage.getItem('wordle_dynamicBg') !== 'false'; // default: true

let isBadWordsFilterOn = localStorage.getItem('wordle_badWordsFilter') !== 'false';
const STOPWORDS = [
  "ANJING", "BABI", "BANGSAT", "KONTOL", "MEMEK", "JEMBUT", "NGENTOT", "PELACUR", "LONTE", "ASU", "JANCUK", "GOBLOK", "TOLOL", "BAJINGAN", "TAIK", "BERAK", "PEJU", "NGACENG", "SANGE", "MEKI", "KNTL", "NGWE", "ANJGN",
  "SLOT", "JUDI", "GACOR", "ZEUS", "POKER", "TOGEL", "ROLET", "SCATTER", "MAXWIN", "RUNGKAD", "DEPO", "WD", "SLOTER", "PRAGMATIC"
];

window.toggleBadWords = function(checked) {
  isBadWordsFilterOn = checked;
  localStorage.setItem('wordle_badWordsFilter', isBadWordsFilterOn);
};

let isLikeRestartEnabled = localStorage.getItem('wordle_likeRestart') === 'true';
let likeRestartThreshold = parseInt(localStorage.getItem('wordle_likeThreshold')) || 1000;
let isAutoFullscreen = localStorage.getItem('wordle_autoFullscreen') !== 'false';
let currentLikes = 0;

window.toggleLikeRestart = function(checked) {
  isLikeRestartEnabled = checked;
  localStorage.setItem('wordle_likeRestart', checked);
  const container = document.getElementById('likeThresholdContainer');
  const progressContainer = document.getElementById('likeProgressContainer');
  if (container) container.style.display = checked ? 'block' : 'none';
  if (progressContainer) progressContainer.style.display = checked ? 'block' : 'none';
  updateLikeProgressBar();
};

let isLowPowerMode = localStorage.getItem('wordle_lowPowerMode') === 'true';
window.toggleLowPowerMode = function(checked) {
  isLowPowerMode = checked;
  localStorage.setItem('wordle_lowPowerMode', checked);
  if (checked) {
    document.body.classList.add('low-power-mode');
    showToast('⚡ Mode Hemat Daya Aktif (Anti-Panas)', 2000);
  } else {
    document.body.classList.remove('low-power-mode');
    showToast('Mode Grafis Penuh Aktif', 2000);
  }
};

let isHeartFlurryEnabled = localStorage.getItem('wordle_heartFlurryEnabled') !== 'false';
window.toggleHeartFlurry = function(checked) {
  isHeartFlurryEnabled = checked;
  localStorage.setItem('wordle_heartFlurryEnabled', checked);
};

let isGameAnimationsEnabled = localStorage.getItem('wordle_gameAnimationsEnabled') !== 'false';
window.toggleGameAnimations = function(checked) {
  isGameAnimationsEnabled = checked;
  localStorage.setItem('wordle_gameAnimationsEnabled', checked);
  if (checked) {
    document.body.classList.remove('no-animations');
  } else {
    document.body.classList.add('no-animations');
  }
  const flipRow = document.getElementById('flipSpeedControlRow');
  if (flipRow) flipRow.style.opacity = checked ? '1' : '0.5';
};

let currentFlipSpeed = localStorage.getItem('wordle_flipSpeed') || 'adaptive';
window.changeFlipSpeed = function(val) {
  currentFlipSpeed = val || 'adaptive';
  localStorage.setItem('wordle_flipSpeed', currentFlipSpeed);
};

function getFlipSpeedConfig(queueLen = 0) {
  const speed = currentFlipSpeed || 'adaptive';
  if (!isGameAnimationsEnabled || speed === 'instant') {
    return { shouldFlip: false, stepDelay: 0, revealOffset: 0 };
  }
  if (speed === 'dramatic') {
    if (queueLen > 5) return { shouldFlip: false, stepDelay: 0, revealOffset: 0 };
    return { shouldFlip: true, stepDelay: 100, revealOffset: 180 };
  }
  if (speed === 'balanced') {
    if (queueLen > 4) return { shouldFlip: false, stepDelay: 0, revealOffset: 0 };
    return { shouldFlip: true, stepDelay: 60, revealOffset: 140 };
  }
  if (speed === 'snappy') {
    if (queueLen > 4) return { shouldFlip: false, stepDelay: 0, revealOffset: 0 };
    return { shouldFlip: true, stepDelay: 30, revealOffset: 110 };
  }
  // Default: adaptive
  if (queueLen > 3) {
    return { shouldFlip: false, stepDelay: 0, revealOffset: 0 };
  }
  const isCrowded = queueLen > 1;
  return {
    shouldFlip: true,
    stepDelay: isCrowded ? 25 : 50,
    revealOffset: isCrowded ? 100 : 130
  };
}

window.previewFlipSpeed = function(e) {
  if (e) e.stopPropagation();
  const cfg = getFlipSpeedConfig(0);
  const firstRow = document.querySelector('#board .board-row') || document.querySelector('.board-row');
  if (firstRow) {
    const tiles = firstRow.querySelectorAll('.tile');
    tiles.forEach((tile, idx) => {
      tile.classList.remove('flip-3d');
      void tile.offsetWidth;
      if (cfg.shouldFlip && cfg.stepDelay > 0) {
        tile.classList.add('flip-3d');
        tile.style.animationDelay = `${idx * cfg.stepDelay}ms`;
        setTimeout(() => {
          if (window.sounds && typeof window.sounds.playFlip === 'function') window.sounds.playFlip(idx);
        }, idx * cfg.stepDelay);
      } else {
        if (window.sounds && typeof window.sounds.playFlip === 'function') window.sounds.playFlip(0);
      }
    });
  } else if (window.sounds) {
    const step = cfg.stepDelay || 40;
    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        if (window.sounds && typeof window.sounds.playFlip === 'function') window.sounds.playFlip(i);
      }, i * step);
    }
  }
};

// ─── SISTEM COOLDOWN DINAMIS (Anti-Dominasi) ───────────────────────────────
// Makin banyak user menang berturut-turut, makin lama cooldown submit berikutnya.
// Ini memberi kesempatan penonton lain ikut berkontribusi.
// Map: userId → { wins: number, lastWinTime: ms, cooldownUntil: ms }
const playerWinStreaks = new Map();

/**
 * Catat kemenangan user dan set cooldown berikutnya.
 * @param {string} userId
 */
function recordWin(userId) {
  if (!userId || userId === 'host' || userId === 'host_offline') return;
  const now = Date.now();
  const entry = playerWinStreaks.get(userId) || { wins: 0, cooldownUntil: 0 };

  // Anggap "berturut-turut" jika menang dalam 3 menit terakhir
  const isStreak = entry.lastWinTime && (now - entry.lastWinTime < 3 * 60 * 1000);
  entry.wins = isStreak ? entry.wins + 1 : 1;
  entry.lastWinTime = now;

  // Cooldown berikutnya:
  // menang 1x → 0s, 2x → 4s, 3x → 8s, 4x+ → 15s
  const cooldownMs = entry.wins <= 1 ? 0
    : entry.wins === 2 ? 4000
    : entry.wins === 3 ? 8000
    : 15000;
  entry.cooldownUntil = now + cooldownMs;

  playerWinStreaks.set(userId, entry);

  if (cooldownMs > 0) {
    const cdSec = Math.round(cooldownMs / 1000);
    // Tidak perlu toast — cooldown diam-diam agar tidak mematikan semangat
    console.log(`[Anti-dominasi] ${userId} menang ${entry.wins}x berturut → cooldown ${cdSec}s`);
  }
}

/**
 * Cek apakah user sedang dalam cooldown anti-dominasi.
 * Return sisa millisecond cooldown (0 = tidak cooldown).
 * @param {string} userId
 * @returns {number}
 */
function getWinCooldownRemaining(userId) {
  if (!userId || userId === 'host' || userId === 'host_offline') return 0;
  const entry = playerWinStreaks.get(userId);
  if (!entry || !entry.cooldownUntil) return 0;
  const remaining = entry.cooldownUntil - Date.now();
  return remaining > 0 ? remaining : 0;
}

/**
 * Reset semua streak kemenangan (dipanggil saat ganti ronde/mode).
 */
function resetWinStreaks() {
  playerWinStreaks.clear();
}
// ──────────────────────────────────────────────────────────────────────────────

let isMarqueeEnabled = localStorage.getItem('wordle_marqueeEnabled') !== 'false';
let playerLikes = {};
let playerShares = {};
let playerGifts = {};
let playerActivePresence = {}; // { username: { accumulatedTime: seconds, lastActiveTime: ms } }
let pendingMarqueeHTML = "";

window.toggleMarquee = function(checked) {
  isMarqueeEnabled = checked;
  localStorage.setItem('wordle_marqueeEnabled', checked);
  updateMarqueeUI(true);
};

function initTrackers() {
  playerLikes = {};
  playerShares = {};
  playerGifts = {};
  playerActivePresence = {};
  const prefix = 'pts_'; // Selalu gunakan prefix global agar Top Liker tidak terreset saat ganti game mode
  const likePrefix = prefix + 'like_';
  const sharePrefix = prefix + 'share_';
  const giftPrefix = prefix + 'gift_';
  const activePrefix = prefix + 'active_';
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key) {
      if (key.startsWith(likePrefix)) {
        const username = key.substring(likePrefix.length);
        const count = parseInt(localStorage.getItem(key)) || 0;
        playerLikes[username] = count;
      } else if (key.startsWith(sharePrefix)) {
        const username = key.substring(sharePrefix.length);
        const count = parseInt(localStorage.getItem(key)) || 0;
        playerShares[username] = count;
      } else if (key.startsWith(giftPrefix)) {
        const username = key.substring(giftPrefix.length);
        const count = parseInt(localStorage.getItem(key)) || 0;
        playerGifts[username] = count;
      } else if (key.startsWith(activePrefix)) {
        const username = key.substring(activePrefix.length);
        const count = parseInt(localStorage.getItem(key)) || 0;
        playerActivePresence[username] = {
          accumulatedTime: count,
          lastEventTime: null,
          lastUpdateTime: null
        };
      }
    }
  }
  updateMarqueeUI(true);
}

function getTop3(trackerObject) {
  return Object.entries(trackerObject)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([username, count]) => ({ username, count }));
}

function getTopActiveViewers() {
  const data = [];
  for (const username in playerActivePresence) {
    const time = playerActivePresence[username].accumulatedTime;
    if (time > 0) {
      data.push({ username, count: time });
    }
  }
  return data
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);
}

function formatActiveTime(seconds) {
  if (seconds < 60) return `${seconds}d`; // detik
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`; // menit
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  if (remainingMinutes === 0) return `${hours}j`; // jam
  return `${hours}j ${remainingMinutes}m`;
}

// In-memory avatar cache to avoid repeated synchronous localStorage disk reads/writes
const avatarMemoryCache = {};

// Debounced batch storage saver to prevent main thread blocking during high-volume live streams
let pendingStorageSaves = {};
let storageSaveTimeout = null;

function queueStorageSave(key, value) {
  pendingStorageSaves[key] = value;
  if (!storageSaveTimeout) {
    storageSaveTimeout = setTimeout(flushStorageSaves, 3000);
  }
}

function flushStorageSaves() {
  storageSaveTimeout = null;
  const entries = Object.entries(pendingStorageSaves);
  pendingStorageSaves = {};
  for (let i = 0; i < entries.length; i++) {
    try {
      localStorage.setItem(entries[i][0], entries[i][1]);
    } catch(e) {}
  }
}
window.addEventListener('beforeunload', flushStorageSaves);

const DEFAULT_HOST_AVATAR = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="hostGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fe2c55"/>
      <stop offset="50%" stop-color="#8b5cf6"/>
      <stop offset="100%" stop-color="#06b6d4"/>
    </linearGradient>
  </defs>
  <circle cx="50" cy="50" r="50" fill="url(#hostGrad)"/>
  <circle cx="50" cy="38" r="18" fill="#ffffff"/>
  <path d="M22 84c0-15.5 12.5-28 28-28s28 12.5 28 28z" fill="#ffffff"/>
  <path d="M30 38c0-11 9-20 20-20s20 9 20 20" fill="none" stroke="#1e1b4b" stroke-width="4.5" stroke-linecap="round"/>
  <rect x="25" y="32" width="8" height="14" rx="4" fill="#1e1b4b"/>
  <rect x="67" y="32" width="8" height="14" rx="4" fill="#1e1b4b"/>
  <path d="M32 44c2 7 8 9 15 9" fill="none" stroke="#1e1b4b" stroke-width="3" stroke-linecap="round"/>
  <circle cx="48" cy="53" r="3.5" fill="#fe2c55"/>
</svg>`.trim());

const DICT_TOP_ICON = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="dictTopGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7"/>
      <stop offset="100%" stop-color="#0369a1"/>
    </linearGradient>
  </defs>
  <circle cx="50" cy="50" r="50" fill="url(#dictTopGrad)"/>
  <rect x="24" y="24" width="52" height="52" rx="8" fill="#ffffff" opacity="0.15"/>
  <path d="M28 32h20a4 4 0 0 1 4 4v34a4 4 0 0 0-4-4H28z" fill="#ffffff"/>
  <path d="M72 32H52a4 4 0 0 0-4 4v34a4 4 0 0 1 4-4h20z" fill="#f1f5f9"/>
  <circle cx="70" cy="28" r="14" fill="#f59e0b" stroke="#0369a1" stroke-width="2"/>
  <text x="70" y="34" font-size="16" font-family="sans-serif" font-weight="900" fill="#ffffff" text-anchor="middle">A</text>
</svg>`.trim());

const DICT_BOTTOM_ICON = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="dictBottomGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#6366f1"/>
      <stop offset="100%" stop-color="#4338ca"/>
    </linearGradient>
  </defs>
  <circle cx="50" cy="50" r="50" fill="url(#dictBottomGrad)"/>
  <rect x="24" y="24" width="52" height="52" rx="8" fill="#ffffff" opacity="0.15"/>
  <path d="M28 32h20a4 4 0 0 1 4 4v34a4 4 0 0 0-4-4H28z" fill="#ffffff"/>
  <path d="M72 32H52a4 4 0 0 0-4 4v34a4 4 0 0 1 4-4h20z" fill="#f1f5f9"/>
  <circle cx="70" cy="72" r="14" fill="#ec4899" stroke="#4338ca" stroke-width="2"/>
  <text x="70" y="78" font-size="16" font-family="sans-serif" font-weight="900" fill="#ffffff" text-anchor="middle">Z</text>
</svg>`.trim());

function getHostAvatar() {
  try {
    const saved = localStorage.getItem('host_avatar_url');
    if (saved && saved.trim()) return saved.trim();
  } catch(e) {}
  return DEFAULT_HOST_AVATAR;
}

function setHostAvatar(url) {
  const clean = (url || '').trim();
  if (clean) {
    localStorage.setItem('host_avatar_url', clean);
  } else {
    localStorage.removeItem('host_avatar_url');
  }
  syncHostAvatarUI();
  if (typeof showToast === 'function') {
    showToast(clean ? 'Foto profil Host berhasil diperbarui!' : 'Avatar Host dikembalikan ke default.', 2000);
  }
}

function syncHostAvatarUI() {
  const current = getHostAvatar();
  const isCustom = !!(localStorage.getItem('host_avatar_url') && localStorage.getItem('host_avatar_url').trim());
  
  const preview = document.getElementById('hostAvatarPreview');
  if (preview) {
    preview.src = current;
    preview.onerror = function() { this.onerror = null; this.src = DEFAULT_HOST_AVATAR; };
  }
  
  const input = document.getElementById('hostAvatarUrlInput');
  if (input && !input.matches(':focus')) {
    input.value = isCustom ? localStorage.getItem('host_avatar_url').trim() : '';
  }

  const loginInput = document.getElementById('loginHostAvatarInput');
  if (loginInput && !loginInput.matches(':focus')) {
    loginInput.value = isCustom ? localStorage.getItem('host_avatar_url').trim() : '';
  }

  const bottomHostAvatar = document.getElementById('bottomHostAvatarImg');
  if (bottomHostAvatar) {
    bottomHostAvatar.src = current;
    bottomHostAvatar.onerror = function() { this.onerror = null; this.src = DEFAULT_HOST_AVATAR; };
  }
}

function saveHostAvatarFromInput() {
  const input = document.getElementById('hostAvatarUrlInput');
  if (input) {
    setHostAvatar(input.value);
  }
}

function resetHostAvatarDefault() {
  setHostAvatar('');
}

function toggleHostAvatarQuickModal(e) {
  if (e) e.stopPropagation();
  const currentUrl = localStorage.getItem('host_avatar_url') || '';
  const newUrl = prompt('Masukkan URL foto profil / avatar external untuk Host:\n(Bisa link Discord, Imgur, TikTok CDN, atau link web apa saja. Kosongkan untuk kembali ke default)', currentUrl);
  if (newUrl !== null) {
    setHostAvatar(newUrl);
  }
}

window.getHostAvatar = getHostAvatar;
window.setHostAvatar = setHostAvatar;
window.syncHostAvatarUI = syncHostAvatarUI;
window.saveHostAvatarFromInput = saveHostAvatarFromInput;
window.resetHostAvatarDefault = resetHostAvatarDefault;
window.toggleHostAvatarQuickModal = toggleHostAvatarQuickModal;

function setUserAvatar(username, url) {
  if (!username || !url) return;
  if (avatarMemoryCache[username] === url) return;
  avatarMemoryCache[username] = url;
  queueStorageSave('pts_avatar_' + username, url);
}

function getUserAvatar(username) {
  if (username === 'Host' || username === 'host_offline' || username === 'host' || username === '@HostOffline') {
    return getHostAvatar();
  }
  if (typeof playerPoints !== 'undefined' && playerPoints[username] && playerPoints[username].avatar) {
    return playerPoints[username].avatar;
  }
  if (avatarMemoryCache[username]) {
    return avatarMemoryCache[username];
  }
  try {
    const saved = localStorage.getItem('pts_avatar_' + username);
    if (saved) {
      avatarMemoryCache[username] = saved;
      return saved;
    }
  } catch(e) {}
  return DEFAULT_HOST_AVATAR;
}

function recordActivity(username, profilePictureUrl = null) {
  if (!username) return;
  const now = Date.now();
  
  if (profilePictureUrl) {
    setUserAvatar(username, profilePictureUrl);
  }

  if (!playerActivePresence[username]) {
    const savedTime = parseInt(localStorage.getItem('pts_active_' + username) || '0');
    playerActivePresence[username] = {
      accumulatedTime: savedTime,
      lastEventTime: now,
      lastUpdateTime: now
    };
  } else {
    const presence = playerActivePresence[username];
    presence.lastEventTime = now;
    if (!presence.lastUpdateTime) {
      presence.lastUpdateTime = now;
    }
  }
}

// Background timer to periodically update active presence
setInterval(() => {
  const now = Date.now();
  let updated = false;
  for (const username in playerActivePresence) {
    const presence = playerActivePresence[username];
    if (presence.lastEventTime && presence.lastUpdateTime) {
      const timeSinceLastEvent = now - presence.lastEventTime;
      const timeSinceLastUpdate = now - presence.lastUpdateTime;
      
      if (timeSinceLastEvent <= 300000) { // 5 minutes active window
        const elapsedSec = Math.round(timeSinceLastUpdate / 1000);
        if (elapsedSec > 0) {
          presence.accumulatedTime += elapsedSec;
          presence.lastUpdateTime = now;
          queueStorageSave('pts_active_' + username, presence.accumulatedTime);
          updated = true;
        }
      } else {
        presence.lastUpdateTime = now;
      }
    }
  }
}, 10000);

let spotlightIndex = 0;
let spotlightTimer = null;
let currentSpotlightSlides = [];

function formatShortNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1).replace(/\.0$/, '').replace('.', ',') + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1).replace(/\.0$/, '').replace('.', ',') + 'K';
  return num;
}

let marqueeUpdateTimer = null;
let lastMarqueeHTML = "";

function buildSupporterMarqueeTrackHTML() {
  const topGifters = getTop3(playerGifts);
  const topLikers = getTop3(playerLikes);
  const topSharers = getTop3(playerShares);
  const topActiveViewers = getTopActiveViewers();

  const categoryGroups = [];

  function createCategoryCluster(catClass, iconClass, catTitle, userList, valFormatter) {
    if (!userList || userList.length === 0) return null;

    const usersHTML = userList.map((u, i) => {
      const rank = i + 1;
      const nameClean = escapeHTML(u.username || 'user');
      const shortName = nameClean.length > 9 ? nameClean.substring(0, 8) + '…' : nameClean;
      const rankBadgeHTML = rank === 1 ? '<i class="fa-solid fa-crown"></i>' : rank;
      const valText = valFormatter(u.count);

      return `
        <div class="marquee-user-item rank-${rank}" title="@${nameClean} • ${valText}">
          <div class="marquee-avatar-wrap">
            <img src="${getUserAvatar(u.username)}" class="marquee-avatar" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="${nameClean}">
            <span class="marquee-rank-badge rank-${rank}">${rankBadgeHTML}</span>
          </div>
          <div class="marquee-user-text">
            <span class="marquee-user-name">${shortName}</span>
            <span class="marquee-user-val">${valText}</span>
          </div>
        </div>
      `;
    }).join('<span class="marquee-user-sep">•</span>');

    return `
      <div class="marquee-category-group ${catClass}">
        <div class="marquee-group-label">
          <i class="${iconClass} group-icon"></i>
          <span class="group-title">${catTitle}</span>
        </div>
        <div class="marquee-group-users">
          ${usersHTML}
        </div>
      </div>
    `;
  }

  // 1. Top Gifters
  const gifterGroup = createCategoryCluster('cat-gift', 'fa-solid fa-gift', 'TOP GIFTER', topGifters, count => `${formatShortNumber(count)} Koin`);
  if (gifterGroup) categoryGroups.push(gifterGroup);

  // 2. Top Likers
  const likerGroup = createCategoryCluster('cat-like', 'fa-solid fa-heart', 'TOP LIKER', topLikers, count => `${formatShortNumber(count)} Likes`);
  if (likerGroup) categoryGroups.push(likerGroup);

  // 3. Top Sharers
  const shareGroup = createCategoryCluster('cat-share', 'fa-solid fa-share-nodes', 'TOP SHARE', topSharers, count => `${formatShortNumber(count)} Share`);
  if (shareGroup) categoryGroups.push(shareGroup);

  // 4. Top Active Viewers
  const activeGroup = createCategoryCluster('cat-active', 'fa-solid fa-clock', 'PALING AKTIF', topActiveViewers, count => formatActiveTime(count));
  if (activeGroup) categoryGroups.push(activeGroup);

  // Fallback if no supporters yet
  if (categoryGroups.length === 0) {
    const welcome1 = `
      <div class="marquee-category-group cat-gift">
        <div class="marquee-group-label">
          <i class="fa-solid fa-gift group-icon"></i>
          <span class="group-title">TOP SUPPORTER</span>
        </div>
        <span class="marquee-welcome-text">Kirim Gift, Like, atau Share untuk tampil di sini</span>
      </div>
    `;
    const welcome2 = `
      <div class="marquee-category-group cat-share">
        <div class="marquee-group-label">
          <i class="fa-solid fa-comment-dots group-icon"></i>
          <span class="group-title">CARA MAIN</span>
        </div>
        <span class="marquee-welcome-text">Ketik tebakan kata di live chat untuk ikut bermain</span>
      </div>
    `;
    const sep = `<span class="marquee-cat-divider"><i class="fa-solid fa-star"></i></span>`;
    const base = welcome1 + sep + welcome2 + sep;
    return base + base + base;
  }

  const catDivider = `<span class="marquee-cat-divider"><i class="fa-solid fa-star"></i></span>`;
  const singleTrack = categoryGroups.join(catDivider) + catDivider;

  let result = singleTrack + singleTrack;
  if (categoryGroups.length < 3) {
    result += singleTrack + singleTrack;
  }
  return result;
}

function updateMarqueeUI(forceImmediate = false) {
  const marqueeContainer = document.getElementById('marqueeContainer');
  const contentEl = document.getElementById('marqueeContent');
  if (!marqueeContainer || !contentEl) return;

  if (!isMarqueeEnabled) {
    marqueeContainer.style.display = 'none';
    if (marqueeUpdateTimer) {
      clearInterval(marqueeUpdateTimer);
      marqueeUpdateTimer = null;
    }
    return;
  }

  marqueeContainer.style.display = 'flex';
  const newHTML = buildSupporterMarqueeTrackHTML();

  if (forceImmediate || newHTML !== lastMarqueeHTML) {
    lastMarqueeHTML = newHTML;
    contentEl.innerHTML = newHTML;
  }

  if (!marqueeUpdateTimer) {
    // Refresh track data smoothly every 8 seconds if supporters change
    marqueeUpdateTimer = setInterval(() => {
      if (isMarqueeEnabled) updateMarqueeUI();
    }, 8000);
  }
}

window.updateLikeThreshold = function(val) {
  let num = parseInt(val);
  if (isNaN(num) || num < 10) num = 1000;
  likeRestartThreshold = num;
  localStorage.setItem('wordle_likeThreshold', num);
  updateLikeProgressBar();
};

function updateLikeProgressBar() {
  const container = document.getElementById('likeProgressContainer');
  const fill = document.getElementById('likeProgressBarFill');
  const text = document.getElementById('likeProgressText');
  
  const mContainer = document.getElementById('multiLikeProgressContainer');
  const mFill = document.getElementById('multiLikeProgressBarFill');
  const mText = document.getElementById('multiLikeProgressText');

  if (!isLikeRestartEnabled) {
    if (container) container.style.display = 'none';
    if (mContainer) mContainer.style.display = 'none';
    return;
  }
  
  const percentage = Math.min(100, (currentLikes / likeRestartThreshold) * 100);
  const textVal = `${currentLikes} / ${likeRestartThreshold}`;

  if (container && fill && text) {
    container.style.display = 'block';
    fill.style.width = `${percentage}%`;
    text.textContent = textVal;
  }

  if (mContainer && mFill && mText) {
    mContainer.style.display = 'block';
    mFill.style.width = `${percentage}%`;
    mText.textContent = textVal;
  }
}

// ═══════════════════════════════════════
//         HEART FLURRY ANIMATION
// ═══════════════════════════════════════
let lastHeartFlurryTime = 0;
const HEART_EMOJIS = ['❤️', '💖', '💗', '💕', '💓', '💘', '💝', '🩷', '🤍', '💜'];
const MAX_HEARTS_ON_SCREEN = 12;

function spawnHeartFlurry(count) {
  if (!isHeartFlurryEnabled || isLowPowerMode) return;
  const now = performance.now();
  if (now - lastHeartFlurryTime < 180) return; // Throttle flurry spawn
  lastHeartFlurryTime = now;

  const container = document.getElementById('heartFlurryContainer');
  if (!container) return;

  const spawnCount = Math.min(count, 3);
  for (let i = 0; i < spawnCount; i++) {
    // Performance cap: if already full, don't spawn new ones to save CPU
    if (container.children.length >= MAX_HEARTS_ON_SCREEN) {
      break;
    }

    const heart = document.createElement('span');
    heart.className = 'heart-particle';
    heart.textContent = HEART_EMOJIS[Math.floor(Math.random() * HEART_EMOJIS.length)];

    // Randomize position and physics
    const xPos = Math.random() * 60;
    const duration = 1.8 + Math.random() * 1.2;
    const delay = i * 0.06;
    const size = 18 + Math.random() * 14;

    heart.style.left = `${xPos}px`;
    heart.style.fontSize = `${size}px`;
    heart.style.setProperty('--duration', `${duration}s`);
    heart.style.setProperty('--delay', `${delay}s`);
    heart.style.setProperty('--drift1', `${(Math.random() - 0.5) * 24}px`);
    heart.style.setProperty('--drift2', `${(Math.random() - 0.5) * 30}px`);
    heart.style.setProperty('--drift3', `${(Math.random() - 0.5) * 24}px`);
    heart.style.setProperty('--drift4', `${(Math.random() - 0.5) * 16}px`);
    heart.style.setProperty('--rot1', `${(Math.random() - 0.5) * 25}deg`);
    heart.style.setProperty('--rot2', `${(Math.random() - 0.5) * 30}deg`);
    heart.style.setProperty('--rot3', `${(Math.random() - 0.5) * 25}deg`);
    heart.style.setProperty('--rot4', `${(Math.random() - 0.5) * 35}deg`);

    container.appendChild(heart);

    // Remove after animation completes
    setTimeout(() => {
      if (heart.parentNode) heart.parentNode.removeChild(heart);
    }, (duration + delay) * 1000 + 100);
  }
}

// Like counter widget state
let totalSessionLikes = 0;
let _likeCounterHideTimer = null;

function updateLikeCounter(data, addedLikes) {
  totalSessionLikes += addedLikes;
  
  const widget = document.getElementById('likeCounterWidget');
  const avatarEl = document.getElementById('likeCounterAvatar');
  const totalEl = document.getElementById('likeCounterTotal');
  const nameEl = document.getElementById('likeCounterName');
  if (!widget) return;

  // Show widget
  widget.style.display = 'flex';

  // Per-user like count (menampilkan total likes kontribusi penonton tersebut)
  const username = data.nickname || data.uniqueId || '';
  const userTotalLikes = (username && playerLikes[username]) ? playerLikes[username] : addedLikes;
  const formattedTotal = typeof formatShortNumber === 'function' ? formatShortNumber(userTotalLikes) : userTotalLikes;
  const batchText = (addedLikes > 1 && userTotalLikes > addedLikes) ? ` <span class="like-counter-batch">(+${addedLikes})</span>` : '';
  
  // Format tampilan dengan ikon Font Awesome (sesuai panduan AGENTS.md)
  totalEl.innerHTML = `<i class="fa-solid fa-heart" style="color: #fe2c55;"></i> ${formattedTotal}${batchText}`;

  // Update last liker info
  const nickname = data.nickname || data.uniqueId || 'Penonton';
  const avatar = data.profilePictureUrl || '';
  if (nickname) nameEl.textContent = nickname;
  if (avatar && avatarEl) {
    avatarEl.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
    avatarEl.src = avatar;
    avatarEl.style.display = 'block';
  } else {
    if (avatarEl) avatarEl.style.display = 'none';
  }

  // Pop animation
  widget.classList.remove('pop');
  void widget.offsetWidth; // Force reflow
  widget.classList.add('pop');

  // Auto-hide after 5s of no likes
  if (_likeCounterHideTimer) clearTimeout(_likeCounterHideTimer);
  _likeCounterHideTimer = setTimeout(() => {
    widget.style.display = 'none';
  }, 5000);
}

let isWaitingForLikes = false;
let _winRevealPending = false;
let _winRevealToken = 0;

window.executeRestartTransition = function() {
  if (!isWaitingForLikes) return; // Prevent double trigger
  isWaitingForLikes = false;
  _winRevealToken++; // Batalkan reveal overlay yang masih tertunda
  _winRevealPending = false;
  
  const winOverlay = document.getElementById('winOverlay');
  if (winOverlay) winOverlay.classList.remove('show');
  
  const multiWinOverlay = document.getElementById('multiWinOverlay');
  if (multiWinOverlay) multiWinOverlay.classList.remove('show');
  if (typeof stopMultiWinAutoScroll === 'function') stopMultiWinAutoScroll();
  
  // Periksa apakah kondisi turnamen juara sesi / rotasi tercapai
  if (typeof checkTourneyConditionMet === 'function' && checkTourneyConditionMet()) {
    triggerTourneyPodiumFinale();
    return;
  }
  
  const board = document.getElementById('board');
  if (board) board.classList.add('board-transitioning');
  
  setTimeout(() => {
    const winAvatar = document.getElementById('winAvatar');
    if (winAvatar) {
      winAvatar.src = 'assets/bg_nature.png';
    }
    const winTitle = document.getElementById('winTitleText');
    if (winTitle) winTitle.textContent = 'WE HAVE A WINNER!';
    const winSubtitle = document.getElementById('winSubtitleText');
    if (winSubtitle) winSubtitle.textContent = 'Guessed the word:';
    if (currentGameMode === 'wordcluster') {
      isGameOver = false;
      wordClusterRound++;
      startWordClusterGame();
    } else {
      round++;
      startNewRound();
    }
    requestAnimationFrame(() => {
      if (board) board.classList.remove('board-transitioning');
    });
  }, 600);
};

function triggerWinTransition(winDuration, isMultiWinner = false) {
  const overlayId = isMultiWinner ? 'multiWinOverlay' : 'winOverlay';
  const footerId = isMultiWinner ? 'multiWinFooter' : 'winFooter';
  const progressId = isMultiWinner ? 'multiLikeProgressContainer' : 'likeProgressContainer';

  const activeOverlay = document.getElementById(overlayId);
  const activeFooter = document.getElementById(footerId);
  const activeProgress = document.getElementById(progressId);
  
  if (isMultiWinner) {
    const multiWinTitle = document.getElementById('multiWinTitle');
    if (multiWinTitle) {
      if (currentGameMode === 'squareword') {
        multiWinTitle.textContent = '🎉 KOTAK KATA 5×5 SELESAI!';
      } else if (currentGameMode === 'wordgrid') {
        multiWinTitle.textContent = 'LEADERBOARD WORD GRID';
      } else if (currentGameMode === 'wordcluster') {
        multiWinTitle.textContent = `TOPIK SELESAI: ${wordClusterCurrentTopic || 'WORD CLUSTER'}`;
      } else {
        multiWinTitle.textContent = 'ROUND COMPLETED!';
      }
    }
  }

  // Guard: cegah trigger ganda (chat flood) yang mengulang animasi, suara & confetti -> kedip
  if (_winRevealPending || (activeOverlay && activeOverlay.classList.contains('show'))) return;
  _winRevealPending = true;
  const revealToken = _winRevealToken;

  const revealOverlay = () => {
    // Tampilkan di frame berikutnya agar perubahan teks/avatar sudah ter-layout dulu
    requestAnimationFrame(() => {
      if (revealToken !== _winRevealToken) return; // sudah di-skip host
      _winRevealPending = false;
      if (activeOverlay) activeOverlay.classList.add('show');
      if (isMultiWinner) {
        startMultiWinAutoScroll();
      }
      if (window.sounds) window.sounds.playWin();
      if (window.playHostAudio) playHostAudio('win');
      
      // Burst confetti setelah kartu mulai muncul, bukan di frame yang sama
      if (typeof triggerConfetti === 'function') {
        setTimeout(triggerConfetti, 180);
      }
    });
  };

  // Tunggu avatar pemenang selesai di-download & di-decode (maks 350ms)
  // agar foto tidak "pop-in" / berkedip di tengah animasi kartu.
  const winAvatarEl = !isMultiWinner ? document.getElementById('winAvatar') : null;
  if (winAvatarEl && typeof winAvatarEl.decode === 'function' && !winAvatarEl.complete) {
    let revealed = false;
    const once = () => { if (!revealed) { revealed = true; revealOverlay(); } };
    winAvatarEl.decode().then(once, once);
    setTimeout(once, 350);
  } else {
    revealOverlay();
  }
  
  if (isLikeRestartEnabled) {
    isWaitingForLikes = true;
    currentLikes = 0;
    if (activeFooter) activeFooter.style.display = 'none';
    if (activeProgress) activeProgress.style.display = 'block';
    updateLikeProgressBar();
  } else {
    isWaitingForLikes = false;
    if (activeFooter) activeFooter.style.display = 'block';
    if (activeProgress) activeProgress.style.display = 'none';
    
    // Automatically restart after the defined duration if no likes required
    setTimeout(() => {
      // Set to true temporarily so executeRestartTransition works
      isWaitingForLikes = true;
      executeRestartTransition();
    }, winDuration);
  }
}
window.triggerWinTransition = triggerWinTransition;

// ═══════════════════════════════════════════════════════════════════
// MULTI-WINNER OVERLAY AUTO-SCROLL SYSTEM (BROADCAST QUALITY)
// ═══════════════════════════════════════════════════════════════════
let multiWinScrollRAF = null;
let multiWinScrollTimer = null;
let multiWinIsHovered = false;

function stopMultiWinAutoScroll() {
  if (multiWinScrollRAF) {
    cancelAnimationFrame(multiWinScrollRAF);
    multiWinScrollRAF = null;
  }
  if (multiWinScrollTimer) {
    clearTimeout(multiWinScrollTimer);
    multiWinScrollTimer = null;
  }
  const list = document.getElementById('multiWinList');
  if (list) {
    list.classList.remove('has-overflow');
  }
}

function startMultiWinAutoScroll() {
  stopMultiWinAutoScroll();
  const list = document.getElementById('multiWinList');
  if (!list) return;

  list.scrollTop = 0;

  // Pasang listener hover agar jika host mengarahkan mouse, scrolling berhenti sementara
  if (!list._hasAutoScrollListeners) {
    list._hasAutoScrollListeners = true;
    list.addEventListener('mouseenter', () => { multiWinIsHovered = true; });
    list.addEventListener('mouseleave', () => { multiWinIsHovered = false; });
  }

  // Jeda 1.5 detik agar penonton sempat membaca Juara 1 (MVP) dan animasi kartu selesai
  multiWinScrollTimer = setTimeout(() => {
    const scrollMax = list.scrollHeight - list.clientHeight;
    // Jika daftar pendek dan muat di dalam kartu (tidak meluap), tidak perlu auto-scroll
    if (scrollMax <= 10) {
      list.classList.remove('has-overflow');
      return;
    }

    list.classList.add('has-overflow');

    const SCROLL_SPEED = 28; // Pixel per detik (kecepatan stabil, nyaman dibaca di video stream HP)
    let lastTime = null;
    let direction = 1; // 1 = scroll ke bawah, -1 = scroll ke atas (ping-pong smooth)
    let isPaused = false;

    function step(timestamp) {
      const overlay = document.getElementById('multiWinOverlay');
      if (!overlay || !overlay.classList.contains('show')) {
        stopMultiWinAutoScroll();
        return;
      }

      if (!lastTime) lastTime = timestamp;
      const deltaTime = (timestamp - lastTime) / 1000;
      lastTime = timestamp;

      if (!isPaused && !multiWinIsHovered) {
        if (direction === 1) {
          list.scrollTop += SCROLL_SPEED * deltaTime;
          if (list.scrollTop >= scrollMax - 2) {
            list.scrollTop = scrollMax;
            isPaused = true;
            // Jeda 2.2 detik di posisi paling bawah agar nama penutup terbaca jelas
            multiWinScrollTimer = setTimeout(() => {
              direction = -1;
              isPaused = false;
              lastTime = null;
              multiWinScrollRAF = requestAnimationFrame(step);
            }, 2200);
            return;
          }
        } else {
          // Scroll kembali ke atas dengan kecepatan 1.5x lebih cepat agar dinamis
          list.scrollTop -= (SCROLL_SPEED * 1.5) * deltaTime;
          if (list.scrollTop <= 2) {
            list.scrollTop = 0;
            isPaused = true;
            // Jeda 2.0 detik di posisi paling atas sebelum siklus bergulir lagi
            multiWinScrollTimer = setTimeout(() => {
              direction = 1;
              isPaused = false;
              lastTime = null;
              multiWinScrollRAF = requestAnimationFrame(step);
            }, 2000);
            return;
          }
        }
      }

      multiWinScrollRAF = requestAnimationFrame(step);
    }

    multiWinScrollRAF = requestAnimationFrame(step);
  }, 1500);
}

window.startMultiWinAutoScroll = startMultiWinAutoScroll;
window.stopMultiWinAutoScroll = stopMultiWinAutoScroll;

let TARGET_WORDS = [];
let VALID_WORDS = [];
let availableWords = [];
let discoveredLetters = [];
let bestGuess = null;
let word500History = []; // { word, c, p, a, score, userData }
let word500PendingInvalidRow = null; // baris invalid yang sedang tampil di board (Word500/600)
let fillBlanksTargets = [];
let wordTangoTargets = []; // { word, length, missingIndices, solved, solver, points }
let wordTangoPool = []; // { id, char, used }
function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

let ytPlayer = null;
let musicQueue = [];
let activeMusic = null;
let isMusicPlaying = false;
let musicSettings = { maxGlobal: 20, maxUser: 2, maxDuration: 6, cooldownSeconds: 60, bannedKeywords: [], volume: 50, requestsEnabled: true, followerOnly: false, playerStyle: 'vinyl', randomGenre: 'milenial', playlistVisibleRows: 4, playlistScale: 100, playlistAutoScroll: true, playlistAccent: 'red' };
try {
  const saved = localStorage.getItem('music_settings');
  if (saved) {
    musicSettings = JSON.parse(saved);
    if (musicSettings.volume === undefined) musicSettings.volume = 50;
    if (musicSettings.requestsEnabled === undefined) musicSettings.requestsEnabled = true;
    if (musicSettings.followerOnly === undefined) musicSettings.followerOnly = false;
    if (musicSettings.cooldownSeconds === undefined) musicSettings.cooldownSeconds = 60;
    if (!musicSettings.playerStyle) musicSettings.playerStyle = 'vinyl';
    if (!musicSettings.randomGenre) musicSettings.randomGenre = 'milenial';
    if (musicSettings.playlistVisibleRows === undefined) musicSettings.playlistVisibleRows = 4;
    if (musicSettings.playlistScale === undefined) musicSettings.playlistScale = 100;
    if (musicSettings.playlistAutoScroll === undefined) musicSettings.playlistAutoScroll = true;
    if (!musicSettings.playlistAccent) musicSettings.playlistAccent = 'red';
  }
} catch(e) {}
let musicSongOffsets = {};
try {
  const savedSongOffsets = localStorage.getItem('music_song_offsets');
  if (savedSongOffsets) {
    musicSongOffsets = JSON.parse(savedSongOffsets);
  }
} catch(e) {}
let currentLyricsData = []; // [{ time: number, text: string }]
let currentLyricsIndex = -1;
let isLyricsLoading = false;
let previousMusicPlayerStyle = 'vinyl';
let musicUserCooldowns = {};
let lastUsername = "";
let lastLang = localStorage.getItem('wordle_lang') || "id";
let lastSessionId = "";
let reconnectTimer = null;
let isConnectedToTikTok = false;
let hasPlayedCloseAudio = false;
let isPlayEveryGiftSound = localStorage.getItem('wordle_playEveryGiftSound') === 'true';

window.togglePlayEveryGiftSound = function(val) {
  isPlayEveryGiftSound = val;
  localStorage.setItem('wordle_playEveryGiftSound', val);
};

// Leaderboard State
let playerPoints = {};
let currentLbTab = 'session';

// Daftar prefix khusus untuk seluruh mode game agar penyimpanan skor terisolasi 100%
const ALL_SPECIAL_PTS_PREFIXES = [
  'pts_w500_',
  'pts_w600_',
  'pts_wfit_',
  'pts_colorfit_',
  'pts_wloop_',
  'pts_fill_',
  'pts_tango_',
  'pts_wgrid_',
  'pts_sqword_',
  'pts_wladder_',
  'pts_betweenle_',
  'pts_cascadle_',
  'pts_wanderwords_',
  'pts_wordcluster_',
  'pts_wmatch_',
  'pts_wpyramid_'
];

function isOtherGameModeKey(key) {
  return ALL_SPECIAL_PTS_PREFIXES.some(specialPrefix => key.startsWith(specialPrefix));
}

function getPtsPrefix() {
  if (currentGameMode === 'word500') return 'pts_w500_';
  if (currentGameMode === 'wordfit') return 'pts_wfit_';
  if (currentGameMode === 'colorfit') return 'pts_colorfit_';
  if (currentGameMode === 'fillblanks') return 'pts_fill_';
  if (currentGameMode === 'wordtango') return 'pts_tango_';
  if (currentGameMode === 'wordgrid') return 'pts_wgrid_';
  if (currentGameMode === 'squareword') return 'pts_sqword_';
  if (currentGameMode === 'wordladder') return 'pts_wladder_';
  if (currentGameMode === 'betweenle') return 'pts_betweenle_';
  if (currentGameMode === 'cascadle') return 'pts_cascadle_';
  if (currentGameMode === 'wanderwords') return 'pts_wanderwords_';
  if (currentGameMode === 'wordcluster') return 'pts_wordcluster_';
  if (currentGameMode === 'wordmatch') return 'pts_wmatch_';
  if (currentGameMode === 'wordpyramid') return 'pts_wpyramid_';
  return 'pts_';
}

// Memuat data harian & mingguan ke memori saat halaman dimuat
function initWeeklyLeaderboard() {
  playerPoints = {};
  const prefix = getPtsPrefix();
  const dailyPrefix = prefix + 'daily_';
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith(prefix)) {
      if (prefix === 'pts_' && isOtherGameModeKey(key)) continue;
      
      if (key.startsWith(prefix + 'like_') || 
          key.startsWith(prefix + 'share_') || 
          key.startsWith(prefix + 'gift_') || 
          key.startsWith(prefix + 'active_') || 
          key.startsWith(prefix + 'avatar_')) continue;
      
      if (key.startsWith(dailyPrefix)) {
        const username = key.substring(dailyPrefix.length);
        const pts = parseInt(localStorage.getItem(key)) || 0;
        if (!playerPoints[username]) {
          const savedAvatar = localStorage.getItem('pts_avatar_' + username) || 'assets/bg_nature.png';
          playerPoints[username] = {
            avatar: savedAvatar,
            sessionPts: pts,
            weeklyPts: 0
          };
        } else {
          playerPoints[username].sessionPts = pts;
        }
      } else {
        const username = key.substring(prefix.length);
        const pts = parseInt(localStorage.getItem(key)) || 0;
        if (!playerPoints[username]) {
          const savedAvatar = localStorage.getItem('pts_avatar_' + username) || 'assets/bg_nature.png';
          playerPoints[username] = {
            avatar: savedAvatar,
            sessionPts: 0,
            weeklyPts: pts
          };
        } else {
          playerPoints[username].weeklyPts = pts;
        }
      }
    }
  }
  renderLeaderboard();
  initTrackers();
}
initWeeklyLeaderboard();

function getWeeklyPts(username) {
  return parseInt(localStorage.getItem(getPtsPrefix() + username) || '0');
}
function saveWeeklyPts(username, pts) {
  localStorage.setItem(getPtsPrefix() + username, pts);
}

function getDailyPts(username) {
  return parseInt(localStorage.getItem(getPtsPrefix() + 'daily_' + username) || '0');
}
function saveDailyPts(username, pts) {
  localStorage.setItem(getPtsPrefix() + 'daily_' + username, pts);
}

// ═════════════════════════════════════════════════════════════════════════════
// 🏆 TOURNAMENT & AUTO-ROTATION ENGINE (GRAND FINALE PODIUM)
// ═════════════════════════════════════════════════════════════════════════════

const ALL_ROTATION_MODES = [
  'wordle', 'word500', 'wordfit', 'colorfit',
  'fillblanks', 'wordtango', 'wordgrid', 'squareword',
  'wordladder', 'betweenle', 'cascadle', 'wanderwords', 'wordcluster', 'wordmatch', 'wordpyramid'
];

const FAST_PACED_MODES = [
  'wordle', 'word500', 'squareword', 'betweenle', 'wordladder', 'fillblanks', 'wordpyramid'
];

const GAME_MODE_PRETTY_NAMES = {
  wordle: 'Wordle',
  word500: 'Word500',
  wordfit: 'Word Fit',
  colorfit: 'Color Fit',
  fillblanks: 'Word Fill',
  wordtango: 'Word Tango',
  wordgrid: 'Word Grid',
  squareword: 'Kotak Kata',
  wordladder: 'Word Ladder',
  betweenle: 'Betweenle',
  cascadle: 'Cascadle',
  wanderwords: 'Wander Words',
  wordcluster: 'Word Cluster',
  wordmatch: 'Word Match',
  wordpyramid: 'Word Pyramid'
};

let tourneySettings = {
  enabled: false,
  triggerType: 'score',     // 'score' or 'rounds'
  targetScore: 50,
  targetRounds: 5,
  podiumDuration: 8,
  allowedModes: [...ALL_ROTATION_MODES]
};

try {
  const savedTourney = localStorage.getItem('wordle_tourney_settings');
  if (savedTourney) {
    const parsed = JSON.parse(savedTourney);
    tourneySettings = { ...tourneySettings, ...parsed };
  }
} catch(e) {}

// Pastikan mode lama (seperti wordloop / word600) dibersihkan dari cache browser
if (Array.isArray(tourneySettings.allowedModes)) {
  tourneySettings.allowedModes = tourneySettings.allowedModes.filter(m => ALL_ROTATION_MODES.includes(m));
  if (tourneySettings.allowedModes.length === 0) {
    tourneySettings.allowedModes = [...ALL_ROTATION_MODES];
  }
} else {
  tourneySettings.allowedModes = [...ALL_ROTATION_MODES];
}

let tourneySessionScores = {}; // { [username]: { nickname, avatar, pts } }
let tourneySessionRounds = 0;
let isTourneyPodiumActive = false;
let tourneyCountdownTimer = null;
let tourneyPendingNextMode = null;

function saveTourneySettings() {
  try {
    localStorage.setItem('wordle_tourney_settings', JSON.stringify(tourneySettings));
  } catch(e) {}
  updateTourneyUIElements();
}

function updateTourneyUIElements() {
  const toggle = document.getElementById('tourneyAutoRotateToggle');
  const optionsContainer = document.getElementById('tourneyOptionsContainer');
  const triggerSelect = document.getElementById('tourneyTriggerTypeSelect');
  const scoreInput = document.getElementById('tourneyTargetScoreInput') || document.getElementById('tourneyTargetScoreSelect');
  const roundsInput = document.getElementById('tourneyTargetRoundsInput') || document.getElementById('tourneyTargetRoundsSelect');
  const durationInput = document.getElementById('tourneyPodiumDurationInput') || document.getElementById('tourneyPodiumDurationSelect');
  const scoreGroup = document.getElementById('tourneyScoreGroup');
  const roundsGroup = document.getElementById('tourneyRoundsGroup');
  const badge = document.getElementById('tourneyBadge');
  const badgeText = document.getElementById('tourneyBadgeText');

  if (toggle) toggle.checked = !!tourneySettings.enabled;
  if (optionsContainer) optionsContainer.style.display = tourneySettings.enabled ? 'block' : 'none';
  if (triggerSelect) triggerSelect.value = tourneySettings.triggerType || 'score';
  if (scoreInput) scoreInput.value = String(tourneySettings.targetScore || 50);
  if (roundsInput) roundsInput.value = String(tourneySettings.targetRounds || 5);
  if (durationInput) durationInput.value = String(tourneySettings.podiumDuration || 8);

  if (scoreGroup) scoreGroup.style.display = (tourneySettings.triggerType === 'rounds') ? 'none' : 'block';
  if (roundsGroup) roundsGroup.style.display = (tourneySettings.triggerType === 'rounds') ? 'block' : 'none';

  if (badge) {
    if (tourneySettings.enabled) {
      badge.style.display = 'inline-flex';
      if (badgeText) {
        if (tourneySettings.triggerType === 'rounds') {
          badgeText.textContent = `Ronde ${tourneySessionRounds}/${tourneySettings.targetRounds}`;
        } else {
          let topPts = 0;
          for (const u in tourneySessionScores) {
            if (tourneySessionScores[u].pts > topPts) topPts = tourneySessionScores[u].pts;
          }
          badgeText.textContent = `Target: ${tourneySettings.targetScore} Poin (Top: ${topPts})`;
        }
      }
    } else {
      badge.style.display = 'none';
    }
  }

  if (typeof renderTourneyModesChecklist === 'function') {
    renderTourneyModesChecklist();
  }
}

window.toggleTourneyAutoRotate = function(checked) {
  tourneySettings.enabled = !!checked;
  saveTourneySettings();
  if (typeof showToast === 'function') {
    showToast(tourneySettings.enabled ? '🏆 Mode Turnamen & Rotasi Game Aktif!' : '⏹️ Mode Turnamen Dinonaktifkan (Manual)', 2500);
  }
};

window.changeTourneyTriggerType = function(val) {
  tourneySettings.triggerType = (val === 'rounds') ? 'rounds' : 'score';
  saveTourneySettings();
};

window.changeTourneyTargetScore = function(val) {
  let num = parseInt(val, 10);
  if (isNaN(num) || num < 5) num = 5;
  tourneySettings.targetScore = num;
  saveTourneySettings();
};

window.changeTourneyTargetRounds = function(val) {
  let num = parseInt(val, 10);
  if (isNaN(num) || num < 1) num = 1;
  tourneySettings.targetRounds = num;
  saveTourneySettings();
};

window.changeTourneyPodiumDuration = function(val) {
  let num = parseInt(val, 10);
  if (isNaN(num) || num < 3) num = 3;
  tourneySettings.podiumDuration = num;
  saveTourneySettings();
};

window.setTourneyScorePreset = function(score, e) {
  if (e) e.stopPropagation();
  const input = document.getElementById('tourneyTargetScoreInput');
  if (input) input.value = score;
  changeTourneyTargetScore(score);
};

window.setTourneyRoundsPreset = function(rounds, e) {
  if (e) e.stopPropagation();
  const input = document.getElementById('tourneyTargetRoundsInput');
  if (input) input.value = rounds;
  changeTourneyTargetRounds(rounds);
};

window.setTourneyDurationPreset = function(sec, e) {
  if (e) e.stopPropagation();
  const input = document.getElementById('tourneyPodiumDurationInput');
  if (input) input.value = sec;
  changeTourneyPodiumDuration(sec);
};

window.renderTourneyModesChecklist = function() {
  const container = document.getElementById('tourneyModesChecklistGrid');
  const countBadge = document.getElementById('tourneyActiveModesCount');
  if (!container) return;

  const allowed = (Array.isArray(tourneySettings.allowedModes) && tourneySettings.allowedModes.length > 0)
    ? tourneySettings.allowedModes
    : ALL_ROTATION_MODES;

  if (countBadge) {
    countBadge.textContent = `${allowed.length} / ${ALL_ROTATION_MODES.length} Aktif`;
  }

  container.innerHTML = ALL_ROTATION_MODES.map(mode => {
    const isChecked = allowed.includes(mode);
    const prettyName = GAME_MODE_PRETTY_NAMES[mode] || mode.toUpperCase();
    const isFastPaced = (typeof FAST_PACED_MODES !== 'undefined' ? FAST_PACED_MODES : []).includes(mode);
    return `
      <label class="tourney-mode-item" style="display: flex; align-items: center; gap: 5px; padding: 4px 6px; background: ${isChecked ? 'rgba(56, 189, 248, 0.08)' : 'rgba(0,0,0,0.3)'}; border: 1px solid ${isChecked ? 'rgba(56, 189, 248, 0.35)' : 'rgba(255,255,255,0.08)'}; border-radius: 4px; font-size: 11px; cursor: pointer; user-select: none;">
        <input type="checkbox" ${isChecked ? 'checked' : ''} onchange="toggleTourneyAllowedMode('${mode}', this.checked)" style="accent-color: #38bdf8; cursor: pointer; margin: 0; width: 13px; height: 13px;">
        <span style="color: ${isChecked ? '#f8fafc' : '#94a3b8'}; font-weight: ${isChecked ? '600' : '400'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; gap: 3px; font-size: 10.5px;">
          ${escapeHTML(prettyName)}
          ${isFastPaced ? '<i class="fa-solid fa-bolt" style="font-size: 8.5px; color: #38bdf8;" title="Rekomendasi Mode Cepat"></i>' : ''}
        </span>
      </label>
    `;
  }).join('');
};

window.toggleTourneyAllowedMode = function(mode, isChecked) {
  if (!Array.isArray(tourneySettings.allowedModes)) {
    tourneySettings.allowedModes = [...ALL_ROTATION_MODES];
  }
  if (isChecked) {
    if (!tourneySettings.allowedModes.includes(mode)) {
      tourneySettings.allowedModes.push(mode);
    }
  } else {
    if (tourneySettings.allowedModes.length <= 1) {
      if (typeof showToast === 'function') {
        showToast('⚠️ Minimal 1 game harus aktif dalam turnamen!', 2000);
      }
      renderTourneyModesChecklist();
      return;
    }
    tourneySettings.allowedModes = tourneySettings.allowedModes.filter(m => m !== mode);
  }
  saveTourneySettings();
  renderTourneyModesChecklist();
};

window.setTourneyModePreset = function(preset, e) {
  if (e) e.stopPropagation();
  if (preset === 'fast') {
    tourneySettings.allowedModes = [...FAST_PACED_MODES];
    if (typeof showToast === 'function') {
      showToast('⚡ Mode Cepat Aktif: 7 Game Terbaik Dipilih', 2200);
    }
  } else {
    tourneySettings.allowedModes = [...ALL_ROTATION_MODES];
    if (typeof showToast === 'function') {
      showToast('🌟 Semua Game Aktif: 15 Game Masuk Rotasi', 2200);
    }
  }
  saveTourneySettings();
  renderTourneyModesChecklist();
};

function recordTourneySessionScore(userData, points) {
  if (!tourneySettings.enabled || !userData || !userData.nickname) return;
  const username = userData.nickname;
  if (!tourneySessionScores[username]) {
    tourneySessionScores[username] = {
      nickname: username,
      avatar: userData.profilePictureUrl || 'assets/bg_nature.png',
      pts: 0
    };
  }
  tourneySessionScores[username].pts += points;
  if (userData.profilePictureUrl) tourneySessionScores[username].avatar = userData.profilePictureUrl;
  updateTourneyUIElements();
}

function checkTourneyConditionMet() {
  if (!tourneySettings.enabled) return false;
  if (tourneySettings.triggerType === 'rounds') {
    tourneySessionRounds++;
    updateTourneyUIElements();
    return tourneySessionRounds >= tourneySettings.targetRounds;
  } else {
    let topPts = 0;
    for (const u in tourneySessionScores) {
      if (tourneySessionScores[u].pts > topPts) topPts = tourneySessionScores[u].pts;
    }
    return topPts >= tourneySettings.targetScore;
  }
}

function pickNextRandomGameMode() {
  const allowed = (tourneySettings.allowedModes && tourneySettings.allowedModes.length > 0)
    ? tourneySettings.allowedModes
    : ALL_ROTATION_MODES;
  const filtered = allowed.filter(m => m !== currentGameMode);
  if (filtered.length === 0) return allowed[0] || 'wordle';
  const randIdx = Math.floor(Math.random() * filtered.length);
  return filtered[randIdx];
}

function triggerTourneyPodiumFinale(isManualPreview = false) {
  if (isTourneyPodiumActive && !isManualPreview) return;
  isTourneyPodiumActive = true;

  const winOverlay = document.getElementById('winOverlay');
  if (winOverlay) winOverlay.classList.remove('show');
  const multiWinOverlay = document.getElementById('multiWinOverlay');
  if (multiWinOverlay) multiWinOverlay.classList.remove('show');
  if (typeof stopMultiWinAutoScroll === 'function') stopMultiWinAutoScroll();
  const settingsDropdown = document.getElementById('settingsDropdown');
  if (settingsDropdown) settingsDropdown.classList.remove('open');

  let sortedPlayers = Object.values(tourneySessionScores)
    .filter(p => p.pts > 0)
    .sort((a, b) => b.pts - a.pts);

  if (isManualPreview && sortedPlayers.length === 0) {
    sortedPlayers = [
      { nickname: 'Budi_Santoso', avatar: 'assets/bg_nature.png', pts: 55 },
      { nickname: 'Siti_Gamer', avatar: 'assets/bg_nature.png', pts: 38 },
      { nickname: 'Rian_Pro', avatar: 'assets/bg_nature.png', pts: 25 },
      { nickname: 'Dina_Lover', avatar: 'assets/bg_nature.png', pts: 18 },
      { nickname: 'Arief_99', avatar: 'assets/bg_nature.png', pts: 12 }
    ];
  }

  tourneyPendingNextMode = pickNextRandomGameMode();
  const nextGameName = GAME_MODE_PRETTY_NAMES[tourneyPendingNextMode] || tourneyPendingNextMode.toUpperCase();
  const currentGamePretty = GAME_MODE_PRETTY_NAMES[currentGameMode] || (currentGameMode ? currentGameMode.toUpperCase() : 'WORDLE');

  const titleElem = document.getElementById('tourneyTitle');
  const subtitleElem = document.getElementById('tourneySubtitle');
  const modeChip = document.getElementById('tourneyModeChip');
  const nextTitleElem = document.getElementById('tourneyNextTitle');

  if (titleElem) titleElem.textContent = `JUARA SESI ${currentGamePretty}`;
  if (subtitleElem) {
    if (tourneySettings.triggerType === 'rounds') {
      subtitleElem.textContent = `Target Selesai ${tourneySettings.targetRounds} Ronde!`;
    } else {
      subtitleElem.textContent = `Target ${tourneySettings.targetScore} Poin Tercapai!`;
    }
  }
  if (modeChip) modeChip.textContent = currentGamePretty;
  if (nextTitleElem) nextTitleElem.textContent = nextGameName;

  const p1 = sortedPlayers[0] || { nickname: 'Belum Ada', avatar: 'assets/bg_nature.png', pts: 0 };
  const p2 = sortedPlayers[1] || { nickname: '—', avatar: 'assets/bg_nature.png', pts: 0 };
  const p3 = sortedPlayers[2] || { nickname: '—', avatar: 'assets/bg_nature.png', pts: 0 };

  const avatar1 = document.getElementById('podiumAvatar1');
  const name1 = document.getElementById('podiumName1');
  const pts1 = document.getElementById('podiumPts1');
  if (avatar1) avatar1.src = p1.avatar || 'assets/bg_nature.png';
  if (name1) name1.textContent = p1.nickname || 'Champion';
  if (pts1) pts1.textContent = `${p1.pts} Poin`;

  const avatar2 = document.getElementById('podiumAvatar2');
  const name2 = document.getElementById('podiumName2');
  const pts2 = document.getElementById('podiumPts2');
  if (avatar2) avatar2.src = p2.avatar || 'assets/bg_nature.png';
  if (name2) name2.textContent = p2.nickname || '—';
  if (pts2) pts2.textContent = `${p2.pts} Poin`;

  const avatar3 = document.getElementById('podiumAvatar3');
  const name3 = document.getElementById('podiumName3');
  const pts3 = document.getElementById('podiumPts3');
  if (avatar3) avatar3.src = p3.avatar || 'assets/bg_nature.png';
  if (name3) name3.textContent = p3.nickname || '—';
  if (pts3) pts3.textContent = `${p3.pts} Poin`;

  const standingsList = document.getElementById('tourneyStandingsList');
  if (standingsList) {
    const runnersUp = sortedPlayers.slice(3, 8);
    if (runnersUp.length === 0) {
      standingsList.innerHTML = `<div class="tourney-standings-empty">Semua penonton lainnya siap menyusul di game berikutnya!</div>`;
    } else {
      standingsList.innerHTML = runnersUp.map((p, idx) => {
        const rankNum = idx + 4;
        return `
          <div class="tourney-standings-row">
            <div class="tourney-row-left">
              <span class="tourney-rank-pill">#${rankNum}</span>
              <img class="tourney-row-avatar" src="${p.avatar || 'assets/bg_nature.png'}" onerror="this.src='assets/bg_nature.png'" alt="${escapeHTML(p.nickname)}">
              <span class="tourney-row-name">${escapeHTML(p.nickname)}</span>
            </div>
            <span class="tourney-row-pts">${p.pts} Poin</span>
          </div>
        `;
      }).join('');
    }
  }

  const overlay = document.getElementById('tourneyPodiumOverlay');
  if (overlay) overlay.classList.add('show');

  if (window.sounds && typeof window.sounds.playWin === 'function') {
    try { window.sounds.playWin(); } catch(e) {}
  }
  if (typeof triggerConfetti === 'function') {
    try { triggerConfetti(); } catch(e) {}
  }

  startTourneyCountdown(tourneySettings.podiumDuration || 8, isManualPreview);
}

function startTourneyCountdown(totalSec, isManualPreview = false) {
  if (tourneyCountdownTimer) {
    clearInterval(tourneyCountdownTimer);
    tourneyCountdownTimer = null;
  }

  let remaining = totalSec;
  const secElem = document.getElementById('tourneyCountdownSec');
  const fillElem = document.getElementById('tourneyCountdownFill');

  if (secElem) secElem.textContent = remaining;
  if (fillElem) {
    fillElem.style.transition = 'none';
    fillElem.style.width = '100%';
    setTimeout(() => {
      if (fillElem) {
        fillElem.style.transition = `width ${totalSec}s linear`;
        fillElem.style.width = '0%';
      }
    }, 40);
  }

  tourneyCountdownTimer = setInterval(() => {
    remaining--;
    if (secElem) secElem.textContent = Math.max(0, remaining);

    if (remaining <= 0) {
      clearInterval(tourneyCountdownTimer);
      tourneyCountdownTimer = null;
      if (isManualPreview) {
        closeTourneyPodium();
        if (typeof showToast === 'function') showToast('✅ Pratinjau Podium Selesai', 2000);
      } else {
        finishTourneyTransition();
      }
    }
  }, 1000);
}

window.skipTourneyTransitionNow = function(e) {
  if (e) e.stopPropagation();
  if (tourneyCountdownTimer) {
    clearInterval(tourneyCountdownTimer);
    tourneyCountdownTimer = null;
  }
  finishTourneyTransition();
};

window.previewTourneyPodium = function(e) {
  if (e) e.stopPropagation();
  const settingsDropdown = document.getElementById('settingsDropdown');
  if (settingsDropdown) settingsDropdown.classList.remove('open');
  triggerTourneyPodiumFinale(true);
};

function closeTourneyPodium() {
  isTourneyPodiumActive = false;
  const overlay = document.getElementById('tourneyPodiumOverlay');
  if (overlay) overlay.classList.remove('show');
}

function finishTourneyTransition() {
  closeTourneyPodium();
  const nextMode = tourneyPendingNextMode || pickNextRandomGameMode();
  const nextGameName = GAME_MODE_PRETTY_NAMES[nextMode] || nextMode.toUpperCase();

  tourneySessionScores = {};
  tourneySessionRounds = 0;
  updateTourneyUIElements();

  if (typeof changeGameModeDirect === 'function') {
    changeGameModeDirect(nextMode);
  }

  if (typeof showToast === 'function') {
    const targetText = (tourneySettings.triggerType === 'rounds')
      ? `${tourneySettings.targetRounds} Ronde`
      : `${tourneySettings.targetScore} Poin`;
    showToast(`🏆 Turnamen Baru: ${nextGameName}! Target Juara: ${targetText}`, 3500);
  }

  try {
    if (typeof localSocket !== 'undefined' && localSocket && localSocket.emit) {
      localSocket.emit('dashboard-change-game', nextMode);
    }
  } catch(e) {}
}

function initTourneyEngine() {
  updateTourneyUIElements();
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTourneyEngine);
} else {
  try { initTourneyEngine(); } catch(e) {}
}

function addPoints(userData, points) {
  if (!userData || !userData.nickname) return;
  if (userData.uniqueId === 'system' || userData.isStarter) return;
  const username = userData.nickname;
  if (userData.profilePictureUrl) {
    try { localStorage.setItem('pts_avatar_' + username, userData.profilePictureUrl); } catch(e) {}
  }
  if (!playerPoints[username]) {
    playerPoints[username] = {
      avatar: userData.profilePictureUrl || 'assets/bg_nature.png',
      sessionPts: getDailyPts(username),
      weeklyPts: getWeeklyPts(username)
    };
  }
  playerPoints[username].sessionPts += points;
  playerPoints[username].weeklyPts += points;
  if (userData.profilePictureUrl) playerPoints[username].avatar = userData.profilePictureUrl;
  saveDailyPts(username, playerPoints[username].sessionPts);
  saveWeeklyPts(username, playerPoints[username].weeklyPts);
  renderLeaderboard();
  if (typeof recordTourneySessionScore === 'function') {
    recordTourneySessionScore(userData, points);
  }
}

function switchLbTab(tab) {
  if (currentLbTab === tab) return;
  currentLbTab = tab;
  const tabSession = document.getElementById('tab-session');
  const tabWeekly = document.getElementById('tab-weekly');
  if (tabSession) tabSession.classList.toggle('active', tab === 'session');
  if (tabWeekly) tabWeekly.classList.toggle('active', tab === 'weekly');
  
  renderLeaderboard();
}

function renderLeaderboard() {
  const lbList = document.getElementById('lbList');
  if (!lbList) return;
  
  const sortedPlayers = Object.entries(playerPoints)
    .filter(([_, data]) => data[currentLbTab + 'Pts'] > 0)
    .sort((a, b) => b[1][currentLbTab + 'Pts'] - a[1][currentLbTab + 'Pts'])
    .slice(0, 3); // Top 3
    
  if (sortedPlayers.length === 0) {
    lbList.innerHTML = '<div style="text-align:center;font-size:10.5px;color:rgba(255,255,255,0.45);padding:4px;">Belum ada tebakan benar</div>';
    return;
  }

  // Clear if previously showing the empty message
  if (lbList.querySelector('div:not(.lb-item)')) {
    lbList.innerHTML = '';
  }

  const existingItems = lbList.querySelectorAll('.lb-item');

  // If item count changed, rebuild cleanly
  if (existingItems.length !== sortedPlayers.length) {
    lbList.innerHTML = sortedPlayers.map(([username, data], index) => `
      <div class="lb-item">
        <div class="lb-avatar-wrapper">
          <img src="${data.avatar || 'assets/bg_nature.png'}" class="lb-avatar" onerror="this.onerror=null;this.src='assets/bg_nature.png';">
          <div class="lb-rank rank-${index + 1}">${index + 1}</div>
        </div>
        <div class="lb-info">
          <span class="lb-name">${escapeHTML(username)}</span>
          <span class="lb-pts">${data[currentLbTab + 'Pts']} pts</span>
        </div>
      </div>
    `).join('');
    return;
  }

  // In-place DOM update without destroying pills (Zero Flicker!)
  sortedPlayers.forEach(([username, data], index) => {
    const item = existingItems[index];
    if (!item) return;

    const avatarImg = item.querySelector('.lb-avatar');
    const newAvatar = data.avatar || 'assets/bg_nature.png';
    if (avatarImg && avatarImg.getAttribute('src') !== newAvatar) {
      avatarImg.src = newAvatar;
    }

    const nameSpan = item.querySelector('.lb-name');
    if (nameSpan && nameSpan.textContent !== username) {
      nameSpan.textContent = username;
    }

    const ptsSpan = item.querySelector('.lb-pts');
    const newPtsText = `${data[currentLbTab + 'Pts']} pts`;
    if (ptsSpan && ptsSpan.textContent !== newPtsText) {
      ptsSpan.textContent = newPtsText;
      ptsSpan.style.transition = 'color 0.25s ease';
      ptsSpan.style.color = '#38bdf8';
      setTimeout(() => { if (ptsSpan) ptsSpan.style.color = ''; }, 350);
    }

    const rankDiv = item.querySelector('.lb-rank');
    if (rankDiv) {
      rankDiv.className = `lb-rank rank-${index + 1}`;
      rankDiv.textContent = index + 1;
    }
  });
}

// Leaderboard overlay is locked to Daily / Current Session for maximum live stream competition

// YouTube Iframe API setup with Universal Auto-Recovery & Tauri Origin Compatibility
let ytPlayerReady = false;
let ytInitStarted = false;

function initYouTubePlayer() {
  if (ytInitStarted || ytPlayerReady) return;
  const container = document.getElementById('ytPlayerContainer');
  if (!container) return;
  if (!window.YT || !window.YT.Player) return;

  ytInitStarted = true;

  // Safe Origin for both Web Browser and Tauri Desktop (prevents YouTube Error 150)
  let safeOrigin = window.location.origin;
  if (!safeOrigin || safeOrigin.startsWith('tauri://') || safeOrigin.startsWith('file://') || safeOrigin.includes('tauri.localhost')) {
    safeOrigin = 'http://localhost:3500';
  }

  console.log('[Music] Initializing YouTube Player with origin:', safeOrigin);

  try {
    ytPlayer = new YT.Player('ytPlayerContainer', {
      height: '200',
      width: '200',
      videoId: '',
      playerVars: {
        'autoplay': 1,
        'controls': 0,
        'playsinline': 1,
        'enablejsapi': 1,
        'origin': safeOrigin,
        'widget_referrer': safeOrigin
      },
      events: {
        'onReady': onPlayerReady,
        'onStateChange': onPlayerStateChange,
        'onError': onPlayerError
      }
    });
  } catch(e) {
    console.error('[Music] Failed to initialize YT.Player:', e);
    ytInitStarted = false;
  }
}

window.onYouTubeIframeAPIReady = function() {
  initYouTubePlayer();
};

// Auto-check if YouTube API was already loaded from cache before app.js executed
if (window.YT && window.YT.Player) {
  initYouTubePlayer();
} else {
  const checkYTInterval = setInterval(() => {
    if (window.YT && window.YT.Player) {
      clearInterval(checkYTInterval);
      initYouTubePlayer();
    }
  }, 200);
  setTimeout(() => clearInterval(checkYTInterval), 10000);
}

function onPlayerReady(event) {
  console.log('[Music] YouTube Player is READY');
  ytPlayerReady = true;
  event.target.unMute();
  event.target.setVolume(musicSettings.volume);

  // If there is already music queued or pending, start playing immediately
  if (isMusicPlaying && activeMusic && event.target.loadVideoById) {
    event.target.loadVideoById(activeMusic.videoId);
  } else if (!isMusicPlaying && musicQueue.length > 0) {
    playNextMusic();
  }
}

let ytPlayAttempts = 0;
let musicProgressInterval = null;

function formatMusicTime(seconds) {
  if (!seconds || isNaN(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function updateMusicQueueUI() {
  const nextContainer = document.getElementById('musicNextSong');
  const nextName = document.getElementById('musicNextSongName');
  if (musicQueue.length > 0) {
    if (nextContainer && nextName) {
      nextName.textContent = musicQueue[0].title;
      nextContainer.style.display = 'block';
    }
  } else {
    if (nextContainer) nextContainer.style.display = 'none';
  }

  // Render Playlist Tracklist (Spotify Minimalist Style)
  const queueContainer = document.getElementById('musicQueueContainer');
  const activeSlot = document.getElementById('musicActiveSlot');
  const queueItems = document.getElementById('musicQueueItems');
  const queueCount = document.getElementById('musicQueueCount');

  if (queueContainer && queueItems) {
    const style = musicSettings.playerStyle || 'vinyl';
    if (style === 'playlist') {
      queueContainer.style.display = 'flex';
      
      // Apply CSS variables for scale & visible rows
      const widget = document.getElementById('musicWidget');
      if (widget) {
        widget.style.setProperty('--playlist-visible-rows', musicSettings.playlistVisibleRows || 4);
        widget.style.setProperty('--playlist-scale', musicSettings.playlistScale || 100);
      }

      const totalSongs = (activeMusic ? 1 : 0) + musicQueue.length;
      if (queueCount) queueCount.textContent = `${totalSongs} Lagu`;

      if (totalSongs === 0) {
        if (activeSlot) activeSlot.innerHTML = '';
        queueItems.innerHTML = `
          <div class="spotify-queue-empty">
            <i class="fa-solid fa-music"></i>
            <span>Antrian kosong • Ketik !play [lagu] di chat</span>
          </div>
        `;
        stopMusicQueueAutoScroll();
        return;
      }

      // Render Row 1: Active Playing Track (Sticky in #musicActiveSlot)
      if (activeMusic && activeSlot) {
        const activeCleanTitle = escapeHTML(cleanSongTitleForLyrics(activeMusic.title, activeMusic.originalQuery) || activeMusic.title);
        const activeAuthor = escapeHTML(activeMusic.author || 'Host');
        const activeReq = (activeMusic.requesterName && activeMusic.requesterName !== 'Host') ? ` • Req ${escapeHTML(activeMusic.requesterName)}` : ` • Req Host`;
        const activeDuration = activeMusic.duration || '0:00';

        let currentProgressStr = `0:00 / ${activeDuration}`;
        let currentProgressPct = 0;
        if (ytPlayer && ytPlayer.getCurrentTime && ytPlayer.getDuration) {
          try {
            const curr = ytPlayer.getCurrentTime();
            const total = ytPlayer.getDuration();
            if (total > 0) {
              currentProgressStr = `${formatMusicTime(curr)} / ${formatMusicTime(total)}`;
              currentProgressPct = Math.min(100, Math.max(0, (curr / total) * 100));
            }
          } catch(e) {}
        }

        const isActiveJustAdded = activeMusic && activeMusic._justAdded && (Date.now() - activeMusic._justAdded < 3200);

        activeSlot.innerHTML = `
          <div class="spotify-track-row active-playing ${isActiveJustAdded ? 'just-added' : ''}" title="${activeCleanTitle}">
            <div class="spotify-track-num">
              <div class="spotify-eq-bars" title="Sedang Diputar">
                <span></span><span></span><span></span><span></span>
              </div>
            </div>
            <img class="spotify-track-thumb" src="${activeMusic.thumbnail || 'assets/bg_nature.png'}" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="Thumb">
            <div class="spotify-track-info">
              <div class="spotify-track-title">${activeCleanTitle}${isActiveJustAdded ? '<span class="spotify-track-new-tag">BARU</span>' : ''}</div>
              <div class="spotify-track-sub">${activeAuthor}${activeReq}</div>
            </div>
            <div class="spotify-track-meta">
              <span class="spotify-track-duration" id="spotifyActiveDuration">${currentProgressStr}</span>
            </div>
            <div class="spotify-row-progress">
              <div class="spotify-row-progress-fill" id="spotifyActiveProgressFill" style="width: ${currentProgressPct}%;"></div>
            </div>
          </div>
        `;
      } else if (activeSlot) {
        activeSlot.innerHTML = '';
      }

      // Render Rows 2..N: Queued Tracks in #musicQueueItems
      if (musicQueue.length === 0) {
        queueItems.innerHTML = `
          <div class="spotify-queue-empty-sub">
            Antrian kosong • Ketik !play [judul lagu] di chat
          </div>
        `;
        stopMusicQueueAutoScroll();
      } else {
        queueItems.innerHTML = musicQueue.map((item, idx) => {
          const trackNum = activeMusic ? (idx + 2) : (idx + 1);
          const cleanTitle = escapeHTML(cleanSongTitleForLyrics(item.title, item.originalQuery) || item.title);
          const author = escapeHTML(item.author || 'Host');
          const req = (item.requesterName && item.requesterName !== 'Host') ? ` • Req ${escapeHTML(item.requesterName)}` : ` • Req Host`;
          const dur = item.duration || '0:00';
          const isJustAdded = item._justAdded && (Date.now() - item._justAdded < 3200);

          return `
            <div class="spotify-track-row is-queued ${isJustAdded ? 'just-added' : ''}" title="${cleanTitle}">
              <div class="spotify-track-num">
                <span>${trackNum}</span>
              </div>
              <img class="spotify-track-thumb" src="${item.thumbnail || 'assets/bg_nature.png'}" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="Thumb">
              <div class="spotify-track-info">
                <div class="spotify-track-title">${cleanTitle}${isJustAdded ? '<span class="spotify-track-new-tag">BARU</span>' : ''}</div>
                <div class="spotify-track-sub">${author}${req}</div>
              </div>
              <div class="spotify-track-meta">
                <span class="spotify-track-duration">${dur}</span>
              </div>
            </div>
          `;
        }).join('');

        const hasJustAdded = musicQueue.some(item => item._justAdded && (Date.now() - item._justAdded < 3200));
        if (hasJustAdded) {
          setTimeout(() => {
            if (queueItems) {
              queueItems.scrollTo({ top: queueItems.scrollHeight, behavior: 'smooth' });
            }
          }, 60);
        } else {
          // Trigger Auto-Scroll Engine if overflow
          triggerMusicQueueAutoScroll();
        }
      }
    } else {
      queueContainer.style.display = 'none';
      if (activeSlot) activeSlot.innerHTML = '';
      queueItems.innerHTML = '';
      stopMusicQueueAutoScroll();
    }
  }

  if (typeof broadcastMusicState === 'function') {
    broadcastMusicState();
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// 📜 PLAYLIST QUEUE AUTO-SCROLL ENGINE
// ═════════════════════════════════════════════════════════════════════════════
let musicQueueAutoScrollTimer = null;
let isMusicQueueHovered = false;
let isMusicQueueScrolling = false;

function stopMusicQueueAutoScroll() {
  if (musicQueueAutoScrollTimer) {
    clearTimeout(musicQueueAutoScrollTimer);
    musicQueueAutoScrollTimer = null;
  }
  isMusicQueueScrolling = false;
}

function triggerMusicQueueAutoScroll() {
  stopMusicQueueAutoScroll();
  initMusicQueueHoverListeners();

  if (!musicSettings.playlistAutoScroll || musicSettings.playerStyle !== 'playlist') return;
  
  const queueItems = document.getElementById('musicQueueItems');
  if (!queueItems) return;

  // Give DOM a frame to compute scroll dimensions
  musicQueueAutoScrollTimer = setTimeout(() => {
    runMusicQueueAutoScrollLoop();
  }, 1000);
}

function runMusicQueueAutoScrollLoop() {
  stopMusicQueueAutoScroll();
  if (!musicSettings.playlistAutoScroll || musicSettings.playerStyle !== 'playlist') return;
  
  const queueItems = document.getElementById('musicQueueItems');
  if (!queueItems) return;

  const maxScroll = queueItems.scrollHeight - queueItems.clientHeight;
  if (maxScroll <= 6) {
    // Everything fits within visible height, no scroll needed
    queueItems.scrollTop = 0;
    return;
  }

  if (isMusicQueueHovered) {
    // Pause while host mouse hover, retry in 2.5s
    musicQueueAutoScrollTimer = setTimeout(runMusicQueueAutoScrollLoop, 2500);
    return;
  }

  // Phase 1: Pause at top for 4.5 seconds
  musicQueueAutoScrollTimer = setTimeout(() => {
    if (isMusicQueueHovered || !musicSettings.playlistAutoScroll) {
      runMusicQueueAutoScrollLoop();
      return;
    }

    // Phase 2: Smooth scroll down to bottom
    const duration = Math.max(1800, Math.min(5000, maxScroll * 24));
    smoothScrollQueueElement(queueItems, maxScroll, duration, () => {
      // Phase 3: Pause at bottom for 4.5 seconds
      musicQueueAutoScrollTimer = setTimeout(() => {
        if (isMusicQueueHovered || !musicSettings.playlistAutoScroll) {
          runMusicQueueAutoScrollLoop();
          return;
        }

        // Phase 4: Smooth scroll back up to top
        smoothScrollQueueElement(queueItems, 0, Math.max(1200, Math.min(3200, maxScroll * 16)), () => {
          // Loop again
          runMusicQueueAutoScrollLoop();
        });
      }, 4500);
    });
  }, 4500);
}

function smoothScrollQueueElement(elem, targetY, duration, onDone) {
  if (!elem) { if (onDone) onDone(); return; }
  const startY = elem.scrollTop;
  const diff = targetY - startY;
  if (Math.abs(diff) < 2) { if (onDone) onDone(); return; }

  const startTime = performance.now();
  isMusicQueueScrolling = true;

  function anim(now) {
    if (!isMusicQueueScrolling || isMusicQueueHovered) {
      isMusicQueueScrolling = false;
      if (onDone) onDone();
      return;
    }
    const elapsed = now - startTime;
    const progress = Math.min(1, elapsed / duration);
    // Smooth easeInOutQuad
    const ease = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
    elem.scrollTop = startY + (diff * ease);

    if (progress < 1) {
      requestAnimationFrame(anim);
    } else {
      elem.scrollTop = targetY;
      isMusicQueueScrolling = false;
      if (onDone) onDone();
    }
  }

  requestAnimationFrame(anim);
}

// Hover listeners on music widget to gracefully pause auto-scroll
function initMusicQueueHoverListeners() {
  const widget = document.getElementById('musicWidget');
  if (widget && !widget.dataset.hoverBound) {
    widget.dataset.hoverBound = 'true';
    widget.addEventListener('mouseenter', () => {
      isMusicQueueHovered = true;
      isMusicQueueScrolling = false;
    });
    widget.addEventListener('mouseleave', () => {
      isMusicQueueHovered = false;
      triggerMusicQueueAutoScroll();
    });
  }
}

// Host controls for playlist options
window.changeMusicPlaylistVisibleRows = function(rows) {
  const r = parseInt(rows) || 4;
  musicSettings.playlistVisibleRows = r;
  try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
  
  const mSelect = document.getElementById('modalMusicPlaylistRowsSelect');
  if (mSelect) mSelect.value = r;
  const mainSelect = document.getElementById('mainMusicPlaylistRowsSelect');
  if (mainSelect) mainSelect.value = r;

  const widget = document.getElementById('musicWidget');
  if (widget) {
    widget.style.setProperty('--playlist-visible-rows', r);
  }
  triggerMusicQueueAutoScroll();
};

window.changeMusicPlaylistScale = function(scale) {
  const s = parseInt(scale) || 100;
  musicSettings.playlistScale = s;
  try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}

  const mSelect = document.getElementById('modalMusicPlaylistScaleSelect');
  if (mSelect) mSelect.value = s;
  const mainSelect = document.getElementById('mainMusicPlaylistScaleSelect');
  if (mainSelect) mainSelect.value = s;

  const widget = document.getElementById('musicWidget');
  if (widget) {
    widget.style.setProperty('--playlist-scale', s);
  }

  // Re-clamp position so if widget was positioned near the edge it stays perfectly clamped
  setTimeout(() => {
    applySavedMusicWidgetPos();
  }, 50);
};

window.toggleMusicPlaylistAutoScroll = function(enabled) {
  musicSettings.playlistAutoScroll = !!enabled;
  try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}

  const mToggle = document.getElementById('modalMusicPlaylistAutoScrollToggle');
  if (mToggle) mToggle.checked = !!enabled;
  const mainToggle = document.getElementById('mainMusicPlaylistAutoScrollToggle');
  if (mainToggle) mainToggle.checked = !!enabled;

  if (musicSettings.playlistAutoScroll) {
    triggerMusicQueueAutoScroll();
  } else {
    stopMusicQueueAutoScroll();
    const queueItems = document.getElementById('musicQueueItems');
    if (queueItems) queueItems.scrollTop = 0;
  }
};

window.changeMusicPlaylistAccent = function(color) {
  const accent = (color === 'green') ? 'green' : 'red';
  musicSettings.playlistAccent = accent;
  try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}

  const widget = document.getElementById('musicWidget');
  if (widget) {
    if (accent === 'green') {
      widget.classList.add('accent-green');
    } else {
      widget.classList.remove('accent-green');
    }
  }

  const mSelect = document.getElementById('modalMusicPlaylistAccentSelect');
  if (mSelect) mSelect.value = accent;
  const mainSelect = document.getElementById('mainMusicPlaylistAccentSelect');
  if (mainSelect) mainSelect.value = accent;
  const dashSelect = document.getElementById('dashMusicPlaylistAccentSelect');
  if (dashSelect) dashSelect.value = accent;
};

// ═════════════════════════════════════════════════════════════════════════════
// 🎵 AESTHETIC SYNCED LYRICS (KARAOKE) ENGINE
// ═════════════════════════════════════════════════════════════════════════════

function cleanSongTitleForLyrics(title, originalQuery) {
  if (originalQuery && typeof originalQuery === 'string' && originalQuery.trim().length > 2) {
    const q = originalQuery.replace(/^!play\s+/i, '').trim();
    if (q.length > 2) return q;
  }
  if (!title) return '';
  let cleaned = title
    .replace(/\s*[\(\[\{](?:official|music|video|audio|lyric|lyrics|mv|hd|4k|hq|visualizer|remastered|full album|explicit)[^\)\]\}]*[\)\]\}]/gi, '')
    .replace(/\s*[\(\[\{][^\)\]\}]*(?:official|music|video|audio|lyric|lyrics|mv|hd|4k|hq|visualizer|remastered|full album|explicit)[\)\]\}]/gi, '')
    .replace(/\s*\|\s*.*$/i, '')
    .replace(/\s*-\s*(?:official\s*(?:video|audio|music)|mv|hd).*$/i, '')
    .replace(/["'“”]/g, '')
    .trim();
  return cleaned || title;
}

function parseDurationToSeconds(durStr) {
  if (!durStr) return 180;
  if (typeof durStr === 'number') return durStr;
  const parts = String(durStr).split(':').map(Number);
  if (parts.length === 2) return (parts[0] * 60) + parts[1];
  if (parts.length === 3) return (parts[0] * 3600) + (parts[1] * 60) + parts[2];
  return 180;
}

function parseLRC(lrcText) {
  if (!lrcText) return [];
  const lines = lrcText.split('\n');
  const result = [];
  const timeRegex = /\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g;
  const offsetRegex = /\[offset:\s*([+-]?\d+)\]/i;
  const spamRegex = /(www\.[a-z0-9\-]+\.[a-z]+|http[s]?:\/\/|download lagu|lirik by|sync by)/i;
  let fileOffsetSec = 0;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const offsetMatch = trimmed.match(offsetRegex);
    if (offsetMatch) {
      fileOffsetSec = (parseInt(offsetMatch[1], 10) || 0) / 1000;
      continue;
    }
    if (spamRegex.test(trimmed)) continue;
    const matches = [...trimmed.matchAll(timeRegex)];
    if (matches.length > 0) {
      const text = trimmed.replace(timeRegex, '').trim();
      if (spamRegex.test(text)) continue;
      for (const m of matches) {
        const min = parseInt(m[1], 10);
        const sec = parseInt(m[2], 10);
        const msStr = m[3] || '0';
        const ms = parseFloat('0.' + msStr) || 0;
        const totalSec = Math.max(0, min * 60 + sec + ms + fileOffsetSec);
        result.push({ time: totalSec, text: text || '♪' });
      }
    }
  }
  result.sort((a, b) => a.time - b.time);
  return result;
}

function resetLyricsUI() {
  const track = document.getElementById('musicLyricsTrack');
  const statusElem = document.getElementById('musicLyricsStatus');
  const badgeText = document.getElementById('musicLyricsBadgeText');
  if (track) {
    track.style.transform = 'translateY(0px)';
    track.innerHTML = `
      <div class="music-lyrics-empty">
        <i class="fa-solid fa-music"></i>
        <span>Menunggu lagu diputar...</span>
      </div>
    `;
  }
  if (statusElem) statusElem.textContent = 'Mencari lirik...';
  if (badgeText) badgeText.textContent = 'KARAOKE';
}

function updateMusicLyricsVisibility() {
  const container = document.getElementById('musicLyricsContainer');
  const quickBtn = document.getElementById('musicLyricsQuickBtn');
  const isLyrics = (musicSettings.playerStyle === 'lyrics');
  if (container) {
    container.style.display = isLyrics ? 'flex' : 'none';
  }
  if (quickBtn) {
    quickBtn.title = isLyrics ? 'Tutup Lirik Karaoke' : 'Mode Lirik Karaoke';
    if (isLyrics) quickBtn.classList.add('active');
    else quickBtn.classList.remove('active');
  }
}

window.toggleMusicLyricsView = function(event) {
  if (event) event.stopPropagation();
  if (musicSettings.playerStyle === 'lyrics') {
    window.changeMusicPlayerStyle(previousMusicPlayerStyle || 'vinyl');
  } else {
    previousMusicPlayerStyle = (musicSettings.playerStyle && musicSettings.playerStyle !== 'lyrics') ? musicSettings.playerStyle : 'vinyl';
    window.changeMusicPlayerStyle('lyrics');
  }
};

function getActiveSongKey(song) {
  const target = song || activeMusic;
  if (!target) return null;
  if (target.videoId) return target.videoId;
  if (target.title) return target.title.trim().toLowerCase();
  return null;
}

function getSongLyricsOffset(song) {
  const key = getActiveSongKey(song);
  if (key && typeof musicSongOffsets[key] === 'number') {
    return musicSongOffsets[key];
  }
  return 0;
}

function setSongLyricsOffset(song, offset) {
  const key = getActiveSongKey(song);
  const rounded = Math.round(offset * 10) / 10;
  if (key) {
    if (rounded === 0) {
      delete musicSongOffsets[key];
    } else {
      musicSongOffsets[key] = rounded;
    }
    try {
      localStorage.setItem('music_song_offsets', JSON.stringify(musicSongOffsets));
    } catch(e) {}
  }
  updateLyricsOffsetUI();
}

window.adjustLyricsOffset = function(delta) {
  const current = getSongLyricsOffset(activeMusic);
  const newOffset = current + delta;
  setSongLyricsOffset(activeMusic, newOffset);
  if (typeof showToast === 'function') {
    const sign = newOffset > 0 ? `+${newOffset.toFixed(1)}` : `${newOffset.toFixed(1)}`;
    const songName = activeMusic && activeMusic.title ? ` (${activeMusic.title.substring(0, 18)}...)` : '';
    showToast(`⏱️ Offset Lirik: ${sign}s${songName}`, 1200);
  }
};

window.setLyricsOffsetExact = function(val) {
  const num = parseFloat(val);
  if (isNaN(num)) return;
  setSongLyricsOffset(activeMusic, num);
  if (typeof showToast === 'function') {
    const sign = num > 0 ? `+${num.toFixed(1)}` : `${num.toFixed(1)}`;
    showToast(`⏱️ Offset Lirik diatur: ${sign}s`, 1200);
  }
};

window.resetLyricsOffset = function() {
  const key = getActiveSongKey(activeMusic);
  if (key && typeof musicSongOffsets[key] === 'number') {
    delete musicSongOffsets[key];
    try {
      localStorage.setItem('music_song_offsets', JSON.stringify(musicSongOffsets));
    } catch(e) {}
  }
  updateLyricsOffsetUI();
  if (typeof showToast === 'function') {
    showToast('⏱️ Offset Lirik lagu ini di-reset (0.0s)', 1200);
  }
};

window.syncFirstLyricNow = function() {
  if (!activeMusic || !ytPlayer || typeof ytPlayer.getCurrentTime !== 'function') {
    if (typeof showToast === 'function') showToast('Tidak ada musik yang sedang diputar', 1500);
    return;
  }
  if (!currentLyricsData || currentLyricsData.length === 0) {
    if (typeof showToast === 'function') showToast('Lirik belum dimuat / instrumental', 1500);
    return;
  }

  isLyricsManualHoverScroll = false;
  const firstLine = currentLyricsData[0];
  const targetTime = firstLine.time;
  const currTime = ytPlayer.getCurrentTime();

  if (currTime <= 0) return;

  const newOffset = Math.round((targetTime - currTime) * 10) / 10;
  setSongLyricsOffset(activeMusic, newOffset);

  const firstElem = document.getElementById('lyricLine_0');
  if (firstElem) {
    firstElem.style.transition = 'all 0.15s ease';
    firstElem.style.backgroundColor = 'rgba(254, 44, 85, 0.45)';
    firstElem.style.transform = 'scale(1.1)';
    setTimeout(() => {
      firstElem.style.backgroundColor = '';
      firstElem.style.transform = '';
    }, 450);
  }

  if (window.sounds && typeof window.sounds.playChime === 'function') {
    try { window.sounds.playChime(); } catch(e) {}
  }

  const sign = newOffset > 0 ? `+${newOffset.toFixed(1)}` : `${newOffset.toFixed(1)}`;
  if (typeof showToast === 'function') {
    showToast(`🎯 Lirik ditarik ke Baris 1 di [${formatMusicTime(currTime)}] (Offset: ${sign}s)`, 2200);
  }

  updateLyricsSync(currTime);
};

window.handleLyricLineTap = function(idx, event) {
  if (event) event.stopPropagation();
  isLyricsManualHoverScroll = false;
  if (!activeMusic || !ytPlayer || typeof ytPlayer.getCurrentTime !== 'function') return;
  if (!currentLyricsData || !currentLyricsData[idx]) return;

  const line = currentLyricsData[idx];
  const targetTime = line.time;
  const currTime = ytPlayer.getCurrentTime();

  if (currTime <= 0) return;

  // Rumus: adjustedTime = currTime + offset
  // Supaya adjustedTime == targetTime saat diklik: offset = targetTime - currTime
  const newOffset = Math.round((targetTime - currTime) * 10) / 10;
  setSongLyricsOffset(activeMusic, newOffset);

  // Efek visual feedback pada baris lirik yang diklik
  const lineElem = document.getElementById(`lyricLine_${idx}`);
  if (lineElem) {
    lineElem.style.transition = 'all 0.15s ease';
    lineElem.style.backgroundColor = 'rgba(254, 44, 85, 0.35)';
    lineElem.style.transform = 'scale(1.08)';
    setTimeout(() => {
      lineElem.style.backgroundColor = '';
      lineElem.style.transform = '';
    }, 450);
  }

  if (window.sounds && typeof window.sounds.playChime === 'function') {
    try { window.sounds.playChime(); } catch(e) {}
  }

  const sign = newOffset > 0 ? `+${newOffset.toFixed(1)}` : `${newOffset.toFixed(1)}`;
  if (typeof showToast === 'function') {
    showToast(`🎯 Lirik disinkronkan ke [${formatMusicTime(currTime)}] (Offset: ${sign}s)`, 2000);
  }

  // Segera sinkronkan ulang baris aktif
  updateLyricsSync(currTime);
};

function updateLyricsOffsetUI() {
  const label = document.getElementById('musicLyricsOffsetLabel');
  const songNameLabel = document.getElementById('musicLyricsSongTarget');
  const inputElem = document.getElementById('musicLyricsOffsetInput');
  const off = getSongLyricsOffset(activeMusic);

  if (inputElem) {
    inputElem.value = off.toFixed(1);
  }

  if (songNameLabel) {
    if (activeMusic && activeMusic.title) {
      const key = getActiveSongKey(activeMusic);
      const isCustom = key && typeof musicSongOffsets[key] === 'number';
      songNameLabel.textContent = `Lagu: ${activeMusic.title.substring(0, 32)}${activeMusic.title.length > 32 ? '...' : ''} ${isCustom ? '(Khusus Lagu Ini)' : '(Default: 0.0s)'}`;
      songNameLabel.style.color = isCustom ? '#facc15' : '#94a3b8';
    } else {
      songNameLabel.textContent = 'Tidak ada lagu yang sedang diputar';
      songNameLabel.style.color = '#94a3b8';
    }
  }

  if (!label) return;
  if (off === 0) {
    label.textContent = '0.0s (Normal)';
    label.style.color = '#38bdf8';
  } else if (off > 0) {
    label.textContent = `+${off.toFixed(1)}s (Dipercepat)`;
    label.style.color = '#4ade80';
  } else {
    label.textContent = `${off.toFixed(1)}s (Diperlambat)`;
    label.style.color = '#f59e0b';
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// 🎲 RANDOM MUSIC GENERATOR (NOSTALGIA MILENIAL, HITS, AKUSTIK)
// ═════════════════════════════════════════════════════════════════════════════

const RANDOM_SONGS_MILENIAL = [
  // Sheila On 7
  "Sheila On 7 - Dan official audio",
  "Sheila On 7 - Sephia official audio",
  "Sheila On 7 - Kisah Klasik official audio",
  "Sheila On 7 - Melompat Lebih Tinggi official audio",
  "Sheila On 7 - Sahabat Sejati official audio",
  "Sheila On 7 - Anugerah Terindah official audio",
  "Sheila On 7 - Pria Kesepian official audio",
  "Sheila On 7 - Pejantan Tangguh official audio",
  "Sheila On 7 - Kita official audio",
  "Sheila On 7 - Radio official audio",
  "Sheila On 7 - Berhenti Berharap official audio",
  "Sheila On 7 - Tunggu Aku Di Jakarta official audio",
  "Sheila On 7 - Tunjuk Satu Bintang official audio",

  // Peterpan / Noah
  "Peterpan - Mungkin Nanti official audio",
  "Peterpan - Ada Apa Denganmu official audio",
  "Peterpan - Menghapus Jejakmu official audio",
  "Peterpan - Yang Terdalam official audio",
  "Peterpan - Mimpi Yang Sempurna official audio",
  "Peterpan - Aku Dan Bintang official audio",
  "Peterpan - Semua Tentang Kita official audio",
  "Peterpan - Sahabat official audio",
  "Peterpan - Di Belakangku official audio",
  "Peterpan - Kukatakan Dengan Indah official audio",
  "Peterpan - Tak Bisakah official audio",
  "Peterpan - Bintang Di Surga official audio",
  "Peterpan - Cobalah Mengerti official audio",
  "Peterpan - Topeng official audio",

  // Dewa 19 / Ari Lasso / Once
  "Dewa 19 - Kangen official audio",
  "Dewa 19 - Pupus official audio",
  "Dewa 19 - Separuh Nafas official audio",
  "Dewa 19 - Risalah Hati official audio",
  "Dewa 19 - Cemburu official audio",
  "Dewa 19 - Aku Milikmu official audio",
  "Dewa 19 - Roman Picisan official audio",
  "Dewa 19 - Kirana official audio",
  "Dewa 19 - Kamulah Satu Satunya official audio",
  "Dewa 19 - Dua Sejoli official audio",
  "Dewa 19 - Sedang Ingin Bercinta official audio",
  "Dewa 19 - Kasidah Cinta official audio",
  "Ari Lasso - Hampa official audio",
  "Ari Lasso - Perbedaan official audio",
  "Ari Lasso - Mengejar Matahari official audio",
  "Ari Lasso - Misteri Ilahi official audio",
  "Ari Lasso - Rahasia Perempuan official audio",
  "Once Mekel - Dealova official audio",

  // Padi
  "Padi - Kasih Tak Sampai official audio",
  "Padi - Begitu Indah official audio",
  "Padi - Menanti Sebuah Jawaban official audio",
  "Padi - Sobat official audio",
  "Padi - Semua Tak Sama official audio",
  "Padi - Mahadewi official audio",
  "Padi - Sesuatu Yang Indah official audio",
  "Padi - Tempat Terakhir official audio",

  // Ungu
  "Ungu - Demi Waktu official audio",
  "Ungu - Kekasih Gelapku official audio",
  "Ungu - Tercipta Untukku official audio",
  "Ungu - Cinta Dalam Hati official audio",
  "Ungu - Andai Ku Tahu official audio",
  "Ungu - Hampa Hatiku official audio",
  "Ungu - Melayang official audio",
  "Ungu - Seperti Yang Dulu official audio",
  "Ungu - Laguku official audio",

  // Samsons
  "Samsons - Kenangan Terindah official audio",
  "Samsons - Naluri Lelaki official audio",
  "Samsons - Akhir Rasa Ini official audio",
  "Samsons - Bukan Diriku official audio",
  "Samsons - Luluh official audio",

  // Ada Band
  "Ada Band - Surga Cinta official audio",
  "Ada Band - Manusia Bodoh official audio",
  "Ada Band - Karena Wanita official audio",
  "Ada Band - Masih (Sahabatku Kekasihku) official audio",
  "Ada Band - Haruskah Ku Mati official audio",
  "Ada Band - Setengah Hati official audio",
  "Ada Band - Nyawa Hidupku official audio",
  "Ada Band - Kau Auraku official audio",
  "Ada Band - Beib official audio",
  "Ada Band - Aksen Asmara official audio",
  "Ada Band - Baiknya official audio",

  // Kerispatih
  "Kerispatih - Mengenangmu official audio",
  "Kerispatih - Demi Cinta official audio",
  "Kerispatih - Kejujuran Hati official audio",
  "Kerispatih - Bila Rasaku Ini Rasamu official audio",
  "Kerispatih - Tertatih official audio",
  "Kerispatih - Lupakan Aku official audio",
  "Kerispatih - Tapi Bukan Aku official audio",
  "Kerispatih - Tak Lekang Oleh Waktu official audio",
  "Kerispatih - Kesalahan Yang Sama official audio",

  // Naff
  "Naff - Kenanglah Aku official audio",
  "Naff - Akhirnya Ku Menemukanmu official audio",
  "Naff - Kau Masih Kekasihku official audio",
  "Naff - Terendap Laraku official audio",
  "Naff - Dosa Apa official audio",
  "Naff - Tak Seindah Cinta Yang Semestinya official audio",

  // D'Masiv
  "D'Masiv - Cinta Ini Membunuhku official audio",
  "D'Masiv - Jangan Menyerah official audio",
  "D'Masiv - Merindukanmu official audio",
  "D'Masiv - Di Antara Kalian official audio",
  "D'Masiv - Diam Tanpa Kata official audio",
  "D'Masiv - Semakin official audio",
  "D'Masiv - Sudahi Perih Ini official audio",

  // Kangen Band
  "Kangen Band - Tentang Aku Kau Dan Dia official audio",
  "Kangen Band - Yolanda official audio",
  "Kangen Band - Doy official audio",
  "Kangen Band - Pujaan Hati official audio",
  "Kangen Band - Kembali Pulang official audio",
  "Kangen Band - Bintang 14 Hari official audio",
  "Kangen Band - Cinta Yang Sempurna official audio",

  // ST12
  "ST12 - Puspa official audio",
  "ST12 - Saat Terakhir official audio",
  "ST12 - Jangan Pernah Berubah official audio",
  "ST12 - Rasa Yang Tertinggal official audio",
  "ST12 - Cari Pacar Lagi official audio",
  "ST12 - Isabella official audio",
  "ST12 - Biarkan Jatuh Cinta official audio",

  // Wali & Armada
  "Wali - Baik Baik Sayang official audio",
  "Wali - Dik official audio",
  "Wali - Cari Jodoh official audio",
  "Wali - Emang Dasar official audio",
  "Armada - Buka Hatimu official audio",
  "Armada - Mau Dibawa Kemana official audio",
  "Armada - Asal Kau Bahagia official audio",
  "Armada - Pergi Pagi Pulang Pagi official audio",
  "Armada - Harusnya Aku official audio",

  // Repvblik & D'Bagindas
  "Repvblik - Hanya Ingin Kau Tahu official audio",
  "Repvblik - Selimut Tetangga official audio",
  "Repvblik - Sandiwara Cinta official audio",
  "Repvblik - Aku Takut official audio",
  "DBagindas - C.I.N.T.A official audio",
  "DBagindas - Empat Mata official audio",
  "DBagindas - Apa Yang Terjadi official audio",

  // Geisha & Utopia
  "Geisha - Jika Cinta Dia official audio",
  "Geisha - Lumpuhkan Ingatanku official audio",
  "Geisha - Takkan Pernah Ada official audio",
  "Geisha - Selalu Salah official audio",
  "Geisha - Pergi Saja official audio",
  "Utopia - Antara Ada Dan Tiada official audio",
  "Utopia - Hujan official audio",
  "Utopia - Mencintaimu Sampai Mati official audio",

  // Cokelat, Jamrud, Seurieus, Element
  "Cokelat - Karma official audio",
  "Cokelat - Luka Lama official audio",
  "Cokelat - Segitiga official audio",
  "Cokelat - Jauh official audio",
  "Jamrud - Pelangi Di Matamu official audio",
  "Jamrud - Surti Tejo official audio",
  "Jamrud - Selamat Ulang Tahun official audio",
  "Jamrud - Berakit Rakit official audio",
  "Seurieus - Rocker Juga Manusia official audio",
  "Element - Rahasia Hati official audio",
  "Element - Cinta Tak Bersyarat official audio",
  "Element - Pergilah Adinda official audio",

  // Seventeen & Drive
  "Seventeen - Selalu Mengalah official audio",
  "Seventeen - Jaga Selalu Hatimu official audio",
  "Seventeen - Kemarin official audio",
  "Seventeen - Untuk Mencintaimu official audio",
  "Drive - Bersama Bintang official audio",
  "Drive - Melepasmu official audio",
  "Drive - Akulah Dia official audio",

  // Letto, Wayang, Gigi, Slank
  "Letto - Ruang Rindu official audio",
  "Letto - Sandaran Hati official audio",
  "Letto - Permintaan Hati official audio",
  "Letto - Sebelum Cahaya official audio",
  "Wayang - Damai official audio",
  "Gigi - 11 Januari official audio",
  "Gigi - Terbang official audio",
  "Gigi - Nakal official audio",
  "Gigi - Jomblo official audio",
  "Gigi - Andai official audio",
  "Slank - Ku Tak Bisa official audio",
  "Slank - Terlalu Manis official audio",
  "Slank - I Miss U But I Hate U official audio",
  "Slank - Balikin official audio",
  "Slank - Seperti Para Koruptor official audio",

  // Nidji, Jikustik, Radja, Vierra, Kotak
  "Nidji - Hapus Aku official audio",
  "Nidji - Laskar Pelangi official audio",
  "Nidji - Biarlah official audio",
  "Nidji - Disco Lazy Time official audio",
  "Nidji - Sudah official audio",
  "Jikustik - Puisi official audio",
  "Jikustik - Setia official audio",
  "Jikustik - Saat Kau Tak Disini official audio",
  "Radja - Jujur official audio",
  "Radja - Cinderella official audio",
  "Radja - Yakin official audio",
  "Radja - Bulan official audio",
  "Radja - Tulus official audio",
  "Vierra - Dengarkan Curhatku official audio",
  "Vierra - Bersamamu official audio",
  "Vierra - Perih official audio",
  "Vierra - Rasa Ini official audio",
  "Vierra - Jadi Yang Kuinginkan official audio",
  "Kotak - Pelan Pelan Saja official audio",
  "Kotak - Beraksi official audio",
  "Kotak - Masih Cinta official audio",
  "Kotak - Terbang official audio",

  // Kahitna, Glenn Fredly, Maliq, Ten 2 Five, The Rain
  "Kahitna - Cantik official audio",
  "Kahitna - Soulmate official audio",
  "Kahitna - Mantan Terindah official audio",
  "Kahitna - Andai Dia Tahu official audio",
  "Kahitna - Cerita Cinta official audio",
  "Glenn Fredly - Januari official audio",
  "Glenn Fredly - Akhir Cerita Cinta official audio",
  "Glenn Fredly - Kasih Putih official audio",
  "Glenn Fredly - Sedih Tak Berujung official audio",
  "Glenn Fredly - Sekali Ini Saja official audio",
  "Maliq & D'Essentials - Untitled official audio",
  "Maliq & D'Essentials - Pilihanku official audio",
  "Maliq & D'Essentials - Dia official audio",
  "The Rain - Dengar Bisikku official audio",
  "The Rain - Terlatih Patah Hati official audio",
  "Ten 2 Five - I Will Fly official audio",
  "Astrid - Jadikan Aku Yang Kedua official audio",
  "Astrid - Tentang Rasa official audio",
  "Rossa - Tegar official audio",
  "Rossa - Hati Yang Kau Sakiti official audio",
  "Rossa - Pudar official audio",
  "Bunga Citra Lestari - Cinta Pertama (Sunny) official audio",
  "Bunga Citra Lestari - Pernah Muda official audio",
  "Bunga Citra Lestari - Karena Kucinta Kau official audio",
  "Audy - Menangis Semalam official audio",
  "Audy - Arti Hadirmu official audio",
  "Lobow - Salah official audio",
  "Matta - Ketahuan official audio"
];

const RANDOM_SONGS_HITS = [
  // Bernadya
  "Bernadya - Satu Bulan official audio",
  "Bernadya - Kata Mereka Ini Berlebihan official audio",
  "Bernadya - Kini Mereka Tahu official audio",
  "Bernadya - Apa Mungkin official audio",
  "Bernadya - Untungnya Hidup Harus Tetap Berjalan official audio",

  // Mahalini
  "Mahalini - Sial official audio",
  "Mahalini - Mati Matian official audio",
  "Mahalini - Sisa Rasa official audio",
  "Mahalini - Melawan Restu official audio",
  "Mahalini - Ini Laguku official audio",

  // Nadin Amizah
  "Nadin Amizah - Rayuan Perempuan Gila official audio",
  "Nadin Amizah - Bertaut official audio",
  "Nadin Amizah - Sorai official audio",
  "Nadin Amizah - Semua Aku Dirayakan official audio",

  // Sal Priadi
  "Sal Priadi - Dari Planet Lain official audio",
  "Sal Priadi - Gala Bunga Matahari official audio",
  "Sal Priadi - Mesra Mesraannya Kecil Kecilan Dulu official audio",
  "Sal Priadi - Amin Paling Serius official audio",

  // Tulus
  "Tulus - Hati Hati di Jalan official audio",
  "Tulus - Interaksi official audio",
  "Tulus - Diri official audio",
  "Tulus - Monokrom official audio",
  "Tulus - Ruang Sendiri official audio",
  "Tulus - Sewindu official audio",

  // Juicy Luicy
  "Juicy Luicy - Sialan official audio",
  "Juicy Luicy - Lantas official audio",
  "Juicy Luicy - Tanpa Tergesa official audio",
  "Juicy Luicy - Asing official audio",
  "Juicy Luicy - Tampar official audio",

  // Hindia & Feast
  "Hindia - Rumah Ke Rumah official audio",
  "Hindia - Evaluasi official audio",
  "Hindia - Secukupnya official audio",
  "Hindia - Cincin official audio",

  // Feby Putri, Raim Laode, Yura Yunita
  "Raim Laode - Komang official audio",
  "Feby Putri Fiersa Besari - Runtuh official audio",
  "Feby Putri - Usik official audio",
  "Yura Yunita - Dunia Tipu Tipu official audio",
  "Yura Yunita - Tutur Batin official audio",
  "Yura Yunita - Tenang official audio",
  "Ghea Indrawari - Jiwa Yang Bersedih official audio",
  "Idgitaf - Satu Satu official audio",
  "Idgitaf - Takut official audio",
  "Rizky Febian - Hingga Tua Bersama official audio",
  "Rizky Febian - Cuek official audio",
  "Rizky Febian - Kesempurnaan Cinta official audio",
  "Tiara Andini - Usai official audio",
  "Tiara Andini - Janji Setia official audio",
  "Lyodra - Pesan Terakhir official audio",
  "Lyodra - Sang Dewi official audio",
  "Fabio Asher - Bertahan Terluka official audio",
  "Fabio Asher - Rumah Singgah official audio",
  "Keisya Levronka - Tak Ingin Usai official audio",
  "Fiersa Besari - Waktu Yang Salah official audio",
  "Fiersa Besari - Celengan Rindu official audio",
  "Fiersa Besari - Garis Terdepan official audio",
  "Anggi Marito - Tak Segampang Itu official audio"
];

const RANDOM_SONGS_AKUSTIK = [
  "Raim Laode - Komang akustik",
  "Feby Putri - Runtuh acoustic",
  "Tulus - Monokrom acoustic",
  "Tulus - Hati Hati di Jalan acoustic",
  "Sheila On 7 - Anugerah Terindah acoustic",
  "Sheila On 7 - Dan acoustic",
  "Dewa 19 - Risalah Hati acoustic",
  "Dewa 19 - Kangen acoustic",
  "Payung Teduh - Akad acoustic",
  "Payung Teduh - Resah acoustic",
  "Payung Teduh - Untuk Perempuan Yang Sedang Dalam Pelukan acoustic",
  "Fourtwnty - Zona Nyaman acoustic",
  "Fourtwnty - Fana Merah Jambu acoustic",
  "Fourtwnty - Aku Tenang acoustic",
  "Danilla - Berdistraksi acoustic",
  "Danilla - Ada Di Sana acoustic",
  "Nadin Amizah - Sorai acoustic",
  "Nadin Amizah - Bertaut acoustic",
  "Iwan Fals - Kemesraan acoustic",
  "Iwan Fals - Yang Terlupakan acoustic",
  "Mocca - I Remember acoustic",
  "Mocca - Secret Admirer acoustic",
  "White Shoes & The Couples Company - Senja Menggila acoustic",
  "Float - Sementara acoustic",
  "Banda Neira - Sampai Jadi Debu acoustic",
  "Banda Neira - Yang Patah Tumbuh Yang Hilang Berganti acoustic",
  "Daun Jatuh - Resah Jadi Luka acoustic",
  "Soegi Bornean - Asmalibrasi acoustic",
  "Fiersa Besari - Celengan Rindu acoustic",
  "Peterpan - Semua Tentang Kita acoustic",
  "Peterpan - Yang Terdalam acoustic",
  "Kahitna - Soulmate acoustic"
];

let recentRandomSongs = [];

// ─── Real-time Spotify Top Daily Charts Pool (Cached & Synced from Server) ───
let spotifyChartsData = {
  updatedAt: null,
  idDaily: [],
  globalDaily: []
};

try {
  const cachedCharts = localStorage.getItem('spotify_charts_cache');
  if (cachedCharts) {
    const parsed = JSON.parse(cachedCharts);
    if (Array.isArray(parsed.idDaily) && Array.isArray(parsed.globalDaily)) {
      spotifyChartsData = parsed;
    }
  }
} catch(e) {}

// Fetch local JSON file if available
fetch('spotify_top_charts.json').then(r => r.json()).then(data => {
  if (data && Array.isArray(data.idDaily) && Array.isArray(data.globalDaily)) {
    spotifyChartsData = data;
    try { localStorage.setItem('spotify_charts_cache', JSON.stringify(data)); } catch(e) {}
  }
}).catch(() => {});

window.updateClientSpotifyCharts = function(data) {
  if (data && Array.isArray(data.idDaily) && Array.isArray(data.globalDaily)) {
    spotifyChartsData = data;
    try { localStorage.setItem('spotify_charts_cache', JSON.stringify(data)); } catch(e) {}
    console.log('[Spotify Charts] Adopted new charts:', data.idDaily.length, 'ID,', data.globalDaily.length, 'Global');
  }
};

window.changeMusicRandomGenre = function(val) {
  musicSettings.randomGenre = val || 'milenial';
  localStorage.setItem('music_settings', JSON.stringify(musicSettings));
  if (localSocket) {
    localSocket.emit('update-game-settings', { musicRandomGenre: musicSettings.randomGenre });
  }
  const modalSel = document.getElementById('modalMusicRandomGenreSelect');
  if (modalSel) modalSel.value = musicSettings.randomGenre;
  const dashSel = document.getElementById('dashMusicRandomGenreSelect');
  if (dashSel) dashSel.value = musicSettings.randomGenre;

  if (typeof showToast === 'function') {
    const names = {
      milenial: 'Nostalgia Milenial',
      spotify_mix: 'Mix Top Spotify (Indo + Global)',
      spotify_id: 'Top 50 Spotify Indonesia Daily',
      spotify_global: 'Top 50 Spotify Global Daily',
      hits: 'Hits Pop Terkini & Viral',
      akustik: 'Akustik Santai / Cafe',
      mix: 'Campuran Semua Kategori (Total Mix)'
    };
    showToast('Vibe Lagu Acak: ' + (names[musicSettings.randomGenre] || val), 1800);
  }
};

window.playRandomMusic = function(event) {
  if (event) event.stopPropagation();

  if (ytPlayer && ytPlayer.unMute) {
    try {
      if (!isMusicPlaying) {
        ytPlayer.unMute();
        ytPlayer.setVolume(musicSettings.volume);
        ytPlayAttempts = 0;
      }
    } catch(e) {}
  }

  const genre = musicSettings.randomGenre || 'milenial';
  let pool = [];

  const idDailyPool = (spotifyChartsData.idDaily && spotifyChartsData.idDaily.length > 0)
    ? spotifyChartsData.idDaily
    : RANDOM_SONGS_HITS;
  const globalDailyPool = (spotifyChartsData.globalDaily && spotifyChartsData.globalDaily.length > 0)
    ? spotifyChartsData.globalDaily
    : ["Billie Eilish - BIRDS OF A FEATHER", "Lady Gaga - Die With A Smile (w/ Bruno Mars)", "Katy Perry - The One That Got Away", "The Weeknd - One Of The Girls"];

  if (genre === 'milenial') {
    pool = RANDOM_SONGS_MILENIAL;
  } else if (genre === 'spotify_mix') {
    // Mix Top 50 Spotify Indo + Top 50 Spotify Global
    pool = [...idDailyPool, ...globalDailyPool];
  } else if (genre === 'spotify_id') {
    pool = idDailyPool;
  } else if (genre === 'spotify_global') {
    pool = globalDailyPool;
  } else if (genre === 'hits') {
    pool = RANDOM_SONGS_HITS;
  } else if (genre === 'akustik') {
    pool = RANDOM_SONGS_AKUSTIK;
  } else {
    // Total Mix: all categories including Spotify Top Charts
    pool = [...RANDOM_SONGS_MILENIAL, ...idDailyPool, ...globalDailyPool, ...RANDOM_SONGS_AKUSTIK];
  }

  let candidates = pool.filter(s => !recentRandomSongs.includes(s));
  if (candidates.length === 0) {
    recentRandomSongs = [];
    candidates = pool;
  }

  const chosen = candidates[Math.floor(Math.random() * candidates.length)];
  recentRandomSongs.push(chosen);
  // Keep anti-repeat history buffer large (up to 60 songs) so songs don't repeat during a long stream
  if (recentRandomSongs.length > Math.min(60, Math.floor(pool.length * 0.75))) {
    recentRandomSongs.shift();
  }

  if (localSocket) {
    localSocket.emit('host-music-request', chosen);
    if (typeof showToast === 'function') {
      const cleanName = chosen.replace(/\s*official\s*audio/i, '').replace(/\s*acoustic/i, '').trim();
      showToast('Memutar acak: ' + cleanName, 2000);
    }
  }
};

async function fetchSongLyrics(song) {
  if (!song) return;
  const track = document.getElementById('musicLyricsTrack');
  const statusElem = document.getElementById('musicLyricsStatus');
  const badgeText = document.getElementById('musicLyricsBadgeText');

  currentLyricsData = [];
  currentLyricsIndex = -1;
  isLyricsLoading = true;

  if (track) {
    track.style.transform = 'translateY(0px)';
    track.innerHTML = `
      <div class="music-lyrics-empty">
        <i class="fa-solid fa-spinner fa-spin" style="color: #fe2c55;"></i>
        <span>Mencari lirik lagu...</span>
      </div>
    `;
  }
  if (statusElem) statusElem.textContent = 'Mencari lirik...';
  if (badgeText) badgeText.textContent = 'KARAOKE';

  const queryCandidates = [];
  if (song.originalQuery && song.originalQuery.trim().length > 2) {
    queryCandidates.push(cleanSongTitleForLyrics(song.title, song.originalQuery));
  }
  const cleanTitle = cleanSongTitleForLyrics(song.title);
  if (cleanTitle && !queryCandidates.includes(cleanTitle)) {
    queryCandidates.push(cleanTitle);
  }
  if (song.author && song.title) {
    const authorTitle = `${song.author} ${cleanTitle}`;
    if (!queryCandidates.includes(authorTitle)) {
      queryCandidates.push(authorTitle);
    }
  }

  let lyricsFound = null;

  for (const q of queryCandidates) {
    try {
      let res = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(q)}`, {
        signal: AbortSignal.timeout(4000)
      }).catch(() => null);

      if (!res || !res.ok) {
        res = await fetch(`/api/lyrics?q=${encodeURIComponent(q)}`, {
          signal: AbortSignal.timeout(4000)
        }).catch(() => null);
      }

      if (res && res.ok) {
        const items = await res.json();
        if (Array.isArray(items) && items.length > 0) {
          const songDur = parseDurationToSeconds(song.duration);
          
          // Prioritaskan hasil synced lyrics yang durasinya paling mendekati lagu YouTube
          const syncedItems = items.filter(item => item.syncedLyrics && item.syncedLyrics.trim().length > 0);
          if (syncedItems.length > 0) {
            syncedItems.sort((a, b) => {
              const diffA = Math.abs((a.duration || songDur) - songDur);
              const diffB = Math.abs((b.duration || songDur) - songDur);
              return diffA - diffB;
            });
            lyricsFound = { type: 'synced', data: syncedItems[0] };
            break;
          }

          const plainItems = items.filter(item => item.plainLyrics && item.plainLyrics.trim().length > 0);
          if (plainItems.length > 0 && !lyricsFound) {
            plainItems.sort((a, b) => {
              const diffA = Math.abs((a.duration || songDur) - songDur);
              const diffB = Math.abs((b.duration || songDur) - songDur);
              return diffA - diffB;
            });
            lyricsFound = { type: 'plain', data: plainItems[0] };
          }
        }
      }
    } catch (e) {
      console.warn('[Lyrics] Search candidate error for', q, e.message);
    }
  }

  isLyricsLoading = false;

  // Make sure we are still playing the same song
  if (activeMusic !== song) return;

  if (!lyricsFound) {
    if (track) {
      track.innerHTML = `
        <div class="music-lyrics-empty">
          <i class="fa-solid fa-music"></i>
          <span>Lirik tidak ditemukan / Instrumental</span>
        </div>
      `;
    }
    if (statusElem) statusElem.textContent = 'Instrumental / Teks -';
    if (badgeText) badgeText.textContent = 'INSTRUMENTAL';
    return;
  }

  if (lyricsFound.type === 'synced') {
    const item = lyricsFound.data;
    currentLyricsData = parseLRC(item.syncedLyrics);
    if (badgeText) badgeText.textContent = 'KARAOKE SYNCED';
    if (statusElem) {
      const art = item.artistName ? item.artistName.trim() : '';
      statusElem.textContent = art ? `${art}` : 'Lirik Tersinkron';
    }
  } else if (lyricsFound.type === 'plain') {
    const item = lyricsFound.data;
    const lines = item.plainLyrics.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const dur = parseDurationToSeconds(song.duration);
    const step = dur / (lines.length + 2);
    currentLyricsData = lines.map((text, idx) => ({
      time: (idx + 1) * step,
      text: text
    }));
    if (badgeText) badgeText.textContent = 'LIRIK TEKS';
    if (statusElem) {
      const art = item.artistName ? item.artistName.trim() : '';
      statusElem.textContent = art ? `${art}` : 'Lirik Teks';
    }
  }

  if (track && currentLyricsData.length > 0) {
    track.innerHTML = currentLyricsData.map((line, idx) => `
      <div class="music-lyric-line" id="lyricLine_${idx}" data-idx="${idx}" data-time="${line.time.toFixed(2)}" onclick="handleLyricLineTap(${idx}, event)" title="Klik saat mendengar lirik ini untuk sinkronisasi otomatis">
        ${escapeHTML(line.text)}
      </div>
    `).join('');
    initLyricsWheelScroll();
  }
}

let isLyricsManualHoverScroll = false;
let lyricsManualScrollY = 0;
let lyricsManualScrollTimer = null;

function initLyricsWheelScroll() {
  const scrollContainer = document.getElementById('musicLyricsScroll');
  const track = document.getElementById('musicLyricsTrack');
  if (!scrollContainer || !track || scrollContainer._wheelAttached) return;
  scrollContainer._wheelAttached = true;

  scrollContainer.addEventListener('wheel', (e) => {
    if (!currentLyricsData || currentLyricsData.length === 0) return;
    e.preventDefault();

    if (!isLyricsManualHoverScroll) {
      const currentTransform = track.style.transform;
      const match = currentTransform.match(/translateY\((-?\d+)px\)/);
      lyricsManualScrollY = match ? parseInt(match[1], 10) : 0;
    }

    isLyricsManualHoverScroll = true;
    lyricsManualScrollY -= e.deltaY * 0.45;

    const maxScroll = (scrollContainer.clientHeight / 2);
    const minScroll = (scrollContainer.clientHeight / 2) - track.scrollHeight;
    lyricsManualScrollY = Math.max(minScroll, Math.min(maxScroll, lyricsManualScrollY));

    track.style.transform = `translateY(${Math.round(lyricsManualScrollY)}px)`;

    clearTimeout(lyricsManualScrollTimer);
    lyricsManualScrollTimer = setTimeout(() => {
      isLyricsManualHoverScroll = false;
    }, 4500);
  }, { passive: false });
}

function updateLyricsSync(currTime) {
  if (!currentLyricsData || currentLyricsData.length === 0) return;
  const track = document.getElementById('musicLyricsTrack');
  const scrollContainer = document.getElementById('musicLyricsScroll');
  if (!track || !scrollContainer) return;

  // Terapkan fine-tuning offset waktu khusus lagu ini atau default 0
  const offset = getSongLyricsOffset(activeMusic);
  const adjustedTime = Math.max(0, currTime + offset);

  let newIndex = -1;
  for (let i = currentLyricsData.length - 1; i >= 0; i--) {
    if (adjustedTime >= currentLyricsData[i].time) {
      newIndex = i;
      break;
    }
  }

  if (newIndex === currentLyricsIndex) return;
  currentLyricsIndex = newIndex;

  const lines = track.querySelectorAll('.music-lyric-line');
  lines.forEach((lineElem, idx) => {
    lineElem.classList.remove('active', 'passed');
    if (idx === currentLyricsIndex) {
      lineElem.classList.add('active');
    } else if (idx < currentLyricsIndex) {
      lineElem.classList.add('passed');
    }
  });

  if (!isLyricsManualHoverScroll) {
    if (currentLyricsIndex >= 0 && lines[currentLyricsIndex]) {
      const activeElem = lines[currentLyricsIndex];
      const containerHeight = scrollContainer.clientHeight || 68;
      const targetY = (containerHeight / 2) - (activeElem.offsetTop + (activeElem.offsetHeight / 2));
      track.style.transform = `translateY(${Math.round(targetY)}px)`;
    } else {
      track.style.transform = 'translateY(0px)';
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// 🖐️ DRAGGABLE MUSIC WIDGET (OBS / HOST CUSTOM POSITIONING)
// ═════════════════════════════════════════════════════════════════════════════

let isMusicWidgetDragInitialized = false;

function initDraggableMusicWidget() {
  const widget = document.getElementById('musicWidget');
  if (!widget || isMusicWidgetDragInitialized) return;
  isMusicWidgetDragInitialized = true;

  let isPointerDown = false;
  let hasDragged = false;
  let startX = 0;
  let startY = 0;
  let elemLeft = 0;
  let elemTop = 0;

  // Restore saved position on startup
  applySavedMusicWidgetPos();

  widget.addEventListener('pointerdown', (e) => {
    // Ignore drag if clicking inside buttons, inputs, selects, links, or textareas
    if (e.target.closest('button, input, select, a, textarea, .music-lyrics-quick-btn')) return;

    // Only respond to primary button (left click / touch)
    if (e.button !== undefined && e.button !== 0) return;

    isPointerDown = true;
    hasDragged = false;
    startX = e.clientX;
    startY = e.clientY;

    const rect = widget.getBoundingClientRect();
    elemLeft = rect.left;
    elemTop = rect.top;

    try {
      widget.setPointerCapture(e.pointerId);
    } catch(err) {}
  });

  widget.addEventListener('pointermove', (e) => {
    if (!isPointerDown) return;

    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    if (!hasDragged) {
      if (Math.hypot(dx, dy) < 6) return; // Prevent accidental drag on simple tap/click
      hasDragged = true;
      widget.classList.add('is-dragging');
    }

    const margin = 8;
    const rect = widget.getBoundingClientRect();
    const widgetW = Math.round(rect.width) || widget.offsetWidth || 260;
    const widgetH = Math.round(rect.height) || widget.offsetHeight || 110;
    const maxLeft = Math.max(margin, window.innerWidth - widgetW - margin);
    const maxTop = Math.max(margin, window.innerHeight - widgetH - margin);

    const clampedX = Math.max(margin, Math.min(elemLeft + dx, maxLeft));
    const clampedY = Math.max(margin, Math.min(elemTop + dy, maxTop));

    widget.style.left = `${Math.round(clampedX)}px`;
    widget.style.top = `${Math.round(clampedY)}px`;
    widget.style.right = 'auto';
    widget.style.bottom = 'auto';
  });

  const onPointerUp = (e) => {
    if (!isPointerDown) return;
    isPointerDown = false;

    try {
      widget.releasePointerCapture(e.pointerId);
    } catch(err) {}

    widget.classList.remove('is-dragging');

    if (hasDragged) {
      const pos = {
        left: widget.style.left,
        top: widget.style.top
      };
      localStorage.setItem('music_widget_custom_pos', JSON.stringify(pos));
    }
    hasDragged = false;
  };

  widget.addEventListener('pointerup', onPointerUp);
  widget.addEventListener('pointercancel', onPointerUp);

  // Keep clamped to viewport on window resize
  window.addEventListener('resize', () => {
    applySavedMusicWidgetPos();
  });
}

function applySavedMusicWidgetPos() {
  const widget = document.getElementById('musicWidget');
  if (!widget) return;
  try {
    const saved = localStorage.getItem('music_widget_custom_pos');
    if (saved) {
      const pos = JSON.parse(saved);
      if (pos && pos.left && pos.top) {
        const pLeft = parseFloat(pos.left);
        const pTop = parseFloat(pos.top);
        if (!isNaN(pLeft) && !isNaN(pTop)) {
          const margin = 8;
          const rect = widget.getBoundingClientRect();
          const widgetW = Math.round(rect.width) || widget.offsetWidth || 260;
          const widgetH = Math.round(rect.height) || widget.offsetHeight || 110;
          const maxLeft = Math.max(margin, window.innerWidth - widgetW - margin);
          const maxTop = Math.max(margin, window.innerHeight - widgetH - margin);
          const clampedX = Math.max(margin, Math.min(pLeft, maxLeft));
          const clampedY = Math.max(margin, Math.min(pTop, maxTop));

          widget.style.left = `${Math.round(clampedX)}px`;
          widget.style.top = `${Math.round(clampedY)}px`;
          widget.style.right = 'auto';
          widget.style.bottom = 'auto';
          return;
        }
      }
    }
  } catch(e) {}

  // Fallback to default stylesheet bottom/right position
  widget.style.left = '';
  widget.style.top = '';
  widget.style.right = '';
  widget.style.bottom = '';
}

window.resetMusicWidgetPos = function() {
  localStorage.removeItem('music_widget_custom_pos');
  const widget = document.getElementById('musicWidget');
  if (widget) {
    widget.style.left = '';
    widget.style.top = '';
    widget.style.right = '';
    widget.style.bottom = '';
  }
  if (typeof showToast === 'function') {
    showToast('Posisi pemutar musik direset ke kanan bawah!', 2000);
  }
};

function showMusicNotif(requesterName, title) {
  const container = document.getElementById('musicNotifContainer');
  const widget = document.getElementById('musicWidget');
  if (!container) return;

  if (widget) {
    widget.classList.add('has-docked-notif');
    try {
      const rect = widget.getBoundingClientRect();
      if (rect.top < 45) {
        container.style.top = 'auto';
        container.style.bottom = '-38px';
      } else {
        container.style.top = '-38px';
        container.style.bottom = 'auto';
      }
    } catch(e) {}
  }

  // Bunyikan SFX Radio FM Tuning & DJ Cue saat request masuk (hanya jika diaktifkan)
  if (musicSettings.radioSFX !== false && window.sounds && typeof window.sounds.playRadioRequest === 'function') {
    window.sounds.playRadioRequest();
  }
  
  // Prevent flooding: limit to 1 active notification by clearing the container first
  container.innerHTML = '';
  
  const notif = document.createElement('div');
  notif.className = 'music-notif';
  
  const cleanName = escapeHTML((requesterName || 'Viewer').replace(/[<>]/g, '').replace(/^@+/, '').trim());
  const cleanTitle = escapeHTML(cleanSongTitleForLyrics(title, title) || title);

  notif.innerHTML = `
    <span class="music-notif-icon"><i class="fa-solid fa-music"></i></span>
    <div class="music-notif-content">
      <span class="music-notif-user">@${cleanName}</span>
      <span class="music-notif-action">request:</span>
      <span class="music-notif-title" title="${cleanTitle}">${cleanTitle}</span>
      <span class="music-notif-badge">Masuk Antrian</span>
    </div>
  `;
  
  container.appendChild(notif);
  
  setTimeout(() => {
    if (notif.parentNode === container) {
      container.removeChild(notif);
    }
    if (container.children.length === 0 && widget) {
      widget.classList.remove('has-docked-notif');
    }
  }, 3100);
}

let lastMusicFollowerWarningTime = 0;
function showMusicFollowerWarningNotif(requesterName) {
  const now = Date.now();
  if (now - lastMusicFollowerWarningTime < 4500) return; // Cooldown 4.5 detik cegah spam
  lastMusicFollowerWarningTime = now;

  const container = document.getElementById('musicNotifContainer');
  const widget = document.getElementById('musicWidget');
  if (!container) return;

  if (widget) {
    widget.classList.add('has-docked-notif');
    try {
      const rect = widget.getBoundingClientRect();
      if (rect.top < 45) {
        container.style.top = 'auto';
        container.style.bottom = '-38px';
      } else {
        container.style.top = '-38px';
        container.style.bottom = 'auto';
      }
    } catch(e) {}
  }

  if (window.sounds && typeof window.sounds.playPop === 'function') {
    try { window.sounds.playPop(); } catch(e) {}
  }

  container.innerHTML = '';
  const notif = document.createElement('div');
  notif.className = 'music-notif music-notif-warning';

  const cleanName = escapeHTML((requesterName || 'Viewer').replace(/[<>]/g, '').replace(/^@+/, '').trim());
  notif.innerHTML = `
    <span class="music-notif-icon" style="color: #f43f5e;"><i class="fa-solid fa-user-lock"></i></span>
    <div class="music-notif-content">
      <span class="music-notif-user">@${cleanName}</span>
      <span class="music-notif-action">Follow live dulu untuk request lagu!</span>
    </div>
  `;

  container.appendChild(notif);

  setTimeout(() => {
    if (notif.parentNode === container) {
      container.removeChild(notif);
    }
    if (container.children.length === 0 && widget) {
      widget.classList.remove('has-docked-notif');
    }
  }, 3200);
}

let lastMusicCooldownWarningTime = 0;
function showMusicCooldownWarningNotif(requesterName, remainingSec) {
  const now = Date.now();
  if (now - lastMusicCooldownWarningTime < 3000) return; // Cooldown notifikasi cegah spam
  lastMusicCooldownWarningTime = now;

  const container = document.getElementById('musicNotifContainer');
  const widget = document.getElementById('musicWidget');
  if (!container) return;

  if (widget) {
    widget.classList.add('has-docked-notif');
    try {
      const rect = widget.getBoundingClientRect();
      if (rect.top < 45) {
        container.style.top = 'auto';
        container.style.bottom = '-38px';
      } else {
        container.style.top = '-38px';
        container.style.bottom = 'auto';
      }
    } catch(e) {}
  }

  if (window.sounds && typeof window.sounds.playPop === 'function') {
    try { window.sounds.playPop(); } catch(e) {}
  }

  container.innerHTML = '';
  const notif = document.createElement('div');
  notif.className = 'music-notif music-notif-cooldown';

  const cleanName = escapeHTML((requesterName || 'Viewer').replace(/[<>]/g, '').replace(/^@+/, '').trim());
  notif.innerHTML = `
    <span class="music-notif-icon" style="color: #f59e0b;"><i class="fa-solid fa-hourglass-half"></i></span>
    <div class="music-notif-content">
      <span class="music-notif-user">@${cleanName}</span>
      <span class="music-notif-action">Tunggu ${remainingSec}d lagi untuk request!</span>
    </div>
  `;

  container.appendChild(notif);

  setTimeout(() => {
    if (notif.parentNode === container) {
      container.removeChild(notif);
    }
    if (container.children.length === 0 && widget) {
      widget.classList.remove('has-docked-notif');
    }
  }, 3200);
}

let lastMusicLimitWarningTime = 0;
function showMusicUserLimitWarningNotif(requesterName, maxUser) {
  const now = Date.now();
  if (now - lastMusicLimitWarningTime < 3000) return; // Anti-spam jeda notifikasi
  lastMusicLimitWarningTime = now;

  const container = document.getElementById('musicNotifContainer');
  const widget = document.getElementById('musicWidget');
  if (!container) return;

  if (widget) {
    widget.classList.add('has-docked-notif');
    try {
      const rect = widget.getBoundingClientRect();
      if (rect.top < 45) {
        container.style.top = 'auto';
        container.style.bottom = '-38px';
      } else {
        container.style.top = '-38px';
        container.style.bottom = 'auto';
      }
    } catch(e) {}
  }

  if (window.sounds && typeof window.sounds.playPop === 'function') {
    try { window.sounds.playPop(); } catch(e) {}
  }

  container.innerHTML = '';
  const notif = document.createElement('div');
  notif.className = 'music-notif music-notif-limit';

  const cleanName = escapeHTML((requesterName || 'Viewer').replace(/[<>]/g, '').replace(/^@+/, '').trim());
  notif.innerHTML = `
    <span class="music-notif-icon" style="color: #38bdf8;"><i class="fa-solid fa-list-check"></i></span>
    <div class="music-notif-content">
      <span class="music-notif-user">@${cleanName}</span>
      <span class="music-notif-action">Limit request penuh (maks ${maxUser || 2} lagu)!</span>
    </div>
  `;

  container.appendChild(notif);

  setTimeout(() => {
    if (notif.parentNode === container) {
      container.removeChild(notif);
    }
    if (container.children.length === 0 && widget) {
      widget.classList.remove('has-docked-notif');
    }
  }, 3200);
}

let lastMusicGlobalFullWarningTime = 0;
function showMusicGlobalFullWarningNotif(requesterName, maxGlobal) {
  const now = Date.now();
  if (now - lastMusicGlobalFullWarningTime < 3000) return; // Anti-spam jeda notifikasi
  lastMusicGlobalFullWarningTime = now;

  const container = document.getElementById('musicNotifContainer');
  const widget = document.getElementById('musicWidget');
  if (!container) return;

  if (widget) {
    widget.classList.add('has-docked-notif');
    try {
      const rect = widget.getBoundingClientRect();
      if (rect.top < 45) {
        container.style.top = 'auto';
        container.style.bottom = '-38px';
      } else {
        container.style.top = '-38px';
        container.style.bottom = 'auto';
      }
    } catch(e) {}
  }

  if (window.sounds && typeof window.sounds.playPop === 'function') {
    try { window.sounds.playPop(); } catch(e) {}
  }

  container.innerHTML = '';
  const notif = document.createElement('div');
  notif.className = 'music-notif music-notif-full';

  const cleanName = escapeHTML((requesterName || 'Penonton').replace(/[<>]/g, '').replace(/^@+/, '').trim());
  notif.innerHTML = `
    <span class="music-notif-icon" style="color: #f43f5e;"><i class="fa-solid fa-compact-disc"></i></span>
    <div class="music-notif-content">
      <span class="music-notif-user">@${cleanName}</span>
      <span class="music-notif-action">Antrian lagu penuh (maks ${maxGlobal || 20} lagu)!</span>
    </div>
  `;

  container.appendChild(notif);

  setTimeout(() => {
    if (notif.parentNode === container) {
      container.removeChild(notif);
    }
    if (container.children.length === 0 && widget) {
      widget.classList.remove('has-docked-notif');
    }
  }, 3200);
}

function onPlayerStateChange(event) {
  const vinyl = document.getElementById('musicVinyl');
  const eq = document.getElementById('musicEqualizer');
  const headerEq = document.getElementById('musicHeaderEqualizer');
  
  // If the video ends (state 0), play the next one
  if (event.data == YT.PlayerState.ENDED) {
    ytPlayAttempts = 0;
    if (vinyl) vinyl.classList.remove('playing');
    if (eq) eq.classList.remove('playing');
    if (headerEq) headerEq.classList.remove('playing');
    clearInterval(musicProgressInterval);
    
    playNextMusic();
  }
  
  if (event.data == YT.PlayerState.PLAYING) {
    ytPlayAttempts = 0;
    if (vinyl) vinyl.classList.add('playing');
    if (eq) eq.classList.add('playing');
    if (headerEq) headerEq.classList.add('playing');
    broadcastMusicState(false);
    
    let progressSyncTick = 0;
    clearInterval(musicProgressInterval);
    musicProgressInterval = setInterval(() => {
      if (ytPlayer && ytPlayer.getCurrentTime && ytPlayer.getDuration) {
        const curr = ytPlayer.getCurrentTime();
        const total = ytPlayer.getDuration();
        const timeStr = `${formatMusicTime(curr)} / ${formatMusicTime(total)}`;
        const progElem = document.getElementById('musicTimeProgress');
        if (progElem) progElem.textContent = timeStr;
        
        const fill = document.getElementById('musicProgressFill');
        if (fill && total > 0) {
          fill.style.width = `${(curr / total) * 100}%`;
        }

        // Real-time Spotify playlist row sync
        const spotifyDuration = document.getElementById('spotifyActiveDuration');
        if (spotifyDuration) spotifyDuration.textContent = timeStr;
        const spotifyFill = document.getElementById('spotifyActiveProgressFill');
        if (spotifyFill && total > 0) {
          spotifyFill.style.width = `${(curr / total) * 100}%`;
        }

        // Real-time Synced Karaoke Lyrics Update
        updateLyricsSync(curr);

        // Sync timeline to dashboard every 1 second (4 ticks of 250ms)
        progressSyncTick++;
        if (progressSyncTick % 4 === 0) {
          broadcastMusicState(false);
        }
      }
    }, 250);
  } else {
    if (vinyl) vinyl.classList.remove('playing');
    if (eq) eq.classList.remove('playing');
    clearInterval(musicProgressInterval);
    if (event.data == YT.PlayerState.PAUSED) {
      broadcastMusicState(true);
    }
  }

  // If video is cued/paused but not playing, force play only if music should be playing (max 3 attempts)
  if (event.data == YT.PlayerState.CUED || event.data == YT.PlayerState.PAUSED) {
    if (!isMusicPlaying || !activeMusic) return; // Prevent looping when queue is empty or stopped

    if (ytPlayAttempts < 3) {
      ytPlayAttempts++;
      setTimeout(() => {
        try { 
          if (isMusicPlaying && activeMusic) ytPlayer.playVideo(); 
        } catch(e) {}
      }, 500);
    } else {
      console.warn("[Music] Autoplay blocked by browser. User interaction required.");
      if (typeof showToast === 'function') {
        showToast("Tolong KLIK layar game 1x agar musik bisa berbunyi!", 5000);
      }
    }
  }
}

function onPlayerError(event) {
  console.warn('[Music] YouTube player error:', event.data);
  
  // Try fallback candidates if available (e.g. lyrics/covers instead of embed-restricted official videos)
  if (activeMusic && activeMusic.candidates && activeMusic.candidates.length > 1) {
    activeMusic.candidates.shift(); // Remove the failed one
    const nextCandidate = activeMusic.candidates[0];
    if (nextCandidate) {
      console.log(`[Music] Trying fallback candidate: ${nextCandidate.title} (${nextCandidate.videoId})`);
      document.getElementById('musicThumb').src = nextCandidate.thumbnail || 'assets/bg_nature.png';
      document.getElementById('musicTitle').textContent = nextCandidate.title;
      const progElem = document.getElementById('musicTimeProgress');
      if (progElem) progElem.textContent = `0:00 / ${nextCandidate.duration || '0:00'}`;
      const fill = document.getElementById('musicProgressFill');
      if (fill) fill.style.width = '0%';
      const spotifyDur = document.getElementById('spotifyActiveDuration');
      if (spotifyDur) spotifyDur.textContent = `0:00 / ${nextCandidate.duration || '0:00'}`;
      const spotifyProg = document.getElementById('spotifyActiveProgressFill');
      if (spotifyProg) spotifyProg.style.width = '0%';
      
      if (ytPlayer && ytPlayer.loadVideoById) {
        ytPlayer.loadVideoById(nextCandidate.videoId);
      }
      fetchSongLyrics(nextCandidate);
      return;
    }
  }
  
  // Skip to next song on error (e.g. restricted/unavailable video)
  setTimeout(() => playNextMusic(), 1000);
}

function broadcastMusicState(isPausedOverride) {
  if (!localSocket) return;
  try {
    let isPaused = false;
    let currTime = 0;
    let totalDur = 0;
    if (ytPlayer) {
      if (typeof ytPlayer.getPlayerState === 'function') {
        const st = ytPlayer.getPlayerState();
        isPaused = (isPausedOverride !== undefined) ? isPausedOverride : (st === 2);
      }
      if (typeof ytPlayer.getCurrentTime === 'function') currTime = Math.floor(ytPlayer.getCurrentTime() || 0);
      if (typeof ytPlayer.getDuration === 'function') totalDur = Math.floor(ytPlayer.getDuration() || 0);
    }
    const statePayload = {
      isPlaying: isMusicPlaying && !!activeMusic,
      isPaused: isPaused,
      activeMusic: activeMusic ? {
        videoId: activeMusic.videoId,
        title: activeMusic.title,
        author: activeMusic.author || "",
        thumbnail: activeMusic.thumbnail || "assets/bg_nature.png",
        duration: activeMusic.duration || "",
        requesterName: activeMusic.requesterName || "Host",
        requesterImg: activeMusic.requesterImg || ""
      } : null,
      queue: (musicQueue || []).map(m => ({
        videoId: m.videoId,
        title: m.title,
        author: m.author || "",
        thumbnail: m.thumbnail || "assets/bg_nature.png",
        duration: m.duration || "",
        requesterName: m.requesterName || "Viewer"
      })),
      volume: (typeof musicSettings !== 'undefined' && typeof musicSettings.volume === 'number') ? musicSettings.volume : 50,
      currentTime: currTime,
      totalDuration: totalDur,
      formattedTime: `${formatMusicTime(currTime)} / ${activeMusic?.duration || formatMusicTime(totalDur)}`
    };
    localSocket.emit("music-state-update", statePayload);
  } catch(e) {
    console.error('[Music] Error broadcasting music state:', e);
  }
}
window.broadcastMusicState = broadcastMusicState;

function playNextMusic() {
  if (!ytPlayerReady || !ytPlayer || !ytPlayer.loadVideoById) {
    // If API isn't ready yet, retry in 500ms
    setTimeout(playNextMusic, 500);
    return;
  }

  const hostSkipBtn = document.getElementById('hostSkipBtn');
  
  if (musicQueue.length === 0) {
    isMusicPlaying = false;
    activeMusic = null;
    currentLyricsData = [];
    currentLyricsIndex = -1;
    resetLyricsUI();
    updateLyricsOffsetUI();
    document.getElementById('musicWidget').classList.remove('show');
    if (hostSkipBtn) hostSkipBtn.style.display = 'none';
    if (window.sounds) window.sounds.stopRadioAmbiance();
    if (ytPlayer && ytPlayer.stopVideo) {
      try { ytPlayer.stopVideo(); } catch(e) {}
    }
    broadcastMusicState();
    return;
  }
  
  isMusicPlaying = true;
  if (hostSkipBtn) hostSkipBtn.style.display = 'flex';
  
  activeMusic = musicQueue.shift();
  updateMusicQueueUI();
  updateLyricsOffsetUI();
  fetchSongLyrics(activeMusic);
  
  document.getElementById('musicThumb').src = activeMusic.thumbnail || 'assets/bg_nature.png';
  document.getElementById('musicTitle').textContent = activeMusic.title;
  document.getElementById('musicRequester').textContent = activeMusic.requesterName || 'user';
  
  const progElem = document.getElementById('musicTimeProgress');
  if (progElem) progElem.textContent = `0:00 / ${activeMusic.duration || '0:00'}`;
  
  const fill = document.getElementById('musicProgressFill');
  if (fill) fill.style.width = '0%';

  const spotifyDur = document.getElementById('spotifyActiveDuration');
  if (spotifyDur) spotifyDur.textContent = `0:00 / ${activeMusic.duration || '0:00'}`;
  const spotifyProg = document.getElementById('spotifyActiveProgressFill');
  if (spotifyProg) spotifyProg.style.width = '0%';
  
  document.getElementById('musicWidget').classList.add('show');
  
  if (window.sounds && musicSettings.radioAmbiance) {
    window.sounds.startRadioAmbiance();
  }

  if (ytPlayer && ytPlayer.loadVideoById) {
    ytPlayer.unMute();
    ytPlayer.setVolume(musicSettings.volume);
    ytPlayer.loadVideoById(activeMusic.videoId);
  }
  broadcastMusicState();
}

// Fetch words on load
let wordsLoaded = false;
let allTargetWords = { 3: [], 4: [], 5: [], 6: [], 7: [], 8: [] };
let allValidWords = { 3: [], 4: [], 5: [], 6: [], 7: [], 8: [] };
let allValidWordsSets = { 3: new Set(), 4: new Set(), 5: new Set(), 6: new Set(), 7: new Set(), 8: new Set() };
let allAvailableWords = { 3: [], 4: [], 5: [], 6: [], 7: [], 8: [] };
let fullValidDictionary = new Set();
let VALID_WORDS_SET = new Set();

function syncValidWordsSet() {
  VALID_WORDS_SET = new Set(VALID_WORDS || []);
}

function loadWordLists(lang) {
  return new Promise((resolve, reject) => {
    let fetches = [];
    if (lang === 'mixed') {
      fetches = [
        Promise.all([fetch(`wordlist/target_words_3.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/target_words_id_3.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words_3.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/valid_words_id_3.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/target_words_4.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/target_words_id_4.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words_4.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/valid_words_id_4.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/target_words.txt`).then(r => r.text()), fetch(`wordlist/target_words_id.txt`).then(r => r.text())]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words.txt`).then(r => r.text()), fetch(`wordlist/valid_words_id.txt`).then(r => r.text())]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/target_words_6.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/target_words_id_6.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words_6.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/valid_words_id_6.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/target_words_7.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/target_words_id_7.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words_7.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/valid_words_id_7.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/target_words_8.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/target_words_id_8.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]),
        Promise.all([fetch(`wordlist/valid_words_8.txt`).then(r => r.text()).catch(()=>""), fetch(`wordlist/valid_words_id_8.txt`).then(r => r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1])
      ];
    } else {
      let suffix = lang === 'en' ? '' : '_id';
      fetches = [
        fetch(`wordlist/target_words${suffix}_3.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/valid_words${suffix}_3.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/target_words${suffix}_4.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/valid_words${suffix}_4.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/target_words${suffix}.txt`).then(r => r.text()),
        fetch(`wordlist/valid_words${suffix}.txt`).then(r => r.text()),
        fetch(`wordlist/target_words${suffix}_6.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/valid_words${suffix}_6.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/target_words${suffix}_7.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/valid_words${suffix}_7.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/target_words${suffix}_8.txt`).then(r => r.text()).catch(() => ""),
        fetch(`wordlist/valid_words${suffix}_8.txt`).then(r => r.text()).catch(() => "")
      ];
    }
    
    // FETCH FULL DICTIONARY FOR UNLIMITED LENGTH IN WORD GRID
    if (lang === 'mixed') {
      fetches.push(Promise.all([fetch('wordlist/dictionary.txt').then(r=>r.text()).catch(()=>""), fetch('wordlist/kamus.txt').then(r=>r.text()).catch(()=>"")]).then(r => r[0] + '\n' + r[1]));
    } else if (lang === 'id') {
      fetches.push(fetch('wordlist/kamus.txt').then(r=>r.text()).catch(()=>""));
    } else {
      fetches.push(fetch('wordlist/dictionary.txt').then(r=>r.text()).catch(()=>""));
    }

    Promise.all(fetches).then((results) => {
      const lengths = [3, 4, 5, 6, 7, 8];
      lengths.forEach((len, idx) => {
        const tStr = typeof results[idx * 2] === 'string' ? results[idx * 2] : "";
        const vStr = typeof results[idx * 2 + 1] === 'string' ? results[idx * 2 + 1] : "";
        allTargetWords[len] = tStr.split('\n').map(w => w.trim().toUpperCase()).filter(w => w.length === len);
        const validList = vStr.split('\n').map(w => w.trim().toUpperCase()).filter(w => w.length === len);
        allValidWords[len] = [...new Set([...validList, ...allTargetWords[len]])];
        allValidWordsSets[len] = new Set(allValidWords[len]);
        allAvailableWords[len] = [...allTargetWords[len]];
        shuffleArray(allAvailableWords[len]);
      });

      wordsLoaded = true;
      betweenleSortedDicts = {};
      syncValidWordsSet();
      console.log(`Loaded target words - Length 3: ${allTargetWords[3].length}, 4: ${allTargetWords[4].length}, 5: ${allTargetWords[5].length}, 6: ${allTargetWords[6].length}, 7: ${allTargetWords[7].length}, 8: ${allTargetWords[8].length}`);
      
      const fullDictText = results[results.length - 1] || "";
      fullValidDictionary.clear();
      fullDictText.split('\n').forEach(w => {
         const word = w.trim().replace(/"/g, '').toUpperCase();
         if (word.length >= 2) fullValidDictionary.add(word);
      });
      console.log(`Loaded FULL dictionary: ${fullValidDictionary.size} words`);

      if (typeof initWordPyramidExtendableSets === 'function') {
        try { initWordPyramidExtendableSets(); } catch(e) { console.error('Error initializing Piramida Kata extendable sets:', e); }
      }
      
      resolve();
    }).catch(err => {
      console.error("Failed to load wordlists:", err);
      reject(err);
    });
  });
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function getRandomWord() {
  if (currentGameMode === 'colorfit') {
    const colors = ['R', 'G', 'B', 'Y', 'P', 'O'];
    let result = '';
    let availableColors = [...colors];
    for (let i = 0; i < WORD_LENGTH; i++) {
      if (isNoRepeatMode) {
        if (availableColors.length === 0) availableColors = [...colors];
        const idx = Math.floor(Math.random() * availableColors.length);
        result += availableColors[idx];
        availableColors.splice(idx, 1);
      } else {
        result += colors[Math.floor(Math.random() * colors.length)];
      }
    }
    return result;
  }

  if (TARGET_WORDS.length === 0) return WORD_LENGTH === 5 ? "HELLO" : "RANDOM"; // fallback

  let pool = TARGET_WORDS;
  const isNoRepeatActive = isNoRepeatMode && (currentGameMode === 'wordle' || currentGameMode === 'word500' || currentGameMode === 'wordfit');
  if (isNoRepeatActive) {
    pool = TARGET_WORDS.filter(w => new Set(w).size === w.length);
    if (pool.length === 0) pool = TARGET_WORDS; // fallback
  }

  if (availableWords.length === 0) {
    availableWords = [...pool];
    shuffleArray(availableWords);
    allAvailableWords[WORD_LENGTH] = availableWords;
  }
  
  let word = availableWords.pop();
  if (isNoRepeatActive && new Set(word).size !== word.length) {
    // If somehow a non-isogram got in, keep searching
    while (word && new Set(word).size !== word.length) {
      if (availableWords.length === 0) {
        availableWords = [...pool];
        shuffleArray(availableWords);
        allAvailableWords[WORD_LENGTH] = availableWords;
      }
      word = availableWords.pop();
    }
  }
  return word || "HELLO";
}

// DOM Elements
const gameSelectOverlay = document.getElementById('gameSelectOverlay');
const loginOverlay = document.getElementById('loginOverlay');
const gameContainer = document.getElementById('gameContainer');
const bgLayer = document.getElementById('bgLayer');
const connectBtn = document.getElementById('connectBtn');
const loginStatus = document.getElementById('loginStatus');
const roomHost = document.getElementById('roomHost');
const board = document.getElementById('board');
const toastContainer = document.getElementById('toastContainer');
const roundNumber = document.getElementById('roundNumber');

// ─── Game Selection ───
function selectGame(mode) {
  currentGameMode = mode;
  // NOTE: Do NOT persist gameMode to sessionStorage here.
  // It is saved after successful TikTok connection to prevent
  // autoReconnect from firing when the user hasn't logged in yet.

  initWeeklyLeaderboard();

  // Update login title and chip
  const loginTitle = document.getElementById('loginTitle');
  const loginGameChip = document.getElementById('loginGameChip');
  const gameNames = {
    wordle: 'WORDLE',
    word500: window.w500UseMastermind ? 'WORD PEGS' : 'WORD500',
    wordfit: 'WORD FIT',
    colorfit: 'COLOR FIT',
    fillblanks: 'WORD FILL',
    wordtango: 'WORD TANGO',
    wordgrid: 'WORD GRID',
    squareword: 'KOTAK KATA 5×5',
    wordladder: 'WORD LADDER',
    betweenle: 'BETWEENLE',
    cascadle: 'CASCADLE',
    wanderwords: 'WANDER WORDS',
    wordcluster: 'WORD CLUSTER',
    wordmatch: 'WORD MATCH',
    wordpyramid: 'WORD PYRAMID'
  };
  const titleName = gameNames[mode] || mode.toUpperCase();

  if (loginTitle) {
    loginTitle.textContent = `TIKTOK ${titleName}`;
  }
  if (loginGameChip) {
    loginGameChip.textContent = `MODE AKTIF: ${titleName}`;
  }

  // If already connected to TikTok, skip login and go straight to game
  if (isConnectedToTikTok && socket && socket.connected) {
    gameSelectOverlay.style.display = 'none';
    loginOverlay.style.display = 'none';
    gameContainer.style.display = 'flex';
    document.getElementById('hostMusicControl').style.display = 'flex';
    applyGameModeUI();
    startNewRound();
    showToast(`🎮 Ganti ke ${titleName}`, 2000);
    return;
  }

  // Not yet connected — show login screen
  gameSelectOverlay.style.display = 'none';
  loginOverlay.style.display = 'flex';
}

function switchGameMode(e) {
  if (e) e.stopPropagation();
  // Close settings
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');

  if (!isConnectedToTikTok && gameContainer.style.display === 'none') {
    currentGameMode = '';
    try { sessionStorage.removeItem('wordle_gameMode'); } catch(e) {}
    loginOverlay.style.display = 'none';
    gameContainer.style.display = 'none';
    gameSelectOverlay.style.display = 'flex';
    return;
  }

  // Seamless switch
  if (currentGameMode === 'wordle') currentGameMode = 'word500';
  else if (currentGameMode === 'word500') currentGameMode = 'wordfit';
  else if (currentGameMode === 'wordfit') currentGameMode = 'colorfit';
  else if (currentGameMode === 'colorfit') currentGameMode = 'fillblanks';
  else if (currentGameMode === 'fillblanks') currentGameMode = 'wordtango';
  else if (currentGameMode === 'wordtango') currentGameMode = 'wordgrid';
  else if (currentGameMode === 'wordgrid') currentGameMode = 'squareword';
  else if (currentGameMode === 'squareword') currentGameMode = 'wordladder';
  else if (currentGameMode === 'wordladder') currentGameMode = 'betweenle';
  else if (currentGameMode === 'betweenle') currentGameMode = 'cascadle';
  else if (currentGameMode === 'cascadle') currentGameMode = 'wanderwords';
  else if (currentGameMode === 'wanderwords') currentGameMode = 'wordcluster';
  else if (currentGameMode === 'wordcluster') currentGameMode = 'wordmatch';
  else if (currentGameMode === 'wordmatch') currentGameMode = 'wordpyramid';
  else currentGameMode = 'wordle';
  try { sessionStorage.setItem('wordle_gameMode', currentGameMode); } catch(e) {}

  applyGameModeUI();
  initWeeklyLeaderboard();
  startNewRound();
}

function changeGameModeDirect(mode, e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  if (wgHintInterval) {
    clearInterval(wgHintInterval);
    wgHintInterval = null;
  }
  
  if (!mode) return;

  if (!isConnectedToTikTok && gameContainer.style.display === 'none') {
    currentGameMode = mode;
    try { sessionStorage.setItem('wordle_gameMode', mode); } catch(e) {}
    loginOverlay.style.display = 'none';
    gameContainer.style.display = 'none';
    gameSelectOverlay.style.display = 'flex';
    return;
  }

  currentGameMode = mode;
  try { sessionStorage.setItem('wordle_gameMode', currentGameMode); } catch(e) {}

  const selectElement = document.getElementById('switchGameSelect');
  if (selectElement) selectElement.value = "";

  tourneySessionScores = {};
  tourneySessionRounds = 0;
  if (typeof updateTourneyUIElements === 'function') updateTourneyUIElements();

  applyGameModeUI();
  initWeeklyLeaderboard();
  startNewRound();
}

function applyGameModeUI() {
  const headerTitle = document.getElementById('headerTitle');
  const hintContainer = document.getElementById('hintContainer');
  const bestGuessContainer = document.getElementById('bestGuessContainer');
  const switchBtn = document.getElementById('switchGameBtn');
  const wordTangoInfoContainer = document.getElementById('wordTangoInfoContainer');
  const tangoPoolContainer = document.getElementById('tangoPoolContainer');
  const tangoGuessFeed = document.getElementById('tangoGuessFeed');

  const wordGridInfoContainer = document.getElementById('wordGridInfoContainer');
  const wordGridContainer = document.getElementById('wordGridContainer');
  const boardObj = document.getElementById('board');
  const squarewordBoardContainer = document.getElementById('squarewordBoardContainer');
  if (squarewordBoardContainer) squarewordBoardContainer.style.display = 'none';
  const wordLadderInfoContainer = document.getElementById('wordLadderInfoContainer');
  if (wordLadderInfoContainer) wordLadderInfoContainer.style.display = 'none';
  const betweenleContainer = document.getElementById('betweenleContainer');
  if (betweenleContainer) betweenleContainer.style.display = 'none';
  const cascadleContainer = document.getElementById('cascadleContainer');
  if (cascadleContainer) cascadleContainer.style.display = 'none';
  const wanderWordsContainer = document.getElementById('wanderWordsContainer');
  if (wanderWordsContainer) wanderWordsContainer.style.display = 'none';
  const wordClusterContainer = document.getElementById('wordClusterContainer');
  if (wordClusterContainer) wordClusterContainer.style.display = 'none';
  const wordMatchContainer = document.getElementById('wordMatchContainer');
  if (wordMatchContainer) wordMatchContainer.style.display = 'none';
  const wordPyramidContainer = document.getElementById('wordPyramidContainer');
  if (wordPyramidContainer) wordPyramidContainer.style.display = 'none';
  if (currentGameMode !== 'wordmatch') {
    if (typeof stopWordMatchAutoReveal === 'function') stopWordMatchAutoReveal();
  }

  const colorFitLegend = document.getElementById('colorFitLegend');
  if (colorFitLegend) colorFitLegend.style.display = (currentGameMode === 'colorfit') ? 'flex' : 'none';
  if (boardObj && boardObj.parentElement) {
    if (currentGameMode === 'colorfit') {
      boardObj.parentElement.classList.add('colorfit-mode');
    } else {
      boardObj.parentElement.classList.remove('colorfit-mode');
    }
  }
  if (wordTangoInfoContainer) wordTangoInfoContainer.style.display = 'none';
  if (tangoPoolContainer) {
    tangoPoolContainer.style.display = 'none';
    const chips = document.getElementById('tangoPoolChips');
    if (currentGameMode !== 'wordtango' && chips) chips.innerHTML = '';
  }
  if (tangoGuessFeed) {
    tangoGuessFeed.style.display = 'none';
    if (currentGameMode !== 'wordtango') tangoGuessFeed.innerHTML = '';
  }
  if (currentGameMode !== 'wordtango') {
    if (typeof tangoGuessedWords !== 'undefined' && tangoGuessedWords.clear) tangoGuessedWords.clear();
  }
  if (wordGridInfoContainer) wordGridInfoContainer.style.display = 'none';
  if (wordGridContainer) wordGridContainer.style.display = 'none';
  if (boardObj) {
    boardObj.style.display = '';
    if (currentGameMode !== 'wordladder') {
      boardObj.classList.remove('wordladder-board');
    }
    if (currentGameMode !== 'wordtango') {
      boardObj.classList.remove('tango-board');
    }
  }

  // Synchronize active game card in settings panel
  const gameCards = document.querySelectorAll('.game-card');
  gameCards.forEach(card => {
    if (card.getAttribute('data-value') === currentGameMode) {
      card.classList.add('active');
    } else {
      card.classList.remove('active');
    }
  });

  if (currentGameMode === 'word500' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit') {
    if (headerTitle) {
      if (currentGameMode === 'word500') {
        headerTitle.textContent = window.w500UseMastermind ? 'WORD PEGS' : 'WORD500';
      } else if (currentGameMode === 'colorfit') {
        headerTitle.textContent = 'COLOR FIT';
      } else {
        headerTitle.textContent = 'WORD FIT';
      }
    }
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none'; // replaced by sorted board
    if (switchBtn) {
      if (currentGameMode === 'word500') switchBtn.textContent = '🔄 Switch to Word Fit';
      else if (currentGameMode === 'wordfit') switchBtn.textContent = '🔄 Switch to Color Fit';
      else switchBtn.textContent = '🔄 Switch to Word Fill';
    }
  } else if (currentGameMode === 'fillblanks') {
    if (headerTitle) headerTitle.textContent = 'WORD FILL';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Tango';
  } else if (currentGameMode === 'wordtango') {
    if (headerTitle) headerTitle.textContent = 'WORD TANGO';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    // wordTangoInfoContainer stays hidden — header already shows mode name
    if (tangoPoolContainer) tangoPoolContainer.style.display = 'flex';
    if (tangoGuessFeed) tangoGuessFeed.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Grid';
  } else if (currentGameMode === 'wordgrid') {
    if (headerTitle) headerTitle.textContent = 'WORD GRID';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (wordGridInfoContainer) wordGridInfoContainer.style.display = '';
    if (wordGridContainer) wordGridContainer.style.display = 'grid';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Kotak Kata';
  } else if (currentGameMode === 'squareword') {
    if (headerTitle) headerTitle.textContent = 'KOTAK KATA 5×5';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    if (squarewordBoardContainer) squarewordBoardContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Ladder';
  } else if (currentGameMode === 'wordladder') {
    if (headerTitle) headerTitle.textContent = 'WORD LADDER';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (wordLadderInfoContainer) wordLadderInfoContainer.style.display = '';
    if (boardObj) boardObj.style.display = '';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Betweenle';
  } else if (currentGameMode === 'betweenle') {
    if (headerTitle) headerTitle.textContent = 'BETWEENLE';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    if (betweenleContainer) betweenleContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Cascadle';
    if (!betweenleTopBound) {
      startBetweenleGame();
    } else {
      renderBetweenleUI();
    }
  } else if (currentGameMode === 'cascadle') {
    if (headerTitle) headerTitle.textContent = 'CASCADLE';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    if (cascadleContainer) cascadleContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Wander Words';
    if (!cascadleTargets || !cascadleTargets[3]) {
      startCascadleGame();
    } else {
      renderCascadleUI();
    }
  } else if (currentGameMode === 'wanderwords') {
    if (headerTitle) headerTitle.textContent = 'WANDER WORDS';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    const wanderWordsContainer = document.getElementById('wanderWordsContainer');
    if (wanderWordsContainer) wanderWordsContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Cluster';
    if (!wanderWordsCurrentPuzzle) {
      startWanderWordsGame();
    } else {
      renderWanderWordsUI();
    }
  } else if (currentGameMode === 'wordcluster') {
    if (headerTitle) headerTitle.textContent = 'WORD CLUSTER';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    const wordClusterContainer = document.getElementById('wordClusterContainer');
    if (wordClusterContainer) wordClusterContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Match';
    if (!wordClusterCurrentTopic) {
      startWordClusterGame();
    } else {
      renderWordClusterUI();
    }
  } else if (currentGameMode === 'wordmatch') {
    if (headerTitle) headerTitle.textContent = 'WORD MATCH';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    const wordMatchContainer = document.getElementById('wordMatchContainer');
    if (wordMatchContainer) wordMatchContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Word Pyramid';
    if (!wordMatchCurrentWord) {
      startWordMatchGame();
    } else {
      renderWordMatchUI();
    }
  } else if (currentGameMode === 'wordpyramid') {
    if (headerTitle) headerTitle.textContent = 'WORD PYRAMID';
    if (hintContainer) hintContainer.style.display = 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    if (boardObj) {
      boardObj.style.display = 'none';
      boardObj.innerHTML = '';
      boardObj.className = '';
    }
    const wordPyramidContainer = document.getElementById('wordPyramidContainer');
    if (wordPyramidContainer) wordPyramidContainer.style.display = 'flex';
    if (switchBtn) switchBtn.textContent = '🔄 Switch to Wordle';
    if (!wordPyramidBaseWord) {
      startWordPyramidGame();
    } else {
      renderWordPyramidUI();
    }
  } else {
    if (headerTitle) headerTitle.textContent = 'WORDLE';
    if (hintContainer) hintContainer.style.display = isShowHintsDiscovered ? '' : 'none';
    if (bestGuessContainer) bestGuessContainer.style.display = 'none';
    const nextName = window.w500UseMastermind ? 'Word Pegs' : 'Word500';
    if (switchBtn) switchBtn.textContent = `🔄 Switch to ${nextName}`;
  }
  updateBoardScaleUI();
  updateNoRepeatBadgeUI();
  if (typeof startInstructionRotation === 'function') {
    startInstructionRotation();
  }
}

function updateBestGuessUI() {
  const container = document.getElementById('bestGuessBoard');
  if (!container) return;
  
  if (!bestGuess) {
    container.innerHTML = '<div style="color: rgba(255,255,255,0.4); font-size: 13px; padding: 5px;">Belum ada tebakan valid</div>';
    return;
  }
  
  let html = `<div style="display: grid; grid-template-columns: 1fr repeat(${bestGuess.word.length}, 1fr) repeat(3, 1fr); gap: 8px; width: 100%; align-items: center; justify-items: center; padding-top: 5px;">`;
  
  // Spacer for avatar column
  html += `<div style="min-width: 0; min-height: 0; width: 100%;"></div>`;

  const isAllRed = bestGuess.a === bestGuess.word.length;
  const extraStyle = isAllRed 
    ? 'background-color: rgba(220, 38, 38, 0.25); border: 2px solid rgba(220, 38, 38, 0.4); color: rgba(255, 255, 255, 0.4);' 
    : '';

  for (let i = 0; i < bestGuess.word.length; i++) {
    html += `<div class="tile blind" style="aspect-ratio: 1/1; height: auto; width: 100%; border-radius: 6px; font-size: 1.1rem; min-width: 0; min-height: 0; display:flex; align-items:center; justify-content:center; ${extraStyle}">${bestGuess.word[i]}</div>`;
  }
  if (window.w500UseMastermind) {
    html += `<div class="mastermind-container" style="grid-column: span 3; width: 100%; height: auto; aspect-ratio: 3/1; margin: 0;">`;
    for (let m=0; m<bestGuess.c; m++) { html += `<div class="mm-block green"></div>`; }
    for (let m=0; m<bestGuess.p; m++) { html += `<div class="mm-block yellow"></div>`; }
    for (let m=0; m<bestGuess.a; m++) { html += `<div class="mm-block red"></div>`; }
    html += `</div></div>`;
  } else {
    html += `
      <div class="w500-count green" style="aspect-ratio: 1/1; height: auto; width: 100%; border-radius: 6px; font-size: 1rem; min-width: 0; min-height: 0;">${bestGuess.c}</div>
      <div class="w500-count yellow" style="aspect-ratio: 1/1; height: auto; width: 100%; border-radius: 6px; font-size: 1rem; min-width: 0; min-height: 0;">${bestGuess.p}</div>
      <div class="w500-count red" style="aspect-ratio: 1/1; height: auto; width: 100%; border-radius: 6px; font-size: 1rem; min-width: 0; min-height: 0;">${bestGuess.a}</div>
    </div>`;
  }
  container.innerHTML = html;
}

// ─── Word500 Sorted Board ───
function createWord500RowEl(guessData, isLatest, revealAllColors = false) {
  const row = document.createElement('div');
  row.className = 'board-row w500-row' + (isLatest ? ' w500-latest-row' : '');
  if (isLatest && isGameAnimationsEnabled) {
    row.classList.add('pop-in');
  }
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar' + (isLatest && isGameAnimationsEnabled ? ' spring-in' : '');
  avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
  avatar.src = (guessData.userData && guessData.userData.profilePictureUrl) ? guessData.userData.profilePictureUrl : 'assets/bg_nature.png';
  avatar.classList.add('show');
  row.appendChild(avatar);
  const isAllRed = guessData.a === guessData.word.length;
  
  let statuses = null;
  if (revealAllColors) {
    statuses = getWordleFeedback(guessData.word, currentWord);
  }

  for (let j = 0; j < guessData.word.length; j++) {
    const tile = document.createElement('div');
    const letter = guessData.word[j];
    
    if (revealAllColors && statuses) {
      tile.className = `tile ${statuses[j]}`;
    } else {
      tile.className = 'tile blind';
      if (isAllRed || knownAbsentLetters.has(letter)) {
        tile.style.backgroundColor = 'rgba(220, 38, 38, 0.25)';
        tile.style.borderColor = 'rgba(220, 38, 38, 0.4)';
        tile.style.color = 'rgba(255, 255, 255, 0.4)';
      }
    }
    tile.textContent = letter;
    if (currentGameMode === 'colorfit') {
      tile.classList.add(`color-${letter.toLowerCase()}`);
    }
    row.appendChild(tile);
  }
  if (window.w500UseMastermind) {
    const mmContainer = document.createElement('div');
    mmContainer.className = 'mastermind-container';
    for (let m=0; m<guessData.c; m++) { const b=document.createElement('div'); b.className='mm-block green'; mmContainer.appendChild(b); }
    for (let m=0; m<guessData.p; m++) { const b=document.createElement('div'); b.className='mm-block yellow'; mmContainer.appendChild(b); }
    for (let m=0; m<guessData.a; m++) { const b=document.createElement('div'); b.className='mm-block red'; mmContainer.appendChild(b); }
    row.appendChild(mmContainer);
  } else {
    const greenClue = document.createElement('div');
    greenClue.className = 'w500-count green';
    greenClue.textContent = guessData.c;
    const yellowClue = document.createElement('div');
    yellowClue.className = 'w500-count yellow';
    yellowClue.textContent = guessData.p;
    const redClue = document.createElement('div');
    redClue.className = 'w500-count red';
    redClue.textContent = guessData.a;
    row.appendChild(greenClue);
    row.appendChild(yellowClue);
    row.appendChild(redClue);
  }
  return row;
}

function createEmptyW500Row(idx) {
  const row = document.createElement('div');
  row.className = 'board-row w500-row';
  row.id = `row-empty-${idx}`;
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar';
  row.appendChild(avatar);
  for (let j = 0; j < WORD_LENGTH; j++) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.style.cursor = 'pointer';
    tile.onclick = function() {
      if (!currentWord) return;
      if (tile.textContent === '') {
        tile.textContent = currentWord[j];
        tile.classList.add('present');
        tile.style.transform = 'scale(1.1)';
        setTimeout(() => tile.style.transform = 'scale(1)', 200);
        if (window.playHostAudio) playHostAudio('click');
      }
    };
    row.appendChild(tile);
  }
  if (window.w500UseMastermind) {
    const mmContainer = document.createElement('div');
    mmContainer.className = 'mastermind-container';
    for (let m=0; m<WORD_LENGTH; m++) {
      const b=document.createElement('div'); b.className='mm-block empty'; mmContainer.appendChild(b);
    }
    row.appendChild(mmContainer);
  } else {
    const classes = ['green', 'yellow', 'red'];
    for (let k = 0; k < 3; k++) {
      const clue = document.createElement('div');
      clue.className = `w500-count ${classes[k]}`;
      row.appendChild(clue);
    }
  }
  return row;
}

function renderWord500Board(revealAllColors = false) {
  document.querySelectorAll('.is-invalid-tooltip').forEach(el => {
    if (el._fadeTimer) clearTimeout(el._fadeTimer);
    if (el._removeTimer) clearTimeout(el._removeTimer);
    el.remove();
  });
  board.innerHTML = '';
  word500PendingInvalidRow = null; // DOM-nya sudah dihapus oleh innerHTML=''
  board.classList.add('w500-board');

  const DISPLAY_ROWS = getDisplayRows();
  document.documentElement.style.setProperty('--display-rows', DISPLAY_ROWS);
  
  knownAbsentLetters.clear();
  for (const g of word500History) {
      if (g.a === g.word.length) {
          for (const char of g.word) knownAbsentLetters.add(char);
      }
  }

  if (word500History.length === 0) {
    for (let i = 0; i < DISPLAY_ROWS; i++) board.appendChild(createEmptyW500Row(i));
    return;
  }

  // Baris paling atas: tebakan terbaru
  const latest = word500History[word500History.length - 1];
  board.appendChild(createWord500RowEl(latest, true, revealAllColors));

  // Di bawahnya: semua tebakan, diurutkan dari skor tertinggi
  const previous = word500History
    .slice() // copy
    .sort((a, b) => b.c - a.c || b.p - a.p || a.a - b.a);

  const slots = DISPLAY_ROWS - 1;
  const toShow = previous.slice(0, slots);
  for (const g of toShow) board.appendChild(createWord500RowEl(g, false, revealAllColors));

  // Isi sisa dengan baris kosong
  for (let i = toShow.length; i < DISPLAY_ROWS - 1; i++) board.appendChild(createEmptyW500Row(i));
}

// ─── WordFit Board ───
function createWordFitRowEl(guessData, isLatest, revealAllColors = false) {
  const row = document.createElement('div');
  row.className = 'board-row wordfit-row' + (isLatest ? ' wordfit-latest-row' : '');
  if (isLatest && isGameAnimationsEnabled) {
    row.classList.add('pop-in');
  }
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar' + (isLatest && isGameAnimationsEnabled ? ' spring-in' : '');
  avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
  avatar.src = (guessData.userData && guessData.userData.profilePictureUrl) ? guessData.userData.profilePictureUrl : 'assets/bg_nature.png';
  avatar.classList.add('show');
  row.appendChild(avatar);
  const isAllRed = guessData.a === guessData.word.length;
  
  let statuses = null;
  if (revealAllColors) {
    statuses = getWordleFeedback(guessData.word, currentWord);
  }

  for (let j = 0; j < guessData.word.length; j++) {
    const tile = document.createElement('div');
    const letter = guessData.word[j];
    
    if (revealAllColors && statuses) {
      tile.className = `tile ${statuses[j]}`;
    } else {
      tile.className = 'tile blind';
      if (isAllRed || knownAbsentLetters.has(letter)) {
        tile.style.backgroundColor = 'rgba(220, 38, 38, 0.25)';
        tile.style.borderColor = 'rgba(220, 38, 38, 0.4)';
        tile.style.color = 'rgba(255, 255, 255, 0.4)';
      }
    }
    tile.textContent = letter;
    if (currentGameMode === 'colorfit') {
      tile.classList.add(`color-${letter.toLowerCase()}`);
    }
    row.appendChild(tile);
  }
  
  // Exact matches indicator
  const greenClue = document.createElement('div');
  greenClue.className = 'wordfit-count ' + (guessData.c > 0 ? 'green' : 'zero');
  greenClue.textContent = guessData.c;
  
  // Partial matches indicator
  const yellowClue = document.createElement('div');
  yellowClue.className = 'wordfit-count ' + (guessData.p > 0 ? 'yellow' : 'zero');
  yellowClue.textContent = guessData.p;
  
  row.appendChild(greenClue);
  row.appendChild(yellowClue);

  return row;
}

function createEmptyWordFitRow(idx) {
  const row = document.createElement('div');
  row.className = 'board-row wordfit-row';
  row.id = `row-empty-wf-${idx}`;
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar';
  row.appendChild(avatar);
  
  for (let j = 0; j < WORD_LENGTH; j++) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.style.cursor = 'pointer';
    tile.onclick = function() {
      if (!currentWord) return;
      if (tile.textContent === '') {
        tile.textContent = currentWord[j];
        tile.classList.add('present');
        tile.style.transform = 'scale(1.1)';
        setTimeout(() => tile.style.transform = 'scale(1)', 200);
        if (window.playHostAudio) playHostAudio('click');
      }
    };
    row.appendChild(tile);
  }
  
  const exactClue = document.createElement('div');
  exactClue.className = 'wordfit-count empty-clue';
  const partialClue = document.createElement('div');
  partialClue.className = 'wordfit-count empty-clue';
  
  row.appendChild(exactClue);
  row.appendChild(partialClue);
  
  return row;
}

function renderWordFitBoard(revealAllColors = false) {
  document.querySelectorAll('.is-invalid-tooltip').forEach(el => {
    if (el._fadeTimer) clearTimeout(el._fadeTimer);
    if (el._removeTimer) clearTimeout(el._removeTimer);
    el.remove();
  });
  board.innerHTML = '';
  word500PendingInvalidRow = null; // Reusing word500 logic for invalid row
  board.classList.add('w500-board'); // Use same general board styling

  const DISPLAY_ROWS = getDisplayRows();
  document.documentElement.style.setProperty('--display-rows', DISPLAY_ROWS);
  
  knownAbsentLetters.clear();
  for (const g of word500History) {
      if (g.a === g.word.length) {
          for (const char of g.word) knownAbsentLetters.add(char);
      }
  }

  if (word500History.length === 0) {
    for (let i = 0; i < DISPLAY_ROWS; i++) board.appendChild(createEmptyWordFitRow(i));
    return;
  }

  const latest = word500History[word500History.length - 1];
  board.appendChild(createWordFitRowEl(latest, true, revealAllColors));

  const previous = word500History
    .slice()
    .sort((a, b) => b.c - a.c || b.p - a.p || a.a - b.a);

  const slots = DISPLAY_ROWS - 1;
  const toShow = previous.slice(0, slots);
  for (const g of toShow) board.appendChild(createWordFitRowEl(g, false, revealAllColors));

  for (let i = toShow.length; i < DISPLAY_ROWS - 1; i++) board.appendChild(createEmptyWordFitRow(i));
}

// Render Word Tango Letter Pool in a 2-row pyramid, hiding used letters
function renderTangoPool() {
  const chipsDiv = document.getElementById('tangoPoolChips');
  if (!chipsDiv) return;
  chipsDiv.innerHTML = '';

  const available = wordTangoPool.filter(item => !item.used);
  if (available.length === 0) return;

  const N = available.length;
  let topCount = Math.floor(N / 2);
  if (topCount === 0 && N > 0) topCount = 1;
  
  const topRow = available.slice(0, topCount);
  const bottomRow = available.slice(topCount);

  const makeRowEl = (chips) => {
    const rowEl = document.createElement('div');
    rowEl.className = 'tango-pool-row';
    rowEl.style.display = 'flex';
    rowEl.style.justifyContent = 'center';
    rowEl.style.gap = '8px';
    rowEl.style.marginBottom = '8px';
    chips.forEach(item => {
      const chip = document.createElement('div');
      chip.className = 'tango-chip';
      chip.id = `tango-chip-${item.id}`;
      chip.textContent = item.char;
      rowEl.appendChild(chip);
    });
    return rowEl;
  };

  if (topRow.length > 0) chipsDiv.appendChild(makeRowEl(topRow));
  if (bottomRow.length > 0) {
    const bEl = makeRowEl(bottomRow);
    bEl.style.marginBottom = '0';
    chipsDiv.appendChild(bEl);
  }
}

// Initialize Board
function initBoard() {
  document.querySelectorAll('.is-invalid-tooltip').forEach(el => {
    if (el._fadeTimer) clearTimeout(el._fadeTimer);
    if (el._removeTimer) clearTimeout(el._removeTimer);
    el.remove();
  });
  board.innerHTML = '';
  board.className = '';
  const colorLegend = document.getElementById('colorFitLegend');
  if (colorLegend) colorLegend.style.display = (currentGameMode === 'colorfit') ? 'flex' : 'none';
  if (currentGameMode === 'colorfit') board.parentElement.classList.add('colorfit-mode');
  else board.parentElement.classList.remove('colorfit-mode');

  if (currentGameMode === 'squareword') {
    initSquarewordBoard();
    return;
  }

  if (currentGameMode === 'wordladder') {
    renderWordLadderBoard();
    return;
  }

  if (currentGameMode === 'wordfit' || currentGameMode === 'colorfit') {
    renderWordFitBoard();
    return;
  } else if (currentGameMode === 'word500') {
    renderWord500Board();
    return;
  } else if (currentGameMode === 'wordtango') {
    board.classList.add('tango-board');
    for (let i = 0; i < 4; i++) {
      const target = wordTangoTargets[i];
      if (!target) continue;
      const row = document.createElement('div');
      row.className = 'tango-row';
      row.id = `tango-row-${i}`;

      // Left Solver Avatar (reserved slot, hidden via CSS until solved)
      const avatar = document.createElement('img');
      avatar.className = 'guesser-avatar tango-avatar';
      avatar.id = `avatar-tango-${i}`;
      row.appendChild(avatar);

      // Center Tiles
      const tilesDiv = document.createElement('div');
      tilesDiv.className = 'tango-tiles';
      for (let j = 0; j < target.length; j++) {
        const tile = document.createElement('div');
        tile.className = 'tile';
        tile.id = `tango-tile-${i}-${j}`;
        if (target.missingIndices.includes(j)) {
          tile.classList.add('tango-slot');
          tile.textContent = '';
        } else {
          tile.classList.add('tango-revealed');
          tile.textContent = target.word[j];
        }
        tilesDiv.appendChild(tile);
      }
      row.appendChild(tilesDiv);

      board.appendChild(row);
    }

    // Render Letter Pool Chips in 2-row pyramid
    renderTangoPool();
    return;
  }

  const rows = getDisplayRows();
  document.documentElement.style.setProperty('--display-rows', rows);
  for (let i = 0; i < rows; i++) {
    board.appendChild(createEmptyBoardRow(i));
  }
}

function createEmptyBoardRow(i) {
  const row = document.createElement('div');
  row.className = 'board-row';
  row.id = `row-empty-${i}`;
  
  // Avatar for the row
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar';
  avatar.id = `avatar-empty-${i}`;
  row.appendChild(avatar);

  for (let j = 0; j < WORD_LENGTH; j++) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.id = `tile-empty-${i}-${j}`;
    
    tile.style.cursor = 'pointer';
    tile.onclick = function() {
      if (!currentWord || currentGameMode === 'wordgrid' || currentGameMode === 'wordtango') return;
      let targetWord = currentWord;
      if (currentGameMode === 'fillblanks' && fillBlanksTargets[i]) {
        targetWord = fillBlanksTargets[i].word;
      }
      if (targetWord && targetWord[j] && tile.textContent === '') {
        tile.textContent = targetWord[j];
        tile.classList.add('correct'); // Hint color (green)
        tile.style.transform = 'scale(1.1)';
        setTimeout(() => tile.style.transform = 'scale(1)', 200);
        if (window.playHostAudio) playHostAudio('click');
      }
    };

    if (currentGameMode === 'fillblanks' && fillBlanksTargets[i]) {
      const clue = fillBlanksTargets[i].clues[j];
      if (clue) {
        tile.textContent = clue.char;
        tile.classList.add(clue.status);
      }
    }
    row.appendChild(tile);
  }

  // Word500/600: add feedback placeholders
  if (currentGameMode === 'word500') {
    row.classList.add('w500-row');
    if (window.w500UseMastermind) {
      const mmContainer = document.createElement('div');
      mmContainer.className = 'mastermind-container';
      for (let m = 0; m < WORD_LENGTH; m++) {
        const b = document.createElement('div');
        b.className = 'mm-block empty';
        mmContainer.appendChild(b);
      }
      row.appendChild(mmContainer);
    } else {
      const classes = ['green', 'yellow', 'red'];
      for (let k = 0; k < 3; k++) {
        const clue = document.createElement('div');
        clue.className = `w500-count ${classes[k]}`;
        row.appendChild(clue);
      }
    }
  }

  return row;
}

function initHintBoard() {
  const hintBoard = document.getElementById('hintBoard');
  hintBoard.innerHTML = '<div class="hint-spacer"></div>';
  for(let i=0; i<WORD_LENGTH; i++) {
    const tile = document.createElement('div');
    tile.className = 'hint-tile';
    tile.id = `hint-${i}`;
    hintBoard.appendChild(tile);
  }
}

// Rotating Instructions & !myrank system
let rankCooldowns = {};
let rankMessageQueue = [];
let isShowingRankMsg = false;
let instructionTimer = null;
let currentInstructionIndex = 0;

function getInstructionText() {
  const steps = [];
  
  // 1. Guessing / Tango / Fillblanks
  steps.push(() => {
    if (currentGameMode === 'wordtango') {
      if (lastLang === 'id') return `Ketik kata dari Letter Pool di komentar!`;
      if (lastLang === 'mixed') return `Ketik kata dari Letter Pool! / Type words from Letter Pool!`;
      return `Type complete words from the Letter Pool in chat!`;
    }
    if (currentGameMode === 'fillblanks') {
      if (lastLang === 'id') return `Tebak kata ${WORD_LENGTH} huruf untuk mengisi baris kosong!`;
      if (lastLang === 'mixed') return `Tebak kata untuk isi baris kosong! / Guess to fill the blanks!`;
      return `Guess a ${WORD_LENGTH}-letter word to fill the blanks!`;
    }
    if (currentGameMode === 'wordgrid') {
      if (lastLang === 'id') return `Ketik kata yang sesuai dengan kriteria baris & kolom!`;
      if (lastLang === 'mixed') return `Ketik kata sesuai kriteria! / Type words matching clues!`;
      return `Type a word that matches the row & column clues!`;
    }
    if (currentGameMode === 'wanderwords') {
      if (lastLang === 'en') return `Connect letters in path (no diagonals)!`;
      if (lastLang === 'mixed') return `Ikuti jalur huruf! / Connect path (no diagonal)!`;
      return `Tebak kata ikuti jalur huruf (tanpa diagonal)!`;
    }
    if (currentGameMode === 'cascadle') {
      if (lastLang === 'id') return `Tebak kata bertahap dari 3 sampai 7 huruf!`;
      if (lastLang === 'mixed') return `Tebak kata bertahap 3-7 huruf! / Guess 3 to 7 letter ladder!`;
      return `Guess words cascading from 3 to 7 letters!`;
    }
    if (currentGameMode === 'betweenle') {
      if (lastLang === 'id') return `Tebak kata alfabetis di antara batas atas & batas bawah!`;
      if (lastLang === 'mixed') return `Tebak kata di antara 2 batas! / Guess word between bounds!`;
      return `Guess the secret word alphabetically between the two bounds!`;
    }
    if (currentGameMode === 'wordmatch') {
      const len = wordMatchCurrentWord ? wordMatchCurrentWord.length : 5;
      if (lastLang === 'id') return `Tebak kata ${len} huruf! Semakin mirip, makin tinggi % barnya!`;
      if (lastLang === 'mixed') return `Tebak kata ${len} huruf! / Guess the ${len}-letter word!`;
      return `Guess the ${len}-letter word! Closer guess gives higher % bar!`;
    }
    if (currentGameMode === 'wordpyramid') {
      const prevStep = (wordPyramidSolvedSteps && wordPyramidSolvedSteps.length > 0) ? wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1] : null;
      const prevWord = prevStep ? prevStep.word : (wordPyramidBaseWord || '2 huruf');
      if (lastLang === 'id') return `Susun kata ${wordPyramidCurrentLevel} huruf dari "${prevWord}" + 1 huruf baru!`;
      if (lastLang === 'mixed') return `Susun ${wordPyramidCurrentLevel} huruf dari "${prevWord}" + 1 huruf!`;
      return `Form a ${wordPyramidCurrentLevel}-letter word from "${prevWord}" + 1 new letter!`;
    }
    if (lastLang === 'id') return `Ketik kata ${WORD_LENGTH} huruf di komentar untuk menebak!`;
    if (lastLang === 'mixed') return `Ketik kata ${WORD_LENGTH} huruf di komentar! / Type a ${WORD_LENGTH}-letter word!`;
    return `Type a ${WORD_LENGTH}-letter word in chat to guess!`;
  });
  
  // 2. Rank Check
  steps.push(() => {
    if (lastLang === 'id') return `Ketik !myrank untuk cek rank & poin kamu!`;
    if (lastLang === 'mixed') return `Ketik !myrank untuk cek poin! / Type !myrank to check points!`;
    return `Type !myrank to check your rank and points!`;
  });
  
  // 3. Request Music (only if enabled)
  if (musicSettings.requestsEnabled !== false) {
    steps.push(() => {
      if (lastLang === 'id') return `Ketik !play&nbsp;<b>judul lagu</b>&nbsp;untuk request musik 🎵`;
      if (lastLang === 'mixed') return `Ketik !play&nbsp;<b>judul</b>&nbsp;untuk musik! / Type !play&nbsp;<b>title</b>&nbsp;for music!`;
      return `Type !play&nbsp;<b>song title</b>&nbsp;in chat to request music 🎵`;
    });
  }
  
  // 4. Social / Engagement
  steps.push(() => {
    if (lastLang === 'id') return `Tap-tap layar & follow live ini ya! ❤️`;
    if (lastLang === 'mixed') return `Tap layar & follow! / Tap & follow! ❤️`;
    return `Tap the screen & follow this live! ❤️`;
  });
  
  const stepIdx = currentInstructionIndex % steps.length;
  const isFollowStep = (stepIdx === steps.length - 1);
  return {
    text: steps[stepIdx](),
    isFollowStep: isFollowStep
  };
}

function startInstructionRotation() {
  if (instructionTimer) clearInterval(instructionTimer);
  
  const updateText = () => {
    const res = getInstructionText();
    const instEl = document.querySelector('.instruction');
    if (instEl) {
      instEl.classList.remove('fade-in');
      instEl.classList.add('fade-out');
      setTimeout(() => {
        instEl.innerHTML = res.text;
        instEl.style.color = 'var(--text-muted)';
        void instEl.offsetWidth; // Trigger reflow for smooth transition
        instEl.classList.remove('fade-out');
        instEl.classList.add('fade-in');
      }, 300);
    }
    
    currentInstructionIndex++;
  };
  
  // Initial display
  const initialRes = getInstructionText();
  const initialInstEl = document.querySelector('.instruction');
  if (initialInstEl) {
    initialInstEl.innerHTML = initialRes.text;
    initialInstEl.style.color = 'var(--text-muted)';
    initialInstEl.classList.add('fade-in');
  }
  currentInstructionIndex++;

  instructionTimer = setInterval(updateText, 5000); // Switch every 5s
}

// ── SISTEM NOTIFIKASI TOAST !myrank (TANPA WEEKLY & DI BAWAH DENGAN TOAST) ──
function showRankToast(data) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  // Anti-flooding: maksimal 3 toast di layar
  const activeToasts = container.querySelectorAll('.toast');
  if (activeToasts.length >= 3) {
    activeToasts[0].remove();
  }

  const toast = document.createElement('div');
  toast.className = 'toast toast-rank';

  let rankBadgeHtml = '';
  let borderHighlight = 'rgba(56, 189, 248, 0.45)';
  if (data.sessionRank === 1) {
    rankBadgeHtml = `<span class="toast-rank-badge rank-1"><i class="fa-solid fa-crown"></i> Rank #1</span>`;
    borderHighlight = 'rgba(245, 158, 11, 0.65)';
  } else if (data.sessionRank === 2) {
    rankBadgeHtml = `<span class="toast-rank-badge rank-2"><i class="fa-solid fa-medal"></i> Rank #2</span>`;
    borderHighlight = 'rgba(203, 213, 225, 0.6)';
  } else if (data.sessionRank === 3) {
    rankBadgeHtml = `<span class="toast-rank-badge rank-3"><i class="fa-solid fa-medal"></i> Rank #3</span>`;
    borderHighlight = 'rgba(217, 119, 6, 0.6)';
  } else if (data.sessionRank !== '-') {
    rankBadgeHtml = `<span class="toast-rank-badge rank-n">Rank #${data.sessionRank}</span>`;
    borderHighlight = 'rgba(56, 189, 248, 0.45)';
  } else {
    rankBadgeHtml = `<span class="toast-rank-badge rank-none">Belum Masuk Rank</span>`;
    borderHighlight = 'rgba(148, 163, 184, 0.35)';
  }

  toast.style.borderColor = borderHighlight;
  toast.innerHTML = `
    <div class="toast-rank-left">
      <img src="${data.avatar}" class="toast-rank-avatar" onerror="this.onerror=null;this.src='assets/bg_nature.png'">
      <div class="toast-rank-info">
        <span class="toast-rank-name">${escapeHTML(data.nick)}</span>
        <div class="toast-rank-details">
          ${rankBadgeHtml}
          <span class="toast-rank-pts"><i class="fa-solid fa-coins" style="color: #fbbf24;"></i> ${data.sessionPts} Pts</span>
        </div>
      </div>
    </div>
  `;

  container.appendChild(toast);

  if (window.sounds && typeof window.sounds.playFlip === 'function') {
    window.sounds.playFlip(1);
  }

  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    toast.classList.add('hide');
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 360);
  }, 4500);
}

function handleMyRank(userData) {
  if (!userData) return;
  const userId = userData.uniqueId || userData.userId || 'unknown';
  const username = userData.nickname || userData.uniqueId || 'Pemain';
  const now = Date.now();
  if (rankCooldowns[userId] && now - rankCooldowns[userId] < 8000) {
    return; // 8s cooldown per user
  }
  rankCooldowns[userId] = now;

  // Hitung poin & rank sesi hari ini (Session Pts saja, tanpa weekly)
  const sessionObj = playerPoints[username];
  const sessionPts = sessionObj ? (sessionObj.sessionPts || 0) : 0;
  let sessionRank = "-";

  const sorted = Object.entries(playerPoints)
    .filter(([_, data]) => (data.sessionPts || 0) > 0)
    .sort((a, b) => b[1].sessionPts - a[1].sessionPts);

  const index = sorted.findIndex(p => p[0] === username);
  if (index !== -1 && sessionPts > 0) {
    sessionRank = index + 1;
  }

  let nick = username;
  if (nick.length > 14) {
    nick = nick.substring(0, 13) + '..';
  }

  const avatar = userData.profilePictureUrl || (sessionObj && sessionObj.avatar) || 'assets/bg_nature.png';

  showRankToast({
    nick: nick,
    sessionPts: sessionPts,
    sessionRank: sessionRank,
    avatar: avatar
  });
}

window.handleMyRank = handleMyRank;
window.showRankToast = showRankToast;

window.testMyRank = function(name = 'Budi Santoso', pts = 45) {
  if (!playerPoints[name]) {
    playerPoints[name] = { avatar: 'assets/bg_nature.png', sessionPts: pts };
  } else {
    playerPoints[name].sessionPts = pts;
  }
  handleMyRank({ uniqueId: 'test_' + name.toLowerCase().replace(/\s+/g, '_'), nickname: name, profilePictureUrl: 'assets/bg_nature.png' });
};

if (window.location && window.location.search && window.location.search.includes('testrank=1')) {
  setTimeout(() => {
    window.testMyRank('Budi Santoso', 45);
  }, 1200);
}

// --- WORD GRID LOGIC ---
const WG_CLUE_EASY = [
  {'type':'length','val':4},
  {'type':'length','val':5},
  {'type':'length','val':6},
  {'type':'length','val':7},
  {'type':'length_max','val':7},
  {'type':'length_min','val':4},
  {'type':'contains','val':'A'},
  {'type':'contains','val':'E'},
  {'type':'contains','val':'I'},
  {'type':'contains','val':'O'},
  {'type':'contains','val':'U'},
  {'type':'contains','val':'R'},
  {'type':'contains','val':'N'},
  {'type':'contains','val':'T'},
  {'type':'contains','val':'S'},
  {'type':'contains','val':'M'},
  {'type':'contains','val':'K'},
  {'type':'contains','val':'AN'},
  {'type':'contains','val':'AR'},
  {'type':'contains','val':'RA'},
  {'type':'contains','val':'AK'},
  {'type':'contains','val':'KA'},
  {'type':'contains','val':'TA'},
  {'type':'contains','val':'SA'},
  {'type':'contains','val':'OB'},
  {'type':'contains','val':'IM'},
  {'type':'contains_multiple','val':['A','I']},
  {'type':'contains_multiple','val':['A','E']},
  {'type':'starts_with','val':'B'},
  {'type':'starts_with','val':'M'},
  {'type':'starts_with','val':'P'},
  {'type':'starts_with','val':'S'},
  {'type':'starts_with','val':'K'},
  {'type':'starts_with','val':'T'},
  {'type':'ends_with','val':'A'},
  {'type':'ends_with','val':'I'},
  {'type':'ends_with','val':'N'},
  {'type':'ends_with','val':'R'},
  {'type':'ends_with','val':'S'},
  {'type':'ends_with','val':'H'},
  {'type':'starts_vowel','val':true},
  {'type':'ends_consonant','val':true},
  {'type':'length_max','val':5},
  {'type':'length_max','val':6},
  {'type':'contains','val':'D'},
  {'type':'contains','val':'F'},
  {'type':'contains','val':'G'},
  {'type':'contains','val':'L'},
  {'type':'contains','val':'P'},
  {'type':'contains','val':'X'},
  {'type':'contains','val':'Y'},
  {'type':'ends_with','val':'D'},
  {'type':'ends_with','val':'G'},
  {'type':'ends_with','val':'K'},
  {'type':'ends_with','val':'L'},
  {'type':'ends_with','val':'P'},
  {'type':'ends_with','val':'T'},
  {'type':'starts_with','val':'A'},
  {'type':'starts_with','val':'C'},
  {'type':'starts_with','val':'D'},
  {'type':'starts_with','val':'E'},
  {'type':'starts_with','val':'F'},
  {'type':'starts_with','val':'G'},
  {'type':'starts_with','val':'I'},
  {'type':'starts_with','val':'J'},
  {'type':'starts_with','val':'L'},
  {'type':'starts_with','val':'N'},
  {'type':'starts_with','val':'O'},
  {'type':'starts_with','val':'R'},
  {'type':'starts_with','val':'U'},
  {'type':'starts_with','val':'V'},
  {'type':'starts_with','val':'Z'}
];

const WG_CLUE_MEDIUM = [
  {'type':'length','val':8},
  {'type':'length','val':9},
  {'type':'length','val':10},
  {'type':'length','val':11},
  {'type':'length_range','min':4,'max':6},
  {'type':'length_range','min':5,'max':7},
  {'type':'length_either','vals':[4,5]},
  {'type':'length_either','vals':[5,6]},
  {'type':'length_either','vals':[6,7]},
  {'type':'not_contains','val':'O'},
  {'type':'not_contains','val':'U'},
  {'type':'not_contains','val':'R'},
  {'type':'not_contains','val':'N'},
  {'type':'not_contains','val':'T'},
  {'type':'not_contains','val':'S'},
  {'type':'not_contains_multiple','val':['A','E']},
  {'type':'not_contains_multiple','val':['I','O']},
  {'type':'not_contains_multiple','val':['U','E']},
  {'type':'not_contains_multiple','val':['R','N']},
  {'type':'not_contains_multiple','val':['G','S','U']},
  {'type':'contains','val':'B'},
  {'type':'contains','val':'P'},
  {'type':'contains','val':'D'},
  {'type':'contains','val':'G'},
  {'type':'contains','val':'L'},
  {'type':'contains','val':'EL'},
  {'type':'contains','val':'UM'},
  {'type':'contains','val':'IN'},
  {'type':'contains','val':'US'},
  {'type':'contains','val':'ER'},
  {'type':'contains','val':'ANG'},
  {'type':'contains','val':'TER'},
  {'type':'contains','val':'BER'},
  {'type':'contains','val':'KAN'},
  {'type':'contains','val':'PER'},
  {'type':'contains','val':'NYA'},
  {'type':'contains_multiple','val':['K','N']},
  {'type':'contains_multiple','val':['A','U']},
  {'type':'starts_with','val':'K'},
  {'type':'starts_with','val':'T'},
  {'type':'starts_with','val':'D'},
  {'type':'starts_with','val':'L'},
  {'type':'starts_with','val':'R'},
  {'type':'starts_with','val':'C'},
  {'type':'ends_with','val':'K'},
  {'type':'ends_with','val':'T'},
  {'type':'ends_with','val':'S'},
  {'type':'ends_with','val':'M'},
  {'type':'ends_with','val':'L'},
  {'type':'ends_with','val':'NG'},
  {'type':'min_vowels','val':3},
  {'type':'multiple_letter','val':'A'},
  {'type':'multiple_letter','val':'E'},
  {'type':'multiple_letter','val':'I'},
  {'type':'no_repeat_letter','val':true},
  {'type':'contains_multiple','val':['A','E']},
  {'type':'contains_multiple','val':['A','O']},
  {'type':'contains','val':'AB'},
  {'type':'contains','val':'AD'},
  {'type':'contains','val':'AL'},
  {'type':'contains','val':'AM'},
  {'type':'contains','val':'AN'},
  {'type':'contains','val':'AP'},
  {'type':'contains','val':'AR'},
  {'type':'contains','val':'AS'},
  {'type':'contains','val':'AT'},
  {'type':'contains_multiple','val':['B','I']},
  {'type':'contains_multiple','val':['B','P']},
  {'type':'contains','val':'BL'},
  {'type':'contains','val':'BO'},
  {'type':'contains_multiple','val':['C','K']},
  {'type':'contains_multiple','val':['D','T']},
  {'type':'contains_multiple','val':['E','G']},
  {'type':'contains_multiple','val':['E','I']},
  {'type':'contains_multiple','val':['E','L']},
  {'type':'contains_multiple','val':['E','U']},
  {'type':'contains','val':'EG'},
  {'type':'contains','val':'EM'},
  {'type':'contains','val':'EN'},
  {'type':'contains','val':'EP'},
  {'type':'contains','val':'ES'},
  {'type':'contains','val':'ET'},
  {'type':'contains','val':'EX'},
  {'type':'contains_multiple','val':['F','E']},
  {'type':'contains_multiple','val':['F','L']},
  {'type':'contains_multiple','val':['G','E']},
  {'type':'contains_multiple','val':['H','R']},
  {'type':'contains_multiple','val':['H','S']},
  {'type':'contains_multiple','val':['H','Y']},
  {'type':'contains','val':'ID'},
  {'type':'contains','val':'IG'},
  {'type':'contains','val':'IL'},
  {'type':'contains','val':'IS'},
  {'type':'contains_multiple','val':['K','C']},
  {'type':'contains_multiple','val':['K','N']},
  {'type':'contains_multiple','val':['K','T']},
  {'type':'contains_multiple','val':['L','I']},
  {'type':'contains_multiple','val':['L','M']},
  {'type':'contains_multiple','val':['L','R']},
  {'type':'contains_multiple','val':['L','T']},
  {'type':'contains','val':'LI'},
  {'type':'contains_multiple','val':['M','N']},
  {'type':'contains_multiple','val':['M','O']},
  {'type':'contains_multiple','val':['N','P']},
  {'type':'contains_multiple','val':['O','D']},
  {'type':'contains_multiple','val':['O','P']},
  {'type':'contains_multiple','val':['O','U']},
  {'type':'contains_multiple','val':['O','R']},
  {'type':'contains','val':'OB'},
  {'type':'contains','val':'OG'},
  {'type':'contains','val':'OL'},
  {'type':'contains','val':'OM'},
  {'type':'contains','val':'ON'},
  {'type':'contains','val':'OO'},
  {'type':'contains','val':'OS'},
  {'type':'contains','val':'OT'},
  {'type':'contains_multiple','val':['P','H']},
  {'type':'contains_multiple','val':['P','O']},
  {'type':'contains','val':'PL'},
  {'type':'contains','val':'RI'},
  {'type':'contains_multiple','val':['S','T']},
  {'type':'contains_multiple','val':['S','Z']},
  {'type':'contains','val':'SL'},
  {'type':'contains','val':'SM'},
  {'type':'contains','val':'SU'},
  {'type':'contains_multiple','val':['T','S']},
  {'type':'contains_multiple','val':['U','G']},
  {'type':'contains_multiple','val':['U','Y']},
  {'type':'contains','val':'UL'},
  {'type':'contains','val':'UN'},
  {'type':'contains','val':'UP'},
  {'type':'contains','val':'UR'},
  {'type':'contains','val':'UT'},
  {'type':'contains_multiple','val':['W','A']},
  {'type':'not_contains','val':'A'},
  {'type':'not_contains_multiple','val':['A','N']},
  {'type':'not_contains_multiple','val':['A','P']},
  {'type':'not_contains_multiple','val':['A','S']},
  {'type':'not_contains_multiple','val':['A','U']},
  {'type':'not_contains_multiple','val':['E','G']},
  {'type':'not_contains_multiple','val':['E','I']},
  {'type':'not_contains_multiple','val':['E','N']},
  {'type':'not_contains_multiple','val':['E','P']},
  {'type':'not_contains_multiple','val':['E','R']},
  {'type':'not_contains_multiple','val':['E','S']},
  {'type':'not_contains_multiple','val':['E','T']},
  {'type':'not_contains_multiple','val':['I','O']},
  {'type':'not_contains_multiple','val':['I','P']},
  {'type':'not_contains_multiple','val':['I','R']},
  {'type':'not_contains_multiple','val':['I','T']},
  {'type':'not_contains_multiple','val':['P','U']},
  {'type':'not_contains_multiple','val':['T','U']},
  {'type':'not_contains_multiple','val':['U','L']},
  {'type':'ends_with','val':'AL'},
  {'type':'ends_with','val':'AR'},
  {'type':'ends_with','val':'AS'},
  {'type':'ends_with','val':'ER'},
  {'type':'ends_with','val':'ID'},
  {'type':'ends_with','val':'IS'},
  {'type':'ends_with','val':'ON'},
  {'type':'ends_with','val':'OR'},
  {'type':'ends_with','val':'OS'},
  {'type':'ends_with','val':'US'},
  {'type':'multiple_letter','val':'C'},
  {'type':'multiple_letter','val':'L'},
  {'type':'multiple_letter','val':'M'},
  {'type':'multiple_letter','val':'N'},
  {'type':'multiple_letter','val':'O'},
  {'type':'multiple_letter','val':'R'},
  {'type':'multiple_letter','val':'S'},
  {'type':'multiple_letter','val':'T'},
  {'type':'starts_with','val':'BA'},
  {'type':'starts_with','val':'BE'},
  {'type':'starts_with','val':'BO'},
  {'type':'starts_with','val':'CA'},
  {'type':'starts_with','val':'CO'},
  {'type':'starts_with','val':'DE'},
  {'type':'starts_with','val':'DO'},
  {'type':'starts_with','val':'DR'},
  {'type':'starts_with','val':'FO'},
  {'type':'starts_with','val':'GL'},
  {'type':'starts_with','val':'HE'},
  {'type':'starts_with','val':'IN'},
  {'type':'starts_with','val':'MA'},
  {'type':'starts_with','val':'MI'},
  {'type':'starts_with','val':'MO'},
  {'type':'starts_with','val':'PA'},
  {'type':'starts_with','val':'RA'},
  {'type':'starts_with','val':'SA'},
  {'type':'starts_with','val':'SC'},
  {'type':'starts_with','val':'SE'},
  {'type':'starts_with','val':'SL'},
  {'type':'starts_with','val':'UN'},
  {'type':'starts_with','val':'WA'}
];

const WG_CLUE_HARD = [
  {'type':'length','val':12},
  {'type':'length','val':13},
  {'type':'length','val':14},
  {'type':'length','val':15},
  {'type':'length_range','min':7,'max':9},
  {'type':'not_contains','val':'A'},
  {'type':'not_contains','val':'E'},
  {'type':'not_contains','val':'I'},
  {'type':'not_contains','val':'K'},
  {'type':'not_contains','val':'M'},
  {'type':'not_contains','val':'L'},
  {'type':'not_contains','val':'P'},
  {'type':'not_contains_multiple','val':['A','E','I']},
  {'type':'not_contains_multiple','val':['U','O','A']},
  {'type':'not_contains_multiple','val':['R','N','T']},
  {'type':'not_contains_multiple','val':['M','K','S']},
  {'type':'not_contains_multiple','val':['B','P','D']},
  {'type':'not_contains_multiple','val':['C','J','Y']},
  {'type':'not_contains_multiple','val':['E','O','T']},
  {'type':'contains','val':'J'},
  {'type':'contains','val':'Y'},
  {'type':'contains','val':'C'},
  {'type':'contains','val':'V'},
  {'type':'contains','val':'W'},
  {'type':'contains','val':'F'},
  {'type':'contains','val':'Z'},
  {'type':'contains','val':'X'},
  {'type':'contains','val':'Q'},
  {'type':'contains','val':'ALA'},
  {'type':'contains','val':'ERA'},
  {'type':'contains','val':'BEL'},
  {'type':'contains','val':'PAN'},
  {'type':'contains','val':'PRO'},
  {'type':'contains','val':'EKS'},
  {'type':'contains','val':'NYA'},
  {'type':'contains_multiple','val':['S','T']},
  {'type':'contains_multiple','val':['N','G']},
  {'type':'starts_with','val':'J'},
  {'type':'starts_with','val':'Y'},
  {'type':'starts_with','val':'G'},
  {'type':'starts_with','val':'W'},
  {'type':'starts_with','val':'C'},
  {'type':'starts_with','val':'F'},
  {'type':'starts_with','val':'Z'},
  {'type':'starts_with','val':'V'},
  {'type':'starts_with','val':'SY'},
  {'type':'ends_with','val':'G'},
  {'type':'ends_with','val':'P'},
  {'type':'ends_with','val':'D'},
  {'type':'ends_with','val':'V'},
  {'type':'ends_with','val':'Z'},
  {'type':'ends_with','val':'F'},
  {'type':'min_vowels','val':4},
  {'type':'multiple_letter','val':'O'},
  {'type':'multiple_letter','val':'U'},
  {'type':'multiple_letter','val':'R'},
  {'type':'double_letter','val':true},
  {'type':'no_repeat_letter','val':true},
  {'type':'not_contains_multiple','val':['A','C','E']},
  {'type':'not_contains_multiple','val':['A','C','R']},
  {'type':'not_contains_multiple','val':['A','C','U']},
  {'type':'not_contains_multiple','val':['A','D','S']},
  {'type':'not_contains_multiple','val':['A','E','I']},
  {'type':'not_contains_multiple','val':['A','E','O']},
  {'type':'not_contains_multiple','val':['A','E','P']},
  {'type':'not_contains_multiple','val':['A','E','S']},
  {'type':'not_contains_multiple','val':['A','E','T']},
  {'type':'not_contains_multiple','val':['A','G','R']},
  {'type':'not_contains_multiple','val':['A','I','L']},
  {'type':'not_contains_multiple','val':['A','I','M']},
  {'type':'not_contains_multiple','val':['A','I','O']},
  {'type':'not_contains_multiple','val':['A','L','N']},
  {'type':'not_contains_multiple','val':['A','L','P']},
  {'type':'not_contains_multiple','val':['A','L','R']},
  {'type':'not_contains_multiple','val':['A','M','D']},
  {'type':'not_contains_multiple','val':['A','M','O']},
  {'type':'not_contains_multiple','val':['A','M','S']},
  {'type':'not_contains_multiple','val':['A','N','D']},
  {'type':'not_contains_multiple','val':['A','N','S','R']},
  {'type':'not_contains_multiple','val':['A','P','S']},
  {'type':'not_contains_multiple','val':['A','R','S']},
  {'type':'not_contains_multiple','val':['A','S','T']},
  {'type':'not_contains_multiple','val':['A','T','S','N']},
  {'type':'not_contains_multiple','val':['C','E','S']},
  {'type':'not_contains_multiple','val':['C','G','I']},
  {'type':'not_contains_multiple','val':['C','O','P']},
  {'type':'not_contains_multiple','val':['C','T','U']},
  {'type':'not_contains_multiple','val':['D','E','N']},
  {'type':'not_contains_multiple','val':['D','G','I']},
  {'type':'not_contains_multiple','val':['D','I','M']},
  {'type':'not_contains_multiple','val':['D','I','S']},
  {'type':'not_contains_multiple','val':['D','O','S']},
  {'type':'not_contains_multiple','val':['E','A','C']},
  {'type':'not_contains_multiple','val':['E','G','I']},
  {'type':'not_contains_multiple','val':['E','I','L']},
  {'type':'not_contains_multiple','val':['E','I','N']},
  {'type':'not_contains_multiple','val':['E','I','S']},
  {'type':'not_contains_multiple','val':['E','I','T']},
  {'type':'not_contains_multiple','val':['E','L','N']},
  {'type':'not_contains_multiple','val':['E','M','N']},
  {'type':'not_contains_multiple','val':['E','M','O']},
  {'type':'not_contains_multiple','val':['E','N','A']},
  {'type':'not_contains_multiple','val':['E','O','P']},
  {'type':'not_contains_multiple','val':['E','O','S']},
  {'type':'not_contains_multiple','val':['E','R','T']},
  {'type':'not_contains_multiple','val':['E','T','R']},
  {'type':'not_contains_multiple','val':['G','I','A']},
  {'type':'not_contains_multiple','val':['G','I','R']},
  {'type':'not_contains_multiple','val':['G','N','U']},
  {'type':'not_contains_multiple','val':['G','O','A']},
  {'type':'not_contains_multiple','val':['G','P','U']},
  {'type':'not_contains_multiple','val':['I','C','N','G']},
  {'type':'not_contains_multiple','val':['I','N','O']},
  {'type':'not_contains_multiple','val':['I','N','T']},
  {'type':'not_contains_multiple','val':['I','R','U']},
  {'type':'not_contains_multiple','val':['L','O','R']},
  {'type':'not_contains_multiple','val':['L','P','U']},
  {'type':'not_contains_multiple','val':['M','A','N','G','O']},
  {'type':'not_contains_multiple','val':['M','E','R','G']},
  {'type':'not_contains_multiple','val':['M','O','P']},
  {'type':'not_contains_multiple','val':['M','O','S']},
  {'type':'not_contains_multiple','val':['N','B','S']},
  {'type':'not_contains_multiple','val':['O','E','D','M']},
  {'type':'not_contains_multiple','val':['O','P','R']},
  {'type':'not_contains_multiple','val':['O','R','L']},
  {'type':'not_contains_multiple','val':['R','A','N']},
  {'type':'not_contains_multiple','val':['R','D','E']},
  {'type':'not_contains_multiple','val':['R','E','D']},
  {'type':'not_contains_multiple','val':['R','E','M']},
  {'type':'not_contains_multiple','val':['S','A','O','D']},
  {'type':'not_contains_multiple','val':['S','D','R','T']},
  {'type':'not_contains_multiple','val':['S','G','I','N']},
  {'type':'not_contains_multiple','val':['T','M','R','E']},
  {'type':'not_contains_multiple','val':['T','S','L','O']},
  {'type':'not_contains_multiple','val':['U','S','D']},
  {'type':'not_contains_multiple','val':['U','S','D','L','C','M']}
];

const WG_CLUE_EASY_EN = [
  {'type':'length','val':4},
  {'type':'length','val':5},
  {'type':'length','val':6},
  {'type':'length','val':7},
  {'type':'length_max','val':7},
  {'type':'length_min','val':4},
  {'type':'contains','val':'A'},
  {'type':'contains','val':'E'},
  {'type':'contains','val':'I'},
  {'type':'contains','val':'O'},
  {'type':'contains','val':'U'},
  {'type':'contains','val':'ER'},
  {'type':'contains','val':'ST'},
  {'type':'contains','val':'EA'},
  {'type':'contains','val':'OU'},
  {'type':'contains','val':'TH'},
  {'type':'contains','val':'CH'},
  {'type':'contains','val':'IN'},
  {'type':'contains','val':'ON'},
  {'type':'contains','val':'AN'},
  {'type':'contains','val':'OB'},
  {'type':'contains','val':'IM'},
  {'type':'contains_multiple','val':['A','I']},
  {'type':'contains_multiple','val':['A','E']},
  {'type':'starts_with','val':'S'},
  {'type':'starts_with','val':'C'},
  {'type':'starts_with','val':'B'},
  {'type':'starts_with','val':'T'},
  {'type':'starts_with','val':'M'},
  {'type':'starts_with','val':'P'},
  {'type':'starts_with','val':'D'},
  {'type':'ends_with','val':'E'},
  {'type':'ends_with','val':'S'},
  {'type':'ends_with','val':'D'},
  {'type':'ends_with','val':'Y'},
  {'type':'ends_with','val':'T'},
  {'type':'ends_with','val':'N'},
  {'type':'starts_vowel','val':true},
  {'type':'ends_consonant','val':true},
  {'type':'length_max','val':5},
  {'type':'length_max','val':6},
  {'type':'contains','val':'D'},
  {'type':'contains','val':'F'},
  {'type':'contains','val':'G'},
  {'type':'contains','val':'K'},
  {'type':'contains','val':'L'},
  {'type':'contains','val':'N'},
  {'type':'contains','val':'P'},
  {'type':'contains','val':'T'},
  {'type':'contains','val':'X'},
  {'type':'contains','val':'Y'},
  {'type':'ends_with','val':'G'},
  {'type':'ends_with','val':'H'},
  {'type':'ends_with','val':'K'},
  {'type':'ends_with','val':'L'},
  {'type':'ends_with','val':'P'},
  {'type':'ends_with','val':'R'},
  {'type':'starts_with','val':'A'},
  {'type':'starts_with','val':'E'},
  {'type':'starts_with','val':'F'},
  {'type':'starts_with','val':'G'},
  {'type':'starts_with','val':'I'},
  {'type':'starts_with','val':'J'},
  {'type':'starts_with','val':'K'},
  {'type':'starts_with','val':'L'},
  {'type':'starts_with','val':'N'},
  {'type':'starts_with','val':'O'},
  {'type':'starts_with','val':'R'},
  {'type':'starts_with','val':'U'},
  {'type':'starts_with','val':'V'},
  {'type':'starts_with','val':'Z'}
];

const WG_CLUE_MEDIUM_EN = [
  {'type':'length','val':8},
  {'type':'length','val':9},
  {'type':'length','val':10},
  {'type':'length','val':11},
  {'type':'length_range','min':4,'max':6},
  {'type':'length_range','min':5,'max':7},
  {'type':'length_either','vals':[4,5]},
  {'type':'length_either','vals':[5,6]},
  {'type':'length_either','vals':[6,7]},
  {'type':'not_contains','val':'O'},
  {'type':'not_contains','val':'U'},
  {'type':'not_contains_multiple','val':['A','E']},
  {'type':'not_contains_multiple','val':['I','O']},
  {'type':'not_contains_multiple','val':['G','S','U']},
  {'type':'contains','val':'IGH'},
  {'type':'contains','val':'GHT'},
  {'type':'contains','val':'STA'},
  {'type':'contains','val':'REA'},
  {'type':'contains','val':'TER'},
  {'type':'contains','val':'AIN'},
  {'type':'contains','val':'ING'},
  {'type':'contains','val':'TION'},
  {'type':'contains','val':'ATE'},
  {'type':'contains','val':'PRO'},
  {'type':'contains','val':'PRE'},
  {'type':'contains','val':'CON'},
  {'type':'contains_multiple','val':['K','N']},
  {'type':'contains_multiple','val':['A','U']},
  {'type':'starts_with','val':'P'},
  {'type':'starts_with','val':'M'},
  {'type':'starts_with','val':'A'},
  {'type':'starts_with','val':'R'},
  {'type':'starts_with','val':'F'},
  {'type':'starts_with','val':'H'},
  {'type':'starts_with','val':'L'},
  {'type':'ends_with','val':'N'},
  {'type':'ends_with','val':'R'},
  {'type':'ends_with','val':'T'},
  {'type':'ends_with','val':'L'},
  {'type':'ends_with','val':'LY'},
  {'type':'ends_with','val':'ER'},
  {'type':'min_vowels','val':3},
  {'type':'multiple_letter','val':'A'},
  {'type':'multiple_letter','val':'E'},
  {'type':'multiple_letter','val':'I'},
  {'type':'no_repeat_letter','val':true},
  {'type':'contains_multiple','val':['A','E']},
  {'type':'contains_multiple','val':['A','O']},
  {'type':'contains','val':'AB'},
  {'type':'contains','val':'AD'},
  {'type':'contains','val':'AL'},
  {'type':'contains','val':'AM'},
  {'type':'contains','val':'AN'},
  {'type':'contains','val':'AP'},
  {'type':'contains','val':'AR'},
  {'type':'contains','val':'AS'},
  {'type':'contains','val':'AT'},
  {'type':'contains_multiple','val':['B','I']},
  {'type':'contains_multiple','val':['B','P']},
  {'type':'contains','val':'BL'},
  {'type':'contains','val':'BO'},
  {'type':'contains','val':'BR'},
  {'type':'contains_multiple','val':['C','K']},
  {'type':'contains_multiple','val':['D','T']},
  {'type':'contains_multiple','val':['E','G']},
  {'type':'contains_multiple','val':['E','I']},
  {'type':'contains_multiple','val':['E','L']},
  {'type':'contains_multiple','val':['E','U']},
  {'type':'contains','val':'ED'},
  {'type':'contains','val':'EE'},
  {'type':'contains','val':'EG'},
  {'type':'contains','val':'EL'},
  {'type':'contains','val':'EM'},
  {'type':'contains','val':'EN'},
  {'type':'contains','val':'EP'},
  {'type':'contains','val':'ER'},
  {'type':'contains','val':'ES'},
  {'type':'contains','val':'ET'},
  {'type':'contains','val':'EX'},
  {'type':'contains_multiple','val':['F','E']},
  {'type':'contains_multiple','val':['F','L']},
  {'type':'contains_multiple','val':['G','E']},
  {'type':'contains_multiple','val':['H','R']},
  {'type':'contains_multiple','val':['H','S']},
  {'type':'contains_multiple','val':['H','Y']},
  {'type':'contains','val':'ID'},
  {'type':'contains','val':'IG'},
  {'type':'contains','val':'IL'},
  {'type':'contains','val':'IN'},
  {'type':'contains','val':'IS'},
  {'type':'contains_multiple','val':['K','C']},
  {'type':'contains_multiple','val':['K','N']},
  {'type':'contains_multiple','val':['K','T']},
  {'type':'contains_multiple','val':['L','I']},
  {'type':'contains_multiple','val':['L','M']},
  {'type':'contains_multiple','val':['L','R']},
  {'type':'contains_multiple','val':['L','T']},
  {'type':'contains','val':'LI'},
  {'type':'contains_multiple','val':['M','N']},
  {'type':'contains_multiple','val':['M','O']},
  {'type':'contains_multiple','val':['N','P']},
  {'type':'contains_multiple','val':['O','D']},
  {'type':'contains_multiple','val':['O','P']},
  {'type':'contains_multiple','val':['O','U']},
  {'type':'contains_multiple','val':['O','R']},
  {'type':'contains','val':'OB'},
  {'type':'contains','val':'OG'},
  {'type':'contains','val':'OL'},
  {'type':'contains','val':'OM'},
  {'type':'contains','val':'ON'},
  {'type':'contains','val':'OO'},
  {'type':'contains','val':'OS'},
  {'type':'contains','val':'OT'},
  {'type':'contains','val':'OU'},
  {'type':'contains_multiple','val':['P','H']},
  {'type':'contains_multiple','val':['P','O']},
  {'type':'contains','val':'PH'},
  {'type':'contains','val':'PL'},
  {'type':'contains','val':'RI'},
  {'type':'contains_multiple','val':['S','T']},
  {'type':'contains_multiple','val':['S','Z']},
  {'type':'contains','val':'SH'},
  {'type':'contains','val':'SL'},
  {'type':'contains','val':'SM'},
  {'type':'contains','val':'ST'},
  {'type':'contains','val':'SU'},
  {'type':'contains_multiple','val':['T','S']},
  {'type':'contains','val':'TH'},
  {'type':'contains_multiple','val':['U','G']},
  {'type':'contains_multiple','val':['U','Y']},
  {'type':'contains','val':'UL'},
  {'type':'contains','val':'UM'},
  {'type':'contains','val':'UN'},
  {'type':'contains','val':'UP'},
  {'type':'contains','val':'UR'},
  {'type':'contains','val':'US'},
  {'type':'contains','val':'UT'},
  {'type':'contains_multiple','val':['W','A']},
  {'type':'not_contains','val':'A'},
  {'type':'not_contains_multiple','val':['A','N']},
  {'type':'not_contains_multiple','val':['A','P']},
  {'type':'not_contains_multiple','val':['A','S']},
  {'type':'not_contains_multiple','val':['A','U']},
  {'type':'not_contains_multiple','val':['E','G']},
  {'type':'not_contains_multiple','val':['E','I']},
  {'type':'not_contains_multiple','val':['E','N']},
  {'type':'not_contains_multiple','val':['E','P']},
  {'type':'not_contains_multiple','val':['E','R']},
  {'type':'not_contains_multiple','val':['E','S']},
  {'type':'not_contains_multiple','val':['E','T']},
  {'type':'not_contains_multiple','val':['I','O']},
  {'type':'not_contains_multiple','val':['I','P']},
  {'type':'not_contains_multiple','val':['I','R']},
  {'type':'not_contains_multiple','val':['I','T']},
  {'type':'not_contains_multiple','val':['P','U']},
  {'type':'not_contains_multiple','val':['T','U']},
  {'type':'not_contains_multiple','val':['U','L']},
  {'type':'ends_with','val':'AL'},
  {'type':'ends_with','val':'AR'},
  {'type':'ends_with','val':'AS'},
  {'type':'ends_with','val':'ED'},
  {'type':'ends_with','val':'ID'},
  {'type':'ends_with','val':'IS'},
  {'type':'ends_with','val':'ON'},
  {'type':'ends_with','val':'OR'},
  {'type':'ends_with','val':'OS'},
  {'type':'ends_with','val':'US'},
  {'type':'multiple_letter','val':'C'},
  {'type':'multiple_letter','val':'L'},
  {'type':'multiple_letter','val':'M'},
  {'type':'multiple_letter','val':'N'},
  {'type':'multiple_letter','val':'O'},
  {'type':'multiple_letter','val':'R'},
  {'type':'multiple_letter','val':'S'},
  {'type':'multiple_letter','val':'T'},
  {'type':'starts_with','val':'BA'},
  {'type':'starts_with','val':'BE'},
  {'type':'starts_with','val':'BO'},
  {'type':'starts_with','val':'BR'},
  {'type':'starts_with','val':'CA'},
  {'type':'starts_with','val':'CH'},
  {'type':'starts_with','val':'CL'},
  {'type':'starts_with','val':'CO'},
  {'type':'starts_with','val':'CR'},
  {'type':'starts_with','val':'DE'},
  {'type':'starts_with','val':'DO'},
  {'type':'starts_with','val':'DR'},
  {'type':'starts_with','val':'FO'},
  {'type':'starts_with','val':'GL'},
  {'type':'starts_with','val':'HE'},
  {'type':'starts_with','val':'IN'},
  {'type':'starts_with','val':'MA'},
  {'type':'starts_with','val':'MI'},
  {'type':'starts_with','val':'MO'},
  {'type':'starts_with','val':'PA'},
  {'type':'starts_with','val':'RA'},
  {'type':'starts_with','val':'SA'},
  {'type':'starts_with','val':'SC'},
  {'type':'starts_with','val':'SE'},
  {'type':'starts_with','val':'SL'},
  {'type':'starts_with','val':'ST'},
  {'type':'starts_with','val':'UN'},
  {'type':'starts_with','val':'WA'}
];

const WG_CLUE_HARD_EN = [
  {'type':'length','val':12},
  {'type':'length','val':13},
  {'type':'length','val':14},
  {'type':'length','val':15},
  {'type':'length_range','min':7,'max':9},
  {'type':'not_contains','val':'A'},
  {'type':'not_contains','val':'E'},
  {'type':'not_contains','val':'I'},
  {'type':'not_contains_multiple','val':['A','E','I']},
  {'type':'not_contains_multiple','val':['U','O','A']},
  {'type':'not_contains_multiple','val':['S','T','R']},
  {'type':'not_contains_multiple','val':['L','N','E']},
  {'type':'not_contains_multiple','val':['C','H','P']},
  {'type':'not_contains_multiple','val':['M','D','G']},
  {'type':'not_contains_multiple','val':['E','O','T']},
  {'type':'contains','val':'J'},
  {'type':'contains','val':'Q'},
  {'type':'contains','val':'Z'},
  {'type':'contains','val':'X'},
  {'type':'contains','val':'V'},
  {'type':'contains','val':'W'},
  {'type':'contains','val':'BB'},
  {'type':'contains','val':'ZZ'},
  {'type':'contains_multiple','val':['S','T']},
  {'type':'contains_multiple','val':['N','G']},
  {'type':'starts_with','val':'J'},
  {'type':'starts_with','val':'K'},
  {'type':'starts_with','val':'V'},
  {'type':'starts_with','val':'Z'},
  {'type':'starts_with','val':'Q'},
  {'type':'starts_with','val':'Y'},
  {'type':'starts_with','val':'U'},
  {'type':'starts_with','val':'O'},
  {'type':'ends_with','val':'K'},
  {'type':'ends_with','val':'M'},
  {'type':'ends_with','val':'P'},
  {'type':'ends_with','val':'Z'},
  {'type':'ends_with','val':'X'},
  {'type':'ends_with','val':'W'},
  {'type':'min_vowels','val':4},
  {'type':'multiple_letter','val':'O'},
  {'type':'multiple_letter','val':'U'},
  {'type':'multiple_letter','val':'R'},
  {'type':'double_letter','val':true},
  {'type':'no_repeat_letter','val':true},
  {'type':'contains','val':'CH'},
  {'type':'contains','val':'CL'},
  {'type':'contains','val':'CR'},
  {'type':'not_contains_multiple','val':['A','C','E']},
  {'type':'not_contains_multiple','val':['A','C','R']},
  {'type':'not_contains_multiple','val':['A','C','U']},
  {'type':'not_contains_multiple','val':['A','D','S']},
  {'type':'not_contains_multiple','val':['A','E','I']},
  {'type':'not_contains_multiple','val':['A','E','O']},
  {'type':'not_contains_multiple','val':['A','E','P']},
  {'type':'not_contains_multiple','val':['A','E','S']},
  {'type':'not_contains_multiple','val':['A','E','T']},
  {'type':'not_contains_multiple','val':['A','G','R']},
  {'type':'not_contains_multiple','val':['A','I','L']},
  {'type':'not_contains_multiple','val':['A','I','M']},
  {'type':'not_contains_multiple','val':['A','I','O']},
  {'type':'not_contains_multiple','val':['A','L','N']},
  {'type':'not_contains_multiple','val':['A','L','P']},
  {'type':'not_contains_multiple','val':['A','L','R']},
  {'type':'not_contains_multiple','val':['A','M','D']},
  {'type':'not_contains_multiple','val':['A','M','O']},
  {'type':'not_contains_multiple','val':['A','M','S']},
  {'type':'not_contains_multiple','val':['A','N','D']},
  {'type':'not_contains_multiple','val':['A','N','S','R']},
  {'type':'not_contains_multiple','val':['A','P','S']},
  {'type':'not_contains_multiple','val':['A','R','S']},
  {'type':'not_contains_multiple','val':['A','S','T']},
  {'type':'not_contains_multiple','val':['A','T','S','N']},
  {'type':'not_contains_multiple','val':['C','E','S']},
  {'type':'not_contains_multiple','val':['C','G','I']},
  {'type':'not_contains_multiple','val':['C','O','P']},
  {'type':'not_contains_multiple','val':['C','T','U']},
  {'type':'not_contains_multiple','val':['D','E','N']},
  {'type':'not_contains_multiple','val':['D','G','I']},
  {'type':'not_contains_multiple','val':['D','I','M']},
  {'type':'not_contains_multiple','val':['D','I','S']},
  {'type':'not_contains_multiple','val':['D','O','S']},
  {'type':'not_contains_multiple','val':['E','A','C']},
  {'type':'not_contains_multiple','val':['E','G','I']},
  {'type':'not_contains_multiple','val':['E','I','L']},
  {'type':'not_contains_multiple','val':['E','I','N']},
  {'type':'not_contains_multiple','val':['E','I','S']},
  {'type':'not_contains_multiple','val':['E','I','T']},
  {'type':'not_contains_multiple','val':['E','L','N']},
  {'type':'not_contains_multiple','val':['E','M','N']},
  {'type':'not_contains_multiple','val':['E','M','O']},
  {'type':'not_contains_multiple','val':['E','N','A']},
  {'type':'not_contains_multiple','val':['E','O','P']},
  {'type':'not_contains_multiple','val':['E','O','S']},
  {'type':'not_contains_multiple','val':['E','R','T']},
  {'type':'not_contains_multiple','val':['E','T','R']},
  {'type':'not_contains_multiple','val':['G','I','A']},
  {'type':'not_contains_multiple','val':['G','I','R']},
  {'type':'not_contains_multiple','val':['G','N','U']},
  {'type':'not_contains_multiple','val':['G','O','A']},
  {'type':'not_contains_multiple','val':['G','P','U']},
  {'type':'not_contains_multiple','val':['I','C','N','G']},
  {'type':'not_contains_multiple','val':['I','N','O']},
  {'type':'not_contains_multiple','val':['I','N','T']},
  {'type':'not_contains_multiple','val':['I','R','U']},
  {'type':'not_contains_multiple','val':['L','O','R']},
  {'type':'not_contains_multiple','val':['L','P','U']},
  {'type':'not_contains_multiple','val':['M','A','N','G','O']},
  {'type':'not_contains_multiple','val':['M','E','R','G']},
  {'type':'not_contains_multiple','val':['M','O','P']},
  {'type':'not_contains_multiple','val':['M','O','S']},
  {'type':'not_contains_multiple','val':['N','B','S']},
  {'type':'not_contains_multiple','val':['O','E','D','M']},
  {'type':'not_contains_multiple','val':['O','P','R']},
  {'type':'not_contains_multiple','val':['O','R','L']},
  {'type':'not_contains_multiple','val':['R','A','N']},
  {'type':'not_contains_multiple','val':['R','D','E']},
  {'type':'not_contains_multiple','val':['R','E','D']},
  {'type':'not_contains_multiple','val':['R','E','M']},
  {'type':'not_contains_multiple','val':['S','A','O','D']},
  {'type':'not_contains_multiple','val':['S','D','R','T']},
  {'type':'not_contains_multiple','val':['S','G','I','N']},
  {'type':'not_contains_multiple','val':['T','M','R','E']},
  {'type':'not_contains_multiple','val':['T','S','L','O']},
  {'type':'not_contains_multiple','val':['U','S','D']},
  {'type':'not_contains_multiple','val':['U','S','D','L','C','M']}
];

function getWgClueDesc(clue) {
  const isEn = lastLang === 'en';
  switch (clue.type) {
    case 'length': return isEn ? `${clue.val}<br>Letters` : `${clue.val}<br>Huruf`;
    case 'length_range': return isEn ? `${clue.min}-${clue.max}<br>Letters` : `${clue.min}-${clue.max}<br>Huruf`;
    case 'length_max': return isEn ? `Max ${clue.val}<br>Letters` : `Maks ${clue.val}<br>Huruf`;
    case 'length_min': return isEn ? `Min ${clue.val}<br>Letters` : `Min ${clue.val}<br>Huruf`;
    case 'length_either': return isEn ? `${clue.vals.join(' or ')}<br>Letters` : `${clue.vals.join(' atau ')}<br>Huruf`;
    case 'contains': return isEn ? `Contains<br>${clue.val}` : `Ada<br>${clue.val}`;
    case 'contains_multiple': return isEn ? `Contains<br>${clue.val.join(' & ')}` : `Ada<br>${clue.val.join(' & ')}`;
    case 'not_contains': return isEn ? `No<br>${clue.val}` : `Tanpa<br>${clue.val}`;
    case 'not_contains_multiple': return isEn ? `No<br>${clue.val.join(', ')}` : `Tanpa<br>${clue.val.join(', ')}`;
    case 'starts_with': return isEn ? `Starts<br>${clue.val}` : `Awalan<br>${clue.val}`;
    case 'ends_with': return isEn ? `Ends<br>${clue.val}` : `Akhiran<br>${clue.val}`;
    case 'starts_vowel': return isEn ? `Starts w/<br>Vowel` : `Awalan<br>Vokal`;
    case 'ends_consonant': return isEn ? `Ends w/<br>Consonant` : `Akhiran<br>Konsonan`;
    case 'min_vowels': return isEn ? `Min ${clue.val}<br>Vowels` : `Min ${clue.val}<br>Vokal`;
    case 'double_letter': return isEn ? `Double<br>Letter` : `Huruf<br>Ganda`;
    case 'multiple_letter': return isEn ? `Multiple<br>${clue.val}'s` : `Lebih dari<br>Satu ${clue.val}`;
    case 'no_repeat_letter': return isEn ? `No Repeat<br>Letters` : `Tanpa Huruf<br>Berulang`;
    default: return '';
  }
}

let wgAllWordsCache = null;

function getValidWordsForWgCell(rowClue, colClue) {
  let valid = [];
  if (!wgAllWordsCache) {
    wgAllWordsCache = [];
    [3, 4, 5, 6, 7, 8].forEach(len => {
      if (allTargetWords[len]) wgAllWordsCache.push(...allTargetWords[len]);
    });
    fullValidDictionary.forEach(w => {
      if (w.length >= 9 && w.length <= 15) {
        wgAllWordsCache.push(w);
      }
    });
  }
  
  for (const w of wgAllWordsCache) {
    if (checkWgClue(w, rowClue) && checkWgClue(w, colClue)) {
      valid.push(w);
    }
  }
  return valid;
}

function checkWgClue(word, clue) {
  if (clue.type === 'length') return word.length === clue.val;
  if (clue.type === 'length_range') return word.length >= clue.min && word.length <= clue.max;
  if (clue.type === 'length_max') return word.length <= clue.val;
  if (clue.type === 'length_min') return word.length >= clue.val;
  if (clue.type === 'length_either') return clue.vals.includes(word.length);
  if (clue.type === 'contains') return word.includes(clue.val);
  if (clue.type === 'contains_multiple') return clue.val.every(letter => word.includes(letter));
  if (clue.type === 'not_contains') return !word.includes(clue.val);
  if (clue.type === 'not_contains_multiple') return clue.val.every(letter => !word.includes(letter));
  if (clue.type === 'starts_with') return word.startsWith(clue.val);
  if (clue.type === 'ends_with') return word.endsWith(clue.val);
  if (clue.type === 'starts_vowel') return /^[AEIOU]/.test(word);
  if (clue.type === 'ends_consonant') return /[^AEIOU]$/.test(word);
  if (clue.type === 'min_vowels') return (word.match(/[AEIOU]/g) || []).length >= clue.val;
  if (clue.type === 'double_letter') return /(.)\1/.test(word);
  if (clue.type === 'multiple_letter') return (word.match(new RegExp(clue.val, 'g')) || []).length >= 2;
  if (clue.type === 'no_repeat_letter') return new Set(word).size === word.length;
  return false;
}

// Memastikan papan Word Grid 3x3 100% solvable (memiliki 9 kata unik yang berbeda secara simultan)
function canSolveWordGrid(dictCache) {
  const cells = [];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const list = dictCache[`${r}-${c}`];
      if (!list || list.length === 0) return false;
      cells.push({ key: `${r}-${c}`, words: list });
    }
  }
  // Sort cells dengan kata valid paling sedikit lebih dulu (MRV heuristic)
  cells.sort((a, b) => a.words.length - b.words.length);

  const used = new Set();
  function backtrack(idx) {
    if (idx === cells.length) return true;
    const cell = cells[idx];
    for (const w of cell.words) {
      if (!used.has(w)) {
        used.add(w);
        if (backtrack(idx + 1)) return true;
        used.delete(w);
      }
    }
    return false;
  }
  return backtrack(0);
}

// Memilih target word hint yang belum terpakai di grid maupun di hint kotak lain
function getWgCellHintTargetWord(r, c) {
  const validWords = wgDictionaryCache[`${r}-${c}`];
  if (!validWords || validWords.length === 0) return null;

  const usedWords = new Set();
  for (let ro = 0; ro < 3; ro++) {
    for (let co = 0; co < 3; co++) {
      if (wgGrid[ro][co]) usedWords.add(wgGrid[ro][co].word);
      const otherKey = `${ro}-${co}`;
      if (otherKey !== `${r}-${c}` && wgHints[otherKey] && wgHints[otherKey].targetWord) {
        usedWords.add(wgHints[otherKey].targetWord);
      }
    }
  }

  const availableWords = validWords.filter(w => !usedWords.has(w));
  const candidates = availableWords.length > 0 ? availableWords : validWords;
  return candidates[Math.floor(Math.random() * candidates.length)];
}

function generateWordGridBoard() {
  wgAllWordsCache = null;
  let attempts = 0;
  let validBoardFound = false;
  
  while (!validBoardFound && attempts < 200) {
    attempts++;
    wgCluesRow = [];
    wgCluesCol = [];
    
    const isEn = lastLang === 'en';
    let easyPool = isEn ? [...WG_CLUE_EASY_EN] : [...WG_CLUE_EASY];
    let mediumPool = isEn ? [...WG_CLUE_MEDIUM_EN] : [...WG_CLUE_MEDIUM];
    let hardPool = isEn ? [...WG_CLUE_HARD_EN] : [...WG_CLUE_HARD];
    shuffleArray(easyPool);
    shuffleArray(mediumPool);
    shuffleArray(hardPool);
    
    let selectedClues = [];
    if (wgDifficulty === 'hard') {
      selectedClues.push(mediumPool.pop(), mediumPool.pop(), mediumPool.pop());
      selectedClues.push(hardPool.pop(), hardPool.pop(), hardPool.pop());
    } else if (wgDifficulty === 'mixed') {
      selectedClues.push(easyPool.pop(), easyPool.pop());
      selectedClues.push(mediumPool.pop(), mediumPool.pop());
      selectedClues.push(hardPool.pop(), hardPool.pop());
    } else if (wgDifficulty === 'medium') {
      selectedClues.push(easyPool.pop(), easyPool.pop(), easyPool.pop(), easyPool.pop());
      selectedClues.push(mediumPool.pop(), mediumPool.pop());
    } else {
      selectedClues.push(easyPool.pop(), easyPool.pop(), easyPool.pop(), easyPool.pop(), easyPool.pop(), easyPool.pop());
    }
    
    shuffleArray(selectedClues);
    for (let i=0; i<3; i++) wgCluesRow.push(selectedClues.pop());
    for (let i=0; i<3; i++) wgCluesCol.push(selectedClues.pop());
    
    let isValid = true;
    wgDictionaryCache = {};
    wgHints = {};
    for (let r=0; r<3; r++) {
      for (let c=0; c<3; c++) {
        const words = getValidWordsForWgCell(wgCluesRow[r], wgCluesCol[c]);
        // Setiap kotak wajib memiliki minimal 2 kata valid agar tidak buntu/terlalu sempit
        if (!words || words.length < 2) {
          isValid = false;
          break;
        }
        wgDictionaryCache[`${r}-${c}`] = words;
      }
      if (!isValid) break;
    }
    
    // Verifikasi matematis bahwa 9 kotak bisa diselesaikan dengan 9 kata unik berbeda
    if (isValid && !canSolveWordGrid(wgDictionaryCache)) {
      isValid = false;
    }
    
    if (isValid) validBoardFound = true;
  }
  
  wgGrid = [
    [null, null, null],
    [null, null, null],
    [null, null, null]
  ];
  
  renderWordGridBoard();
  resetWgHintTimer();
}

function renderWordGridBoard() {
  for (let i=0; i<3; i++) {
    document.getElementById(`wg-row-${i}`).innerHTML = wgCluesRow[i] ? getWgClueDesc(wgCluesRow[i]) : '';
    document.getElementById(`wg-col-${i}`).innerHTML = wgCluesCol[i] ? getWgClueDesc(wgCluesCol[i]) : '';
  }
  
  for (let r=0; r<3; r++) {
    for (let c=0; c<3; c++) {
      const cell = document.getElementById(`wg-cell-${r}-${c}`);
      const data = wgGrid[r][c];
      
      const rarityEl = cell.querySelector('.wg-rarity');
      const wordEl = cell.querySelector('.wg-word');
      const playerEl = cell.querySelector('.wg-player');
      
      cell.className = 'word-grid-cell word-grid-ans'; 
      wordEl.style.color = ''; // reset hint color
      
      if (data) {
        let dynSize = 18;
        let lSpace = 1;
        if (data.word.length >= 14) { dynSize = 8; lSpace = -0.5; }
        else if (data.word.length >= 12) { dynSize = 9.5; lSpace = 0; }
        else if (data.word.length >= 9) { dynSize = 11; lSpace = 0.5; }
        else if (data.word.length >= 7) { dynSize = 13; lSpace = 0.5; }
        else if (data.word.length === 6) { dynSize = 15; lSpace = 1; }
        
        wordEl.style.fontSize = `calc(${dynSize}px * var(--board-scale, 1))`;
        wordEl.style.letterSpacing = `${lSpace}px`;
        wordEl.textContent = data.word;
        playerEl.innerHTML = `
          <img class="wg-player-avatar" src="${data.profilePic || 'assets/bg_nature.png'}">
          <span class="wg-player-name">${data.username}</span>
        `;
        rarityEl.style.display = 'block';
        
        cell.classList.add(data.rarityClass);
        if (data.breakdown) {
          rarityEl.innerHTML = `+${data.points} Pts<br><span style="font-size:0.45em;opacity:0.85;line-height:1.1;display:block;margin-top:2px;">${data.breakdown}</span>`;
          rarityEl.style.lineHeight = '1.2';
        } else {
          rarityEl.textContent = `${data.rarityName} (+${data.points})`;
        }
        rarityEl.style.background = 'rgba(0,0,0,0.7)';
      } else {
        let hintData = wgHints[`${r}-${c}`];
        if (hintData && hintData.targetWord) {
          let dynSize = 18;
          let lSpace = 1;
          if (hintData.targetWord.length >= 14) { dynSize = 8; lSpace = -0.5; }
          else if (hintData.targetWord.length >= 12) { dynSize = 9.5; lSpace = 0; }
          else if (hintData.targetWord.length >= 9) { dynSize = 11; lSpace = 0.5; }
          else if (hintData.targetWord.length >= 7) { dynSize = 13; lSpace = 0.5; }
          else if (hintData.targetWord.length === 6) { dynSize = 15; lSpace = 1; }
          
          wordEl.style.fontSize = `calc(${dynSize}px * var(--board-scale, 1))`;
          wordEl.style.letterSpacing = `${lSpace}px`;
        } else {
          wordEl.style.fontSize = ''; // reset font size
          wordEl.style.letterSpacing = ''; // reset letter spacing
        }
        
        wordEl.textContent = hintData ? hintData.currentHint : '';
        if (hintData) wordEl.style.color = '#ffd54f';
        
        playerEl.textContent = '';
        rarityEl.style.display = 'none';
      }

      // Hint click handler for Word Grid
      cell.style.cursor = 'pointer';
      cell.onclick = function() {
        if (currentGameMode !== 'wordgrid') return;
        if (wgGrid[r][c]) return; // already solved
        
        let hintData = wgHints[`${r}-${c}`];
        if (!hintData) {
          const targetWord = getWgCellHintTargetWord(r, c);
          if (!targetWord) return;
          hintData = { targetWord, currentHint: '' };
          wgHints[`${r}-${c}`] = hintData;
        }
        
        if (hintData.currentHint.length < hintData.targetWord.length) {
           hintData.currentHint += hintData.targetWord[hintData.currentHint.length];
           renderWordGridBoard();
           cell.style.transform = 'scale(1.05)';
           setTimeout(() => cell.style.transform = 'scale(1)', 200);
           if (window.playHostAudio) playHostAudio('click');
        }
      };
    }
  }
}

function checkWordGridGuess(word, username, profilePic) {
  if (isGameOver) return false;
  word = word.toUpperCase();
  
  // Validasi apakah kata ada di kamus lengkap
  if (!fullValidDictionary.has(word)) return false;
  
  for (let r=0; r<3; r++) {
    for (let c=0; c<3; c++) {
      if (wgGrid[r][c] && wgGrid[r][c].word === word) return false;
    }
  }
  
  let bestCell = null;
  let bestScore = -1;
  
  for (let r=0; r<3; r++) {
    for (let c=0; c<3; c++) {
      if (checkWgClue(word, wgCluesRow[r]) && checkWgClue(word, wgCluesCol[c])) {
        const existing = wgGrid[r][c];
        
        let basePoints = 1;
        let validCount = wgDictionaryCache[`${r}-${c}`]?.length || 0;
        let rarityClass = 'wg-rarity-common';
        let rarityName = 'COMMON';
        if (validCount <= 10) { basePoints = 15; rarityClass = 'wg-rarity-legendary'; rarityName = 'LEGENDARY'; }
        else if (validCount <= 50) { basePoints = 7; rarityClass = 'wg-rarity-epic'; rarityName = 'EPIC'; }
        else if (validCount <= 200) { basePoints = 3; rarityClass = 'wg-rarity-rare'; rarityName = 'RARE'; }
        
        let usageCount = wordUsageFreq[word] || 0;
        let usagePoints = 0;
        let usageName = 'Mainstream';
        if (usageCount === 0) { usagePoints = 10; usageName = 'First Time'; }
        else if (usageCount <= 3) { usagePoints = 5; usageName = 'Rarely Used'; }
        else if (usageCount <= 10) { usagePoints = 2; usageName = 'Sometimes Used'; }
        
        let lenPoints = 0;
        let len = word.length;
        if (len === 5) lenPoints = 1;
        else if (len === 6) lenPoints = 2;
        else if (len === 7) lenPoints = 4;
        else if (len === 8) lenPoints = 6;
        else if (len >= 9) lenPoints = 10;
        
        let obsPoints = 5;
        let obsName = 'Rare Word';
        if (allTargetWords[len] && allTargetWords[len].includes(word)) {
          obsPoints = 0;
          obsName = 'Common Word';
        }
        
        let totalPoints = basePoints + usagePoints + lenPoints + obsPoints;
        
        if (!existing) {
          if (totalPoints > bestScore) {
            bestScore = totalPoints;
            bestCell = { r, c, totalPoints, basePoints, rarityClass, rarityName, usagePoints, usageName, lenPoints, obsPoints, obsName, isTakeover: false };
          }
        } else if (isWgTakeoverMode) {
          if (totalPoints > existing.points) {
            if (totalPoints > bestScore) {
              bestScore = totalPoints;
              bestCell = { r, c, totalPoints, basePoints, rarityClass, rarityName, usagePoints, usageName, lenPoints, obsPoints, obsName, isTakeover: true };
            }
          }
        }
      }
    }
  }
  
  if (bestCell) {
    const { r, c, totalPoints, basePoints, rarityClass, rarityName, usagePoints, usageName, lenPoints, obsPoints, obsName, isTakeover } = bestCell;
    let finalRarityClass = 'wg-rarity-common';
    if (totalPoints >= 20) finalRarityClass = 'wg-rarity-legendary';
    else if (totalPoints >= 13) finalRarityClass = 'wg-rarity-epic';
    else if (totalPoints >= 6) finalRarityClass = 'wg-rarity-rare';
    
    let len = word.length;
    let finalBreakdown = `${rarityName}`;
    if (usagePoints > 0) finalBreakdown += ` | ${usageName}`;
    if (lenPoints > 0) finalBreakdown += ` | ${len} Letters`;
    if (obsPoints > 0) finalBreakdown += ` | ${obsName}`;
    if (isTakeover) finalBreakdown += ` (TAKEOVER)`;
    
    wgGrid[r][c] = { 
      word, 
      username, 
      profilePic, 
      points: totalPoints, 
      rarityClass: finalRarityClass,
      rarityName,
      breakdown: finalBreakdown 
    };
    
    // Update usage frequency
    wordUsageFreq[word] = (wordUsageFreq[word] || 0) + 1;
    try {
      localStorage.setItem('wordle_wordUsageStats', JSON.stringify(wordUsageFreq));
    } catch(e) {}
    
    // Bersihkan hint di kotak ini dan re-roll hint di kotak lain jika memakai kata yang baru tertebak
    delete wgHints[`${r}-${c}`];
    for (const k in wgHints) {
      if (wgHints[k] && wgHints[k].targetWord === word) {
        delete wgHints[k];
      }
    }
    
    renderWordGridBoard();
    triggerCellParticleEffect(r, c, totalPoints);
    if (window.sounds) window.sounds.playGreenChime();
    resetWgHintTimer();
    checkWordGridWin();
    return totalPoints; 
  }
  return false;
}

window.toggleWgTakeover = function(checked) {
  isWgTakeoverMode = checked;
  localStorage.setItem('wordle_wgTakeover', checked);
};

window.updateWgHintDelay = function(value) {
  wgHintDelay = parseInt(value);
  localStorage.setItem('wordle_wgHintDelay', wgHintDelay);
  const label = document.getElementById('wgHintDelayLabel');
  if (label) label.textContent = `${wgHintDelay} Detik`;
  resetWgHintTimer();
};

// Reset auto-hint timer for Word Grid
function resetWgHintTimer() {
  if (wgHintInterval) clearInterval(wgHintInterval);
  if (currentGameMode !== 'wordgrid' || isGameOver) return;
  wgHintInterval = setInterval(() => {
    triggerWgAutoHint();
  }, wgHintDelay * 1000);
}

// Trigger auto-hint for an unsolved cell
function triggerWgAutoHint() {
  if (currentGameMode !== 'wordgrid' || isGameOver) return;
  
  const unsolved = [];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      if (!wgGrid[r][c]) unsolved.push({ r, c });
    }
  }
  
  if (unsolved.length === 0) return;
  
  const targetCell = unsolved[Math.floor(Math.random() * unsolved.length)];
  const r = targetCell.r;
  const c = targetCell.c;
  const key = `${r}-${c}`;
  
  let hintData = wgHints[key];
  if (!hintData) {
    const targetWord = getWgCellHintTargetWord(r, c);
    if (!targetWord) return;
    hintData = { targetWord, currentHint: '' };
    wgHints[key] = hintData;
  }
  
  if (hintData.currentHint.length < hintData.targetWord.length) {
    hintData.currentHint += hintData.targetWord[hintData.currentHint.length];
    renderWordGridBoard();
    
    const cell = document.getElementById(`wg-cell-${r}-${c}`);
    if (cell) {
      cell.style.transform = 'scale(1.05)';
      setTimeout(() => cell.style.transform = 'scale(1)', 200);
    }
  }
}

// Particle explosion effect inside a grid cell
function triggerCellParticleEffect(row, col, score) {
  const cell = document.getElementById(`wg-cell-${row}-${col}`);
  if (!cell) return;
  
  const rect = cell.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  
  let count = 8;
  let colors = ['#2ecc71', '#3498db', '#ffffff'];
  
  if (score >= 20) {
    count = 35;
    colors = ['#f1c40f', '#f39c12', '#e67e22', '#ffffff', '#ffed4a'];
  } else if (score >= 13) {
    count = 22;
    colors = ['#9b59b6', '#8e44ad', '#ec4899', '#ffffff'];
  } else if (score >= 6) {
    count = 14;
    colors = ['#3498db', '#2980b9', '#1abc9c', '#ffffff'];
  }
  
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    const color = colors[Math.floor(Math.random() * colors.length)];
    p.style.position = 'fixed';
    p.style.pointerEvents = 'none';
    p.style.zIndex = '9999';
    p.style.backgroundColor = color;
    p.style.boxShadow = `0 0 8px ${color}`;
    p.style.borderRadius = '50%';
    
    // Set random sizing
    const size = (score >= 13 ? 6 : 4) + Math.random() * 4;
    p.style.width = `${size}px`;
    p.style.height = `${size}px`;
    
    p.style.left = `${centerX}px`;
    p.style.top = `${centerY}px`;
    
    const angle = Math.random() * Math.PI * 2;
    const velocity = 30 + Math.random() * (score >= 13 ? 90 : 50);
    const tx = Math.cos(angle) * velocity;
    const ty = Math.sin(angle) * velocity;
    
    document.body.appendChild(p);
    
    p.animate([
      { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
      { transform: `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px)) scale(0)`, opacity: 0 }
    ], {
      duration: 600 + Math.random() * 600,
      easing: 'cubic-bezier(0.1, 0.8, 0.3, 1)'
    }).onfinish = () => p.remove();
  }
}

function triggerConfetti() {
  const colors = ['#fe2c55', '#25f4ee', '#16a34a', '#f59e0b', '#ffd54f', '#c6aa24', '#ffffff'];
  // Anti-stutter: 100 elemen sekaligus terlalu berat untuk OBS/HP. 45 sudah cukup meriah.
  const count = isLowPowerMode ? 15 : 45;
  const frag = document.createDocumentFragment();
  const pieces = [];
  let maxDuration = 0;
  for (let i = 0; i < count; i++) {
    const confetti = document.createElement('div');
    confetti.className = 'confetti';
    
    // Spread in a circle
    const angle = Math.random() * Math.PI * 2;
    const velocity = 150 + Math.random() * 400; 
    const tx = Math.cos(angle) * velocity;
    const ty = Math.sin(angle) * velocity + (Math.random() * 200);
    const duration = 1 + Math.random();
    if (duration > maxDuration) maxDuration = duration;
    
    // Satu kali tulis style (cssText) agar tidak memicu banyak style recalc
    confetti.style.cssText =
      `background-color:${colors[Math.floor(Math.random() * colors.length)]};` +
      `--tx:${tx}px;--ty:${ty}px;animation-duration:${duration}s;` +
      (Math.random() > 0.5 ? 'border-radius:50%;' : '');
    
    confetti.addEventListener('animationend', () => confetti.remove(), { once: true });
    frag.appendChild(confetti);
    pieces.push(confetti);
  }
  // Satu kali insert ke DOM (1 reflow, bukan 100)
  document.body.appendChild(frag);
  // Fallback cleanup jika animationend tidak terpicu (tab background, dsb.)
  setTimeout(() => {
    pieces.forEach(el => { if (el.isConnected) el.remove(); });
  }, maxDuration * 1000 + 300);
}

function checkWordGridWin() {
  let allFilled = true;
  for (let r=0; r<3; r++) {
    for (let c=0; c<3; c++) {
      if (!wgGrid[r][c]) allFilled = false;
    }
  }
  
  if (allFilled) {
    isGameOver = true;
    setTimeout(() => {
      triggerConfetti();
      showWordGridWinOverlay();
    }, 1000);
  }
}

function showWordGridWinOverlay() {
  const overlay = document.getElementById('multiWinOverlay');
  const list = document.getElementById('multiWinList');
  const title = document.getElementById('multiWinTitle');
  
  title.textContent = 'LEADERBOARD WORD GRID';
  list.innerHTML = '';
  
  const scores = {};
  for (let r=0; r<3; r++) {
    for (let c=0; c<3; c++) {
      const solver = wgGrid[r][c];
      if (solver) {
        if (!scores[solver.username]) {
          scores[solver.username] = {
            username: solver.username,
            profilePic: solver.profilePic,
            points: 0,
            words: []
          };
        }
        scores[solver.username].points += (solver.points || 10);
        scores[solver.username].words.push(`${solver.word}`);
      }
    }
  }
  
  const sortedPlayers = Object.values(scores).sort((a, b) => b.points - a.points);
  
  let delay = 0;
  sortedPlayers.forEach((player, index) => {
    setTimeout(() => {
      const item = document.createElement('div');
      item.className = 'multi-win-item' + (index === 0 ? ' mvp' : '');
      
      let avHTML = `<div class="multi-win-letter">${player.username.charAt(0).toUpperCase()}</div>`;
      if (player.profilePic) {
         avHTML = `<img src="${player.profilePic}" alt="Avatar" class="multi-win-avatar" crossorigin="anonymous" referrerpolicy="no-referrer" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"><div class="multi-win-letter" style="display:none;">${player.username.charAt(0).toUpperCase()}</div>`;
      }
      
      let rankText = index === 0 ? 'MVP' : `#${index + 1}`;
      let rankColor = index === 0 ? '#ffd700' : (index === 1 ? '#c0c0c0' : (index === 2 ? '#cd7f32' : '#ffffff'));
      
      // Truncate words list to keep it compact
      let wordsDisplay = player.words.slice(0, 3).join(', ');
      if (player.words.length > 3) {
        wordsDisplay += `, dan ${player.words.length - 3} lainnya`;
      }
      
      item.innerHTML = `
        <div style="font-weight:900; color:${rankColor}; width: 50px; text-align:center; flex-shrink: 0; font-size: 14px;">${rankText}</div>
        <div class="multi-win-avatar-wrap">
          ${avHTML}
        </div>
        <div class="multi-win-details" style="flex: 1; padding: 0 10px; min-width: 0;">
          <div class="multi-win-name" style="font-size: 15px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #fff;">${player.username}</div>
          <div class="multi-win-word" style="font-size: 11px; color: #bbb; margin-top: 2px; line-height: 1.3;">Menjawab: ${wordsDisplay}</div>
        </div>
        <div class="multi-win-pts" style="font-size: 18px; color: #ffd700; font-weight: 900; flex-shrink: 0; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">+${player.points}</div>
      `;
      list.appendChild(item);
      item.style.animation = 'slideInRight 0.3s ease-out forwards';
    }, delay);
    delay += 300;
  });
  
  // Gunakan fungsi bawaan untuk transisi menang (mengurus Like, timer otomatis, dan audio)
  setTimeout(() => {
    triggerWinTransition(7000, true);
  }, delay + 1000);
}
// Helper universal untuk mengecek apakah ronde/puzzle saat ini sudah aktif (mencegah puzzle berganti sendiri saat koneksi terhubung)
function hasActiveGameRound() {
  if (currentGameMode === 'betweenle') return !!betweenleSecretWord;
  if (currentGameMode === 'cascadle') return !!(cascadleTargets && cascadleTargets[cascadleCurrentLevel]);
  if (currentGameMode === 'wanderwords') return !!wanderWordsCurrentPuzzle;
  if (currentGameMode === 'wordcluster') return !!(wordClusterItems && wordClusterItems.length > 0 && wordClusterCurrentTopic);
  if (currentGameMode === 'wordladder') return !!wordLadderTargetWord;
  if (currentGameMode === 'wordmatch') return !!wordMatchCurrentWord;
  if (currentGameMode === 'fillblanks') return !!(fillBlanksTargets && fillBlanksTargets.length > 0);
  if (currentGameMode === 'wordtango') return !!(wordTangoTargets && wordTangoTargets.length > 0);
  if (currentGameMode === 'wordgrid') return !!(wgGrid && wgGrid.length > 0);
  if (currentGameMode === 'squareword') return currentWord === 'SQUAREWORD' || (typeof squarewordSolution !== 'undefined' && !!squarewordSolution);
  return !!currentWord;
}

// Helper untuk mem-parsing nickname pemenang menjadi kata starting word yang valid
function parseWinnerNicknameForStarter(winnerObj) {
  if (!winnerObj) return null;
  const candidates = [winnerObj.nickname, winnerObj.uniqueId];
  for (const raw of candidates) {
    if (!raw || typeof raw !== 'string') continue;
    // Ambil hanya karakter huruf Latin alfabet (A-Z)
    const letters = raw.toUpperCase().replace(/[^A-Z]/g, '');
    // Minimum 3 huruf untuk batas kata yang valid di kamus (panjang 3 sampai 8)
    if (letters.length >= 3) {
      // Jika nickname lebih dari 8 huruf potong nickname sampai 8 huruf
      return letters.slice(0, 8);
    }
  }
  return null;
}

// Start Game
function startNewRound() {
  applyGameModeUI();
  if (typeof updateLangBadgeUI === 'function') updateLangBadgeUI(lastLang);
  hasPlayedCloseAudio = false;
  resetWinStreaks(); // Reset cooldown anti-dominasi setiap ronde baru

  if (currentGameMode === 'betweenle') {
    betweenleRound = round;
    startBetweenleGame();
    return;
  }
  if (currentGameMode === 'cascadle') {
    cascadleRound = round;
    startCascadleGame();
    return;
  }
  if (currentGameMode === 'wanderwords') {
    wanderWordsRound = round;
    startWanderWordsGame();
    return;
  }
  if (currentGameMode === 'wordcluster') {
    wordClusterRound = round;
    startWordClusterGame();
    return;
  }
  if (currentGameMode === 'wordmatch') {
    wordMatchRound = round;
    startWordMatchGame();
    return;
  }
  if (currentGameMode === 'wordpyramid') {
    wordPyramidRound = round;
    startWordPyramidGame();
    return;
  }
  if (currentGameMode === 'squareword') {
    WORD_LENGTH = 5;
    document.documentElement.style.setProperty('--word-length', 5);
    updateBoardScaleUI();
    if (wordsLoaded && allValidWords && allValidWords[5] && allValidWords[5].length > 0) {
      VALID_WORDS = allValidWords[5];
      TARGET_WORDS = allTargetWords[5];
      availableWords = allAvailableWords[5];
    }
    syncValidWordsSet();
    initSquarewordRound();
    return;
  }

  // Simpan kata target ronde sebelumnya sebelum menentukan WORD_LENGTH baru
  if (currentWord && currentWord.length >= 3 && currentWord.length <= 8) {
    lastRoundTargetWord = currentWord;
  }

  const isGuessMode = !currentGameMode || currentGameMode === 'wordle' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit';
  let parsedWinnerWord = null;
  if (isAutoStarterWinnerNickname && isGuessMode && lastRoundWinner) {
    parsedWinnerWord = parseWinnerNicknameForStarter(lastRoundWinner);
  }

  // Word500 uses lengths selected by host from allowed_lengths (Panjang Kata checkboxes)
  if (currentGameMode === 'word500') {
    let allowedLengths = [5];
    try {
      const saved = JSON.parse(localStorage.getItem('allowed_lengths') || '[5]');
      // Ambil panjang kata yang dipilih host (cocok untuk Word500: 4, 5, 6 huruf)
      const validForW500 = saved.filter(l => l >= 4 && l <= 6);
      if (validForW500.length > 0) {
        allowedLengths = validForW500;
      } else if (saved.some(l => l > 6)) {
        allowedLengths = [6];
      } else if (saved.includes(3)) {
        allowedLengths = [4];
      }
    } catch(e) {}
    const rIdx = Math.floor(Math.random() * allowedLengths.length);
    WORD_LENGTH = allowedLengths[rIdx];
  } else if (isAutoStarterWinnerNickname && isGuessMode && parsedWinnerWord) {
    // Jumlah huruf yang dimainkan mengikuti jumlah huruf nickname pemenang (maks 8 huruf)
    WORD_LENGTH = parsedWinnerWord.length;
    if (currentGameMode === 'colorfit' && WORD_LENGTH > 6) {
      WORD_LENGTH = 6;
      parsedWinnerWord = parsedWinnerWord.slice(0, 6);
    }
  } else if (isAutoStarterWinnerNickname && isGuessMode && lastRoundTargetWord && lastRoundTargetWord.length >= 3 && lastRoundTargetWord.length <= 8) {
    // Jika nickname bukan huruf valid / tidak bisa diparsing, jumlah huruf mengikuti kata target sebelumnya
    WORD_LENGTH = lastRoundTargetWord.length;
    if (currentGameMode === 'colorfit' && WORD_LENGTH > 6) {
      WORD_LENGTH = 6;
    }
  } else {
    let allowedLengths = [5, 6, 7];
    try { allowedLengths = JSON.parse(localStorage.getItem('allowed_lengths') || '[5,6,7,8]'); } catch(e) {}
    if (!allowedLengths || allowedLengths.length === 0) allowedLengths = [5];
    const rIdx = Math.floor(Math.random() * allowedLengths.length);
    WORD_LENGTH = allowedLengths[rIdx];
    if (currentGameMode === 'colorfit' && WORD_LENGTH > 6) {
      WORD_LENGTH = 6;
    }
  }
  document.documentElement.style.setProperty('--word-length', WORD_LENGTH);
  updateBoardScaleUI();
  
  if (wordsLoaded) {
    TARGET_WORDS = allTargetWords[WORD_LENGTH];
    VALID_WORDS = allValidWords[WORD_LENGTH];
    availableWords = allAvailableWords[WORD_LENGTH];
  } else {
    TARGET_WORDS = [];
    VALID_WORDS = [];
    availableWords = [];
  }
  syncValidWordsSet();

  lastRoundTargetWord = lastRoundTargetWord || currentWord;
  currentWord = getRandomWord();

  // Pastikan target baru tidak sama persis dengan starting word agar tidak langsung menang seketika
  const checkConflictWord = parsedWinnerWord || lastRoundTargetWord;
  if (checkConflictWord && TARGET_WORDS && TARGET_WORDS.length > 1) {
    let attempts = 0;
    while (currentWord === checkConflictWord && attempts < 50) {
      currentWord = getRandomWord();
      attempts++;
    }
  }
  guesses = [];
  guessQueue = [];
  discoveredLetters = Array(WORD_LENGTH).fill(null);
  bestGuess = null;
  word500History = [];
  word500PendingInvalidRow = null;
  userGuessDedup = new Set(); // reset per ronde
  isGameOver = false;
  isProcessing = false;
  isWaitingForLikes = false;
  roundNumber.textContent = round;
  
  // Reset like progress for new round
  currentLikes = 0;
  
  // Hide progress bar and reset win avatar on new round
  const winAvatar = document.getElementById('winAvatar');
  if (winAvatar) winAvatar.src = 'assets/bg_nature.png';
  const likeProgress = document.getElementById('likeProgressContainer');
  if (likeProgress) likeProgress.style.display = 'none';
  
  updateLikeProgressBar();
  
  // Toggle background for visual delight (only if dynamic mode is on)
  if (isDynamicBg) {
    currentBg = currentBg === 'nature' ? 'city' : 'nature';
    applyDynamicBg();
  }
  
  if (currentGameMode === 'fillblanks') {
    fillBlanksTargets = [];
    if (TARGET_WORDS.length >= 6) {
      const shuffled = [...TARGET_WORDS];
      shuffleArray(shuffled);
      const isUltra = (hardModeState === 'ultra');
      
      for (let i = 0; i < 6; i++) {
        const word = shuffled[i];
        const numClues = WORD_LENGTH <= 5 ? 1 : (WORD_LENGTH <= 7 ? 2 : 3);
        const clues = Array(WORD_LENGTH).fill(null);
        const allIndices = Array.from({length: WORD_LENGTH}, (_, k) => k);
        shuffleArray(allIndices);
        
        if (isUltra) {
          // Place yellow clues: correct letters in wrong positions
          let placedClues = 0;
          for (let c = 0; c < WORD_LENGTH && placedClues < numClues; c++) {
            const letterIdx = allIndices[c];
            const letter = word[letterIdx];
            // Find an empty spot k such that word[k] !== letter
            let validSpots = [];
            for (let k = 0; k < WORD_LENGTH; k++) {
              if (clues[k] === null && word[k] !== letter) {
                validSpots.push(k);
              }
            }
            if (validSpots.length > 0) {
              const placeIdx = validSpots[Math.floor(Math.random() * validSpots.length)];
              clues[placeIdx] = { char: letter, status: 'present' };
              placedClues++;
            } else {
              // Fallback to any empty spot
              let emptySpots = [];
              for (let k = 0; k < WORD_LENGTH; k++) {
                if (clues[k] === null) emptySpots.push(k);
              }
              if (emptySpots.length > 0) {
                const placeIdx = emptySpots[Math.floor(Math.random() * emptySpots.length)];
                const status = (word[placeIdx] === letter) ? 'correct' : 'present';
                clues[placeIdx] = { char: letter, status: status };
                placedClues++;
              }
            }
          }
          fillBlanksTargets.push({ word, clues, solved: false, solver: null, isAnimating: false, isYellowRow: true });
        } else {
          // Place green clues (Hard Mode is OFF)
          const greenSources = [];
          for (let c = 0; c < numClues; c++) {
            greenSources.push(allIndices[c]);
          }
          // Place green clues
          for (const idx of greenSources) {
            clues[idx] = { char: word[idx], status: 'correct' };
          }
          fillBlanksTargets.push({ word, clues, solved: false, solver: null, isAnimating: false, isYellowRow: false });
        }
      }
    }
  }

  if (currentGameMode === 'wordtango') {
    wordTangoTargets = [];
    wordTangoPool = [];
    tangoGuessedWords.clear();
    const tangoGuessFeed = document.getElementById('tangoGuessFeed');
    if (tangoGuessFeed) tangoGuessFeed.innerHTML = '';
    const tangoPatterns = [
      [4, 4, 5, 6],
      [4, 5, 5, 6],
      [4, 4, 5, 5],
      [4, 5, 6, 6],
      [4, 4, 6, 6],
      [4, 5, 5, 5],
      [3, 4, 5, 6],
      [3, 5, 5, 6]
    ];
    const tangoLengths = tangoPatterns[Math.floor(Math.random() * tangoPatterns.length)];
    let poolIdCounter = 0;

    for (let i = 0; i < 4; i++) {
      const len = tangoLengths[i];
      const list = allTargetWords[len] || [];
      const chosenWord = list.length > 0
        ? list[Math.floor(Math.random() * list.length)]
        : (len === 3 ? "APA" : (len === 4 ? "KATA" : (len === 5 ? "RUMAH" : "MENARA")));

      const missingIndices = [];
      const numMissing = len === 3 ? 2 : (len === 4 ? 3 : (len === 5 ? 3 : 4));
      const allIdx = Array.from({ length: len }, (_, k) => k);
      shuffleArray(allIdx);
      for (let m = 0; m < numMissing; m++) {
        const idx = allIdx[m];
        missingIndices.push(idx);
        wordTangoPool.push({ id: poolIdCounter++, char: chosenWord[idx], used: false });
      }
      missingIndices.sort((a, b) => a - b);
      wordTangoTargets.push({
        word: chosenWord,
        length: len,
        missingIndices,
        solved: false,
        solver: null,
        points: len * 3
      });
    }
    shuffleArray(wordTangoPool);
  }

  if (currentGameMode === 'wordgrid') {
    generateWordGridBoard();
  }

  if (currentGameMode === 'wordladder') {
    startWordLadderRound();
  }

  // Apply mode-specific UI
  applyGameModeUI();
  initBoard();
  if (currentGameMode !== 'word500' && currentGameMode !== 'fillblanks' && currentGameMode !== 'wordtango') {
    initHintBoard();
  }
  updateBestGuessUI();

  console.log(`[Cheat] Target word is: ${currentWord}`);
  startInstructionRotation();
  const getW500Name = () => window.w500UseMastermind ? 'Word Pegs 5' : 'Word500';
  const gameName = currentGameMode === 'wordladder' ? 'Word Ladder' : (currentGameMode === 'squareword' ? 'Kotak Kata' : (currentGameMode === 'wordtango' ? 'Word Tango' : (currentGameMode === 'fillblanks' ? 'Word Fill' : (currentGameMode === 'word500' ? getW500Name() : 'Wordle'))));
  showToast(`${gameName} Round ${round} Started!`, 2000);
  
  if (window.playHostAudio) playHostAudio('start');

  // Auto-Starter logic
  const isGuessModeForStarter = !currentGameMode || currentGameMode === 'wordle' || currentGameMode === 'word500' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit';

  if (isGuessModeForStarter && (isAutoStarterWinnerNickname || isAutoStarterPreviousTarget)) {
    let starterWord = null;
    let starterUserData = null;
    let starterToastMsg = null;

    if (isAutoStarterWinnerNickname) {
      const winnerWord = parseWinnerNicknameForStarter(lastRoundWinner);
      if (winnerWord && winnerWord.length === WORD_LENGTH) {
        starterWord = winnerWord;
        const dispName = (lastRoundWinner && (lastRoundWinner.nickname || lastRoundWinner.uniqueId)) || winnerWord;
        starterUserData = {
          nickname: dispName,
          uniqueId: (lastRoundWinner && lastRoundWinner.uniqueId) || 'winner',
          profilePictureUrl: (lastRoundWinner && lastRoundWinner.profilePictureUrl) || 'assets/bg_nature.png',
          isStarter: true
        };
        starterToastMsg = `Starting Word: "${starterWord}" (${dispName} • ${WORD_LENGTH} Huruf)`;
      } else if (lastRoundTargetWord && lastRoundTargetWord.length === WORD_LENGTH && lastRoundTargetWord !== currentWord) {
        // Fallback: starting word menggunakan kata target sebelumnya jika nickname tidak ada/tidak valid
        starterWord = lastRoundTargetWord;
        starterUserData = { nickname: 'TARGET SBLM', uniqueId: 'system', isStarter: true };
        starterToastMsg = `Starting Word: "${starterWord}" (Target Sebelumnya • ${WORD_LENGTH} Huruf)`;
      } else {
        // Fallback jika belum ada ronde sebelumnya (Ronde 1)
        const wordPool = (VALID_WORDS && VALID_WORDS.length > 0) ? VALID_WORDS : (TARGET_WORDS || []);
        if (wordPool.length > 0) {
          const matchingWords = wordPool.filter(w => w.length === WORD_LENGTH && w !== currentWord);
          starterWord = matchingWords.length > 0 ? matchingWords[Math.floor(Math.random() * matchingWords.length)] : wordPool[0];
          starterUserData = { nickname: 'SISTEM', uniqueId: 'system', isStarter: true };
        }
      }
    } else if (isAutoStarterPreviousTarget) {
      // 1. Jika kata target sebelumnya ada dan panjangnya sama persis
      if (lastRoundTargetWord && lastRoundTargetWord.length === WORD_LENGTH && lastRoundTargetWord !== currentWord) {
        starterWord = lastRoundTargetWord;
      } else {
        // 2. Jika panjang huruf berbeda atau ronde 1, pilih kata acak yang valid
        const wordPool = (VALID_WORDS && VALID_WORDS.length > 0) ? VALID_WORDS : (TARGET_WORDS || []);
        if (wordPool.length > 0) {
          const matchingWords = wordPool.filter(w => w.length === WORD_LENGTH && w !== currentWord);
          if (matchingWords.length > 0) {
            starterWord = matchingWords[Math.floor(Math.random() * matchingWords.length)];
          } else {
            starterWord = wordPool[Math.floor(Math.random() * wordPool.length)];
          }
        }
      }
      if (starterWord) {
        starterUserData = { nickname: 'SISTEM', uniqueId: 'system', isStarter: true };
      }
    }

    if (starterWord) {
      guessQueue.push({ guessWord: starterWord, userData: starterUserData || { nickname: 'SISTEM', uniqueId: 'system', isStarter: true } });
      setTimeout(processQueue, 300);
      if (starterToastMsg) {
        setTimeout(() => showToast(starterToastMsg, 3500), 400);
      }
    }
  }
}

// Switch Account — disconnect and go back to login
function switchAccount() {
  // Stop auto-reconnect
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }

  // Tell server to disconnect TikTok
  if (socket && socket.connected) {
    socket.emit('disconnect-tiktok');
  }

  // Clear saved session
  try {
    localStorage.removeItem('wordle_username');
    localStorage.removeItem('wordle_lang');
    localStorage.removeItem('wordle_sessionid');
  } catch (e) {}

  // Reset state
  lastUsername = "";
  lastLang = "";
  lastSessionId = "";
  currentWord = "";
  isConnectedToTikTok = false;
  isGameOver = false;
  guesses = [];
  round = 1;
  
  // Reset Leaderboard Sesi
  playerPoints = {};
  initWeeklyLeaderboard();

  // Switch UI back to login
  gameContainer.style.display = 'none';
  document.getElementById('hostMusicControl').style.display = 'none';
  hideDisconnectBanner();
  loginOverlay.style.display = 'flex';
  connectBtn.disabled = false;
  connectBtn.textContent = "Connect to Live";
  loginStatus.textContent = "";
  document.getElementById('usernameInput').value = "";
  document.getElementById('usernameInput').focus();
}

// Kembali ke Daftar Game (Menu Utama)
function backToGameList(e) {
  if (e) e.stopPropagation();

  // Hentikan auto-reconnect timer
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }

  // Keep TikTok connection alive — only clear game state
  // Connection is only terminated via explicit 'Disconnect' button

  // Hapus mode game saat ini dari sessionStorage
  try {
    sessionStorage.removeItem('wordle_gameMode');
  } catch (ex) {}

  // Reset status game (tapi BUKAN status koneksi)
  currentGameMode = "";
  currentWord = "";
  isGameOver = false;
  guesses = [];
  round = 1;
  playerPoints = {};

  // Sembunyikan container game & login overlay, tampilkan game selection
  gameContainer.style.display = 'none';
  loginOverlay.style.display = 'none';
  document.getElementById('hostMusicControl').style.display = 'none';
  hideDisconnectBanner();
  
  const gameSelectOverlay = document.getElementById('gameSelectOverlay');
  if (gameSelectOverlay) {
    gameSelectOverlay.style.display = 'flex';
  }

  // Update connection status banner on game select screen
  const connBanner = document.getElementById('gameSelectConnectedBanner');
  const connUser = document.getElementById('gameSelectConnectedUser');
  const subtitle = document.getElementById('gameSelectSubtitle');
  if (connBanner && connUser) {
    if (isConnectedToTikTok && lastUsername) {
      connUser.textContent = `@${lastUsername}`;
      connBanner.style.display = 'flex';
      if (subtitle) subtitle.textContent = 'Pilih game berikutnya — langsung mulai!';
    } else {
      connBanner.style.display = 'none';
      if (subtitle) subtitle.textContent = 'Pilih game untuk dimainkan';
    }
  }

  // Tutup dropdown pengaturan
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
}
window.backToGameList = backToGameList;

// Settings — language picker
function toggleSettings(e) {
  e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  dropdown.classList.toggle('open');

  // Highlight active language
  document.querySelectorAll('.lang-option').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lastLang);
  });

  // Sync display-rows label with current mode
  updateDisplayRowsUI();
}

function changeLang(lang, e) {
  e.stopPropagation();
  if (lang === lastLang) {
    document.getElementById('settingsDropdown').classList.remove('open');
    return;
  }

  lastLang = lang;
  try { localStorage.setItem('wordle_lang', lang); } catch (e) {}

  updateLangBadgeUI(lang);

  // Close dropdown
  document.getElementById('settingsDropdown').classList.remove('open');

  // Reload word lists with new language and start fresh round
  loadWordLists(lang).then(() => {
    showToast(`Language changed!`, 2000);
    startNewRound();
  });
}

function updateLangBadgeUI(lang) {
  const badge = document.getElementById('currentLangBadge');
  if (!badge) return;
  const target = lang || lastLang || localStorage.getItem('wordle_lang') || 'id';
  if (target === 'en') {
    badge.innerHTML = '<i class="fa-solid fa-language" style="margin-right: 4px;"></i>EN';
  } else if (target === 'mixed') {
    badge.innerHTML = '<i class="fa-solid fa-globe" style="margin-right: 4px;"></i>MIX';
  } else {
    badge.innerHTML = '<i class="fa-solid fa-language" style="margin-right: 4px;"></i>ID';
  }
}


// Close settings dropdown when clicking elsewhere
document.addEventListener('click', () => {
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
});

let hardModeState = localStorage.getItem('wordle_hardModeState') || 'off';
let isNoYellowMode = localStorage.getItem('wordle_noYellow') === 'true';

if (localStorage.getItem('wordle_hardMode') === 'true') {
  hardModeState = 'hard';
  localStorage.removeItem('wordle_hardMode');
  localStorage.setItem('wordle_hardModeState', 'hard');
} else if (localStorage.getItem('wordle_hardMode') === 'false') {
  localStorage.removeItem('wordle_hardMode');
}

function toggleNoYellow(checked) {
  isNoYellowMode = checked;
  try { localStorage.setItem('wordle_noYellow', checked); } catch(e) {}
  if (currentGameMode === 'word500' || currentGameMode === 'wordfit') {
    if (currentGameMode === 'wordfit') renderWordFitBoard();
    else renderWord500Board();
  }
}

let isNoRepeatMode = localStorage.getItem('wordle_noRepeat') === 'true';

window.isNoRepeatActiveForMode = function() {
  if (!isNoRepeatMode) return false;
  return currentGameMode === 'wordle' || 
         currentGameMode === 'word500' || 
         
         currentGameMode === 'wordfit' || 
         currentGameMode === 'colorfit';
};

window.toggleNoRepeat = function(checked) {
  isNoRepeatMode = checked;
  try { localStorage.setItem('wordle_noRepeat', checked); } catch(e) {}
  
  // Clear available words pool to force generation using the new filter
  for (let key in allAvailableWords) {
    allAvailableWords[key] = [];
  }

  updateNoRepeatBadgeUI();
  
  // Restart round for puzzle modes so the new rule applies immediately
  if (currentGameMode === 'wordfit' || currentGameMode === 'word500') {
    startNewRound();
  }
};

window.toggleAutoStarterWinner = function(checked) {
  isAutoStarterWinnerNickname = checked;
  try { localStorage.setItem('wordle_autoStarterWinner', checked); } catch(e) {}
  showToast(checked ? 'Starting Word Nickname: AKTIF' : 'Starting Word Nickname: NONAKTIF', 2000);
  if (typeof localSocket !== 'undefined' && localSocket && localSocket.connected) {
    localSocket.emit('update-game-settings', { autoStarterWinner: checked });
  }
};

window.toggleAutoStarter = function(checked) {
  isAutoStarterPreviousTarget = checked;
  try { localStorage.setItem('wordle_autoStarter', checked); } catch(e) {}
  showToast(checked ? 'Auto-Starter Kata Target: AKTIF' : 'Auto-Starter Kata Target: NONAKTIF', 2000);
  if (typeof localSocket !== 'undefined' && localSocket && localSocket.connected) {
    localSocket.emit('update-game-settings', { autoStarterPreviousTarget: checked });
  }
};

window.toggleShowHintsDiscovered = function(checked) {
  isShowHintsDiscovered = checked;
  try { localStorage.setItem('wordle_showHintsDiscovered', checked); } catch(e) {}
  applyGameModeUI();
  showToast(checked ? '💡 Bar Hints Discovered: AKTIF' : '💡 Bar Hints Discovered: NONAKTIF', 2000);
};

let isFollowerOnlyGuess = localStorage.getItem('wordle_followerOnlyGuess') === 'true';

window.updateFollowerOnlyGuessBadgeUI = function() {
  const badge = document.getElementById('followerOnlyBadge');
  if (badge) {
    badge.style.display = isFollowerOnlyGuess ? 'inline-flex' : 'none';
  }
};

window.toggleFollowerOnlyGuess = function(checked) {
  isFollowerOnlyGuess = checked;
  try { localStorage.setItem('wordle_followerOnlyGuess', checked); } catch(e) {}
  const tog = document.getElementById('followerOnlyGuessToggle');
  if (tog) tog.checked = checked;
  if (typeof updateFollowerOnlyGuessBadgeUI === 'function') updateFollowerOnlyGuessBadgeUI();
  if (localSocket) {
    localSocket.emit('update-game-settings', { followerOnlyGuess: checked });
  }
  showToast(checked ? '👤 Tebakan Kata: Hanya Follower' : '👥 Tebakan Kata: Semua Penonton', 2000);
};

window.toggleFollowerOnlyMusic = function(checked) {
  musicSettings.followerOnly = checked;
  try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
  const togModal = document.getElementById('musicFollowerOnlyToggle');
  if (togModal) togModal.checked = checked;
  const togGroup = document.getElementById('musicFollowerOnlyGroupToggle');
  if (togGroup) togGroup.checked = checked;
  if (localSocket) {
    localSocket.emit('update-game-settings', { followerOnlyMusic: checked });
  }
  showToast(checked ? '🎵 Request Musik: Hanya Follower' : '🎵 Request Musik: Semua Penonton', 2000);
};

function updateNoRepeatBadgeUI() {
  const badge = document.getElementById('noRepeatBadge');
  if (!badge) return;
  badge.style.display = window.isNoRepeatActiveForMode() ? 'inline-flex' : 'none';
}


function toggleHardMode(e) {
  if (e) e.stopPropagation();
  if (hardModeState === 'off') {
    hardModeState = 'hard';
  } else if (hardModeState === 'hard') {
    hardModeState = 'ultra';
  } else {
    hardModeState = 'off';
  }
  try { localStorage.setItem('wordle_hardModeState', hardModeState); } catch(e) {}
  updateHardModeUI();
  
  let msg = 'Hard Mode Dinonaktifkan';
  const isSortedClueMode = (currentGameMode === 'word500' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit');
  if (hardModeState === 'hard') {
    msg = isSortedClueMode ? '🔥 Hard Mode: Wajib cocok dgn skor petunjuk!' : '🔥 Hard Mode Diaktifkan';
  } else if (hardModeState === 'ultra') {
    msg = isSortedClueMode ? '☠️ Ultra Hard: Wajib cocok semua petunjuk!' : '☠️ Ultra Hard Mode Diaktifkan';
  }
  showToast(msg, 2500);

  // Restart round so the new mode is applied immediately
  startNewRound();
}

window.toggleWgDifficulty = function(e) {
  if (e) e.stopPropagation();
  if (wgDifficulty === 'easy') {
    wgDifficulty = 'medium';
  } else if (wgDifficulty === 'medium') {
    wgDifficulty = 'hard';
  } else if (wgDifficulty === 'hard') {
    wgDifficulty = 'mixed';
  } else {
    wgDifficulty = 'easy';
  }
  try { localStorage.setItem('wordle_wgDifficulty', wgDifficulty); } catch(e) {}
  updateWgDifficultyUI();
  
  let msg = 'Kesulitan Word Grid: MUDAH';
  if (wgDifficulty === 'medium') msg = '🧩 Kesulitan Word Grid: SEDANG';
  if (wgDifficulty === 'hard') msg = '🧩 Kesulitan Word Grid: SULIT';
  if (wgDifficulty === 'mixed') msg = '🧩 Kesulitan Word Grid: CAMPURAN';
  showToast(msg, 2000);
  
  if (currentGameMode === 'wordgrid') {
    generateWordGridBoard();
  }
};

function updateWgDifficultyUI() {
  const btn = document.getElementById('wgDifficultyBtn');
  if (btn) {
    if (wgDifficulty === 'easy') {
      btn.innerHTML = '🧩 Kesulitan Board: MUDAH';
      btn.style.color = '';
    } else if (wgDifficulty === 'medium') {
      btn.innerHTML = '🧩 Kesulitan Board: SEDANG';
      btn.style.color = '#ff9f43';
    } else if (wgDifficulty === 'hard') {
      btn.innerHTML = '🧩 Kesulitan Board: SULIT';
      btn.style.color = '#ee5253';
    } else if (wgDifficulty === 'mixed') {
      btn.innerHTML = '🧩 Kesulitan Board: CAMPURAN';
      btn.style.color = '#a855f7'; // matching purple theme
    }
  }
}

function updateHardModeUI() {
  const btn = document.getElementById('hardModeBtn');
  if (btn) {
    if (hardModeState === 'off') {
      btn.innerHTML = '🔥 Hard Mode: OFF';
      btn.style.color = '';
    } else if (hardModeState === 'hard') {
      btn.innerHTML = '🔥 Hard Mode: ON';
      btn.style.color = '#fe2c55';
    } else if (hardModeState === 'ultra') {
      btn.innerHTML = '☠️ Ultra Hard: ON';
      btn.style.color = '#8b0000';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('wordle_lang') || 'id';
  lastLang = savedLang;
  const langSelect = document.getElementById('languageSelect');
  if (langSelect) langSelect.value = savedLang;
  updateLangBadgeUI(savedLang);
  const nrToggle = document.getElementById('noRepeatToggle');
  if (nrToggle) nrToggle.checked = isNoRepeatMode;
  updateNoRepeatBadgeUI();
  const fogToggle = document.getElementById('followerOnlyGuessToggle');
  if (fogToggle) fogToggle.checked = isFollowerOnlyGuess;
  if (typeof updateFollowerOnlyGuessBadgeUI === 'function') updateFollowerOnlyGuessBadgeUI();
  const fomGroupToggle = document.getElementById('musicFollowerOnlyGroupToggle');
  if (fomGroupToggle) fomGroupToggle.checked = !!musicSettings.followerOnly;
  updateHardModeUI();
  // Sync dynamic bg toggle state
  const toggle = document.getElementById('dynamicBgToggle');
  if (toggle) toggle.checked = isDynamicBg;
  // Apply static bg immediately if needed
  if (!isDynamicBg) applyStaticBg();
  
  // Load background customization
  const savedBgUrl = localStorage.getItem('custom_bg_url');
  if (savedBgUrl && !savedBgUrl.startsWith('data:')) {
    // Only show URL in input if it's not a base64 data URL (too large)
    const inputEl = document.getElementById('bgUrlInput');
    if (inputEl) inputEl.value = savedBgUrl;
  }
  if (!isDynamicBg) applyStaticBg();

  // Restore saved solid color into RGB picker
  const savedColor = localStorage.getItem('custom_bg_color');
  if (savedColor) {
    const hexInput = document.getElementById('bgHexInput');
    if (hexInput) hexInput.value = savedColor;
    syncRgbFromHex(savedColor);
  } else {
    // Default dark color
    if (typeof updateRgbPreview === 'function') updateRgbPreview(32, 33, 36);
  }

  const savedBlur = localStorage.getItem('custom_bg_blur') || 12;
  const savedDim = localStorage.getItem('custom_bg_dim') || 60;
  const blurSlider = document.getElementById('bgBlurSlider');
  const dimSlider = document.getElementById('bgDimSlider');
  if (blurSlider) blurSlider.value = savedBlur;
  if (dimSlider) dimSlider.value = savedDim;
  if (typeof applyBgEffects === 'function') applyBgEffects(savedBlur, savedDim);
  
  // Initialize like restart settings UI
  const playEveryGiftSoundToggle = document.getElementById('playEveryGiftSoundToggle');
  if (playEveryGiftSoundToggle) playEveryGiftSoundToggle.checked = isPlayEveryGiftSound;

  const likeToggle = document.getElementById('likeRestartToggle');
  if (likeToggle) likeToggle.checked = isLikeRestartEnabled;
  const likeThresholdInput = document.getElementById('likeThresholdInput');
  if (likeThresholdInput) likeThresholdInput.value = likeRestartThreshold;
  const likeContainer = document.getElementById('likeThresholdContainer');
  if (likeContainer) likeContainer.style.display = isLikeRestartEnabled ? 'block' : 'none';
  updateLikeProgressBar();
  
  // Load auto fullscreen pref
  const savedFs = localStorage.getItem('tiktok_auto_fullscreen');
  if (savedFs !== null) {
    isAutoFullscreen = savedFs === 'true';
  }
  const fsToggle = document.getElementById('autoFullscreenToggle');
  if (fsToggle) fsToggle.checked = isAutoFullscreen;

  // Initialize visual theme UI
  syncVisualThemeUI(currentVisualTheme);

  // Start instruction rotation immediately so instruction bar rotates in all modes
  if (typeof startInstructionRotation === 'function') {
    startInstructionRotation();
  }
});

// ═══════════════════════════════════════════════════════
//  VISUAL THEME SYSTEM (Dark Modern / Sepia Cream Pastel)
// ═══════════════════════════════════════════════════════
const urlThemeParam = new URLSearchParams(window.location.search).get('theme');
let currentVisualTheme = urlThemeParam || localStorage.getItem('wordle_theme') || 'dark';

function syncVisualThemeUI(theme) {
  const isSepia = theme === 'sepia';
  document.body.classList.toggle('theme-sepia', isSepia);
  document.body.setAttribute('data-theme', theme);
  document.documentElement.classList.toggle('theme-sepia', isSepia);

  // Update Settings Buttons
  const btnDark = document.getElementById('themeBtnDark');
  const btnSepia = document.getElementById('themeBtnSepia');
  if (btnDark) btnDark.classList.toggle('active', !isSepia);
  if (btnSepia) btnSepia.classList.toggle('active', isSepia);

  // Update Header Theme Icon & Title
  const headerIcon = document.getElementById('headerThemeIcon');
  if (headerIcon) {
    headerIcon.className = isSepia ? 'fa-solid fa-moon' : 'fa-solid fa-palette';
  }
  const headerBtn = document.getElementById('themeToggleBtn');
  if (headerBtn) {
    headerBtn.title = isSepia ? 'Ganti ke Tema Gelap (Dark Mode)' : 'Ganti ke Tema Sepia Cream Pastel (Sore Hari)';
  }

  // Update Front Menu Toggle Label & Icon
  const frontLabel = document.getElementById('frontThemeLabel');
  if (frontLabel) {
    frontLabel.textContent = isSepia ? 'Tema: Gelap' : 'Tema: Sepia Cream';
  }
  const frontIcon = document.getElementById('frontThemeIcon');
  if (frontIcon) {
    frontIcon.className = isSepia ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
  }
}

// Initial theme apply before DOMContentLoaded
try {
  const initialTheme = urlThemeParam || localStorage.getItem('wordle_theme') || 'dark';
  currentVisualTheme = initialTheme;
  const isSepia = initialTheme === 'sepia';
  if (document.body) {
    document.body.classList.toggle('theme-sepia', isSepia);
    document.body.setAttribute('data-theme', initialTheme);
  }
  document.documentElement.classList.toggle('theme-sepia', isSepia);
} catch(e) {}

window.setVisualTheme = function(theme, e) {
  if (e) e.stopPropagation();
  currentVisualTheme = theme;
  try {
    localStorage.setItem('wordle_theme', theme);
  } catch(err) {}

  syncVisualThemeUI(theme);

  // Re-apply static bg if active to harmonize colors
  if (!isDynamicBg) {
    applyStaticBg();
  }

  const isSepia = theme === 'sepia';
  showToast(isSepia ? '🌅 Tema Sepia Cream Pastel (Sore Hari) Aktif' : '🌙 Tema Gelap Modern Aktif', 1800);
};

window.toggleVisualTheme = function(e) {
  if (e) e.stopPropagation();
  const nextTheme = (currentVisualTheme === 'sepia') ? 'dark' : 'sepia';
  window.setVisualTheme(nextTheme, e);
};

window.toggleAutoFullscreen = function(enabled) {
  isAutoFullscreen = enabled;
  localStorage.setItem('tiktok_auto_fullscreen', enabled);
  showToast(enabled ? '🔲 Auto Fullscreen Aktif' : '🔲 Auto Fullscreen Nonaktif', 1500);
};

// Dynamic / Static Background toggle
function applyStaticBg() {
  const customUrl = localStorage.getItem('custom_bg_url');
  const customColor = localStorage.getItem('custom_bg_color');
  bgLayer.className = 'bg-layer';
  if (customUrl) {
    bgLayer.style.backgroundImage = `url("${customUrl}")`;
    bgLayer.style.backgroundColor = '';
  } else if (customColor) {
    bgLayer.style.backgroundImage = 'none';
    bgLayer.style.backgroundColor = customColor;
  } else {
    // If sepia theme is active, let CSS gradient shine without solid black override
    if (document.body.classList.contains('theme-sepia')) {
      bgLayer.style.backgroundImage = '';
      bgLayer.style.backgroundColor = '';
    } else {
      // Warna background tab header Google Chrome: #202124
      bgLayer.style.backgroundImage = 'none';
      bgLayer.style.backgroundColor = '#202124';
    }
  }
}

function applyDynamicBg() {
  bgLayer.style.backgroundColor = '';
  bgLayer.style.backgroundImage = ''; // Menghapus inline style 'none' dari applyStaticBg
  bgLayer.className = `bg-layer ${currentBg}`;
}

function toggleDynamicBg(enabled) {
  isDynamicBg = enabled;
  try { localStorage.setItem('wordle_dynamicBg', enabled); } catch(e) {}
  if (enabled) {
    applyDynamicBg();
    showToast('🖼️ Background Dinamis Aktif', 1500);
  } else {
    applyStaticBg();
    showToast('⬛ Background Statis Aktif', 1500);
  }
}

function getScore(guess, target) {
  const g = guess.split('');
  const t = target.split('');
  let c = 0, p = 0;
  for(let i=0; i<g.length; i++) {
    if(g[i]===t[i]) { c++; t[i]=null; g[i]=null; }
  }
  for(let i=0; i<g.length; i++) {
    if(g[i]!==null && t.includes(g[i])) {
      p++;
      t[t.indexOf(g[i])] = null;
    }
  }
  return {c, p};
}

function getWordleFeedback(guess, target) {
  const g = guess.split('');
  const t = target.split('');
  const statuses = Array(g.length).fill('absent');
  for(let i=0; i<g.length; i++) {
    if(g[i]===t[i]) { statuses[i] = 'correct'; t[i]=null; g[i]=null; }
  }
  if (!isNoYellowMode) {
    for(let i=0; i<g.length; i++) {
      if(g[i]!==null && t.includes(g[i])) {
        statuses[i] = 'present';
        t[t.indexOf(g[i])] = null;
      }
    }
  }
  return statuses;
}

function validateHardMode(guessWord) {
  if (hardModeState === 'off' || guesses.length === 0) return { valid: true };

  let validPastGuesses;
  if (currentGameMode === 'colorfit') {
    validPastGuesses = guesses.filter(g => /^[RGBYPO]+$/.test(g));
  } else {
    validPastGuesses = guesses.filter(g => VALID_WORDS.includes(g));
  }

  for (const past of validPastGuesses) {
    if (currentGameMode === 'word500' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit') {
      const actual = getScore(past, currentWord);
      const simulated = getScore(past, guessWord);
      if (actual.c !== simulated.c || actual.p !== simulated.p) {
        // Pesan singkat, jelas, & manusiawi agar langsung dipahami penonton live stream
        let reason = "";
        const actC = actual.c, actP = actual.p;
        const simC = simulated.c, simP = simulated.p;
        const isEn = (typeof lastLang !== 'undefined' && lastLang === 'en');

        if (actC === 0 && actP === 0) {
          reason = isEn 
            ? `All letters in "${past}" are wrong (0🟩 0🟨)! Cannot use them` 
            : `Huruf di "${past}" salah semua (0🟩 0🟨)! Dilarang dipakai`;
        } else if (simC + simP < actC + actP) {
          reason = isEn 
            ? `Need more matching letters from "${past}" (Must have ${actC}🟩 ${actP}🟨)` 
            : `Kurang huruf cocok dgn "${past}"! Wajib ada ${actC}🟩 ${actP}🟨`;
        } else if (simC + simP > actC + actP) {
          reason = isEn 
            ? `Too many matching letters with "${past}" (Max ${actC}🟩 ${actP}🟨)` 
            : `Kebanyakan huruf sama dgn "${past}"! Maksimal ${actC}🟩 ${actP}🟨`;
        } else if (simC !== actC) {
          reason = isEn 
            ? `Green position mismatch with "${past}"! Must have ${actC}🟩` 
            : `Posisi hijau bentrok dgn petunjuk "${past}"! Wajib tepat ${actC}🟩`;
        } else {
          reason = isEn 
            ? `Score doesn't match clue "${past}"! Must be ${actC}🟩 ${actP}🟨` 
            : `Menabrak petunjuk "${past}"! Wajib cocok ${actC}🟩 ${actP}🟨`;
        }
        return { 
          valid: false, 
          msg: `❌ ${reason}`,
          conflictWord: past
        };
      }
    } else {
      const statuses = getWordleFeedback(past, currentWord);
      const newG = guessWord.split('');
      
      // Ultra hard mode check: no using completely gray letters & yellow must change position
      if (hardModeState === 'ultra') {
        const completelyGray = new Set();
        for(let i=0; i<past.length; i++) {
          if (statuses[i] === 'absent') {
            let hasOther = false;
            for(let j=0; j<past.length; j++) {
              if (past[j] === past[i] && (statuses[j] === 'correct' || statuses[j] === 'present')) {
                hasOther = true; break;
              }
            }
            if (!hasOther) completelyGray.add(past[i]);
          }
        }
        for(let i=0; i<guessWord.length; i++) {
          if (completelyGray.has(guessWord[i])) {
            return { valid: false, msg: `Huruf "${guessWord[i]}" (abu-abu) tidak boleh digunakan lagi`, conflictWord: past };
          }
        }

        // Yellow letters CANNOT be reused in the same spot where they were yellow
        for(let i=0; i<past.length; i++) {
          if (statuses[i] === 'present' && guessWord[i] === past[i]) {
            return { 
              valid: false, 
              msg: `Huruf "${past[i]}" kuning di posisi ke-${i+1}, harus dipindah ke posisi lain!`, 
              conflictWord: past 
            };
          }
        }
      }
      
      // Check Greens
      for(let i=0; i<past.length; i++) {
        if(statuses[i] === 'correct') {
          if(newG[i] !== past[i]) {
            return { valid: false, msg: `Huruf ke-${i+1} harus "${past[i]}"`, conflictWord: past };
          }
          newG[i] = null;
        }
      }
      
      // Check Yellows
      for(let i=0; i<past.length; i++) {
        if(statuses[i] === 'present') {
          if(!newG.includes(past[i])) {
             return { valid: false, msg: `Harus mengandung huruf "${past[i]}"`, conflictWord: past };
          }
          newG[newG.indexOf(past[i])] = null;
        }
      }
    }
  }
  return { valid: true };
}

// Connection Logic
function showDisconnectBanner(message, type = 'error') {
  const banner = document.getElementById('disconnectBanner');
  if (banner) {
    const msg = document.getElementById('disconnectMsg');
    if (msg) msg.textContent = message || 'Koneksi terputus';
    
    banner.classList.remove('banner-warning', 'banner-reconnecting');
    if (type === 'warning') {
      banner.classList.add('banner-warning');
    } else if (type === 'reconnecting') {
      banner.classList.add('banner-reconnecting');
    }
    banner.classList.add('show');
  }
}

function hideDisconnectBanner() {
  const banner = document.getElementById('disconnectBanner');
  if (banner) {
    banner.classList.remove('show', 'banner-warning', 'banner-reconnecting');
  }
}

function attemptReconnect() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (!lastUsername) return;

  // Jika backend IndoFinity
  if (socket instanceof IndoFinitySocket) {
    reconnectTimer = setTimeout(() => {
      console.log('[Reconnect] Attempting to reconnect IndoFinity...');
      showToast('🔄 Reconnecting IndoFinity...', 3000);
      connectToLive();
    }, 5000);
    return;
  }

  // Jika backend server.js lokal, server sudah otomatis auto-reconnect.
  // Fallback cadangan jika server perlu disenggol:
  reconnectTimer = setTimeout(() => {
    if (!isConnectedToTikTok && socket && socket.connected) {
      console.log('[Reconnect] Fallback ping to local server for @' + lastUsername);
      socket.emit('connect-tiktok', { uniqueId: lastUsername, sessionId: lastSessionId });
    }
  }, 8000);
}

window.toggleAdvancedSettings = function() {
  const container = document.getElementById('advancedSettingsContainer');
  const btn = document.getElementById('advancedToggleBtn');
  if (container.style.display === 'none') {
    container.style.display = 'block';
    if (btn) btn.innerHTML = '<span>⚙️ Pengaturan Lanjutan</span> <span class="adv-arrow">▲</span>';
  } else {
    container.style.display = 'none';
    if (btn) btn.innerHTML = '<span>⚙️ Pengaturan Lanjutan</span> <span class="adv-arrow">▼</span>';
  }
};

window.handleBackendChange = function(val) {
  const usernameGroup = document.getElementById('usernameInput').parentElement;
  const sessionGroup = document.getElementById('sessionInput').parentElement;
  const ipGroup = document.getElementById('indofinityIpGroup');
  const loginSubtitle = document.getElementById('loginTitle').nextElementSibling;
  if (val === 'indofinity') {
    usernameGroup.style.display = 'none';
    sessionGroup.style.display = 'none';
    if (ipGroup) ipGroup.style.display = 'flex';
    if (loginSubtitle) loginSubtitle.textContent = "Connect via IndoFinity to start";
  } else {
    usernameGroup.style.display = 'flex';
    sessionGroup.style.display = 'flex';
    if (ipGroup) ipGroup.style.display = 'none';
    if (loginSubtitle) loginSubtitle.textContent = "Enter TikTok username to start";
  }
};

function connectToLive() {
  const username = document.getElementById('usernameInput').value.trim();
  const lang = document.getElementById('languageSelect').value;
  const sessionInputElem = document.getElementById('sessionInput');
  const sessionId = sessionInputElem ? sessionInputElem.value.trim() : "";
  const backendSelect = document.getElementById('backendSelect');
  const backend = backendSelect ? backendSelect.value : 'socketio';

  if (backend !== 'indofinity' && !username) {
    loginStatus.textContent = "Enter a username first!";
    return;
  }

  // Destroy socket if it doesn't match current backend or if IndoFinity is disconnected
  if (socket) {
    const isIndoFinity = socket instanceof IndoFinitySocket;
    if ((backend === 'indofinity' && !isIndoFinity) || (backend === 'socketio' && isIndoFinity) || (isIndoFinity && (!socket.connected || (socket.ws && socket.ws.readyState >= 2)))) {
      try { if (socket.ws) socket.ws.close(); } catch(e) {}
      try { if (socket.disconnect) socket.disconnect(); } catch(e) {}
      socket = null;
    }
  }

  // Fallback username for IndoFinity so it doesn't break header/localStorage
  lastUsername = backend === 'indofinity' ? 'IndoFinity_Host' : username;
  lastLang = lang;
  lastSessionId = sessionId;
  updateLangBadgeUI(lang);

  // Read IndoFinity IP
  const ipInput = document.getElementById('indofinityIpInput');
  const indofinityIp = ipInput ? ipInput.value.trim() || 'localhost' : 'localhost';

  // Persist to localStorage for auto-reconnect on refresh
  try {
    localStorage.setItem('wordle_username', username);
    localStorage.setItem('wordle_lang', lang);
    localStorage.setItem('wordle_sessionid', sessionId);
    localStorage.setItem('wordle_backend', backend);
    localStorage.setItem('wordle_indofinity_ip', indofinityIp);
  } catch (e) {}
  connectBtn.disabled = true;
  connectBtn.textContent = "Connecting...";
  loginStatus.textContent = "Loading dictionary...";

  loadWordLists(lang).then(() => {
    loginStatus.textContent = "Connecting to server...";

    if (!socket) {
      if (backend === 'indofinity') {
        socket = new IndoFinitySocket(`ws://${indofinityIp}:62024`);
      } else {
        socket = io(SOCKET_URL);
        loginStatus.textContent = "Connecting to TikTok Live...";
      }
      setupSocketListeners();
    } else if (socket.connected) {
      if (backend === 'indofinity') {
        if (socket.listeners['statusUpdate']) {
          socket.listeners['statusUpdate'].forEach(cb => cb({ status: 'connected', uniqueId: 'IndoFinity' }));
        }
      } else {
        loginStatus.textContent = "Connecting to TikTok Live...";
        socket.emit('connect-tiktok', { uniqueId: username, sessionId });
      }
    } else {
      loginStatus.textContent = "Waiting for server connection...";
    }
  }).catch(err => {
    loginStatus.textContent = "Error loading words!";
    connectBtn.disabled = false;
    connectBtn.textContent = "Connect to Live";
  });
}

function startOfflineMode() {
  const lang = document.getElementById('languageSelect').value;
  lastLang = lang;
  updateLangBadgeUI(lang);
  lastUsername = ""; // Clear username to prevent TikTok auto-connect
  connectBtn.disabled = true;
  connectBtn.textContent = "Loading...";
  loginStatus.textContent = "Loading dictionary...";

  loadWordLists(lang).then(() => {
    loginOverlay.style.display = 'none';
    gameContainer.style.display = 'flex';
    document.getElementById('hostMusicControl').style.display = 'flex';
    roomHost.textContent = `@HostOffline`;
    
    isConnectedToTikTok = false;
    
    // Initialize socket to local server for music requests
    if (!socket) {
      socket = io(SOCKET_URL);
      setupSocketListeners();
    }
    
    if (!hasActiveGameRound()) {
      startNewRound();
    }
  }).catch(err => {
    loginStatus.textContent = "Error loading words!";
    connectBtn.disabled = false;
    connectBtn.textContent = "Connect to Live";
  });
}

// Auto-reconnect on page refresh using saved credentials or URL params
function autoReconnect() {
  try {
    const savedUser = localStorage.getItem('wordle_username');
    const savedLang = localStorage.getItem('wordle_lang');
    const savedSession = localStorage.getItem('wordle_sessionid');
    const savedBackend = localStorage.getItem('wordle_backend');
    const savedIp = localStorage.getItem('wordle_indofinity_ip');
    const savedMode = sessionStorage.getItem('wordle_gameMode');
    
    const activeMode = urlInitialMode || savedMode || currentGameMode;
    const activeBackend = urlBackend || savedBackend || (isObsMode ? 'indofinity' : null);
    const activeUser = urlUsername || savedUser;

    if ((activeUser || activeBackend === 'indofinity') && activeMode) {
      // Restore game mode
      currentGameMode = activeMode;

      // Hide game select, show login for auto-connect
      if (typeof gameSelectOverlay !== 'undefined' && gameSelectOverlay) gameSelectOverlay.style.display = 'none';
      if (typeof loginOverlay !== 'undefined' && loginOverlay) loginOverlay.style.display = 'flex';

      // Pre-fill login fields
      const userInput = document.getElementById('usernameInput');
      if (userInput) userInput.value = activeUser || '';
      const langSelect = document.getElementById('languageSelect');
      if (savedLang && langSelect) langSelect.value = savedLang;
      const ipInput = document.getElementById('indofinityIpInput');
      const activeIp = urlIndofinityIp || savedIp;
      if (activeIp && ipInput) ipInput.value = activeIp;
      const sessionInput = document.getElementById('sessionInput');
      if (savedSession && sessionInput) sessionInput.value = savedSession;
      const backendSelect = document.getElementById('backendSelect');
      if (activeBackend && backendSelect) {
        backendSelect.value = activeBackend;
        if (typeof handleBackendChange === 'function') handleBackendChange(activeBackend);
      }

      // Auto-connect
      connectToLive();
    }
  } catch (e) {}
}

// Run auto-reconnect when page loads
window.addEventListener('DOMContentLoaded', () => {
  // Smart IP detection: use the hostname the page was loaded from
  const ipInput = document.getElementById('indofinityIpInput');
  if (ipInput) {
    const savedIp = localStorage.getItem('wordle_indofinity_ip');
    if (savedIp) {
      ipInput.value = savedIp;
    } else {
      // Auto-detect: if page is loaded via a LAN IP, use that same IP for IndoFinity
      const host = window.location.hostname;
      ipInput.value = (host && host !== '0.0.0.0') ? host : 'localhost';
    }
  }

  autoReconnect();
  const backendSelect = document.getElementById('backendSelect');
  if (backendSelect && typeof handleBackendChange === 'function') {
    handleBackendChange(backendSelect.value);
  }

  // Always establish local socket for music features
  localSocket = io(SOCKET_URL);
  
  localSocket.on('music-request-rejected', (data) => {
    if (data && data.reason === 'follower_only') {
      showMusicFollowerWarningNotif(data.requesterName);
    } else if (data && data.reason === 'cooldown') {
      showMusicCooldownWarningNotif(data.requesterName, data.remainingSeconds || 10);
    }
  });

  localSocket.on('music-request', (data) => {
    // If music requests are disabled, only allow the Host to request music
    if (musicSettings.requestsEnabled === false && data.requesterName !== "Host") {
      console.log("[Music] Request ignored: requests are disabled for audience.");
      return;
    }
    console.log("Music Requested:", data);
    
    // Check banned keywords
    const titleLower = data.title.toLowerCase();
    const queryLower = (data.originalQuery || "").toLowerCase();
    
    if (musicSettings.bannedKeywords.length > 0) {
      if (musicSettings.bannedKeywords.some(kw => titleLower.includes(kw) || queryLower.includes(kw))) {
        console.log("Music rejected: Contains banned keyword");
        if (data.requesterName === "Host") showToast("🚫 Lagu ditolak: Mengandung kata terlarang!");
        return;
      }
    }
    
    // Check duration
    let durMins = 0;
    if (data.duration) {
      const parts = data.duration.split(':').map(Number);
      if (parts.length === 2) durMins = parts[0] + (parts[1]/60);
      else if (parts.length === 3) durMins = (parts[0]*60) + parts[1] + (parts[2]/60);
    }
    if (musicSettings.maxDuration > 0 && durMins > musicSettings.maxDuration) {
      console.log("Music rejected: Exceeds max duration");
      if (data.requesterName === "Host") showToast(`🚫 Lagu ditolak: Durasi melebihi batas (${musicSettings.maxDuration} menit)!`);
      return;
    }
    
    // Check global limit
    if (musicSettings.maxGlobal > 0 && musicQueue.length >= musicSettings.maxGlobal) {
      console.log("Music rejected: Global queue full");
      if (data.requesterName === "Host") {
        showToast("🚫 Antrian penuh!");
      } else {
        showMusicGlobalFullWarningNotif(data.requesterName, musicSettings.maxGlobal);
      }
      return;
    }
    
    // Check user limit & cooldown
    if (data.requesterName !== "Host") {
      if (musicSettings.maxUser > 0) {
        const userReqs = musicQueue.filter(m => m.requesterName === data.requesterName).length;
        if (userReqs >= musicSettings.maxUser) {
          console.log(`Music rejected: User ${data.requesterName} hit queue limit`);
          showMusicUserLimitWarningNotif(data.requesterName, musicSettings.maxUser);
          return;
        }
      }

      const userKey = (data.requesterName || '').toLowerCase().trim();
      const cdSec = typeof musicSettings.cooldownSeconds === 'number' ? musicSettings.cooldownSeconds : 60;
      if (cdSec > 0 && userKey) {
        const lastReqTime = musicUserCooldowns[userKey] || 0;
        const elapsedSec = (Date.now() - lastReqTime) / 1000;
        if (lastReqTime > 0 && elapsedSec < cdSec) {
          const remSec = Math.ceil(cdSec - elapsedSec);
          console.log(`[Music] Rejected: User ${data.requesterName} is on cooldown (${remSec}s left)`);
          showMusicCooldownWarningNotif(data.requesterName, remSec);
          return;
        }
        musicUserCooldowns[userKey] = Date.now();
      }
    }
    
    data._justAdded = Date.now();
    musicQueue.push(data);
    updateMusicQueueUI();
    showMusicNotif(data.requesterName, data.title);
    
    if (!isMusicPlaying && musicQueue.length === 1) {
      playNextMusic();
    }
  });

  localSocket.on('music-skip', () => {
    console.log("Music skip requested via command");
    if (isMusicPlaying) {
      playNextMusic();
    }
  });

  localSocket.on('trigger-random-music', (data) => {
    if (data && data.genre) {
      if (typeof changeMusicRandomGenre === 'function') changeMusicRandomGenre(data.genre);
      else musicSettings.randomGenre = data.genre;
    }
    if (typeof window.playRandomMusic === 'function') {
      window.playRandomMusic();
    }
  });

  localSocket.on('music-toggle-pause', () => {
    if (ytPlayer && typeof ytPlayer.getPlayerState === 'function') {
      try {
        const state = ytPlayer.getPlayerState();
        if (state === 1) { // 1 = playing -> pause
          ytPlayer.pauseVideo();
          broadcastMusicState(true);
        } else { // 2 = paused -> play
          ytPlayer.playVideo();
          broadcastMusicState(false);
        }
      } catch(e) {}
    }
  });

  localSocket.on('music-stop', () => {
    musicQueue = [];
    isMusicPlaying = false;
    activeMusic = null;
    currentLyricsData = [];
    currentLyricsIndex = -1;
    if (typeof resetLyricsUI === 'function') resetLyricsUI();
    const mw = document.getElementById('musicWidget');
    if (mw) mw.classList.remove('show');
    const hostSkipBtn = document.getElementById('hostSkipBtn');
    if (hostSkipBtn) hostSkipBtn.style.display = 'none';
    if (window.sounds && typeof window.sounds.stopRadioAmbiance === 'function') window.sounds.stopRadioAmbiance();
    if (ytPlayer && ytPlayer.stopVideo) {
      try { ytPlayer.stopVideo(); } catch(e) {}
    }
    updateMusicQueueUI();
    broadcastMusicState();
  });

  localSocket.on('music-volume-set', (data) => {
    if (data && typeof data.volume === 'number') {
      musicSettings.volume = Math.max(0, Math.min(100, data.volume));
      try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
      if (ytPlayer && ytPlayer.setVolume) {
        try { ytPlayer.setVolume(musicSettings.volume); } catch(e) {}
      }
      const slider = document.getElementById('musicVolumeSlider');
      const label = document.getElementById('musicVolumeLabel');
      if (slider) slider.value = musicSettings.volume;
      if (label) label.textContent = musicSettings.volume + '%';
      broadcastMusicState();
    }
  });

  localSocket.on('music-remove-queue-item', (data) => {
    let idx = parseInt(data?.index);
    if ((isNaN(idx) || idx < 0) && data?.videoId) {
      idx = musicQueue.findIndex(m => m.videoId === data.videoId);
    }
    if (!isNaN(idx) && idx >= 0 && idx < musicQueue.length) {
      musicQueue.splice(idx, 1);
      updateMusicQueueUI();
      broadcastMusicState();
      if (typeof showToast === 'function') showToast('Lagu dihapus dari antrian', 1500);
    }
  });

  localSocket.on('music-clear-queue', () => {
    musicQueue = [];
    updateMusicQueueUI();
    broadcastMusicState();
    if (typeof showToast === 'function') showToast('Antrian musik dikosongkan', 1500);
  });

  localSocket.on('get-music-state', () => {
    broadcastMusicState();
  });

  localSocket.on('host-guess-submit', (data) => {
    if (data && data.guess) {
      const guess = data.guess.trim().toUpperCase();
      console.log('[Host] Remote host guess received:', guess);
      if (typeof handleChatGuess === 'function') {
        handleChatGuess({
          comment: guess,
          uniqueId: 'host_offline',
          nickname: 'Host',
          profilePictureUrl: (typeof getHostAvatar === 'function') ? getHostAvatar() : 'assets/bg_nature.png'
        });
        if (typeof showToast === 'function') showToast(`Host Tebak: ${guess}`, 1800);
      }
    }
  });

  localSocket.on('trigger-give-hint', () => {
    console.log('[Host] Remote hint triggered');
    if (currentGameMode === 'wanderwords' && typeof window.wanderWordsGiveHint === 'function') {
      window.wanderWordsGiveHint();
      if (typeof showToast === 'function') showToast('💡 Hint Wander Words Terbuka!', 2000);
    } else if (currentGameMode === 'wordcluster' && typeof window.revealWordClusterHint === 'function') {
      window.revealWordClusterHint();
      if (typeof showToast === 'function') showToast('💡 Bantuan Kata Terkait Terbuka!', 2000);
    } else if (currentGameMode === 'wordmatch' && typeof window.revealWordMatchHint === 'function') {
      window.revealWordMatchHint();
      if (typeof showToast === 'function') showToast('Bantuan Word Match Terbuka!', 2000);
    } else if (currentGameMode === 'wordpyramid' && typeof window.revealWordPyramidHint === 'function') {
      window.revealWordPyramidHint();
    } else if (typeof revealHelpModal === 'function') {
      if (typeof showToast === 'function') showToast('💡 Petunjuk Permainan', 2000);
    }
  });

  // ─── OBS Overlay & Remote Control Handlers ───
  localSocket.on('obs-config-update', (config) => {
    updateObsShareLinkUI(config);
    if (config) {
      document.body.classList.toggle('show-host-controls', !!config.showHostControls);
      const hostMusic = document.getElementById('hostMusicControl');
      if (hostMusic && config.showHostControls) {
        hostMusic.style.display = 'flex';
      }
    }
  });

  localSocket.on('change-game-mode', (data) => {
    if (data && data.mode) {
      console.log('[OBS] Remote game mode change to:', data.mode);
      remoteChangeGameMode(data.mode);
    }
  });

  localSocket.on('trigger-new-round', () => {
    console.log('[OBS] Remote new round triggered');
    if (typeof startNewRound === 'function') {
      startNewRound();
      if (typeof showToast === 'function') showToast('🔄 Ronde Baru Dimulai!', 2000);
    }
  });

  localSocket.emit('get-obs-config');

  // Sync the overlay's real localStorage settings up to server.js so server and dashboard always match the overlay
  function syncOverlaySettingsToServer() {
    try {
      const overlayCfg = {
        allowedLengths: JSON.parse(localStorage.getItem('allowed_lengths') || '[5,6,7,8]'),
        language: localStorage.getItem('wordle_lang') || 'id',
        hardMode: localStorage.getItem('wordle_hardModeState') || 'off',
        noRepeat: localStorage.getItem('wordle_noRepeat') === 'true',
        noYellow: localStorage.getItem('wordle_noYellow') === 'true',
        showHints: localStorage.getItem('wordle_showHintsDiscovered') !== 'false',
        displayRows: parseInt(localStorage.getItem('displayRows_wordle')) || 6,
        boardScale: parseInt(localStorage.getItem('board_scale')) || 100,
        theme: localStorage.getItem('wordle_theme') || 'dark',
        autoStarterWinner: localStorage.getItem('wordle_autoStarterWinner') !== 'false',
        autoStarterPreviousTarget: localStorage.getItem('wordle_autoStarter') === 'true',
        followerOnlyGuess: localStorage.getItem('wordle_followerOnlyGuess') === 'true',
        followerOnlyMusic: (typeof musicSettings !== 'undefined' && musicSettings.followerOnly === true),
        musicCooldown: (typeof musicSettings !== 'undefined' && typeof musicSettings.cooldownSeconds === 'number' ? musicSettings.cooldownSeconds : 60),
        musicPlayerStyle: (typeof musicSettings !== 'undefined' ? (musicSettings.playerStyle || 'vinyl') : 'vinyl')
      };
      localSocket.emit('sync-game-settings-from-overlay', overlayCfg);
    } catch(e) {}
  }
  syncOverlaySettingsToServer();

  // Game Settings Remote Listener
  localSocket.on('game-settings-update', (settings) => {
    applyRemoteGameSettings(settings);
  });

  // Spotify Top Charts Listener & Fetch
  localSocket.on('spotify-charts-update', (charts) => {
    if (typeof window.updateClientSpotifyCharts === 'function') {
      window.updateClientSpotifyCharts(charts);
    }
  });
  localSocket.emit('get-spotify-charts');

  // If in OBS Browser mode, prepare clean overlay layout
  if (isObsMode) {
    initObsMode();
  }
});

function applyRemoteGameSettings(settings) {
  if (!settings) return;
  console.log('[Settings] Applying remote game settings:', settings);

  let needReloadWords = false;
  let needNewRound = false;

  // 1. Allowed Word Lengths
  if (Array.isArray(settings.allowedLengths) && settings.allowedLengths.length > 0) {
    try {
      localStorage.setItem('allowed_lengths', JSON.stringify(settings.allowedLengths));
      [3, 4, 5, 6, 7, 8].forEach(n => {
        const cb = document.getElementById(`len${n}Toggle`);
        if (cb) cb.checked = settings.allowedLengths.includes(n);
      });
      if (settings.restartRound) needNewRound = true;
    } catch(e) {}
  }

  // 2. Language
  if (settings.language && settings.language !== lastLang) {
    lastLang = settings.language;
    try { localStorage.setItem('wordle_lang', settings.language); } catch(e) {}
    if (typeof updateLangBadgeUI === 'function') updateLangBadgeUI(settings.language);
    needReloadWords = true;
  }

  // 3. Hard Mode
  if (settings.hardMode !== undefined && settings.hardMode !== hardModeState) {
    hardModeState = settings.hardMode;
    try { localStorage.setItem('wordle_hardModeState', hardModeState); } catch(e) {}
    if (typeof updateHardModeUI === 'function') updateHardModeUI();
    if (settings.restartRound) needNewRound = true;
  }

  // 4. No Repeat (Isogram)
  if (settings.noRepeat !== undefined && settings.noRepeat !== isNoRepeatMode) {
    isNoRepeatMode = settings.noRepeat;
    try { localStorage.setItem('wordle_noRepeat', settings.noRepeat); } catch(e) {}
    if (typeof updateNoRepeatBadgeUI === 'function') updateNoRepeatBadgeUI();
    const nrToggle = document.getElementById('noRepeatToggle');
    if (nrToggle) nrToggle.checked = isNoRepeatMode;
    if (settings.restartRound) needNewRound = true;
  }

  // 5. No Yellow
  if (settings.noYellow !== undefined && settings.noYellow !== isNoYellowMode) {
    isNoYellowMode = settings.noYellow;
    try { localStorage.setItem('wordle_noYellow', settings.noYellow); } catch(e) {}
    const nyToggle = document.getElementById('noYellowToggle');
    if (nyToggle) nyToggle.checked = isNoYellowMode;
    if (currentGameMode === 'wordfit' && typeof renderWordFitBoard === 'function') renderWordFitBoard();
    else if ((currentGameMode === 'word500') && typeof renderWord500Board === 'function') renderWord500Board();
  }

  // 6. Show Hints Discovered
  if (settings.showHints !== undefined && settings.showHints !== isShowHintsDiscovered) {
    isShowHintsDiscovered = settings.showHints;
    try { localStorage.setItem('wordle_showHintsDiscovered', settings.showHints); } catch(e) {}
    const shToggle = document.getElementById('showHintsDiscoveredToggle');
    if (shToggle) shToggle.checked = isShowHintsDiscovered;
    if (typeof applyGameModeUI === 'function') applyGameModeUI();
  }

  // 6.5. Auto Starter Winner Nickname
  if (settings.autoStarterWinner !== undefined && settings.autoStarterWinner !== isAutoStarterWinnerNickname) {
    isAutoStarterWinnerNickname = !!settings.autoStarterWinner;
    try { localStorage.setItem('wordle_autoStarterWinner', isAutoStarterWinnerNickname); } catch(e) {}
    const aswToggle = document.getElementById('autoStarterWinnerToggle');
    if (aswToggle) aswToggle.checked = isAutoStarterWinnerNickname;
  }

  // 6.6. Auto Starter Previous Target
  if (settings.autoStarterPreviousTarget !== undefined && settings.autoStarterPreviousTarget !== isAutoStarterPreviousTarget) {
    isAutoStarterPreviousTarget = !!settings.autoStarterPreviousTarget;
    try { localStorage.setItem('wordle_autoStarter', isAutoStarterPreviousTarget); } catch(e) {}
    const astToggle = document.getElementById('autoStarterToggle');
    if (astToggle) astToggle.checked = isAutoStarterPreviousTarget;
  }

  // 7. Display Rows
  const currentModeRows = getDisplayRows();
  if (typeof settings.displayRows === 'number' && settings.displayRows >= 3 && settings.displayRows <= 12 && settings.displayRows !== currentModeRows) {
    displayRowsWordle = settings.displayRows;
    displayRowsWord500 = settings.displayRows;
    displayRowsWordfit = settings.displayRows;
    try {
      localStorage.setItem('displayRows_wordle', settings.displayRows);
      localStorage.setItem('displayRows_word500', settings.displayRows);
      localStorage.setItem('displayRows_wordfit', settings.displayRows);
    } catch(e) {}
    if (typeof updateDisplayRowsUI === 'function') updateDisplayRowsUI();
    if (currentGameMode === 'word500') {
      if (typeof renderWord500Board === 'function') renderWord500Board();
    } else if (currentGameMode === 'wordfit') {
      if (typeof renderWordFitBoard === 'function') renderWordFitBoard();
    } else {
      if (typeof adjustWordleBoardRows === 'function') {
        adjustWordleBoardRows(settings.displayRows);
      } else if (!guesses || guesses.length === 0) {
        if (typeof initBoard === 'function') initBoard();
      }
    }
  }

  // 8. Board Scale
  if (typeof settings.boardScale === 'number' && settings.boardScale >= 50 && settings.boardScale <= 150) {
    boardScale = settings.boardScale;
    try { localStorage.setItem('board_scale', boardScale); } catch(e) {}
    if (typeof updateBoardScaleUI === 'function') updateBoardScaleUI();
  }

  // 9. Visual Theme
  if (settings.theme && typeof window.setVisualTheme === 'function') {
    window.setVisualTheme(settings.theme);
  }

  // 10. Follower Only Guess
  if (settings.followerOnlyGuess !== undefined && settings.followerOnlyGuess !== isFollowerOnlyGuess) {
    isFollowerOnlyGuess = !!settings.followerOnlyGuess;
    try { localStorage.setItem('wordle_followerOnlyGuess', isFollowerOnlyGuess); } catch(e) {}
    const fogToggle = document.getElementById('followerOnlyGuessToggle');
    if (fogToggle) fogToggle.checked = isFollowerOnlyGuess;
    if (typeof updateFollowerOnlyGuessBadgeUI === 'function') updateFollowerOnlyGuessBadgeUI();
  }

  // 11. Follower Only Music
  if (settings.followerOnlyMusic !== undefined && settings.followerOnlyMusic !== musicSettings.followerOnly) {
    musicSettings.followerOnly = !!settings.followerOnlyMusic;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const fomToggle = document.getElementById('musicFollowerOnlyToggle');
    if (fomToggle) fomToggle.checked = musicSettings.followerOnly;
    const fomGroupToggle = document.getElementById('musicFollowerOnlyGroupToggle');
    if (fomGroupToggle) fomGroupToggle.checked = musicSettings.followerOnly;
  }

  // 11.5 Music Cooldown
  if (settings.musicCooldown !== undefined && settings.musicCooldown !== musicSettings.cooldownSeconds) {
    musicSettings.cooldownSeconds = parseInt(settings.musicCooldown) || 0;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const cdInput = document.getElementById('musicCooldownSeconds');
    if (cdInput) cdInput.value = musicSettings.cooldownSeconds;
  }

  // 11.6 Music Player Style
  if (settings.musicPlayerStyle && settings.musicPlayerStyle !== musicSettings.playerStyle) {
    if (typeof window.changeMusicPlayerStyle === 'function') {
      window.changeMusicPlayerStyle(settings.musicPlayerStyle);
    }
  }

  // 11.7 Playlist Sub-Settings (Rows, Scale, Auto-Scroll)
  if (settings.musicPlaylistVisibleRows !== undefined && settings.musicPlaylistVisibleRows !== musicSettings.playlistVisibleRows) {
    if (typeof window.changeMusicPlaylistVisibleRows === 'function') {
      window.changeMusicPlaylistVisibleRows(settings.musicPlaylistVisibleRows);
    }
  }
  if (settings.musicPlaylistScale !== undefined && settings.musicPlaylistScale !== musicSettings.playlistScale) {
    if (typeof window.changeMusicPlaylistScale === 'function') {
      window.changeMusicPlaylistScale(settings.musicPlaylistScale);
    }
  }
  if (settings.musicPlaylistAutoScroll !== undefined && settings.musicPlaylistAutoScroll !== musicSettings.playlistAutoScroll) {
    if (typeof window.toggleMusicPlaylistAutoScroll === 'function') {
      window.toggleMusicPlaylistAutoScroll(settings.musicPlaylistAutoScroll);
    }
  }
  if (settings.musicPlaylistAccent && settings.musicPlaylistAccent !== musicSettings.playlistAccent) {
    if (typeof window.changeMusicPlaylistAccent === 'function') {
      window.changeMusicPlaylistAccent(settings.musicPlaylistAccent);
    }
  }

  // 11.8 Music Requests Enabled (Chat !play)
  if (settings.musicRequestsEnabled !== undefined && settings.musicRequestsEnabled !== musicSettings.requestsEnabled) {
    musicSettings.requestsEnabled = !!settings.musicRequestsEnabled;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const mre = document.getElementById('musicRequestsEnabled');
    if (mre) mre.checked = musicSettings.requestsEnabled;
  }

  // 11.9 Music Remote Volume
  if (typeof settings.musicVolume === 'number' && settings.musicVolume !== musicSettings.volume) {
    musicSettings.volume = Math.max(0, Math.min(100, settings.musicVolume));
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    if (ytPlayer && ytPlayer.setVolume) {
      try { ytPlayer.setVolume(musicSettings.volume); } catch(e) {}
    }
    const mvol = document.getElementById('musicVolumeSlider');
    const mlabel = document.getElementById('musicVolumeLabel');
    if (mvol) mvol.value = musicSettings.volume;
    if (mlabel) mlabel.textContent = musicSettings.volume + '%';
    broadcastMusicState();
  }

  // 11.10 Music Chat Request Limits & Filter
  if (typeof settings.musicMaxDuration === 'number') {
    musicSettings.maxDuration = settings.musicMaxDuration;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const md = document.getElementById('musicMaxDuration');
    if (md) md.value = musicSettings.maxDuration;
  }
  if (typeof settings.musicMaxGlobal === 'number') {
    musicSettings.maxGlobal = settings.musicMaxGlobal;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const mg = document.getElementById('musicMaxGlobal');
    if (mg) mg.value = musicSettings.maxGlobal;
  }
  if (typeof settings.musicMaxUser === 'number') {
    musicSettings.maxUser = settings.musicMaxUser;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const mu = document.getElementById('musicMaxUser');
    if (mu) mu.value = musicSettings.maxUser;
  }
  if (Array.isArray(settings.musicBannedKeywords)) {
    musicSettings.bannedKeywords = settings.musicBannedKeywords;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const mbk = document.getElementById('musicBannedKeywords');
    if (mbk) mbk.value = musicSettings.bannedKeywords.join(', ');
  }
  if (settings.musicRadioSFX !== undefined) {
    musicSettings.radioSFX = !!settings.musicRadioSFX;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
  }
  if (settings.musicRadioAmbiance !== undefined) {
    musicSettings.radioAmbiance = !!settings.musicRadioAmbiance;
    try { localStorage.setItem('music_settings', JSON.stringify(musicSettings)); } catch(e) {}
    const mra = document.getElementById('musicRadioAmbianceToggle');
    if (mra) mra.checked = musicSettings.radioAmbiance;
  }

  // 11.11 OBS Show Host Controls Toggle
  if (settings.showHostControlsOnObs !== undefined) {
    document.body.classList.toggle('show-host-controls', !!settings.showHostControlsOnObs);
    const hostMusic = document.getElementById('hostMusicControl');
    if (hostMusic && settings.showHostControlsOnObs) hostMusic.style.display = 'flex';
  }

  // 12. Wander Words Custom Words List
  if (Array.isArray(settings.wanderWordsCustomList)) {
    window.wanderWordsCustomWords = settings.wanderWordsCustomList;
    try { localStorage.setItem('wanderwords_custom_words', JSON.stringify(settings.wanderWordsCustomList)); } catch(e) {}
    wanderWordsShuffledPool = [];
    wanderWordsPuzzleIndex = 0;
    console.log('[WanderWords] Adopted custom words from remote settings:', settings.wanderWordsCustomList.length);
    if (currentGameMode === 'wanderwords' && settings.restartRound) {
      needNewRound = true;
    }
  }

  // 13. Word Cluster Custom Words List
  if (Array.isArray(settings.wordClusterCustomList)) {
    window.wordClusterCustomWords = settings.wordClusterCustomList;
    try { localStorage.setItem('wordcluster_custom_words', JSON.stringify(settings.wordClusterCustomList)); } catch(e) {}
    wordClusterShuffledPool = [];
    wordClusterPuzzleIndex = 0;
    try { sessionStorage.removeItem('wordcluster_shuffled_pool'); sessionStorage.removeItem('wordcluster_pool_idx'); } catch(e) {}
    console.log('[WordCluster] Adopted custom words from remote settings:', settings.wordClusterCustomList.length);
    if (currentGameMode === 'wordcluster' && settings.restartRound) {
      needNewRound = true;
    }
  }

  // Apply reloads if requested
  if (settings.restartRound || needReloadWords || needNewRound) {
    if (needReloadWords && typeof loadWordLists === 'function') {
      loadWordLists(lastLang).then(() => {
        if (typeof startNewRound === 'function') startNewRound();
        if (typeof showToast === 'function') showToast('⚙️ Pengaturan & Bahasa diperbarui!', 2500);
      }).catch(e => console.error(e));
    } else if (typeof startNewRound === 'function') {
      startNewRound();
      if (typeof showToast === 'function') showToast('⚙️ Aturan baru diterapkan & Ronde di-reset!', 2500);
    }
  } else {
    if (typeof showToast === 'function') showToast('⚙️ Pengaturan game diperbarui!', 1800);
  }
}

function updateObsShareLinkUI(config) {
  if (!config) return;

  // Real-time OBS Compact Mode toggle (Hanya Bagian Tengah) - Hanya aktif jika di OBS overlay
  if (typeof config.compactMode === 'boolean') {
    if (isObsMode && config.compactMode) {
      document.documentElement.classList.add('obs-compact');
      if (document.body) document.body.classList.add('obs-compact');
    } else if (!isObsCompact) {
      document.documentElement.classList.remove('obs-compact');
      if (document.body) document.body.classList.remove('obs-compact');
    }
  }

  // Real-time OBS Transparent Background toggle - Hanya aktif jika di OBS overlay
  if (typeof config.transparentBg === 'boolean') {
    if (isObsMode && config.transparentBg) {
      document.documentElement.classList.add('obs-transparent');
      if (document.body) document.body.classList.add('obs-transparent');
    } else if (!isObsTransparent) {
      document.documentElement.classList.remove('obs-transparent');
      if (document.body) document.body.classList.remove('obs-transparent');
    }
  }

  const banner = document.getElementById('obsShareLinkBanner');
  const textEl = document.getElementById('obsShareLinkText');
  if (!banner || !textEl) return;

  if (config.shareLinkVisible && config.shareLinkText && config.shareLinkText.trim()) {
    textEl.textContent = config.shareLinkText.trim();
    banner.style.display = 'flex';
    banner.classList.remove('position-top', 'position-bottom');
    banner.classList.add(config.shareLinkPosition === 'bottom' ? 'position-bottom' : 'position-top');
  } else {
    banner.style.display = 'none';
  }
}

function remoteChangeGameMode(mode) {
  if (!mode) return;
  currentGameMode = mode;
  try { sessionStorage.setItem('wordle_gameMode', mode); } catch(e) {}
  
  if (typeof wgHintInterval !== 'undefined' && wgHintInterval) {
    clearInterval(wgHintInterval);
    wgHintInterval = null;
  }
  
  if (typeof initWeeklyLeaderboard === 'function') initWeeklyLeaderboard();
  
  const gSelect = document.getElementById('gameSelectOverlay');
  const lOverlay = document.getElementById('loginOverlay');
  const gContainer = document.getElementById('gameContainer');
  
  if (gSelect) gSelect.style.display = 'none';
  if (lOverlay) lOverlay.style.display = 'none';
  if (gContainer) gContainer.style.display = 'flex';
  
  const hostMusic = document.getElementById('hostMusicControl');
  if (hostMusic) hostMusic.style.display = 'flex';

  const selectElement = document.getElementById('switchGameSelect');
  if (selectElement) selectElement.value = "";

  if (typeof applyGameModeUI === 'function') applyGameModeUI();
  if (typeof startNewRound === 'function') startNewRound();
  if (typeof showToast === 'function') showToast(`🎮 Mode: ${mode.toUpperCase()}`, 2500);
}

function initObsMode() {
  console.log('[OBS] Initializing OBS Clean Overlay Mode...');
  if (!currentGameMode) currentGameMode = urlInitialMode || 'wordle';
  
  const gSelect = document.getElementById('gameSelectOverlay');
  const lOverlay = document.getElementById('loginOverlay');
  const gContainer = document.getElementById('gameContainer');
  
  if (gSelect) gSelect.style.display = 'none';
  if (lOverlay) lOverlay.style.display = 'none';
  if (gContainer) gContainer.style.display = 'flex';
  
  if (typeof applyGameModeUI === 'function') applyGameModeUI();
  if (typeof initBoard === 'function') initBoard();

  // Determine target backend, IP, and credentials for OBS auto-connect
  const targetBackend = urlBackend || localStorage.getItem('wordle_backend') || 'indofinity';
  const targetIp = urlIndofinityIp || localStorage.getItem('wordle_indofinity_ip') || (window.location.hostname && window.location.hostname !== '0.0.0.0' ? window.location.hostname : 'localhost');
  const targetUser = urlUsername || localStorage.getItem('wordle_username') || '';
  const targetLang = urlLang || localStorage.getItem('wordle_lang') || 'id';
  lastLang = targetLang;
  if (typeof updateLangBadgeUI === 'function') updateLangBadgeUI(targetLang);

  const backendSelect = document.getElementById('backendSelect');
  if (backendSelect && targetBackend) {
    backendSelect.value = targetBackend;
    if (typeof handleBackendChange === 'function') handleBackendChange(targetBackend);
  }
  const ipInput = document.getElementById('indofinityIpInput');
  if (ipInput && targetIp) ipInput.value = targetIp;
  const userInput = document.getElementById('usernameInput');
  if (userInput && targetUser) userInput.value = targetUser;
  const langSelect = document.getElementById('languageSelect');
  if (langSelect && targetLang) langSelect.value = targetLang;

  // Always load dictionary & start active round immediately so the board rows are always rendered
  if (!hasActiveGameRound()) {
    if (typeof loadWordLists === 'function') {
      loadWordLists(targetLang).then(() => {
        if (typeof startNewRound === 'function') startNewRound();
      }).catch(e => {
        console.error('[OBS] Word load error:', e);
        if (typeof startNewRound === 'function') startNewRound();
      });
    } else if (typeof startNewRound === 'function') {
      startNewRound();
    }
  }

  // Auto connect if not yet connected
  if (!socket) {
    console.log(`[OBS] Auto-connecting overlay to backend: ${targetBackend} (IP: ${targetIp})...`);
    connectToLive();
  }
}

// Cache of known followers in current session
const knownFollowers = new Set();

function setupSocketListeners() {
  // --- Socket.IO connection lifecycle (Bug 3 fix) ---
  socket.on('connect', () => {
    console.log('[Socket.IO] Connected to local server');
    hideDisconnectBanner();
    // Only send connect-tiktok if we're NOT already connected (prevent duplicates)
    if (lastUsername && !isConnectedToTikTok) {
      if (loginStatus) loginStatus.textContent = "Connecting to TikTok Live...";
      socket.emit('connect-tiktok', { uniqueId: lastUsername, sessionId: lastSessionId });
    }
  });

  socket.on('envSessionId', (sessionId) => {
    const sessionInputElem = document.getElementById('sessionInput');
    if (sessionInputElem && !sessionInputElem.value.trim()) {
      sessionInputElem.value = sessionId;
    }
  });

  socket.on('disconnect', () => {
    console.log('[Socket.IO] Disconnected from server');
    isConnectedToTikTok = false;
    if (gameContainer.style.display !== 'none') {
      showDisconnectBanner('Server connection lost. Reconnecting...');
    }
  });

  socket.on('reconnect', () => {
    console.log('[Socket.IO] Reconnected to server');
    showToast('✅ Server reconnected!', 2000);
    if (lastUsername) {
      socket.emit('connect-tiktok', { uniqueId: lastUsername, sessionId: lastSessionId });
    }
  });

  // --- TikTok status updates (Bug 1, 6, 7 fix) ---
  socket.on('statusUpdate', (data) => {
    if (data.status === 'connected') {
      isConnectedToTikTok = true;
      hideDisconnectBanner();
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }

      const badge = document.querySelector('.live-badge');
      if (badge) {
        badge.textContent = 'LIVE';
        badge.classList.remove('is-warning', 'is-stalled', 'is-reconnecting');
      }

      // Persist gameMode to sessionStorage NOW (after successful connection),
      // so autoReconnect works correctly on page refresh while in-game.
      try { if (currentGameMode) sessionStorage.setItem('wordle_gameMode', currentGameMode); } catch(e) {}

      loginOverlay.style.display = 'none';
      gameContainer.style.display = 'flex';
      document.getElementById('hostMusicControl').style.display = 'flex';
      roomHost.textContent = `@${data.uniqueId}`;

      // Cek apakah sudah ada ronde aktif agar puzzle tidak ter-reset/berganti sendiri saat status update
      if (!hasActiveGameRound()) {
        startNewRound();
      }
    } else if (data.status === 'connecting') {
      loginStatus.textContent = "Connecting to TikTok Live...";
      if (gameContainer.style.display !== 'none') {
        showDisconnectBanner('Menyambungkan ke TikTok Live...', 'reconnecting');
      }
      const badge = document.querySelector('.live-badge');
      if (badge) {
        badge.textContent = 'CONNECT';
        badge.classList.add('is-reconnecting');
      }
    } else if (data.status === 'disconnected') {
      isConnectedToTikTok = false;
      const errorMsg = data.error || 'Koneksi terputus';

      if (gameContainer.style.display === 'none') {
        loginStatus.textContent = "Error: " + errorMsg;
        connectBtn.disabled = false;
        connectBtn.textContent = "Coba Lagi";
      } else {
        showDisconnectBanner(errorMsg);
        if (socket instanceof IndoFinitySocket) {
          attemptReconnect();
        }
      }
      const badge = document.querySelector('.live-badge');
      if (badge) {
        badge.textContent = 'OFFLINE';
        badge.classList.remove('is-warning', 'is-stalled', 'is-reconnecting');
      }
    }
  });

  // --- Watchdog & Auto-Reconnect listeners ---
  socket.on('tiktokReconnecting', (data) => {
    console.log('[TikTok] Auto-reconnecting...', data);
    isConnectedToTikTok = false;
    const msg = `🔄 Menyambung ulang TikTok (ke-${data.attempt}/${data.maxAttempts})...`;
    if (gameContainer.style.display !== 'none') {
      showDisconnectBanner(msg, 'reconnecting');
    }
    const badge = document.querySelector('.live-badge');
    if (badge) {
      badge.textContent = 'RETRY';
      badge.classList.remove('is-stalled');
      badge.classList.add('is-reconnecting');
    }
  });

  socket.on('tiktokStalled', (data) => {
    console.warn('[TikTok] Aliran data freeze:', data);
    const msg = `⚠️ Aliran chat hening (${data.seconds}d). Memeriksa koneksi...`;
    if (gameContainer.style.display !== 'none') {
      showDisconnectBanner(msg, 'warning');
    }
    const badge = document.querySelector('.live-badge');
    if (badge) {
      badge.textContent = 'STALLED';
      badge.classList.remove('is-reconnecting');
      badge.classList.add('is-stalled');
    }
  });

  socket.on('tiktokPulse', (data) => {
    const badge = document.querySelector('.live-badge');
    if (!badge) return;
    if (data.status === 'connected') {
      if (data.secondsSinceLastEvent > 25) {
        badge.classList.add('is-warning');
        badge.title = `Data TikTok terakhir: ${data.secondsSinceLastEvent}d lalu`;
      } else {
        badge.classList.remove('is-warning', 'is-stalled', 'is-reconnecting');
        badge.textContent = 'LIVE';
        badge.title = 'Koneksi TikTok aktif';
      }
    }
  });

  // --- Bug 5 fix: handle tiktokConnected for late-joining clients ---
  socket.on('tiktokConnected', (data) => {
    console.log('[TikTok] Connected event received', data);
    isConnectedToTikTok = true;
    hideDisconnectBanner();
    showToast('✅ Terhubung ke TikTok Live!', 2500);

    const badge = document.querySelector('.live-badge');
    if (badge) {
      badge.textContent = 'LIVE';
      badge.classList.remove('is-warning', 'is-stalled', 'is-reconnecting');
      badge.title = 'Koneksi TikTok aktif';
    }

    // Persist gameMode to sessionStorage after successful connection
    try { if (currentGameMode) sessionStorage.setItem('wordle_gameMode', currentGameMode); } catch(e) {}

    if (gameContainer.style.display === 'none') {
      loginOverlay.style.display = 'none';
      gameContainer.style.display = 'flex';
      document.getElementById('hostMusicControl').style.display = 'flex';
    }

    // Cek apakah sudah ada ronde aktif agar puzzle tidak ter-reset saat event tiktokConnected masuk
    if (!hasActiveGameRound()) {
      startNewRound();
    }
  });

  // --- Bug 4 fix: handle tiktokDisconnected ---
  socket.on('tiktokDisconnected', (reason) => {
    console.log('[TikTok] Disconnected:', reason);
    isConnectedToTikTok = false;

    let message = 'TikTok connection lost';
    if (reason === 'tiktok.live_ended') message = 'Live stream ended';
    else if (reason === 'tiktok.disconnected') message = 'Koneksi TikTok terputus';
    else if (reason === 'manual_disconnect') message = 'Disconnected manually';

    const badge = document.querySelector('.live-badge');
    if (badge) {
      badge.textContent = (reason === 'tiktok.live_ended') ? 'ENDED' : 'OFFLINE';
      badge.classList.remove('is-warning', 'is-stalled', 'is-reconnecting');
    }

    if (gameContainer.style.display !== 'none') {
      showDisconnectBanner(message);
      // Auto-reconnect unless manually disconnected
      if (reason !== 'manual_disconnect' && socket instanceof IndoFinitySocket) {
        attemptReconnect();
      }
    }
  });

  // --- Game events ---
  socket.on('chat', (data) => {
    const username = data.nickname || data.uniqueId;
    if (username) recordActivity(username);

    // Cache follower if detected
    if (data.isFollower || data.isFollowerOfAnchor || data.followRole === 1 || data.followRole === 2) {
      if (data.uniqueId) knownFollowers.add(data.uniqueId.toLowerCase());
      if (data.nickname) knownFollowers.add(data.nickname.toLowerCase());
      if (data.userId) knownFollowers.add(data.userId.toString());
    }

    // Check for music request when using IndoFinity (local server handles it otherwise)
    if (socket instanceof IndoFinitySocket && data.comment && data.comment.toLowerCase().startsWith('!play ')) {
      if (musicSettings.requestsEnabled !== false) {
        const isHost = (data.uniqueId === 'host' || data.uniqueId === 'host_offline' || (typeof data.uniqueId === 'string' && data.uniqueId.toLowerCase().includes('host')));
        const isFollower = Boolean(
          data.isFollower || 
          data.isFollowerOfAnchor ||
          data.userIdentity?.isFollowerOfAnchor ||
          data.followRole === 1 || 
          data.followRole === 2 || 
          data.isModerator || 
          data.isSubscriber ||
          isHost ||
          knownFollowers.has((data.uniqueId || '').toLowerCase()) ||
          knownFollowers.has((data.nickname || '').toLowerCase())
        );
        if (musicSettings.followerOnly && !isFollower) {
          console.log('[Music] Blocked !play request from non-follower (IndoFinity):', data.uniqueId);
          showMusicFollowerWarningNotif(data.nickname || data.uniqueId);
          return;
        }

        // Check Cooldown
        const userKey = (data.uniqueId || data.nickname || '').toLowerCase().trim();
        const cdSec = typeof musicSettings.cooldownSeconds === 'number' ? musicSettings.cooldownSeconds : 60;
        if (!isHost && cdSec > 0 && userKey) {
          const lastTime = musicUserCooldowns[userKey] || 0;
          const elapsedSec = (Date.now() - lastTime) / 1000;
          if (lastTime > 0 && elapsedSec < cdSec) {
            const remSec = Math.ceil(cdSec - elapsedSec);
            console.log(`[Music] Blocked !play from ${data.uniqueId}: on cooldown (${remSec}s left)`);
            showMusicCooldownWarningNotif(data.nickname || data.uniqueId, remSec);
            return;
          }
        }

        // Check User Limit
        if (!isHost && musicSettings.maxUser > 0) {
          const reqName = data.nickname || data.uniqueId;
          const userReqs = musicQueue.filter(m => m.requesterName === reqName).length;
          if (userReqs >= musicSettings.maxUser) {
            console.log(`[Music] Blocked !play from ${reqName}: queue limit reached`);
            showMusicUserLimitWarningNotif(reqName, musicSettings.maxUser);
            return;
          }
        }

        // Check Global Limit
        if (!isHost && musicSettings.maxGlobal > 0 && musicQueue.length >= musicSettings.maxGlobal) {
          console.log(`[Music] Blocked !play: Global queue full`);
          showMusicGlobalFullWarningNotif(data.nickname || data.uniqueId, musicSettings.maxGlobal);
          return;
        }

        const query = data.comment.substring(6).trim();
        if (query && localSocket) {
          localSocket.emit('chat-music-request', {
            query: query,
            requesterName: data.nickname || data.uniqueId,
            requesterImg: data.profilePictureUrl,
            isFollower: isFollower
          });
        }
      }
      return;
    }

    readTTS(data.nickname, data.comment, data.followRole, data.isFollower);
    handleChatGuess(data);
  });

  socket.on('member', (data) => {
    const username = data.nickname || data.uniqueId;
    if (username) recordActivity(username);
    if (typeof handleAutoGuessOnJoin === 'function') handleAutoGuessOnJoin(data);
  });

  let socialAlertTimeout = null;
  function showSocialAlert(userData, actionType) {
    const container = document.getElementById('socialAlertContainer');
    const avatar = document.getElementById('socialAlertAvatar');
    const nameEl = document.getElementById('socialAlertName');
    const actionEl = document.getElementById('socialAlertAction');
    const tagEl = document.getElementById('socialAlertActionTag');
    const badgeIconEl = document.getElementById('socialAlertBadgeIcon');
    const giftWrap = document.getElementById('socialAlertGiftWrap');
    const giftImg = document.getElementById('socialAlertGiftImg');
    const giftCount = document.getElementById('socialAlertGiftCount');

    if (!container || !userData) return;

    avatar.onerror = function() { this.onerror = null; this.src = 'assets/default-avatar.png'; };
    avatar.src = userData.profilePictureUrl || 'assets/default-avatar.png';
    const rawNick = userData.nickname || userData.uniqueId || 'Seseorang';
    const cleanNick = rawNick.replace(/^@+/, '').trim() || 'Seseorang';
    if (nameEl) nameEl.textContent = actionType === 'gift' ? cleanNick : `@${cleanNick}`;

    // Reset alert type modifier classes
    container.classList.remove('alert-type-follow', 'alert-type-share', 'alert-type-gift');
    container.classList.add(`alert-type-${actionType}`);

    if (giftWrap) giftWrap.style.display = 'none';
    if (giftImg) giftImg.style.display = 'none';
    if (giftCount) giftCount.style.display = 'none';

    if (actionType === 'share') {
      if (tagEl) {
        tagEl.className = 'social-alert-tag tag-share';
        tagEl.innerHTML = '<i class="fa-solid fa-share-nodes"></i> SHARE';
      }
      if (badgeIconEl) {
        badgeIconEl.className = 'social-alert-badge-icon badge-share';
        badgeIconEl.innerHTML = '<i class="fa-solid fa-share-nodes"></i>';
      }
      if (actionEl) actionEl.textContent = 'Membagikan siaran live!';
    } else if (actionType === 'follow') {
      if (tagEl) {
        tagEl.className = 'social-alert-tag tag-follow';
        tagEl.innerHTML = '<i class="fa-solid fa-heart"></i> FOLLOW';
      }
      if (badgeIconEl) {
        badgeIconEl.className = 'social-alert-badge-icon badge-follow';
        badgeIconEl.innerHTML = '<i class="fa-solid fa-heart"></i>';
      }
      if (actionEl) actionEl.textContent = 'Mulai mengikuti live!';
      playSocialAlertAudio(socialAudioSettings.followSound);
    } else if (actionType === 'gift') {
      const giftName = userData.giftName ? userData.giftName.toUpperCase() : 'GIFT';
      if (tagEl) {
        tagEl.className = 'social-alert-tag tag-gift';
        tagEl.innerHTML = '<i class="fa-solid fa-gift"></i> GIFT';
      }
      if (badgeIconEl) {
        badgeIconEl.className = 'social-alert-badge-icon badge-gift';
        badgeIconEl.innerHTML = '<i class="fa-solid fa-gift"></i>';
      }
      if (actionEl) actionEl.textContent = `Mengirim ${giftName}!`;

      let hasGiftMedia = false;
      if (giftImg && userData.giftPictureUrl) {
        giftImg.src = userData.giftPictureUrl;
        giftImg.style.display = 'block';
        hasGiftMedia = true;
      }
      if (giftCount && userData.repeatCount) {
        giftCount.textContent = `x${userData.repeatCount}`;
        giftCount.style.display = 'block';
        hasGiftMedia = true;
      }
      if (giftWrap && hasGiftMedia) {
        giftWrap.style.display = 'flex';
      }

      const rawGiftName = userData.giftName ? userData.giftName.trim().toLowerCase() : '';
      const customMatch = (socialAudioSettings.customGifts || []).find(item => item.giftName === rawGiftName);
      const giftSoundUrl = customMatch ? customMatch.soundUrl : socialAudioSettings.defaultGiftSound;
      playSocialAlertAudio(giftSoundUrl);
    }

    container.classList.add('show');

    if (socialAlertTimeout) clearTimeout(socialAlertTimeout);
    socialAlertTimeout = setTimeout(() => {
      container.classList.remove('show');
    }, 3800);
  }

  // Animasi Floating Gift & Sparkle Particles di Layar
  // Gerak dipisah 3 lapis agar natural: item = naik (1 kurva kontinu),
  // sway = ayunan sinus kiri-kanan, content = pop-in. Tidak ada keyframe
  // berlapis yang membuat gerak "berhenti-jalan" di tiap titik.
  const FLOATING_GIFT_MAX = 8;
  const _decodedGiftImgs = new Set();
  function preloadGiftImage(url) {
    if (!url || _decodedGiftImgs.has(url)) return Promise.resolve();
    return new Promise((resolve) => {
      const img = new Image();
      let done = false;
      const finish = () => { if (!done) { done = true; _decodedGiftImgs.add(url); resolve(); } };
      img.onload = finish;
      img.onerror = finish;
      img.src = url;
      if (img.decode) img.decode().then(finish, finish);
      setTimeout(finish, 300); // jangan tahan animasi terlalu lama
    });
  }

  function spawnFloatingGift(userData) {
    const container = document.getElementById('floatingGiftContainer');
    if (!container || !userData) return;

    const repeatCount = userData.repeatCount || 1;
    let spawnCount = repeatCount >= 10 ? 3 : (repeatCount >= 3 ? 2 : 1);
    if (isLowPowerMode) spawnCount = 1;
    const avatarSrc = userData.profilePictureUrl || 'assets/default-avatar.png';
    const rawName = userData.nickname || userData.uniqueId || 'Seseorang';
    const cleanNick = rawName.replace(/^@+/, '').trim() || 'Seseorang';

    preloadGiftImage(userData.giftPictureUrl).then(() => {
    for (let i = 0; i < spawnCount; i++) {
      setTimeout(() => {
        // Batasi jumlah gift melayang bersamaan (gift storm)
        while (container.children.length >= FLOATING_GIFT_MAX) {
          container.firstElementChild.remove();
        }

        const item = document.createElement('div');
        item.className = 'floating-gift-item';

        // Sebar posisi per gelombang agar tidak menumpuk di satu titik
        const randomLeft = Math.floor(12 + Math.random() * 76);
        item.style.left = `${randomLeft}%`;
        item.style.setProperty('--rise-dur', `${(4.2 + Math.random() * 0.8).toFixed(2)}s`);

        const sway = document.createElement('div');
        sway.className = 'floating-gift-sway';
        const swayDur = 1.6 + Math.random() * 0.6;
        sway.style.setProperty('--sway-x', `${(8 + Math.random() * 10).toFixed(1)}px`);
        sway.style.setProperty('--sway-rot', `${(2 + Math.random() * 3).toFixed(1)}deg`);
        sway.style.setProperty('--sway-dur', `${swayDur.toFixed(2)}s`);
        // Fase acak supaya tiap gift tidak berayun serempak
        sway.style.animationDelay = `-${(Math.random() * swayDur).toFixed(2)}s`;

        const content = document.createElement('div');
        content.className = 'floating-gift-content';

        if (userData.giftPictureUrl) {
          const giftImg = document.createElement('img');
          giftImg.className = 'floating-gift-img';
          giftImg.src = userData.giftPictureUrl;
          giftImg.alt = userData.giftName || 'Gift';
          giftImg.onerror = function() { this.style.display = 'none'; };
          content.appendChild(giftImg);
        } else {
          const giftIcon = document.createElement('div');
          giftIcon.className = 'floating-gift-img';
          giftIcon.style.display = 'flex';
          giftIcon.style.alignItems = 'center';
          giftIcon.style.justifyContent = 'center';
          giftIcon.style.fontSize = '38px';
          giftIcon.style.color = '#ffd700';
          giftIcon.innerHTML = '<i class="fa-solid fa-gift"></i>';
          content.appendChild(giftIcon);
        }

        if (repeatCount > 1) {
          const combo = document.createElement('span');
          combo.className = 'floating-gift-combo';
          combo.textContent = `x${repeatCount}`;
          content.appendChild(combo);
        }

        const senderPill = document.createElement('div');
        senderPill.className = 'floating-gift-sender-pill';

        const senderAvatar = document.createElement('img');
        senderAvatar.className = 'floating-gift-avatar';
        senderAvatar.src = avatarSrc;
        senderAvatar.onerror = function() { this.src = 'assets/default-avatar.png'; };

        const senderName = document.createElement('span');
        senderName.className = 'floating-gift-name';
        senderName.textContent = cleanNick;

        senderPill.appendChild(senderAvatar);
        senderPill.appendChild(senderName);
        content.appendChild(senderPill);

        sway.appendChild(content);
        item.appendChild(sway);

        // Percikan kecil saat muncul (tanpa glow, warna palet resmi)
        const sparkleColors = ['#ffd54f', '#fe2c55', '#25f4ee', '#ffffff', '#f59e0b'];
        const sparkleCount = isLowPowerMode ? 0 : 6;
        for (let s = 0; s < sparkleCount; s++) {
          const sparkle = document.createElement('div');
          sparkle.className = 'floating-sparkle';
          const size = Math.floor(Math.random() * 5 + 5);
          sparkle.style.width = `${size}px`;
          sparkle.style.height = `${size}px`;
          sparkle.style.backgroundColor = sparkleColors[Math.floor(Math.random() * sparkleColors.length)];

          const angle = (Math.PI * 2 / sparkleCount) * s + (Math.random() * 0.4);
          const dist = Math.random() * 40 + 40;
          const tx = Math.cos(angle) * dist;
          const ty = Math.sin(angle) * dist - 20;

          sparkle.style.setProperty('--tx', `${tx.toFixed(1)}px`);
          sparkle.style.setProperty('--ty', `${ty.toFixed(1)}px`);
          sparkle.style.setProperty('--duration', `${(0.9 + Math.random() * 0.5).toFixed(2)}s`);
          sparkle.addEventListener('animationend', () => sparkle.remove(), { once: true });
          item.appendChild(sparkle);
        }

        const cleanup = () => { if (item.parentNode) item.remove(); };
        item.addEventListener('animationend', (e) => {
          if (e.target === item && e.animationName === 'floatingGiftRise') cleanup();
        });
        setTimeout(cleanup, 5600); // fallback jika animationend tidak terpicu

        container.appendChild(item);
      }, i * 320);
    }
    });
  }
  window.spawnFloatingGift = spawnFloatingGift;

  socket.on('share', (data) => {
    showSocialAlert(data, 'share');
    const username = data.nickname || data.uniqueId;
    if (username) {
      recordActivity(username, data.profilePictureUrl);
      playerShares[username] = (playerShares[username] || 0) + 1;
      queueStorageSave('pts_share_' + username, playerShares[username]);
    }
  });

  socket.on('follow', (data) => {
    if (data.uniqueId) knownFollowers.add(data.uniqueId.toLowerCase());
    if (data.nickname) knownFollowers.add(data.nickname.toLowerCase());
    if (data.userId) knownFollowers.add(data.userId.toString());
    showSocialAlert(data, 'follow');
    const username = data.nickname || data.uniqueId;
    if (username) recordActivity(username, data.profilePictureUrl);
  });

  const lastGiftAlerts = {};
  socket.on('gift', (data) => {
    const comboKey = data.groupId ? data.groupId : (data.uniqueId + '_' + data.giftId);
    let shouldAlert = false;

    if (data.giftType === 1) {
      if (isPlayEveryGiftSound) {
        // If play every sound is enabled, alert if we haven't alerted this count yet
        if (lastGiftAlerts[comboKey] !== data.repeatCount) {
          shouldAlert = true;
          lastGiftAlerts[comboKey] = data.repeatCount;
        }
      } else {
        // If disabled, only alert on the final end event
        if (data.repeatEnd) {
          shouldAlert = true;
        }
      }
    } else {
      // Non-repeatable gifts always alert
      shouldAlert = true;
    }

    if (shouldAlert) {
      showSocialAlert(data, 'gift');
      spawnFloatingGift(data);
    }

    const username = data.nickname || data.uniqueId;
    if (username) {
      recordActivity(username, data.profilePictureUrl);
      
      // Points should ONLY be added on the final event to avoid double/inflated counting!
      if (data.giftType === 1 && !data.repeatEnd) return;

      const coins = data.totalDiamonds || ((data.diamondCount || 0) * (data.repeatCount || 1));
      if (coins > 0) {
        playerGifts[username] = (playerGifts[username] || 0) + coins;
        queueStorageSave('pts_gift_' + username, playerGifts[username]);
      }
      
      // Cleanup tracking to prevent memory leak
      if (data.giftType === 1 && data.repeatEnd) {
        setTimeout(() => { delete lastGiftAlerts[comboKey]; }, 5000);
      }
    }
  });

  socket.on('like', (data) => {
    const addedLikes = (typeof data.likeCount === 'number') ? data.likeCount : 1;
    const username = data.nickname || data.uniqueId;
    if (username) {
      recordActivity(username, data.profilePictureUrl);
      playerLikes[username] = (playerLikes[username] || 0) + addedLikes;
      queueStorageSave('pts_like_' + username, playerLikes[username]);
    }
    
    // Spawn throttled heart animation + counter for visual feedback
    spawnHeartFlurry(Math.min(addedLikes, 3));
    updateLikeCounter(data, addedLikes);
    
    // Like-restart logic only when waiting
    if (isLikeRestartEnabled && isWaitingForLikes) {
      currentLikes += addedLikes;
      updateLikeProgressBar();
      
      if (currentLikes >= likeRestartThreshold) {
        if (window.playHostAudio) playHostAudio('interaction');
        executeRestartTransition();
      }
    }
  });

}

// Queue system for high-volume chat
let guessQueue = [];

// Deduplication: mencegah user kirim kata yang sama lebih dari sekali per ronde
let userGuessDedup = new Set(); // key: "userId:KATA"
let joinGuessUsersDedup = new Set(); // key: userId
let lastJoinGuessTime = 0;

function getFarWordFromTarget() {
  if (currentGameMode === 'squareword') return null;
  if (!VALID_WORDS || VALID_WORDS.length === 0 || !currentWord) return null;
  const targetChars = new Set(currentWord.split(''));
  
  // 1. Cari kata dengan 0 huruf overlap dengan target
  const zeroOverlap = VALID_WORDS.filter(w => w.length === WORD_LENGTH && w !== currentWord && ![...w].some(c => targetChars.has(c)));
  if (zeroOverlap.length > 0) {
    return zeroOverlap[Math.floor(Math.random() * zeroOverlap.length)];
  }
  
  // 2. Jika tidak ada 0 overlap, cari dengan overlap minimal
  let bestWords = [];
  let minOverlap = 99;
  for (let w of VALID_WORDS) {
    if (w.length !== WORD_LENGTH || w === currentWord) continue;
    let overlap = 0;
    for (let c of w) {
      if (targetChars.has(c)) overlap++;
    }
    if (overlap < minOverlap) {
      minOverlap = overlap;
      bestWords = [w];
    } else if (overlap === minOverlap) {
      bestWords.push(w);
    }
  }
  if (bestWords.length > 0) {
    return bestWords[Math.floor(Math.random() * bestWords.length)];
  }
  return null;
}

function handleAutoGuessOnJoin(memberData) {
  if (isGameOver || !window.autoGuessOnJoin) return;
  
  const userId = memberData.uniqueId || memberData.nickname || 'anon_joiner';
  if (joinGuessUsersDedup.has(userId)) return; // 1x auto-jawab saat join per ronde
  
  // Throttle agar tidak spam jika banyak joiner sekaligus (min interval 2.5 detik)
  const now = Date.now();
  if (now - lastJoinGuessTime < 2500) return;
  
  const farWord = getFarWordFromTarget();
  if (!farWord) return;
  
  lastJoinGuessTime = now;
  joinGuessUsersDedup.add(userId);
  
  const simulatedData = {
    nickname: memberData.nickname || memberData.uniqueId || 'Viewer',
    uniqueId: memberData.uniqueId || 'viewer',
    profilePictureUrl: memberData.profilePictureUrl || 'assets/bg_nature.png',
    comment: farWord,
    followRole: memberData.followRole || 0,
    isFollower: memberData.isFollower || false
  };

  handleChatGuess(simulatedData);
}

// Handle Guesses from Chat
function handleChatGuess(data, optionalUserData) {
  if (typeof data === 'string') {
    data = Object.assign({ comment: data }, optionalUserData || {});
  }
  if (!data || !data.comment) return;
  const rawMsg = data.comment.trim().toLowerCase();
  
  // Rank Command (selalu aktif kapan pun)
  if (rawMsg === '!myrank' || rawMsg === '!rank') {
    handleMyRank(data);
    return;
  }

  const isCurrentOver = (currentGameMode === 'betweenle') ? betweenleIsGameOver : ((currentGameMode === 'cascadle') ? cascadleIsGameOver : ((currentGameMode === 'wanderwords') ? wanderWordsIsGameOver : ((currentGameMode === 'wordpyramid') ? wordPyramidIsGameOver : isGameOver)));
  if (isCurrentOver) return;

  // Hapus semua karakter selain huruf A-Z untuk bypass filter TikTok
  const msg = data.comment.toUpperCase().replace(/[^A-Z]/g, '');
  
  let isAllowedLength = (msg.length === WORD_LENGTH);
  if (currentGameMode === 'wordladder') {
    isAllowedLength = (msg.length === (wordLadderStartWord ? wordLadderStartWord.length : 4));
  } else if (currentGameMode === 'wordtango') {
    isAllowedLength = (msg.length >= 3 && msg.length <= 6);
  } else if (currentGameMode === 'wordgrid') {
    isAllowedLength = (msg.length >= 3);
  } else if (currentGameMode === 'betweenle') {
    isAllowedLength = (msg.length === betweenleLetterLength);
  } else if (currentGameMode === 'cascadle') {
    isAllowedLength = (msg.length === cascadleCurrentLevel);
  } else if (currentGameMode === 'wanderwords') {
    const targetClean = (wanderWordsCurrentPuzzle && wanderWordsCurrentPuzzle.cleanAnswer) ? wanderWordsCurrentPuzzle.cleanAnswer : '';
    // Hanya proses tebakan jika panjang huruf sama dengan target kata atau jawaban persis (abaikan obrolan santai penonton)
    isAllowedLength = Boolean(targetClean ? (msg.length === targetClean.length || msg === targetClean) : (msg.length >= 4));
  } else if (currentGameMode === 'wordcluster') {
    isAllowedLength = (msg.length >= 2);
  } else if (currentGameMode === 'wordmatch') {
    isAllowedLength = (msg.length >= 2);
  } else if (currentGameMode === 'wordpyramid') {
    isAllowedLength = (msg.length === wordPyramidCurrentLevel);
  }

  if (isAllowedLength) {
    const userId = data.uniqueId || data.nickname || 'anon';
    const isHost = (userId === 'host' || userId === 'host_offline' || (typeof userId === 'string' && userId.toLowerCase().includes('host')));
    const uIdLower = (data.uniqueId || '').toLowerCase();
    const nickLower = (data.nickname || '').toLowerCase();
    const uIdStr = (data.userId || '').toString();

    const isCachedFollower = Boolean(
      (uIdLower && knownFollowers.has(uIdLower)) ||
      (nickLower && knownFollowers.has(nickLower)) ||
      (uIdStr && knownFollowers.has(uIdStr))
    );

    const isFollower = Boolean(
      data.isFollower ||
      data.isFollowerOfAnchor ||
      data.userIdentity?.isFollowerOfAnchor ||
      data.userIdentity?.isMutualFollowingWithAnchor ||
      data.followRole === 1 ||
      data.followRole === 2 ||
      data.isModerator ||
      data.isSubscriber ||
      (data.teamMemberLevel && data.teamMemberLevel > 0) ||
      isHost ||
      isCachedFollower
    );

    if (isFollower) {
      if (uIdLower) knownFollowers.add(uIdLower);
      if (nickLower) knownFollowers.add(nickLower);
      if (uIdStr) knownFollowers.add(uIdStr);
    }

    // Follower-only filter for word guesses
    if (isFollowerOnlyGuess && !isFollower) {
      console.log(`[Follower Filter] Tebakan "${msg}" dari @${userId} diabaikan karena belum follow (isFollower: ${isFollower}, followRole: ${data.followRole}).`);
      return;
    }

    // Untuk Wander Words & Word Cluster: proses instan langsung real-time tanpa antrean buatan
    if (currentGameMode === 'wanderwords') {
      processWanderWordsGuess(msg, data);
      return;
    }
    if (currentGameMode === 'wordcluster') {
      processWordClusterGuess(msg, data);
      return;
    }
    if (currentGameMode === 'wordmatch') {
      processWordMatchGuess(msg, data);
      return;
    }
    if (currentGameMode === 'wordpyramid') {
      processWordPyramidGuess(msg, data);
      return;
    }

    // Deduplikasi dan pra-validasi cerdas untuk Betweenle agar antrean tidak tersumbat
    if (currentGameMode === 'betweenle') {
      if (!isHost) {
        // Abaikan kata duplikat yang sudah pernah dievaluasi di ronde ini
        if (typeof betweenleGuessedWords !== 'undefined' && betweenleGuessedWords.has(msg)) return;
        const dedupKey = `${userId}:${msg}`;
        if (userGuessDedup.has(dedupKey)) return;
        userGuessDedup.add(dedupKey);

        // Pra-validasi kamus: abaikan obrolan/typo penonton non-baku sebelum masuk queue
        if (typeof getBetweenleWordIndex === 'function') {
          const wordIdx = getBetweenleWordIndex(msg, betweenleLetterLength);
          if (wordIdx === -1) return; // Drop chat typo penonton agar queue tidak penuh
        }
      }
    } else if (currentGameMode === 'squareword') {
      if (!isHost) {
        const dedupKey = `${userId}:${msg}`;
        if (userGuessDedup.has(dedupKey)) return; // skip duplikat user
        userGuessDedup.add(dedupKey);

        // Pra-validasi kamus: abaikan obrolan biasa/typo penonton agar queue tidak tersumbat
        const isValid = (allValidWordsSets && allValidWordsSets[5] && allValidWordsSets[5].has(msg)) ||
                        (VALID_WORDS_SET && VALID_WORDS_SET.has(msg)) ||
                        (allValidWords && allValidWords[5] && allValidWords[5].includes(msg)) ||
                        (fullValidDictionary && fullValidDictionary.has(msg));
        if (!isValid) return; // Drop chat biasa yang bukan kata baku KBBI

        // Jika kata sudah pernah dievaluasi di ronde ini & antrean sedang ramai, skip agar stream responsif
        if (squarewordGuesses && squarewordGuesses.includes(msg) && guessQueue.length >= 2) return;
      }
    } else if (currentGameMode === 'wordle' || currentGameMode === 'word500' || currentGameMode === 'wordfit' || currentGameMode === 'colorfit') {
      if (!isHost) {
        if (msg.length !== WORD_LENGTH) return;

        const dedupKey = `${userId}:${msg}`;
        if (userGuessDedup.has(dedupKey)) return; // skip duplikat user
        userGuessDedup.add(dedupKey);

        if (currentGameMode === 'colorfit') {
          if (!/^[RGBYPO]+$/.test(msg)) return;
        } else {
          // Pra-validasi kamus: buang obrolan live chat penonton yang bukan kata baku 5 huruf
          const isValid = (VALID_WORDS_SET && VALID_WORDS_SET.size > 0 && VALID_WORDS_SET.has(msg)) ||
                          (VALID_WORDS && VALID_WORDS.includes(msg)) ||
                          (allValidWordsSets && allValidWordsSets[WORD_LENGTH] && allValidWordsSets[WORD_LENGTH].has(msg)) ||
                          (allValidWords && allValidWords[WORD_LENGTH] && allValidWords[WORD_LENGTH].includes(msg)) ||
                          (typeof fullValidDictionary !== 'undefined' && fullValidDictionary && fullValidDictionary.has(msg));
          if (!isValid) return; // Drop chat obrolan penonton agar antrean Wordle 0ms instan & tidak lag!

          // Abaikan jika kata sudah ditebak di ronde ini
          if (guesses && guesses.includes(msg)) return;
        }
      }
    } else if (currentGameMode !== 'cascadle') {
      const dedupKey = `${userId}:${msg}`;
      if (userGuessDedup.has(dedupKey)) return; // skip duplikat
      userGuessDedup.add(dedupKey);
    }

    if (guessQueue.length < 50) {
      // Cek cooldown anti-dominasi (diam-diam — user tidak diberitahu)
      const cdUserId = data.uniqueId || data.nickname || 'anon';
      const cdIsHost = (cdUserId === 'host' || cdUserId === 'host_offline' || (typeof cdUserId === 'string' && cdUserId.toLowerCase().includes('host')));
      if (!cdIsHost && getWinCooldownRemaining(cdUserId) > 0) return; // silently drop

      guessQueue.push({ guessWord: msg, userData: data });
      processQueue();
    }
  }
}

async function processQueue() {
  const isCurrentOver = (currentGameMode === 'betweenle') ? betweenleIsGameOver : ((currentGameMode === 'cascadle') ? cascadleIsGameOver : ((currentGameMode === 'wanderwords') ? wanderWordsIsGameOver : isGameOver));
  if (isProcessing || guessQueue.length === 0 || isCurrentOver) return;
  isProcessing = true;
  
  const queueLen = guessQueue.length;
  const { guessWord, userData } = guessQueue.shift();

  try {
    if (currentGameMode === 'squareword') {
      await processSquarewordGuess(guessWord, userData);
    } else {
      processGuess(guessWord, userData, queueLen);
    }
  } catch (err) {
    console.error('Error processing guess:', err);
  }
  
  isProcessing = false;
  if (guessQueue.length > 0 && !isCurrentOver) {
    let nextDelay = 10;
    if (isGameAnimationsEnabled && currentGameMode !== 'squareword' && currentGameMode !== 'wanderwords') {
      if (guessQueue.length <= 1) {
        nextDelay = 50; // Responsif & real-time (turun dari 280ms)
      } else if (guessQueue.length <= 3) {
        nextDelay = 20; // Cepat (turun dari 100ms)
      } else {
        nextDelay = 5;  // Instan saat ramai
      }
    } else {
      nextDelay = 5;
    }
    setTimeout(processQueue, nextDelay);
  }
}

function showFloatingPoints(points, targetElementId) {
  const target = document.getElementById(targetElementId);
  if (!target) return;
  
  const floater = document.createElement('div');
  floater.className = 'floating-points';
  floater.textContent = `+${points}`;
  document.body.appendChild(floater);
  
  const rect = target.getBoundingClientRect();
  floater.style.left = `${rect.left + (rect.width / 2)}px`;
  floater.style.top = `${rect.top}px`;
  
  setTimeout(() => floater.remove(), 2600);
}

let lastInvalidTime = 0;



// Keep track of guessed words for the feed in Word Tango
let tangoGuessedWords = new Set();

// Function to add a guess to the Word Tango live feed
function addTangoGuessToFeed(word, userData, isCorrect) {
  const feed = document.getElementById('tangoGuessFeed');
  if (!feed) return;
  
  const upperWord = word.toUpperCase();
  // If already guessed and it's wrong, we can skip adding it again to prevent spamming the history
  if (!isCorrect && tangoGuessedWords.has(upperWord)) return;
  tangoGuessedWords.add(upperWord);
  
  const item = document.createElement('div');
  item.className = `tango-guess-item ${isCorrect ? 'correct' : 'wrong'}`;
  
  const avatar = document.createElement('img');
  avatar.className = 'tango-guess-avatar';
  avatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/default_avatar.png';
  // handle broken image link gracefully
  avatar.onerror = function() { this.src = 'assets/default_avatar.png'; };
  
  const wordSpan = document.createElement('span');
  wordSpan.className = 'tango-guess-word';
  wordSpan.textContent = upperWord;
  
  const icon = document.createElement('span');
  icon.className = 'tango-guess-icon';
  icon.textContent = isCorrect ? '✅' : '❌';
  
  item.appendChild(avatar);
  item.appendChild(wordSpan);
  item.appendChild(icon);
  
  feed.appendChild(item);
  
  // Maintain max 3 visible items, sliding out the oldest
  const activeItems = Array.from(feed.children).filter(child => !child.classList.contains('slide-out'));
  if (activeItems.length > 3) {
    const oldest = activeItems[0];
    oldest.classList.add('slide-out');
    setTimeout(() => {
      if (oldest.parentNode) oldest.remove();
    }, 300);
  }
}

// Process a valid guess — optimized: adaptive pacing & smooth flip
function processGuess(guessWord, userData, queueLen = 0) {
  const isStarterGuess = !!(userData && (userData.isStarter || userData.uniqueId === 'system'));

  if (isBadWordsFilterOn && !isStarterGuess) {
    const isTarget = (currentWord && guessWord === currentWord) || 
                     (typeof betweenleSecretWord !== 'undefined' && guessWord === betweenleSecretWord);
    if (!isTarget) {
      for (const bad of STOPWORDS) {
        if (guessWord === bad || (bad.length >= 5 && guessWord.includes(bad))) {
          console.log(`[Bad Word Filter] Rejected guess: ${guessWord}`);
          return; // Reject silently from the board
        }
      }
    }
  }

  if (currentGameMode === 'betweenle') {
    processBetweenleGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'cascadle') {
    processCascadleGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wanderwords') {
    processWanderWordsGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wordcluster') {
    processWordClusterGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wordmatch') {
    processWordMatchGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wordpyramid') {
    processWordPyramidGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'squareword') {
    processSquarewordGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wordladder') {
    processWordLadderGuess(guessWord, userData);
    return;
  }

  if (currentGameMode === 'wordgrid') {
    const pointsWon = checkWordGridGuess(guessWord, userData.nickname || userData.uniqueId, userData.profilePictureUrl);
    if (pointsWon) {
      addPoints(userData, pointsWon);
    }
    return;
  }

  if (currentGameMode === 'wordtango') {
    const validSet = allValidWordsSets[guessWord.length];
    let isValidWord = (validSet && validSet.size > 0) ? validSet.has(guessWord) : (allValidWords[guessWord.length] && allValidWords[guessWord.length].includes(guessWord));
    if (!isValidWord) return;

    let matchedIndex = -1;
    let matchedPatternIndex = -1;

    for (let i = 0; i < 4; i++) {
      const t = wordTangoTargets[i];
      if (t && !t.solved) {
        if (t.word === guessWord) {
          matchedIndex = i;
          break;
        }
        
        // Check if guess matches the revealed pattern
        if (guessWord.length === t.length) {
          let fitsPattern = true;
          for (let j = 0; j < t.length; j++) {
             if (!t.missingIndices.includes(j)) {
                if (guessWord[j] !== t.word[j]) {
                   fitsPattern = false;
                   break;
                }
             }
          }
          if (fitsPattern) {
             matchedPatternIndex = i;
          }
        }
      }
    }

    if (matchedIndex === -1) {
      // If it doesn't match the exact target, but matches a pattern, add to feed as wrong
      if (matchedPatternIndex !== -1) {
        addTangoGuessToFeed(guessWord, userData, false);
      }
      return;
    }

    // Add correct guess to the feed
    addTangoGuessToFeed(guessWord, userData, true);

    const target = wordTangoTargets[matchedIndex];
    target.solved = true;
    target.solver = userData;
    const pts = target.points || 15;
    addPoints(userData, pts);
    recordWin(userData && (userData.uniqueId || userData.nickname));

    const row = document.getElementById(`tango-row-${matchedIndex}`);
    if (row) {
      row.classList.add('solved');
      const avatar = row.querySelector('.guesser-avatar');
      if (avatar) {
        avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
        avatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
        avatar.style.display = '';
        avatar.classList.add('show');
        showFloatingPoints(pts, avatar.id);
      }

      const tiles = row.querySelectorAll('.tile');
      for (let j = 0; j < target.length; j++) {
        const tile = tiles[j];
        if (tile) {
          tile.textContent = target.word[j];
          tile.className = 'tile correct';
          tile.style.transform = 'scale(1.15)';
          setTimeout(() => tile.style.transform = '', 200);
        }
      }
    }

    for (const idx of target.missingIndices) {
      const letter = target.word[idx];
      const poolItem = wordTangoPool.find(item => !item.used && item.char === letter);
      if (poolItem) {
        poolItem.used = true;
      }
    }
    renderTangoPool();

    if (window.playHostAudio) playHostAudio('correct');

    if (wordTangoTargets.every(t => t.solved)) {
      isGameOver = true;

      const solverScores = {};
      wordTangoTargets.forEach(t => {
        if (t.solver && t.solver.uniqueId) {
          if (!solverScores[t.solver.uniqueId]) {
            solverScores[t.solver.uniqueId] = { score: 0, words: 0, data: t.solver };
          }
          solverScores[t.solver.uniqueId].score += (t.points || 15);
          solverScores[t.solver.uniqueId].words++;
        }
      });

      let maxScore = 0;
      Object.values(solverScores).forEach(s => {
        if (s.score > maxScore) maxScore = s.score;
      });

      let mvpData = userData;
      if (userData && userData.uniqueId && solverScores[userData.uniqueId] && solverScores[userData.uniqueId].score === maxScore) {
        mvpData = userData;
      } else {
        const mvp = Object.values(solverScores).find(s => s.score === maxScore);
        if (mvp) mvpData = mvp.data;
      }

      setTimeout(() => {
        const multiWinList = document.getElementById('multiWinList');
        if (multiWinList) {
          multiWinList.innerHTML = '';
          wordTangoTargets.forEach((t) => {
            const solverData = t.solver || { nickname: 'Unknown', profilePictureUrl: 'assets/bg_nature.png' };
            const isMvp = (mvpData && solverData.uniqueId === mvpData.uniqueId);
            
            const item = document.createElement('div');
            item.className = `multi-win-item ${isMvp ? 'mvp' : ''}`;
            item.innerHTML = `
              <img class="multi-win-avatar" src="${solverData.profilePictureUrl || 'assets/bg_nature.png'}" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="Avatar">
              <div class="multi-win-info">
                <div class="multi-win-name">${solverData.nickname || 'Unknown'}</div>
                <div class="multi-win-word">${t.word}</div>
              </div>
              <div class="multi-win-points">+${t.points || 15}</div>
            `;
            multiWinList.appendChild(item);
          });
        }
        triggerWinTransition(5000, true);
      }, 1000);
    }
    return;
  }

  let isValidWord = (VALID_WORDS_SET && VALID_WORDS_SET.size > 0) ? VALID_WORDS_SET.has(guessWord) : VALID_WORDS.includes(guessWord);
  if (currentGameMode === 'colorfit') {
    isValidWord = /^[RGBYPO]+$/.test(guessWord) && guessWord.length === WORD_LENGTH;
  }
  if (isStarterGuess) {
    isValidWord = (guessWord.length === WORD_LENGTH);
  }

  if (currentGameMode === 'fillblanks') {
    if (!isValidWord) return;
    
    let matchedIndex = -1;
    let isCorrectTarget = false;
    
    // Exact match target
    for (let i = 0; i < 6; i++) {
      if (fillBlanksTargets[i] && !fillBlanksTargets[i].solved && fillBlanksTargets[i].word === guessWord) {
        matchedIndex = i;
        isCorrectTarget = true;
        break;
      }
    }
    
    // If not exact target, check pattern match for invalid display
    if (matchedIndex === -1) {
      for (let i = 0; i < 6; i++) {
        const target = fillBlanksTargets[i];
        if (target && !target.solved && !target.isAnimating) {
          let matchesPattern = true;
          for (let j = 0; j < WORD_LENGTH; j++) {
            const clue = target.clues[j];
            if (clue) {
              if (clue.status === 'correct' && guessWord[j] !== clue.char) {
                matchesPattern = false; break;
              }
              if (clue.status === 'present' && (guessWord[j] === clue.char || !guessWord.includes(clue.char))) {
                matchesPattern = false; break;
              }
            }
          }
          if (matchesPattern) {
            matchedIndex = i;
            isCorrectTarget = false;
            break;
          }
        }
      }
    }
    
    if (matchedIndex !== -1) {
      const row = document.getElementById(`row-empty-${matchedIndex}`);
      
      if (isCorrectTarget) {
        fillBlanksTargets[matchedIndex].solved = true;
        fillBlanksTargets[matchedIndex].solver = userData;
        const pts = fillBlanksTargets[matchedIndex].isYellowRow ? 15 : 10;
        fillBlanksTargets[matchedIndex].points = pts;
        addPoints(userData, pts);
        recordWin(userData && (userData.uniqueId || userData.nickname));
        
        if (row) {
          const avatar = row.querySelector('.guesser-avatar');
          if (avatar) {
            avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
            avatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
            avatar.classList.add('show');
            showFloatingPoints(pts, avatar.id);
          }
          
          for (let j = 0; j < WORD_LENGTH; j++) {
            const tile = document.getElementById(`tile-empty-${matchedIndex}-${j}`);
            if (tile) {
              tile.textContent = guessWord[j];
              tile.className = 'tile correct';
              tile.style.transform = 'scale(1.1)';
              setTimeout(() => tile.style.transform = '', 200);
            }
          }
        }
        
        if (fillBlanksTargets.every(t => t.solved)) {
          isGameOver = true;
          
          let mvpData = userData;
          const solverScores = {};
          fillBlanksTargets.forEach(t => {
            if (t.solver && t.solver.uniqueId) {
              if (!solverScores[t.solver.uniqueId]) {
                solverScores[t.solver.uniqueId] = { score: 0, words: 0, data: t.solver };
              }
              solverScores[t.solver.uniqueId].score += (t.points || 15);
              solverScores[t.solver.uniqueId].words++;
            }
          });
          
          let maxScore = 0;
          Object.values(solverScores).forEach(s => {
            if (s.score > maxScore) maxScore = s.score;
          });
          
          if (userData && userData.uniqueId && solverScores[userData.uniqueId] && solverScores[userData.uniqueId].score === maxScore) {
            mvpData = userData; // Final guesser is tied for points, they win the tiebreaker
          } else {
            const mvp = Object.values(solverScores).find(s => s.score === maxScore);
            if (mvp) mvpData = mvp.data;
          }

          setTimeout(() => {
            const multiWinList = document.getElementById('multiWinList');
            if (multiWinList) {
              multiWinList.innerHTML = '';
              fillBlanksTargets.forEach((t) => {
                const solverData = t.solver || { nickname: 'Unknown', profilePictureUrl: 'assets/bg_nature.png' };
                const isMvp = (mvpData && solverData.uniqueId === mvpData.uniqueId);
                
                const item = document.createElement('div');
                item.className = `multi-win-item ${isMvp ? 'mvp' : ''}`;
                item.innerHTML = `
                  <img class="multi-win-avatar" src="${solverData.profilePictureUrl || 'assets/bg_nature.png'}" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="Avatar">
                  <div class="multi-win-info">
                    <div class="multi-win-name">${solverData.nickname || 'Unknown'}</div>
                    <div class="multi-win-word">${t.word}</div>
                  </div>
                  <div class="multi-win-points">+${t.points || 15}</div>
                `;
                multiWinList.appendChild(item);
              });
            }
            triggerWinTransition(10000, true);
          }, 1000);
        }
      } else {
        // Pattern matched but wrong target word
        fillBlanksTargets[matchedIndex].isAnimating = true;
        if (row) {
          row.classList.remove('shake');
          void row.offsetWidth; // Trigger reflow
          row.classList.add('shake');
          
          const avatar = row.querySelector('.guesser-avatar');
          const originalAvatarSrc = avatar ? avatar.src : '';
          const originalAvatarShow = avatar ? avatar.classList.contains('show') : false;
          
          if (avatar) {
            avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
            avatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
            avatar.classList.add('show');
          }
          
          const targetWord = fillBlanksTargets[matchedIndex].word;
          let statuses = Array(WORD_LENGTH).fill('absent');
          let targetLetters = targetWord.split('');

          // First pass: correct
          for (let j = 0; j < WORD_LENGTH; j++) {
            if (guessWord[j] === targetWord[j]) {
              statuses[j] = 'correct';
              targetLetters[j] = null;
            }
          }
          
          // Second pass: present
          if (hardModeState === 'off') {
            for (let j = 0; j < WORD_LENGTH; j++) {
              if (statuses[j] !== 'correct' && targetLetters.includes(guessWord[j])) {
                statuses[j] = 'present';
                targetLetters[targetLetters.indexOf(guessWord[j])] = null;
              }
            }
          }

          for (let j = 0; j < WORD_LENGTH; j++) {
            const tile = document.getElementById(`tile-empty-${matchedIndex}-${j}`);
            if (tile) {
              tile.textContent = guessWord[j];
              tile.className = 'tile ' + statuses[j];
              if (statuses[j] !== 'correct') {
                 tile.style.transition = 'all 0.3s';
              }
              // optional: add small pulse effect for invalid guess
              tile.style.transform = 'scale(0.95)';
            }
          }
          
          setTimeout(() => {
            if (row) row.classList.remove('shake');
            
            if (!fillBlanksTargets[matchedIndex].solved) {
               fillBlanksTargets[matchedIndex].isAnimating = false;
               if (avatar) {
                 if (originalAvatarShow) {
                   avatar.src = originalAvatarSrc;
                 } else {
                   avatar.classList.remove('show');
                 }
               }
               for (let j = 0; j < WORD_LENGTH; j++) {
                 const tile = document.getElementById(`tile-empty-${matchedIndex}-${j}`);
                 if (tile) {
                   const clue = fillBlanksTargets[matchedIndex].clues[j];
                   tile.className = 'tile';
                   tile.style.transform = '';
                   if (clue) {
                     tile.textContent = clue.char;
                     tile.classList.add(clue.status);
                   } else {
                     tile.textContent = '';
                   }
                 }
               }
            }
          }, 3000); // revert after 3s
        }
      }
    }
    return;
  }

  let hardModeMsg = "";

  // Cek duplikat untuk semua mode (kecuali fillblanks)
  if (!isStarterGuess && isValidWord && guesses.includes(guessWord)) {
    isValidWord = false;
    if (lastLang === 'en') hardModeMsg = `Already guessed this round`;
    else if (lastLang === 'mixed') hardModeMsg = `Sudah ditebak / Already guessed`;
    else hardModeMsg = `Kata sudah ditebak di ronde ini`;
  }
  
  const isNoRepeatActive = isNoRepeatMode && (currentGameMode === 'wordle' || currentGameMode === 'word500' || currentGameMode === 'wordfit');
  if (!isStarterGuess && isValidWord && isNoRepeatActive) {
    if (new Set(guessWord).size !== guessWord.length) {
      isValidWord = false;
      if (lastLang === 'en') hardModeMsg = `No repeat letters allowed`;
      else if (lastLang === 'mixed') hardModeMsg = `Tidak boleh huruf ganda / No repeat letters`;
      else hardModeMsg = `Tidak boleh ada huruf ganda`;
    }
  }

  let hardModeConflictWord = null;

  if (!isStarterGuess && isValidWord) {
    const hmCheck = validateHardMode(guessWord);
    if (!hmCheck.valid) {
      hardModeMsg = hmCheck.msg;
      hardModeConflictWord = hmCheck.conflictWord || null;
      isValidWord = false; // Treat hard mode violation as invalid guess
    }
  }

  if (!isValidWord) {
    // Hapus dari dedup jika tebakan tidak valid (misal salah ejaan atau melanggar Hard Mode)
    // Supaya user bisa memperbaikinya atau menebak lagi setelah Hard Mode dimatikan
    if (userData) {
      const userId = userData.uniqueId || userData.nickname || 'anon';
      userGuessDedup.delete(`${userId}:${guessWord}`);
    }

    const now = Date.now();
    if (now - lastInvalidTime < 1200) {
      return false; // Skip to prevent flooding & flickering
    }
    lastInvalidTime = now;
  }

  const isWord500 = currentGameMode === 'word500';
  const isWordFit = currentGameMode === 'wordfit' || currentGameMode === 'colorfit';
  const isAnySortedMode = isWord500 || isWordFit;

  // Hapus baris invalid sebelumnya dari layar (saat ada tebakan baru masuk)
  if (isAnySortedMode && word500PendingInvalidRow) {
    if (isWordFit) renderWordFitBoard();
    else renderWord500Board();
  } else {
    if (word500PendingInvalidRow) {
      if (word500PendingInvalidRow.parentNode) word500PendingInvalidRow.remove();
      word500PendingInvalidRow = null;
    }
    const invalidRows = document.querySelectorAll('.is-invalid-row');
    invalidRows.forEach(el => {
      el.remove();
      if (board.children.length < getDisplayRows()) {
        board.appendChild(createEmptyBoardRow(board.children.length));
      }
    });
  }
  const invalidTooltips = document.querySelectorAll('.is-invalid-tooltip');
  invalidTooltips.forEach(el => {
    // Batalkan timer auto-dismiss agar tidak terjadi konflik
    if (el._fadeTimer) clearTimeout(el._fadeTimer);
    if (el._removeTimer) clearTimeout(el._removeTimer);
    el.remove();
  });

  const currentRow = guesses.length;
  
  // 1. Create a new row and attach to top of grid
  const row = document.createElement('div');
  row.className = 'board-row' + (isWordFit ? ' wordfit-row' : (isWord500 ? ' w500-row' : ''));
  row.id = `row-${currentRow}`;
  row.style.position = 'relative';
  if (!isValidWord) {
    row.style.zIndex = "5";
    if (isGameAnimationsEnabled) {
      row.classList.add('elastic-shake');
    }
  } else {
    if (isGameAnimationsEnabled) {
      row.classList.add('pop-in');
    }
  }
  
  let invalidTooltipMsg = hardModeMsg;
  if (!isValidWord && !hardModeMsg) {
    if (lastLang === 'en') invalidTooltipMsg = "Word not in dictionary";
    else if (lastLang === 'mixed') invalidTooltipMsg = "Kata tidak ada di kamus / Not in dictionary";
    else invalidTooltipMsg = "Kata tidak ada di kamus";
  }

  if (invalidTooltipMsg) {
    if (window.sounds) window.sounds.playInvalid();
    if (window.playHostAudio) playHostAudio('invalid');
    const tooltip = document.createElement('div');
    tooltip.className = 'row-tooltip is-invalid-tooltip' + (hardModeConflictWord ? ' clue-conflict-tooltip' : '');
    tooltip.textContent = invalidTooltipMsg;
    document.body.appendChild(tooltip);
    
    // Position it dynamically after row is rendered
    requestAnimationFrame(() => {
      const rowRect = row.getBoundingClientRect();
      const tooltipHeight = tooltip.offsetHeight;
      tooltip.style.position = 'fixed';
      tooltip.style.bottom = 'auto';
      tooltip.style.left = (rowRect.left + rowRect.width / 2) + 'px';
      tooltip.style.top = (rowRect.top - tooltipHeight - 8) + 'px';
      tooltip.style.zIndex = '50';
    });

    // Auto-dismiss setelah 2.5 detik dengan fade-out
    // (tetap langsung hilang jika tebakan lain masuk via invalidTooltips.forEach(el => el.remove()))
    const TOOLTIP_LIFETIME = 2500;
    const FADE_DURATION = 400;
    const autoRemove = ((t) => {
      // Mulai fade-out 400ms sebelum hilang
      const fadeTimer = setTimeout(() => {
        if (t.parentNode) t.classList.add('is-fading-out');
      }, TOOLTIP_LIFETIME - FADE_DURATION);

      const removeTimer = setTimeout(() => {
        if (t.parentNode) t.remove();
      }, TOOLTIP_LIFETIME);

      // Simpan timer ID di elemen agar bisa dibatalkan jika tooltip dihapus paksa lebih awal
      t._fadeTimer = fadeTimer;
      t._removeTimer = removeTimer;
    })(tooltip);
  }
  
  const avatar = document.createElement('img');
  avatar.className = 'guesser-avatar show' + (isGameAnimationsEnabled ? ' spring-in' : '');
  avatar.id = `avatar-${currentRow}`;
  avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
  avatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
  row.appendChild(avatar);

  const tiles = [];
  for (let j = 0; j < WORD_LENGTH; j++) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.id = `tile-${currentRow}-${j}`;
    tile.textContent = guessWord[j];
    
    if (currentGameMode === 'colorfit') {
      tile.classList.add(`color-${guessWord[j].toLowerCase()}`);
    }
    
    row.appendChild(tile);
    tiles.push(tile);
  }
  
  // 2. Determine statuses
  const guessArray = guessWord.split('');
  const targetArray = currentWord ? currentWord.split('') : [];
  const statuses = Array(WORD_LENGTH).fill('absent');
  
  let correctCount = 0;
  let presentCount = 0;
  let absentCount = 0;

  if (isValidWord) {
    // First pass: correct
    for (let i = 0; i < WORD_LENGTH; i++) {
      if (guessArray[i] === targetArray[i]) {
        statuses[i] = 'correct';
        targetArray[i] = null;
        correctCount++;
        
        // Wordle mode: hint discovery + assist points
        if (!isAnySortedMode && !discoveredLetters[i]) {
          if (guessWord !== currentWord && !isStarterGuess) {
            addPoints(userData, 2);
            showFloatingPoints(2, `tile-${currentRow}-${i}`);
          }
          const currentlyDiscovered = discoveredLetters.filter(l => l !== null).length;
          if (currentlyDiscovered < WORD_LENGTH - 1) {
            const letter = guessArray[i];
            discoveredLetters[i] = letter;
            const hintTile = document.getElementById(`hint-${i}`);
            if (hintTile) {
              hintTile.textContent = letter;
              hintTile.classList.add('discovered');
            }
          }
        }
        guessArray[i] = null;
      }
    }

    // Second pass: present
    for (let i = 0; i < WORD_LENGTH; i++) {
      if (guessArray[i] !== null && targetArray.includes(guessArray[i])) {
        if (!isNoYellowMode || isAnySortedMode) {
          statuses[i] = 'present';
        }
        targetArray[targetArray.indexOf(guessArray[i])] = null;
        presentCount++;
      }
    }
    
    absentCount = WORD_LENGTH - correctCount - presentCount;
    
    // Update Best Guess for Word500/WordFit
    if (isAnySortedMode && guessWord !== currentWord) {
      const score = (correctCount * 2) + presentCount;
      if (!bestGuess || score > bestGuess.score) {
        bestGuess = {
          word: guessWord,
          score: score,
          c: correctCount,
          p: presentCount,
          a: absentCount
        };
        updateBestGuessUI();
      }
    }
  }
  
  // 3. Apply tile classes
  for (let i = 0; i < WORD_LENGTH; i++) {
    if (!isValidWord) {
      // Beda warna: oranye untuk "tidak cocok clue", pink untuk "bukan kata"
      tiles[i].classList.add(hardModeConflictWord ? 'clue-conflict' : 'invalid');
    } else if (isAnySortedMode) {
      // Word500 / WordFit: all tiles are blind (no color feedback)
      tiles[i].classList.add('blind');
    } else {
      // Wordle: normal colored feedback
      const flipCfg = getFlipSpeedConfig(queueLen);
      if (flipCfg.shouldFlip) {
        const stepDelay = flipCfg.stepDelay;
        const revealOffset = flipCfg.revealOffset;
        tiles[i].classList.add('flip-3d');
        tiles[i].style.animationDelay = `${i * stepDelay}ms`;

        // Suara ubin berputar sinkron dengan tiap kotak huruf
        setTimeout(() => {
          if (window.sounds && typeof window.sounds.playFlip === 'function') {
            window.sounds.playFlip(i);
          }
        }, i * stepDelay);

        setTimeout(() => {
          tiles[i].classList.add(statuses[i]);
          // Jika terbuka huruf hijau (correct), bunyikan chime halus
          if (statuses[i] === 'correct' && queueLen <= 2 && window.sounds && typeof window.sounds.playGreenChime === 'function') {
            window.sounds.playGreenChime();
          }
        }, (i * stepDelay) + revealOffset);
      } else {
        tiles[i].classList.add(statuses[i]);
      }
    }
  }

  // 4. Word500 / WordFit: append feedback counters
  if (isWord500) {
    if (window.w500UseMastermind) {
      const mmContainer = document.createElement('div');
      mmContainer.className = 'mastermind-container';
      if (!isValidWord) {
        for (let m = 0; m < WORD_LENGTH; m++) {
          const b = document.createElement('div');
          b.className = 'mm-block empty';
          mmContainer.appendChild(b);
        }
      } else {
        for (let m = 0; m < correctCount; m++) { const b = document.createElement('div'); b.className = 'mm-block green'; mmContainer.appendChild(b); }
        for (let m = 0; m < presentCount; m++) { const b = document.createElement('div'); b.className = 'mm-block yellow'; mmContainer.appendChild(b); }
        for (let m = 0; m < absentCount; m++) { const b = document.createElement('div'); b.className = 'mm-block red'; mmContainer.appendChild(b); }
      }
      row.appendChild(mmContainer);
    } else {
      const greenClue = document.createElement('div');
      greenClue.className = 'w500-count green';
      greenClue.textContent = isValidWord ? correctCount : '';

      const yellowClue = document.createElement('div');
      yellowClue.className = 'w500-count yellow';
      yellowClue.textContent = isValidWord ? presentCount : '';

      const redClue = document.createElement('div');
      redClue.className = 'w500-count red';
      redClue.textContent = isValidWord ? absentCount : '';

      if (!isValidWord) {
        greenClue.className = 'w500-count empty-clue';
        yellowClue.className = 'w500-count empty-clue';
        redClue.className = 'w500-count empty-clue';
      }

      row.appendChild(greenClue);
      row.appendChild(yellowClue);
      row.appendChild(redClue);
    }
  } else if (isWordFit) {
    const exactClue = document.createElement('div');
    exactClue.className = 'wordfit-count ' + (isValidWord ? (correctCount > 0 ? 'green' : 'zero') : 'empty-clue');
    exactClue.textContent = isValidWord ? correctCount : '';

    const partialClue = document.createElement('div');
    partialClue.className = 'wordfit-count ' + (isValidWord ? (presentCount > 0 ? 'yellow' : 'zero') : 'empty-clue');
    partialClue.textContent = isValidWord ? presentCount : '';

    row.appendChild(exactClue);
    row.appendChild(partialClue);
  }

  let isClose = false;
  if (isValidWord && guessWord !== currentWord && (correctCount + presentCount >= Math.floor(WORD_LENGTH / 2) + 1)) {
    if (!hasPlayedCloseAudio) {
      hasPlayedCloseAudio = true;
      isClose = true;
      if (window.playHostAudio) playHostAudio('close');
    }
  }

  if (isAnySortedMode && isValidWord) {
    // Word500/WordFit valid: tambah ke history lalu render ulang terurut
    word500History.push({ word: guessWord, c: correctCount, p: presentCount, a: absentCount, score: (correctCount * 2) + presentCount, userData });
    guesses.push(guessWord);
    if (isWordFit) renderWordFitBoard();
    else renderWord500Board();
  } else if (isAnySortedMode && !isValidWord) {
    // Word500/WordFit invalid: masukkan ke dalam board di posisi terbaru (atas) menggantikan tebakan terbaru,
    // tetap terlihat sampai digantikan oleh tebakan berikutnya.
    row.classList.add(isWordFit ? 'wordfit-latest-row' : 'w500-latest-row', 'is-invalid-row');
    if (board.firstChild) {
      board.replaceChild(row, board.firstChild);
    } else {
      board.appendChild(row);
    }
    // Simpan referensi agar bisa dihapus tepat saat tebakan berikutnya masuk
    word500PendingInvalidRow = row;
  } else {
    // WORDLE: Tebakan terbaru selalu berada di baris paling atas
    board.insertBefore(row, board.firstChild);
    const displayRows = getDisplayRows();
    if (board.children.length > displayRows) board.removeChild(board.lastChild);
    
    if (isValidWord) {
      guesses.push(guessWord);
    } else {
      row.classList.add('is-invalid-row');
    }
  }

  // Flash baris clue yang berkonflik (Word500/Wordle hard mode)
  if (hardModeConflictWord && !isValidWord) {
    const allRows = board.querySelectorAll('.board-row');
    for (const boardRow of allRows) {
      if (boardRow === row) continue; // Skip row invalid itu sendiri
      const rowTiles = boardRow.querySelectorAll('.tile');
      let rowWord = '';
      rowTiles.forEach(t => rowWord += (t.textContent || ''));
      if (rowWord === hardModeConflictWord) {
        boardRow.classList.add('flash-conflict');
        setTimeout(() => boardRow.classList.remove('flash-conflict'), 1500);
        break;
      }
    }
  }
  
  // Check win
  let isWin = false;
  let winPts = 0;
  if (guessWord === currentWord && !isStarterGuess) {
    isWin = true;
    winPts = (currentGameMode === 'word500' || currentGameMode === 'wordfit') ? 15 : 10;
  }

  if (isWin) {
    isGameOver = true;
    guessQueue = []; // Bug#1+#5 fix: clear antrian agar tebakan lama tidak masuk ronde baru
    

      if (winPts > 0) {
        addPoints(userData, winPts);
        recordWin(userData && (userData.uniqueId || userData.nickname));
        showFloatingPoints(winPts, `avatar-${currentRow}`);
      }
      lastRoundWinner = userData;
      lastRoundTargetWord = currentWord;
      const winnerName = userData ? (userData.nickname || userData.uniqueId || 'Someone') : 'Someone';
      const avatarUrl = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
      const winOverlay = document.getElementById('winOverlay');
      const winAvatar = document.getElementById('winAvatar');
      if (winAvatar) {
        winAvatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
        winAvatar.src = avatarUrl;
      }
      document.getElementById('winName').textContent = winnerName;
      document.getElementById('winPts').innerHTML = `🪙 +${winPts} Bonus`;
      const winWordEl = document.getElementById('winWord');
      if (winWordEl) {
        if (currentGameMode === 'colorfit') {
          winWordEl.innerHTML = '';
          winWordEl.style.display = 'flex';
          winWordEl.style.justifyContent = 'center';
          winWordEl.style.gap = '8px';
          winWordEl.style.marginTop = '10px';
          
          for (let i = 0; i < currentWord.length; i++) {
            const letter = currentWord[i];
            const box = document.createElement('div');
            box.className = `color-box color-${letter.toLowerCase()}`;
            box.textContent = letter;
            box.style.width = '32px';
            box.style.height = '32px';
            box.style.fontSize = '18px';
            box.style.textShadow = 'none'; 
            winWordEl.appendChild(box);
          }
        } else {
          winWordEl.innerHTML = '';
          winWordEl.textContent = currentWord;
          winWordEl.style.display = 'block';
          winWordEl.style.fontSize = '';
          winWordEl.style.letterSpacing = '';
          winWordEl.style.marginTop = '';
        }
      }
      
      // Jika di mode Word500/WordFit, reveal seluruh grid sebelum overlay muncul
      if (currentGameMode === 'word500' || currentGameMode === 'wordfit') {
          if (currentGameMode === 'wordfit') renderWordFitBoard(true);
          else renderWord500Board(true);
      }
      
      // Tunggu 2 detik dulu agar jawaban di grid (dan efek reveal) terlihat, baru tampilkan overlay
      if (isGameAnimationsEnabled) {
        const winningRow = (currentGameMode === 'word500' || currentGameMode === 'wordfit') ? board.firstChild : row;
        if (winningRow) {
          const winningTiles = winningRow.querySelectorAll('.tile');
          setTimeout(() => {
            winningTiles.forEach((t, idx) => {
              setTimeout(() => {
                t.classList.add('win-wave');
                if (window.sounds && typeof window.sounds.playWaveTile === 'function') {
                  window.sounds.playWaveTile(idx, winningTiles.length);
                }
              }, idx * 100);
            });
          }, 1200); // Mulai wave saat huruf terakhir hampir selesai flip
        }
        
        setTimeout(() => {
          triggerWinTransition(4000);
        }, 2400); // Tunggu wave selesai sebelum memunculkan overlay
      } else {
        triggerWinTransition(4000);
      }
  }

  if (isValidWord && !isWin && !isClose) {
    if (window.playHostAudio) playHostAudio('interaction');
  }
}

// Toast System (Smooth Fade In / Fade Out + Anti-Flooding Protection)
let lastToastMsg = '';
let lastToastTime = 0;

function showToast(message, duration = 2800) {
  if (!message) return;
  const now = Date.now();
  
  // 1. Anti-spam: Cegah pesan yang persis sama muncul bertubi-tubi dalam waktu 1.5 detik
  if (message === lastToastMsg && (now - lastToastTime < 1500)) {
    return;
  }
  lastToastMsg = message;
  lastToastTime = now;

  // 2. Anti-flooding: Batasi maksimal 2 toast sekaligus di layar
  if (typeof toastContainer !== 'undefined' && toastContainer) {
    const activeToasts = toastContainer.querySelectorAll('.toast');
    if (activeToasts.length >= 2) {
      activeToasts[0].remove();
    }
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  if (typeof toastContainer !== 'undefined' && toastContainer) {
    toastContainer.appendChild(toast);
  } else {
    document.body.appendChild(toast);
  }
  
  // Smooth fade-in
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });
  
  // Smooth fade-out
  setTimeout(() => {
    toast.classList.remove('show');
    toast.classList.add('hide');
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 360);
  }, duration);
}

// Enter key support for login
document.getElementById('usernameInput').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') connectToLive();
});

// Set initial background
bgLayer.className = `bg-layer ${currentBg}`;

// Session restore is handled by autoReconnect() via DOMContentLoaded

// Fullscreen / Immersive Mode Support
document.addEventListener('click', () => {
  if (!isAutoFullscreen) return;
  const docElm = document.documentElement;
  if (!document.fullscreenElement && !document.webkitFullscreenElement) {
    if (docElm.requestFullscreen) {
      docElm.requestFullscreen().catch(err => console.log(err));
    } else if (docElm.webkitRequestFullscreen) { /* Safari */
      docElm.webkitRequestFullscreen().catch(err => console.log(err));
    }
  }
});

// Host Guess Logic
const hostGuessBtn = document.getElementById('hostGuessBtn');
const hostGuessInput = document.getElementById('hostGuessInput');
const hostGuessInputContainer = document.getElementById('hostGuessInputContainer');

if (hostGuessBtn && hostGuessInput && hostGuessInputContainer) {
  const submitHostGuess = () => {
    const guess = hostGuessInput.value.trim().toUpperCase();
    if (guess === '/TESTPEAK' || guess === 'TESTPEAK') {
      if (wordPyramidSolvedSteps.length <= 1) {
        wordPyramidSolvedSteps = [
          { level: 2, word: 'AN', userName: 'KATA AWAL', userAvatar: 'assets/bg_nature.png', addedChar: null, points: 0, isBase: true },
          { level: 3, word: 'INA', userName: 'Budi Santoso', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'I', points: 3, isBase: false },
          { level: 4, word: 'KINA', userName: 'Siti Rahma', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'K', points: 5, isBase: false },
          { level: 5, word: 'TIKNA', userName: 'Rian Pratama', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'T', points: 7, isBase: false },
          { level: 6, word: 'CANTIK', userName: 'Dedi Kurnia', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'C', points: 10, isBase: false },
          { level: 7, word: 'CANTRIK', userName: 'Agus Pemenang', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'R', points: 25, isBase: false }
        ];
        wordPyramidCurrentLevel = 7;
        wordPyramidIsGameOver = true;
      }
      if (typeof showWordPyramidPeakOverlay === 'function') {
        showWordPyramidPeakOverlay('CANTRIK', 7, { nickname: 'Agus Pemenang', userId: 'user_agus' }, 25);
      }
      hostGuessInput.value = '';
      return;
    }
    if (guess === '/TESTSHOWCASE' || guess === 'TESTSHOWCASE') {
      if (wordPyramidSolvedSteps.length <= 1) {
        wordPyramidSolvedSteps = [
          { level: 2, word: 'AN', userName: 'KATA AWAL', userAvatar: 'assets/bg_nature.png', addedChar: null, points: 0, isBase: true },
          { level: 3, word: 'INA', userName: 'Budi Santoso', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'I', points: 3, isBase: false },
          { level: 4, word: 'KINA', userName: 'Siti Rahma', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'K', points: 5, isBase: false },
          { level: 5, word: 'TIKNA', userName: 'Rian Pratama', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'T', points: 7, isBase: false },
          { level: 6, word: 'CANTIK', userName: 'Dedi Kurnia', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'C', points: 10, isBase: false },
          { level: 7, word: 'CANTRIK', userName: 'Agus Pemenang', userAvatar: DEFAULT_HOST_AVATAR, addedChar: 'R', points: 25, isBase: false }
        ];
        wordPyramidCurrentLevel = 7;
        wordPyramidIsGameOver = true;
      }
      if (typeof launchWordPyramidVictoryShowcase === 'function') {
        launchWordPyramidVictoryShowcase();
      }
      hostGuessInput.value = '';
      return;
    }
    if (guess) {
      handleChatGuess({
        comment: guess,
        uniqueId: 'host_offline',
        nickname: 'Host',
        profilePictureUrl: getHostAvatar()
      });
      hostGuessInput.value = '';
    }
  };

  hostGuessBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    hostGuessInputContainer.classList.toggle('open');
    if (hostGuessInputContainer.classList.contains('open')) {
      hostGuessInput.focus();
    } else {
      submitHostGuess();
    }
  });

  hostGuessInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      submitHostGuess();
      hostGuessInputContainer.classList.remove('open');
      hostGuessInput.blur();
    }
  });
  
  hostGuessInputContainer.addEventListener('click', (e) => e.stopPropagation());
  hostGuessInput.addEventListener('click', (e) => e.stopPropagation());
}

// Global keydown for PC host typing
document.addEventListener('keydown', (e) => {
  // Ignore if user is already typing in an input
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  
  // Only intercept letter keys (A-Z)
  if (e.key.length === 1 && e.key.match(/[a-zA-Z]/)) {
    if (hostGuessInputContainer && hostGuessInput) {
      if (!hostGuessInputContainer.classList.contains('open')) {
        hostGuessInputContainer.classList.add('open');
      }
      hostGuessInput.focus();
      hostGuessInput.value += e.key;
      e.preventDefault();
    }
  }
});

// Host Music Control Logic
const hostMusicBtn = document.getElementById('hostMusicBtn');
const hostSkipBtn = document.getElementById('hostSkipBtn');
const hostMusicInputContainer = document.getElementById('hostMusicInputContainer');
const hostMusicInput = document.getElementById('hostMusicInput');

if (hostMusicBtn) {
  hostMusicBtn.addEventListener('click', (e) => {
    e.stopPropagation(); // prevent fullscreen trigger
    // Unlock audio context on music button tap (mobile user gesture)
    try {
      if (ytPlayer && ytPlayer.unMute) {
        ytPlayer.unMute();
        ytPlayer.setVolume(musicSettings.volume);
        ytPlayAttempts = 0;
      }
    } catch(eu) {}
    hostMusicInputContainer.classList.toggle('open');
    if (hostMusicInputContainer.classList.contains('open')) {
      hostMusicInput.focus();
    }
  });

  if (hostSkipBtn) {
    hostSkipBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (isMusicPlaying) {
        playNextMusic();
      }
    });
  }

  hostMusicInputContainer.addEventListener('click', (e) => e.stopPropagation());

  hostMusicInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const query = hostMusicInput.value.trim();
      if (query && localSocket) {
        // Pre-warm YouTube player within user gesture context (mobile requires this)
        if (ytPlayer && ytPlayer.unMute) {
          try {
            if (!isMusicPlaying) {
              ytPlayer.unMute();
              ytPlayer.setVolume(musicSettings.volume);
              ytPlayAttempts = 0;
              console.log('[Music] YouTube player pre-warmed via user gesture');
            }
          } catch(ew) {}
        }
        localSocket.emit('host-music-request', query.replace('!play ', ''));
        hostMusicInput.value = '';
        hostMusicInputContainer.classList.remove('open');
      }
    }
  });
}

// ─── Collapsible Host Toolbar Toggle Logic ───
window.toggleHostToolbar = function(e) {
  if (e) e.stopPropagation();
  const toolbar = document.getElementById('hostMusicControl');
  if (!toolbar) return;
  const isCollapsed = toolbar.classList.toggle('is-collapsed');
  try {
    localStorage.setItem('host_toolbar_collapsed', isCollapsed ? '1' : '0');
  } catch(err) {}
  updateHostToolbarToggleIcon(isCollapsed);
};

function updateHostToolbarToggleIcon(isCollapsed) {
  const icon = document.getElementById('hostToolbarToggleIcon');
  const btn = document.getElementById('hostToolbarToggleBtn');
  if (icon) {
    if (isCollapsed) {
      icon.className = 'fa-solid fa-chevron-left';
      if (btn) btn.title = 'Tampilkan Toolbar Host';
    } else {
      icon.className = 'fa-solid fa-chevron-right';
      if (btn) btn.title = 'Sembunyikan Toolbar Host';
    }
  }
}

// Initialize toolbar state from localStorage
(function initHostToolbarState() {
  try {
    const saved = localStorage.getItem('host_toolbar_collapsed');
    if (saved === '1') {
      const toolbar = document.getElementById('hostMusicControl');
      if (toolbar) {
        toolbar.classList.add('is-collapsed');
        updateHostToolbarToggleIcon(true);
      }
    }
  } catch(err) {}
})();

// ─── Custom Confirm Modal ───
function showCustomConfirm(message, onConfirm) {
  const overlay = document.getElementById('confirmModal');
  const messageEl = document.getElementById('confirmModalMessage');
  const yesBtn = document.getElementById('confirmModalYes');
  const noBtn = document.getElementById('confirmModalNo');
  
  if (!overlay || !messageEl || !yesBtn || !noBtn) return;
  
  // Close settings dropdown so it doesn't cover the modal
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  messageEl.textContent = message;
  overlay.style.display = 'flex';
  
  // Clone nodes to clean up any previous click listeners
  const newYes = yesBtn.cloneNode(true);
  const newNo = noBtn.cloneNode(true);
  yesBtn.parentNode.replaceChild(newYes, yesBtn);
  noBtn.parentNode.replaceChild(newNo, noBtn);
  
  newYes.addEventListener('click', (e) => {
    e.stopPropagation();
    overlay.style.display = 'none';
    if (typeof onConfirm === 'function') onConfirm();
  });
  
  newNo.addEventListener('click', (e) => {
    e.stopPropagation();
    overlay.style.display = 'none';
  });
}

// ─── Reset Leaderboard ───
window.resetDailyLeaderboard = function(e) {
  if (e) e.stopPropagation();
  showCustomConfirm("Reset HANYA poin Daily untuk mode ini? Tindakan ini tidak bisa dibatalkan.", () => {
    // Reset daily points, likes, shares, and gifts in memory
    for (const username in playerPoints) {
      playerPoints[username].sessionPts = 0;
    }
    playerLikes = {};
    playerShares = {};
    playerGifts = {};
    playerActivePresence = {};
    
    // Clear daily points, likes, shares, and gifts from localStorage
    const keysToRemove = [];
    const prefix = getPtsPrefix();
    const dailyPrefix = prefix + 'daily_';
    const likePrefix = 'pts_like_';
    const sharePrefix = 'pts_share_';
    const giftPrefix = 'pts_gift_';
    const activePrefix = 'pts_active_';
    const avatarPrefix = 'pts_avatar_';
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith(dailyPrefix) || key.startsWith(likePrefix) || key.startsWith(sharePrefix) || key.startsWith(giftPrefix) || key.startsWith(activePrefix) || key.startsWith(avatarPrefix))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));
    
    // Refresh UI
    renderLeaderboard();
    updateMarqueeUI(true);
    showToast("Leaderboard Daily dan statistik keaktifan telah di-reset!");
    
    // Close settings dropdown if open
    const dropdown = document.getElementById('settingsDropdown');
    if (dropdown) dropdown.classList.remove('show');
  });
};

window.resetLeaderboard = function(e) {
  if (e) e.stopPropagation();
  showCustomConfirm("Reset Poin Daily dan Weekly (Tebakan Game)? Tindakan ini tidak bisa dibatalkan.", () => {
    playerPoints = {};
    const keysToRemove = [];
    const prefix = getPtsPrefix();
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(prefix)) {
        if (key.includes('_like_') || key.includes('_share_') || key.includes('_gift_') || key.includes('_active_') || key.includes('_avatar_')) continue;
        if (prefix === 'pts_' && isOtherGameModeKey(key)) continue;
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));
    
    renderLeaderboard();
    showToast("Peringkat Game (Daily/Weekly) telah di-reset!");
    
    const dropdown = document.getElementById('settingsDropdown');
    if (dropdown) dropdown.classList.remove('show');
  });
};

window.resetTopSupporters = function(e) {
  if (e) e.stopPropagation();
  showCustomConfirm("Reset Statistik Top Supporters (Likes, Shares, Gifts, Active)? Tindakan ini tidak bisa dibatalkan.", () => {
    playerLikes = {};
    playerShares = {};
    playerGifts = {};
    playerActivePresence = {};
    
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.includes('_like_') || key.includes('_share_') || key.includes('_gift_') || key.includes('_active_') || key.includes('_avatar_'))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));
    
    updateMarqueeUI(true);
    showToast("Statistik Top Supporters telah di-reset!");
    
    const dropdown = document.getElementById('settingsDropdown');
    if (dropdown) dropdown.classList.remove('show');
  });
};

// ─── Export & Import Leaderboard Data ───
window.exportLeaderboardData = function(e) {
  if (e) e.stopPropagation();
  
  // Pastikan data pending di-flush ke storage sebelum ekspor
  if (typeof flushStorageSaves === 'function') flushStorageSaves();
  
  const exportPayload = {
    appName: "TikTok Wordle Live Game",
    version: "1.0",
    exportedAt: new Date().toISOString(),
    gameMode: currentGameMode,
    rawEntries: {},
    summary: {
      totalKeys: 0,
      totalPlayersRecorded: 0
    }
  };

  // Kumpulkan seluruh data pts_* dari localStorage (poin game, daily, weekly, supporter, avatar)
  const playersSet = new Set();
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('pts_')) {
      const val = localStorage.getItem(key);
      exportPayload.rawEntries[key] = val;
      exportPayload.summary.totalKeys++;
      
      const cleanName = key.replace(/^pts_(w500_|w600_|wfit_|colorfit_|wloop_|fill_|tango_|wgrid_|sqword_|wladder_|betweenle_|cascadle_|wanderwords_|wordcluster_|daily_|like_|share_|gift_|active_|avatar_)?/, '');
      if (cleanName) playersSet.add(cleanName);
    }
  }
  exportPayload.summary.totalPlayersRecorded = playersSet.size;

  if (exportPayload.summary.totalKeys === 0) {
    showToast("⚠️ Belum ada data leaderboard untuk diekspor!", 2500);
    return;
  }

  const jsonStr = JSON.stringify(exportPayload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const d = new Date();
  const dateStr = d.toISOString().slice(0, 10);
  const timeStr = d.toTimeString().slice(0, 5).replace(':', '-');
  const filename = `leaderboard_backup_${dateStr}_${timeStr}.json`;
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  showToast(`📤 Ekspor berhasil! (${exportPayload.summary.totalKeys} data tersimpan)`, 2500);
  
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('show');
};

window.handleLeaderboardFileImport = function(input) {
  if (!input || !input.files || input.files.length === 0) return;
  const file = input.files[0];
  const reader = new FileReader();
  
  reader.onload = function(e) {
    try {
      const content = JSON.parse(e.target.result);
      if (!content || typeof content !== 'object') {
        throw new Error('Format JSON tidak valid');
      }

      let entriesToImport = {};
      if (content.rawEntries && typeof content.rawEntries === 'object') {
        entriesToImport = content.rawEntries;
      } else {
        // Fallback untuk file JSON flat key-value
        for (const k in content) {
          if (k.startsWith('pts_')) {
            entriesToImport[k] = content[k];
          }
        }
      }

      const count = Object.keys(entriesToImport).length;
      if (count === 0) {
        showToast("⚠️ File JSON tidak berisi data leaderboard yang valid!", 3000);
        input.value = '';
        return;
      }

      showCustomConfirm(`Impor ${count} data leaderboard dari "${file.name}"? Data saat ini akan digabungkan/diperbarui.`, () => {
        for (const key in entriesToImport) {
          localStorage.setItem(key, entriesToImport[key]);
        }
        
        // Reset cache memori avatar dan refresh state
        if (typeof avatarMemoryCache === 'object') {
          for (const k in avatarMemoryCache) delete avatarMemoryCache[k];
        }
        initWeeklyLeaderboard();
        initTrackers();
        renderLeaderboard();
        updateMarqueeUI(true);
        
        showToast(`✅ Berhasil mengimpor ${count} data leaderboard!`, 3000);
        input.value = '';
        
        const dropdown = document.getElementById('settingsDropdown');
        if (dropdown) dropdown.classList.remove('show');
      });

    } catch (err) {
      console.error('Import error:', err);
      showToast("❌ Gagal membaca file JSON: " + err.message, 3000);
      input.value = '';
    }
  };
  
  reader.readAsText(file);
};

window.changeBackground = function() {
  const fileInput = document.getElementById('bgFileInput');
  if (fileInput && fileInput.files && fileInput.files.length > 0) {
    const file = fileInput.files[0];
    console.log("Memulai proses upload file background:", file.name, "Ukuran:", file.size);
    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.onload = function() {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1280;
        const MAX_HEIGHT = 720;
        let width = img.width;
        let height = img.height;
        
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        try {
          localStorage.setItem('custom_bg_url', dataUrl);
          localStorage.removeItem('custom_bg_color'); // Clear solid color if image is set
          const toggle = document.getElementById('dynamicBgToggle');
          if (toggle) toggle.checked = false;
          toggleDynamicBg(false);
          applyStaticBg();
          showToast("Background berhasil diubah!");
          fileInput.value = '';
          console.log("Background file lokal berhasil disimpan dan diterapkan!");
        } catch(err) {
          console.error("Gagal menyimpan gambar ke localStorage:", err);
          showToast("Error: Memori penuh atau file terlalu besar!", 4000);
        }
      };
      img.onerror = function(err) {
        console.error("Gagal memuat elemen gambar:", err);
        showToast("Error: File gambar tidak valid!", 3000);
      };
      img.src = e.target.result;
    };
    reader.onerror = function(err) {
      console.error("FileReader error:", err);
      showToast("Error membaca file!", 3000);
    };
    reader.readAsDataURL(file);
    return;
  }

  const url = document.getElementById('bgUrlInput').value.trim();
  if (url) {
    console.log("Terapkan custom background URL:", url);
    try {
      localStorage.setItem('custom_bg_url', url);
      localStorage.removeItem('custom_bg_color'); // Clear solid color if image URL is set
      const toggle = document.getElementById('dynamicBgToggle');
      if (toggle) toggle.checked = false;
      toggleDynamicBg(false);
      
      applyStaticBg();
      showToast("Background berhasil diubah!");
    } catch(err) {
      console.error("Gagal menyimpan URL ke localStorage:", err);
      showToast("Error: Memori penyimpanan penuh!", 4000);
    }
  } else {
    localStorage.removeItem('custom_bg_url');
    applyStaticBg();
    showToast("Background custom dihapus!");
  }
};

window.updateBgEffects = function() {
  const blurSlider = document.getElementById('bgBlurSlider');
  const dimSlider = document.getElementById('bgDimSlider');
  if (!blurSlider || !dimSlider) return;

  const blurVal = blurSlider.value;
  const dimVal = dimSlider.value;
  
  const blurLabel = document.getElementById('bgBlurValue');
  if (blurLabel) blurLabel.textContent = `${blurVal}px`;
  const dimLabel = document.getElementById('bgDimValue');
  if (dimLabel) dimLabel.textContent = `${dimVal}%`;

  localStorage.setItem('custom_bg_blur', blurVal);
  localStorage.setItem('custom_bg_dim', dimVal);
  
  if (typeof window.applyBgEffects === 'function') {
    window.applyBgEffects(blurVal, dimVal);
  }
};

window.resetBgEffects = function(e) {
  if (e) e.stopPropagation();
  const blurSlider = document.getElementById('bgBlurSlider');
  const dimSlider = document.getElementById('bgDimSlider');
  if (blurSlider) blurSlider.value = 12;
  if (dimSlider) dimSlider.value = 60;
  window.updateBgEffects();
  showToast('↺ Efek Blur (12px) & Kegelapan (60%) di-reset ke default!', 2000);
};

window.applyBgEffects = function(blurVal, dimVal) {
  const overlay = document.querySelector('.glass-overlay');
  if (overlay) {
    overlay.style.backdropFilter = `blur(${blurVal}px)`;
    overlay.style.webkitBackdropFilter = `blur(${blurVal}px)`;
    const op = dimVal / 100;
    overlay.style.background = `rgba(0, 0, 0, ${op})`;
  }
};

// --- Hapus background custom (gambar/URL/warna solid) ---
window.clearBackground = function() {
  localStorage.removeItem('custom_bg_url');
  localStorage.removeItem('custom_bg_color');

  // Reset URL input
  const urlInput = document.getElementById('bgUrlInput');
  if (urlInput) urlInput.value = '';
  const fileInput = document.getElementById('bgFileInput');
  if (fileInput) fileInput.value = '';

  // Reset RGB picker ke default
  const rSlider = document.getElementById('rgbR');
  const gSlider = document.getElementById('rgbG');
  const bSlider = document.getElementById('rgbB');
  if (rSlider) rSlider.value = 32;
  if (gSlider) gSlider.value = 33;
  if (bSlider) bSlider.value = 36;
  updateRgbPreview(32, 33, 36);

  applyStaticBg();
  showToast('🗑️ Background dihapus — kembali ke warna default', 2000);
};

// --- RGB helper: update preview swatch + hex code ---
function updateRgbPreview(r, g, b) {
  const hex = '#' + [r, g, b].map(v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
  const preview = document.getElementById('bgColorPreview');
  const hexInput = document.getElementById('bgHexInput');
  const rVal = document.getElementById('rgbRVal');
  const gVal = document.getElementById('rgbGVal');
  const bVal = document.getElementById('rgbBVal');
  if (preview) preview.style.background = hex;
  if (hexInput) hexInput.value = hex;
  if (rVal) rVal.textContent = r;
  if (gVal) gVal.textContent = g;
  if (bVal) bVal.textContent = b;
}
window.updateRgbPreview = updateRgbPreview;

// --- Fired when RGB sliders move ---
window.onRgbSliderChange = function() {
  const r = parseInt(document.getElementById('rgbR').value);
  const g = parseInt(document.getElementById('rgbG').value);
  const b = parseInt(document.getElementById('rgbB').value);
  updateRgbPreview(r, g, b);
};

// --- Sync sliders from hex code typed in input ---
window.syncRgbFromHex = function(rawHex) {
  let hex = rawHex.trim();
  if (!hex.startsWith('#')) hex = '#' + hex;
  // Only proceed if it's a valid 6-digit hex
  if (!/^#[0-9A-Fa-f]{6}$/.test(hex)) {
    // Update just the preview if partial (at least 4 chars)
    const preview = document.getElementById('bgColorPreview');
    if (preview && /^#[0-9A-Fa-f]{3,6}$/.test(hex)) {
      preview.style.background = hex;
    }
    return;
  }
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const rSlider = document.getElementById('rgbR');
  const gSlider = document.getElementById('rgbG');
  const bSlider = document.getElementById('rgbB');
  if (rSlider) rSlider.value = r;
  if (gSlider) gSlider.value = g;
  if (bSlider) bSlider.value = b;
  const rVal = document.getElementById('rgbRVal');
  const gVal = document.getElementById('rgbGVal');
  const bVal = document.getElementById('rgbBVal');
  if (rVal) rVal.textContent = r;
  if (gVal) gVal.textContent = g;
  if (bVal) bVal.textContent = b;
  const preview = document.getElementById('bgColorPreview');
  if (preview) preview.style.background = hex;
};

// --- Terapkan warna solid sebagai background ---
window.applyRgbBackground = function() {
  const r = parseInt(document.getElementById('rgbR').value);
  const g = parseInt(document.getElementById('rgbG').value);
  const b = parseInt(document.getElementById('rgbB').value);
  const hex = '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');

  // Clear image background, save solid color
  localStorage.removeItem('custom_bg_url');
  localStorage.setItem('custom_bg_color', hex);

  // Clear URL/file input so the image section is visually reset
  const urlInput = document.getElementById('bgUrlInput');
  if (urlInput) urlInput.value = '';
  const fileInput = document.getElementById('bgFileInput');
  if (fileInput) fileInput.value = '';

  // Switch to static mode and apply
  const toggle = document.getElementById('dynamicBgToggle');
  if (toggle) toggle.checked = false;
  toggleDynamicBg(false);
  applyStaticBg();

  showToast(`🎨 Background warna solid diterapkan: ${hex}`, 2000);
};

document.addEventListener('DOMContentLoaded', () => {
  const badWordsToggle = document.getElementById('badWordsToggle');
  if (badWordsToggle) badWordsToggle.checked = isBadWordsFilterOn;

  const wgTakeoverToggle = document.getElementById('wgTakeoverToggle');
  if (wgTakeoverToggle) wgTakeoverToggle.checked = isWgTakeoverMode;

  updateWgDifficultyUI();

  const wgHintDelayInput = document.getElementById('wgHintDelayInput');
  if (wgHintDelayInput) {
    wgHintDelayInput.value = wgHintDelay;
    const label = document.getElementById('wgHintDelayLabel');
    if (label) label.textContent = `${wgHintDelay} Detik`;
  }

  const noYellowToggle = document.getElementById('noYellowToggle');
  if (noYellowToggle) noYellowToggle.checked = isNoYellowMode;

  const fogToggle = document.getElementById('followerOnlyGuessToggle');
  if (fogToggle) fogToggle.checked = isFollowerOnlyGuess;

  const fomGroupToggle = document.getElementById('musicFollowerOnlyGroupToggle');
  if (fomGroupToggle) fomGroupToggle.checked = !!musicSettings.followerOnly;

  const autoStarterWinnerToggle = document.getElementById('autoStarterWinnerToggle');
  if (autoStarterWinnerToggle) autoStarterWinnerToggle.checked = isAutoStarterWinnerNickname;

  const autoStarterToggle = document.getElementById('autoStarterToggle');
  if (autoStarterToggle) autoStarterToggle.checked = isAutoStarterPreviousTarget;

  const showHintsDiscoveredToggle = document.getElementById('showHintsDiscoveredToggle');
  if (showHintsDiscoveredToggle) showHintsDiscoveredToggle.checked = isShowHintsDiscovered;

  const marqueeToggle = document.getElementById('marqueeToggle');
  if (marqueeToggle) marqueeToggle.checked = isMarqueeEnabled;

  const lowPowerModeToggle = document.getElementById('lowPowerModeToggle');
  if (lowPowerModeToggle) lowPowerModeToggle.checked = isLowPowerMode;
  if (isLowPowerMode) {
    document.body.classList.add('low-power-mode');
  }

  const heartFlurryToggle = document.getElementById('heartFlurryToggle');
  if (heartFlurryToggle) heartFlurryToggle.checked = isHeartFlurryEnabled;

  const gameAnimationsToggle = document.getElementById('gameAnimationsToggle');
  if (gameAnimationsToggle) gameAnimationsToggle.checked = isGameAnimationsEnabled;
  if (!isGameAnimationsEnabled) {
    document.body.classList.add('no-animations');
  }

  const flipSpeedSelect = document.getElementById('flipSpeedSelect');
  if (flipSpeedSelect) flipSpeedSelect.value = currentFlipSpeed;
  const flipSpeedControlRow = document.getElementById('flipSpeedControlRow');
  if (flipSpeedControlRow) flipSpeedControlRow.style.opacity = isGameAnimationsEnabled ? '1' : '0.5';

  // Initialize length checkboxes
  try {
    const savedLengths = JSON.parse(localStorage.getItem('allowed_lengths') || '[5,6,7,8]');
    if (document.getElementById('len3Toggle')) document.getElementById('len3Toggle').checked = savedLengths.includes(3);
    if (document.getElementById('len4Toggle')) document.getElementById('len4Toggle').checked = savedLengths.includes(4);
    if (document.getElementById('len5Toggle')) document.getElementById('len5Toggle').checked = savedLengths.includes(5);
    if (document.getElementById('len6Toggle')) document.getElementById('len6Toggle').checked = savedLengths.includes(6);
    if (document.getElementById('len7Toggle')) document.getElementById('len7Toggle').checked = savedLengths.includes(7);
    if (document.getElementById('len8Toggle')) document.getElementById('len8Toggle').checked = savedLengths.includes(8);
  } catch(e) {}
  if (typeof updateBoardScaleUI === 'function') updateBoardScaleUI();

  // Initialize Background Blur & Dim sliders
  try {
    const savedBlur = localStorage.getItem('custom_bg_blur') || 12;
    const savedDim = localStorage.getItem('custom_bg_dim') || 60;
    const blurSlider = document.getElementById('bgBlurSlider');
    const dimSlider = document.getElementById('bgDimSlider');
    if (blurSlider) blurSlider.value = savedBlur;
    if (dimSlider) dimSlider.value = savedDim;
    const blurLabel = document.getElementById('bgBlurValue');
    if (blurLabel) blurLabel.textContent = `${savedBlur}px`;
    const dimLabel = document.getElementById('bgDimValue');
    if (dimLabel) dimLabel.textContent = `${savedDim}%`;
    if (typeof window.applyBgEffects === 'function') {
      window.applyBgEffects(savedBlur, savedDim);
    }
  } catch(e) {}

  // Synchronize active game card on load
  try {
    const gameCards = document.querySelectorAll('.game-card');
    gameCards.forEach(card => {
      if (card.getAttribute('data-value') === currentGameMode) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });
  } catch(e) {}

  updateMarqueeUI(true);

  if (typeof window.changeMusicPlayerStyle === 'function') {
    window.changeMusicPlayerStyle(musicSettings.playerStyle || 'vinyl');
  }

  if (typeof initDraggableMusicWidget === 'function') {
    initDraggableMusicWidget();
  }
});

setTimeout(() => {
  if (typeof initDraggableMusicWidget === 'function') {
    initDraggableMusicWidget();
  }
}, 200);

window.updateAllowedLengths = function() {
  const is3 = document.getElementById('len3Toggle') ? document.getElementById('len3Toggle').checked : false;
  const is4 = document.getElementById('len4Toggle') ? document.getElementById('len4Toggle').checked : false;
  const is5 = document.getElementById('len5Toggle') ? document.getElementById('len5Toggle').checked : true;
  const is6 = document.getElementById('len6Toggle') ? document.getElementById('len6Toggle').checked : true;
  const is7 = document.getElementById('len7Toggle') ? document.getElementById('len7Toggle').checked : true;
  const is8 = document.getElementById('len8Toggle') ? document.getElementById('len8Toggle').checked : true;
  
  let lengths = [];
  if (is3) lengths.push(3);
  if (is4) lengths.push(4);
  if (is5) lengths.push(5);
  if (is6) lengths.push(6);
  if (is7) lengths.push(7);
  if (is8) lengths.push(8);
  
  // Prevent all unchecked (default to 5)
  if (lengths.length === 0) {
    lengths = [5];
    if (document.getElementById('len5Toggle')) document.getElementById('len5Toggle').checked = true;
  }
  
  localStorage.setItem('allowed_lengths', JSON.stringify(lengths));
};

window.applyAllowedLengths = function(e) {
  if (e) e.stopPropagation();
  updateAllowedLengths();

  // Sync allowedLengths ke server agar server tidak kirim balik nilai lama yang akan menimpa localStorage
  try {
    const newLengths = JSON.parse(localStorage.getItem('allowed_lengths') || '[5]');
    if (typeof localSocket !== 'undefined' && localSocket && localSocket.connected) {
      localSocket.emit('update-game-settings', { allowedLengths: newLengths });
    }
  } catch(e) {}

  // Reset state ronde sebelumnya agar startNewRound tidak terkunci di panjang kata lama.
  // PENTING: currentWord juga harus di-null-kan karena baris pertama startNewRound()
  // selalu mengisi ulang lastRoundTargetWord dari currentWord, sehingga cabang
  // (isAutoStarterWinnerNickname && lastRoundTargetWord) akan mengabaikan allowed_lengths.
  lastRoundTargetWord = null;
  lastRoundWinner = null;
  currentWord = null;
  startNewRound();
  showToast("⚡ Panjang kata diterapkan & ronde baru dimulai!");
};

// Word500/WordFit manual hint marking
document.addEventListener('click', (e) => {
  if (currentGameMode !== 'word500' && currentGameMode !== 'wordfit') return;
  const tile = e.target.closest('.tile');
  if (!tile || !tile.textContent.trim()) return;
  
  // Only allow clicking tiles inside board or bestGuessBoard
  if (!tile.closest('#board') && !tile.closest('#bestGuessBoard')) return;
  
  if (tile.classList.contains('correct')) {
    tile.classList.remove('correct');
    tile.classList.add('present');
  } else if (tile.classList.contains('present')) {
    tile.classList.remove('present');
    tile.classList.add('absent');
  } else if (tile.classList.contains('absent')) {
    tile.classList.remove('absent');
    tile.classList.add('blind');
  } else {
    tile.classList.remove('blind', 'present', 'absent');
    tile.classList.add('correct');
  }
});

// Mastermind Style Initialization
window.w500UseMastermind = true;

window.updateMastermindNames = function() {
  const isMM = window.w500UseMastermind;
  const nameW500 = document.getElementById('cardNameW500');
  const descW500 = document.getElementById('cardDescW500');
  const iconW500 = document.getElementById('cardIconW500');

  if (nameW500) nameW500.textContent = isMM ? 'WORD PEGS' : 'WORD500';
  if (descW500) descW500.textContent = isMM ? 'Clue balok warna Mastermind (4-6 huruf): berapa huruf hijau & kuning tanpa posisi pasti. Unlimited!' : 'Hanya dapat angka (4-6 huruf): berapa huruf benar & hampir benar. Unlimited!';
  const w500PegsSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="12" r="3"></circle><circle cx="12" cy="12" r="3"></circle><circle cx="18" cy="12" r="3"></circle></svg>';
  const w500LockSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>';

  if (iconW500) iconW500.innerHTML = isMM ? w500PegsSvg : w500LockSvg;
};

document.addEventListener('DOMContentLoaded', () => {
  try {
    const savedStyle = localStorage.getItem('w500_mastermind');
    if (savedStyle !== null) {
      window.w500UseMastermind = savedStyle === 'true';
    }
    const toggle = document.getElementById('w500StyleToggle');
    if (toggle) toggle.checked = window.w500UseMastermind;
    if (window.updateMastermindNames) window.updateMastermindNames();

    const savedAutoJoin = localStorage.getItem('auto_guess_on_join');
    window.autoGuessOnJoin = savedAutoJoin === 'true';
    const joinToggle = document.getElementById('autoGuessJoinToggle');
    if (joinToggle) joinToggle.checked = window.autoGuessOnJoin;
  } catch(e) {}
});

window.toggleW500Style = function(checked) {
  window.w500UseMastermind = checked;
  localStorage.setItem('w500_mastermind', checked);
  if (window.updateMastermindNames) window.updateMastermindNames();
  if (typeof applyGameModeUI === 'function') applyGameModeUI();
  updateBestGuessUI();
  if (currentGameMode === 'word500' || currentGameMode === 'wordfit') {
    if (currentGameMode === 'wordfit') renderWordFitBoard();
    else renderWord500Board();
  }
};

window.toggleAutoGuessJoin = function(checked) {
  window.autoGuessOnJoin = checked;
  localStorage.setItem('auto_guess_on_join', checked);
};

// ─── Music Settings Functions ───
window.openMusicSettings = function(e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  const reqToggle = document.getElementById('musicRequestsEnabled');
  if (reqToggle) reqToggle.checked = musicSettings.requestsEnabled !== false;

  const followToggle = document.getElementById('musicFollowerOnlyToggle');
  if (followToggle) followToggle.checked = !!musicSettings.followerOnly;

  document.getElementById('musicMaxGlobal').value = musicSettings.maxGlobal;
  document.getElementById('musicMaxUser').value = musicSettings.maxUser;
  document.getElementById('musicMaxDuration').value = musicSettings.maxDuration;
  const cdInput = document.getElementById('musicCooldownSeconds');
  if (cdInput) cdInput.value = musicSettings.cooldownSeconds !== undefined ? musicSettings.cooldownSeconds : 60;
  document.getElementById('musicBannedKeywords').value = musicSettings.bannedKeywords.join(', ');
  
  document.getElementById('musicVolumeSlider').value = musicSettings.volume;
  document.getElementById('musicVolumeLabel').textContent = `${musicSettings.volume}%`;

  const modalStyleSelect = document.getElementById('modalMusicPlayerStyleSelect');
  if (modalStyleSelect) modalStyleSelect.value = musicSettings.playerStyle || 'vinyl';

  const ambianceToggle = document.getElementById('musicRadioAmbianceToggle');
  const ambianceSlider = document.getElementById('musicRadioAmbianceSlider');
  const ambianceLabel = document.getElementById('musicRadioAmbianceLabel');
  const ambianceContainer = document.getElementById('musicRadioAmbianceSliderContainer');

  const isAmbianceOn = musicSettings.radioAmbiance === true;
  if (ambianceToggle) ambianceToggle.checked = isAmbianceOn;
  if (ambianceSlider) ambianceSlider.value = musicSettings.radioAmbianceVolume || 20;
  if (ambianceLabel) ambianceLabel.textContent = `${musicSettings.radioAmbianceVolume || 20}%`;
  if (ambianceContainer) ambianceContainer.style.display = isAmbianceOn ? 'block' : 'none';

  if (typeof updateLyricsOffsetUI === 'function') {
    updateLyricsOffsetUI();
  }

  const randomGenreSelect = document.getElementById('modalMusicRandomGenreSelect');
  if (randomGenreSelect) randomGenreSelect.value = musicSettings.randomGenre || 'milenial';

  document.getElementById('musicSettingsModal').style.display = 'flex';
};

window.updateMusicVolumeUI = function(val) {
  document.getElementById('musicVolumeLabel').textContent = `${val}%`;
  if (ytPlayer && ytPlayer.setVolume) {
    ytPlayer.setVolume(val);
  }
};

window.saveMusicSettings = function() {
  const reqToggle = document.getElementById('musicRequestsEnabled');
  musicSettings.requestsEnabled = reqToggle ? reqToggle.checked : true;

  const followToggle = document.getElementById('musicFollowerOnlyToggle');
  musicSettings.followerOnly = followToggle ? followToggle.checked : false;
  const followGroupToggle = document.getElementById('musicFollowerOnlyGroupToggle');
  if (followGroupToggle) followGroupToggle.checked = musicSettings.followerOnly;
  if (localSocket) {
    localSocket.emit('update-game-settings', { followerOnlyMusic: musicSettings.followerOnly });
  }

  musicSettings.maxGlobal = parseInt(document.getElementById('musicMaxGlobal').value) || 20;
  musicSettings.maxUser = parseInt(document.getElementById('musicMaxUser').value) || 2;
  musicSettings.maxDuration = parseInt(document.getElementById('musicMaxDuration').value) || 6;
  const cdInputVal = document.getElementById('musicCooldownSeconds');
  musicSettings.cooldownSeconds = cdInputVal ? (parseInt(cdInputVal.value) ?? 60) : 60;
  musicSettings.volume = parseInt(document.getElementById('musicVolumeSlider').value) || 50;

  const randomGenreSelect = document.getElementById('modalMusicRandomGenreSelect');
  if (randomGenreSelect) musicSettings.randomGenre = randomGenreSelect.value;

  const ambianceToggle = document.getElementById('musicRadioAmbianceToggle');
  const ambianceSlider = document.getElementById('musicRadioAmbianceSlider');
  musicSettings.radioAmbiance = ambianceToggle ? ambianceToggle.checked : false;
  musicSettings.radioAmbianceVolume = ambianceSlider ? (parseInt(ambianceSlider.value) || 20) : 20;
  if (window.sounds) {
    window.sounds.setRadioAmbiance(musicSettings.radioAmbiance, musicSettings.radioAmbianceVolume);
    if (isMusicPlaying && musicSettings.radioAmbiance) {
      window.sounds.startRadioAmbiance();
    } else {
      window.sounds.stopRadioAmbiance();
    }
  }
  
  const keywords = document.getElementById('musicBannedKeywords').value;
  musicSettings.bannedKeywords = keywords.split(',').map(k => k.trim().toLowerCase()).filter(k => k);
  
  localStorage.setItem('music_settings', JSON.stringify(musicSettings));
  if (localSocket) {
    localSocket.emit('update-game-settings', { 
      followerOnlyMusic: musicSettings.followerOnly,
      musicCooldown: musicSettings.cooldownSeconds
    });
  }
  const modalStyleSelect = document.getElementById('modalMusicPlayerStyleSelect');
  if (modalStyleSelect && modalStyleSelect.value) {
    changeMusicPlayerStyle(modalStyleSelect.value);
  }

  document.getElementById('musicSettingsModal').style.display = 'none';
  
  if (ytPlayer && ytPlayer.setVolume) {
    ytPlayer.setVolume(musicSettings.volume);
  }
  
  // Re-start instruction rotation so the change in !play instruction is immediately reflected
  startInstructionRotation();
  
  showToast("✅ Pengaturan Musik disimpan!");
};

// ─── Social Audio Settings Functions ───
let socialAudioSettings = {
  enabled: true,
  duckingEnabled: true,
  volume: 80,
  followSound: "https://www.myinstants.com/media/sounds/anime-wow.mp3",
  defaultGiftSound: "https://www.myinstants.com/media/sounds/coin-sound-effect.mp3",
  customGifts: [
    { giftName: "mawar", soundUrl: "https://www.myinstants.com/media/sounds/uwu.mp3" },
    { giftName: "universe", soundUrl: "https://www.myinstants.com/media/sounds/tuturu.mp3" }
  ]
};
try {
  const savedSocialAudio = localStorage.getItem('social_audio_settings');
  if (savedSocialAudio) {
    socialAudioSettings = JSON.parse(savedSocialAudio);
  }
} catch(e) {}

window.openSocialAudioSettings = function(e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  document.getElementById('socialAudioEnabled').checked = socialAudioSettings.enabled !== false;
  const duckingEl = document.getElementById('socialAudioDuckingEnabled');
  if (duckingEl) duckingEl.checked = socialAudioSettings.duckingEnabled !== false;
  document.getElementById('socialAudioVolumeSlider').value = socialAudioSettings.volume;
  document.getElementById('socialAudioVolumeLabel').textContent = `${socialAudioSettings.volume}%`;
  document.getElementById('socialAudioFollowUrl').value = socialAudioSettings.followSound || '';
  document.getElementById('socialAudioDefaultGiftUrl').value = socialAudioSettings.defaultGiftSound || '';
  
  // Format custom gifts mapping text: "Rose = URL"
  const mappingLines = (socialAudioSettings.customGifts || []).map(item => {
    return `${item.giftName} = ${item.soundUrl}`;
  });
  document.getElementById('socialAudioCustomGifts').value = mappingLines.join('\n');
  
  document.getElementById('socialAudioSettingsModal').style.display = 'flex';
};

window.saveSocialAudioSettings = function() {
  socialAudioSettings.enabled = document.getElementById('socialAudioEnabled').checked;
  const duckingEl = document.getElementById('socialAudioDuckingEnabled');
  socialAudioSettings.duckingEnabled = duckingEl ? duckingEl.checked : true;
  socialAudioSettings.volume = parseInt(document.getElementById('socialAudioVolumeSlider').value) || 80;
  socialAudioSettings.followSound = document.getElementById('socialAudioFollowUrl').value.trim();
  socialAudioSettings.defaultGiftSound = document.getElementById('socialAudioDefaultGiftUrl').value.trim();
  
  const customGiftsText = document.getElementById('socialAudioCustomGifts').value;
  const lines = customGiftsText.split('\n');
  const customGifts = [];
  lines.forEach(line => {
    const parts = line.split('=');
    if (parts.length === 2) {
      const name = parts[0].trim().toLowerCase();
      const url = parts[1].trim();
      if (name && url) {
        customGifts.push({ giftName: name, soundUrl: url });
      }
    }
  });
  socialAudioSettings.customGifts = customGifts;
  
  localStorage.setItem('social_audio_settings', JSON.stringify(socialAudioSettings));
  document.getElementById('socialAudioSettingsModal').style.display = 'none';
  
  showToast("✅ Pengaturan Sound Alert disimpan!");
};

function playSocialAlertAudio(soundUrl) {
  if (!socialAudioSettings.enabled || !soundUrl) return;
  try {
    const audio = new Audio(soundUrl);
    audio.volume = (socialAudioSettings.volume / 100);
    
    // Duck music if enabled
    const shouldDuck = socialAudioSettings.duckingEnabled !== false;
    if (shouldDuck) {
      duckMusicVolume();
    }
    audio.play().catch(e => {
      console.log('[SocialAudio] Play blocked', e);
      if (shouldDuck) restoreMusicVolume();
    });
    
    audio.onended = () => {
      if (shouldDuck) restoreMusicVolume();
    };
    audio.onerror = () => {
      if (shouldDuck) restoreMusicVolume();
    };
  } catch (err) {
    console.warn('[SocialAudio] Play error', err);
    if (socialAudioSettings.duckingEnabled !== false) restoreMusicVolume();
  }
}

window.previewAlertSound = function(url) {
  if (!url) {
    showToast("⚠️ Masukkan URL sound alert terlebih dahulu!");
    return;
  }
  
  try {
    const vol = parseInt(document.getElementById('socialAudioVolumeSlider').value) || 80;
    const audio = new Audio(url);
    audio.volume = vol / 100;
    
    const shouldDuck = socialAudioSettings.duckingEnabled !== false;
    if (shouldDuck) duckMusicVolume();
    audio.play().catch(e => {
      showToast("🚫 Gagal memutar suara! Periksa kembali URL.");
      if (shouldDuck) restoreMusicVolume();
    });
    
    audio.onended = () => {
      if (shouldDuck) restoreMusicVolume();
    };
    audio.onerror = () => {
      showToast("🚫 Gagal memutar suara! Format URL salah atau diblokir.");
      if (shouldDuck) restoreMusicVolume();
    };
  } catch (err) {
    showToast("🚫 Gagal memutar file audio!");
    if (socialAudioSettings.duckingEnabled !== false) restoreMusicVolume();
  }
};

window.testCustomGiftSound = function() {
  const giftNameInput = document.getElementById('socialAudioTestGiftName');
  if (!giftNameInput) return;
  
  const testName = giftNameInput.value.trim().toLowerCase();
  if (!testName) {
    showToast("⚠️ Ketik nama gift yang ingin ditest!");
    return;
  }
  
  const customGiftsText = document.getElementById('socialAudioCustomGifts').value;
  const lines = customGiftsText.split('\n');
  let matchedUrl = "";
  
  lines.forEach(line => {
    const parts = line.split('=');
    if (parts.length === 2) {
      const name = parts[0].trim().toLowerCase();
      const url = parts[1].trim();
      if (name === testName) {
        matchedUrl = url;
      }
    }
  });
  
  if (matchedUrl) {
    showToast(`🔊 Memutar suara kustom untuk gift "${testName}"...`);
    previewAlertSound(matchedUrl);
  } else {
    const defaultUrl = document.getElementById('socialAudioDefaultGiftUrl').value.trim();
    showToast(`🔊 Gift "${testName}" tidak terdaftar. Memutar suara umum...`);
    previewAlertSound(defaultUrl);
  }
};

window.openCustomSFXSettings = function(e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  document.getElementById('customSfxEnabled').checked = customSfxSettings.enabled !== false;
  document.getElementById('customSfxVolumeSlider').value = customSfxSettings.volume;
  document.getElementById('customSfxVolumeLabel').textContent = `${customSfxSettings.volume}%`;
  
  document.getElementById('customSfxStartUrl').value = customSfxSettings.start || '';
  document.getElementById('customSfxWinUrl').value = customSfxSettings.win || '';
  document.getElementById('customSfxCloseUrl').value = customSfxSettings.close || '';
  document.getElementById('customSfxCorrectUrl').value = customSfxSettings.correct || '';
  document.getElementById('customSfxInteractionUrl').value = customSfxSettings.interaction || '';
  document.getElementById('customSfxClickUrl').value = customSfxSettings.click || '';
  document.getElementById('customSfxInvalidUrl').value = customSfxSettings.invalid || '';
  
  document.getElementById('customSfxSettingsModal').style.display = 'flex';
};

window.saveCustomSFXSettings = function() {
  customSfxSettings.enabled = document.getElementById('customSfxEnabled').checked;
  customSfxSettings.volume = parseInt(document.getElementById('customSfxVolumeSlider').value) || 80;
  
  customSfxSettings.start = document.getElementById('customSfxStartUrl').value.trim();
  customSfxSettings.win = document.getElementById('customSfxWinUrl').value.trim();
  customSfxSettings.close = document.getElementById('customSfxCloseUrl').value.trim();
  customSfxSettings.correct = document.getElementById('customSfxCorrectUrl').value.trim();
  customSfxSettings.interaction = document.getElementById('customSfxInteractionUrl').value.trim();
  customSfxSettings.click = document.getElementById('customSfxClickUrl').value.trim();
  customSfxSettings.invalid = document.getElementById('customSfxInvalidUrl').value.trim();
  
  localStorage.setItem('custom_sfx_settings', JSON.stringify(customSfxSettings));
  document.getElementById('customSfxSettingsModal').style.display = 'none';
  
  showToast("✅ Pengaturan SFX Kustom disimpan!");
};

window.previewCustomSfxSound = function(type) {
  const inputEl = document.getElementById(`customSfx${type.charAt(0).toUpperCase() + type.slice(1)}Url`);
  if (!inputEl) return;
  const url = inputEl.value.trim();
  if (!url) {
    showToast(`⚠️ Masukkan URL audio untuk event ${type} terlebih dahulu!`);
    return;
  }
  
  try {
    const vol = parseInt(document.getElementById('customSfxVolumeSlider').value) || 80;
    const audio = new Audio(url);
    audio.volume = vol / 100;
    
    duckMusicVolume();
    audio.play().catch(e => {
      showToast("🚫 Gagal memutar suara! Periksa kembali URL.");
      restoreMusicVolume();
    });
    
    audio.onended = () => {
      restoreMusicVolume();
    };
    audio.onerror = () => {
      showToast("🚫 Gagal memutar suara! Format URL salah atau diblokir.");
      restoreMusicVolume();
    };
  } catch (err) {
    showToast("🚫 Gagal memutar file audio!");
    restoreMusicVolume();
  }
};

window.handleSfxFileUpload = function(inputEl, type) {
  const file = inputEl.files[0];
  if (!file) return;
  
  // Cek ukuran file (rekomendasi maks 500KB agar muat di localStorage)
  if (file.size > 500 * 1024) {
    showToast("⚠️ Ukuran file terlalu besar! Gunakan file di bawah 500KB agar tersimpan dengan aman.");
    inputEl.value = "";
    return;
  }
  
  const reader = new FileReader();
  reader.onload = function(e) {
    const dataUrl = e.target.result;
    const urlInput = document.getElementById(`customSfx${type.charAt(0).toUpperCase() + type.slice(1)}Url`);
    if (urlInput) {
      urlInput.value = dataUrl;
      showToast(`✅ File audio untuk ${type} berhasil dimuat! Klik Simpan untuk menyimpan.`);
    }
    inputEl.value = ""; // Reset input file agar bisa mendeteksi file yang sama jika di-upload ulang
  };
  reader.onerror = function() {
    showToast("🚫 Gagal membaca file audio!");
    inputEl.value = "";
  };
  reader.readAsDataURL(file);
};

// ─── TTS Settings Functions ───
let ttsSettings = {
  enabled: false,
  followerOnly: false,
  readNickname: true,
  mode: 'all',
  voiceURI: '',
  volume: 100
};
try {
  const savedTTS = localStorage.getItem('tts_settings');
  if (savedTTS) {
    ttsSettings = JSON.parse(savedTTS);
    if (ttsSettings.volume === undefined) ttsSettings.volume = 100;
    if (ttsSettings.readNickname === undefined) ttsSettings.readNickname = true;
  }
} catch(e) {}

let availableVoices = [];
function loadTTSVoices() {
  availableVoices = window.speechSynthesis.getVoices();
  const select = document.getElementById('ttsVoiceSelect');
  if (select) {
    select.innerHTML = '<option value="">Default Browser Voice</option>';
    availableVoices.forEach(voice => {
      const option = document.createElement('option');
      option.value = voice.voiceURI;
      option.textContent = `${voice.name} (${voice.lang})`;
      if (voice.voiceURI === ttsSettings.voiceURI) option.selected = true;
      select.appendChild(option);
    });
  }
}
if (window.speechSynthesis) {
  window.speechSynthesis.onvoiceschanged = loadTTSVoices;
  setTimeout(loadTTSVoices, 500);
}

window.openTTSSettings = function(e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('settingsDropdown');
  if (dropdown) dropdown.classList.remove('open');
  
  loadTTSVoices(); // Reload voices just in case
  
  document.getElementById('ttsEnabledToggle').checked = ttsSettings.enabled;
  document.getElementById('ttsFollowerOnlyToggle').checked = ttsSettings.followerOnly;
  
  if (document.getElementById('ttsReadNicknameToggle')) {
    document.getElementById('ttsReadNicknameToggle').checked = ttsSettings.readNickname;
  }
  
  document.getElementById('ttsModeSelect').value = ttsSettings.mode;
  document.getElementById('ttsVoiceSelect').value = ttsSettings.voiceURI;
  
  document.getElementById('ttsVolumeSlider').value = ttsSettings.volume;
  document.getElementById('ttsVolumeLabel').textContent = `${ttsSettings.volume}%`;
  
  document.getElementById('hostAudioEnabledToggle').checked = hostAudioSettings.enabled;
  document.getElementById('hostAudioVolumeSlider').value = hostAudioSettings.volume;
  document.getElementById('hostAudioVolumeLabel').textContent = `${hostAudioSettings.volume}%`;
  
  document.getElementById('ttsSettingsModal').style.display = 'flex';
};

window.updateTTSVolumeUI = function(val) {
  document.getElementById('ttsVolumeLabel').textContent = `${val}%`;
  // We can temporarily store the active volume for testTTS
  window._tempTTSVolume = parseInt(val) || 100;
};

// Original save function handled directly, hook handles host audio
const originalSaveTTS2 = window.saveTTSSettings;
window.saveTTSSettings = function() {
  ttsSettings.enabled = document.getElementById('ttsEnabledToggle').checked;
  ttsSettings.followerOnly = document.getElementById('ttsFollowerOnlyToggle').checked;
  if (document.getElementById('ttsReadNicknameToggle')) {
    ttsSettings.readNickname = document.getElementById('ttsReadNicknameToggle').checked;
  }
  ttsSettings.mode = document.getElementById('ttsModeSelect').value;
  ttsSettings.voiceURI = document.getElementById('ttsVoiceSelect').value;
  ttsSettings.volume = parseInt(document.getElementById('ttsVolumeSlider').value) || 100;
  
  localStorage.setItem('tts_settings', JSON.stringify(ttsSettings));
  document.getElementById('ttsSettingsModal').style.display = 'none';
  window._tempTTSVolume = null;
  
  // Also save host audio (from hook)
  hostAudioSettings.enabled = document.getElementById('hostAudioEnabledToggle').checked;
  hostAudioSettings.volume = parseInt(document.getElementById('hostAudioVolumeSlider').value) || 100;
  localStorage.setItem('host_audio_settings', JSON.stringify(hostAudioSettings));
  window._tempHostAudioVolume = null;
  
  showToast("✅ Pengaturan Suara disimpan!");
};

window.testTTS = function() {
  if (!window.speechSynthesis) return;
  const voiceURI = document.getElementById('ttsVoiceSelect').value;
  const utterance = new SpeechSynthesisUtterance("Halo, ini adalah tes pembaca suara dari TikTok Wordle!");
  
  const vol = (window._tempTTSVolume !== undefined && window._tempTTSVolume !== null) ? window._tempTTSVolume : ttsSettings.volume;
  utterance.volume = vol / 100;
  
  if (voiceURI && availableVoices.length > 0) {
    const selectedVoice = availableVoices.find(v => v.voiceURI === voiceURI);
    if (selectedVoice) utterance.voice = selectedVoice;
  }
  
  // Duck musik saat test TTS
  utterance.onstart = function() { duckMusicVolume(); };
  utterance.onend = function() { restoreMusicVolume(); };
  utterance.onerror = function() { restoreMusicVolume(); };
  
  window.speechSynthesis.cancel(); // Stop any currently playing speech
  window.speechSynthesis.speak(utterance);
};

function readTTS(nickname, comment, followRole, isFollower) {
  if (!ttsSettings.enabled || !window.speechSynthesis) return;
  
  const nickLower = (nickname || '').toLowerCase();
  const isCached = knownFollowers.has(nickLower);

  if (ttsSettings.followerOnly) {
    // Check if the user is a follower (followRole 1 or 2, or isFollower boolean, or cached)
    if (followRole !== 1 && followRole !== 2 && !isFollower && !isCached) return;
  }
  
  const msg = comment.trim();
  if (msg.startsWith('!')) return; // Ignore commands
  
  let textToSpeak = "";
  if (ttsSettings.mode === 'guess_only') {
    if (/^[a-zA-Z]+$/.test(msg)) {
       textToSpeak = ttsSettings.readNickname ? `${nickname} menebak ${msg}` : msg;
    }
  } else {
    textToSpeak = ttsSettings.readNickname ? `${nickname} berkata ${msg}` : msg;
  }
  
  if (textToSpeak) {
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.volume = ttsSettings.volume / 100;
    
    if (ttsSettings.voiceURI && availableVoices.length > 0) {
      const selectedVoice = availableVoices.find(v => v.voiceURI === ttsSettings.voiceURI);
      if (selectedVoice) utterance.voice = selectedVoice;
    }
    
    // Duck musik saat TTS bicara
    utterance.onstart = function() { duckMusicVolume(); };
    utterance.onend = function() { restoreMusicVolume(); };
    utterance.onerror = function() { restoreMusicVolume(); };
    
    window.speechSynthesis.speak(utterance);
  }
}

// ─── Host MP3 Audio Auto Functions ───
let hostAudioSettings = {
  enabled: false,
  volume: 100
};
try {
  const savedHostAudio = localStorage.getItem('host_audio_settings');
  if (savedHostAudio) hostAudioSettings = JSON.parse(savedHostAudio);
} catch(e) {}

const hostAudioFiles = {
  start: ['assets/audio/start.mp3'],
  win: ['assets/audio/win1.mp3', 'assets/audio/win2.mp3'],
  close: ['assets/audio/dikit-lagi.mp3'],
  interaction: ['assets/audio/interaction.mp3', 'assets/audio/interaction2.mp3']
};

const sfxAudioFiles = {
  win: ['assets/audio/sfx-win.mp3']
};

let customSfxSettings = {
  enabled: true,
  volume: 80,
  start: '',
  win: '',
  close: '',
  correct: '',
  interaction: '',
  click: '',
  invalid: ''
};
try {
  const savedCustomSfx = localStorage.getItem('custom_sfx_settings');
  if (savedCustomSfx) {
    customSfxSettings = Object.assign(customSfxSettings, JSON.parse(savedCustomSfx));
  }
} catch (e) {
  console.warn('Failed to load custom SFX settings', e);
}

let currentHostAudio = null;
let _musicDucked = false;
let _duckRestoreTimer = null;
const DUCK_VOLUME_RATIO = 0.55; // Musik turun halus ke 55% saat host audio/alert bermain (Soft Ducking)

// ─── Audio Ducking: turunkan volume YouTube secara halus saat host bicara / alert ───
function duckMusicVolume() {
  if (_musicDucked) return;
  _musicDucked = true;
  try {
    if (ytPlayer && ytPlayer.setVolume && isMusicPlaying) {
      const duckedVol = Math.max(1, Math.round(musicSettings.volume * DUCK_VOLUME_RATIO));
      ytPlayer.setVolume(duckedVol);
      console.log('[Audio] Music soft-ducked to', duckedVol + '%');
    }
  } catch(e) { console.warn('[Audio] Duck error', e); }

  // Failsafe auto-restore setelah 6 detik jika audio selesai tanpa event atau macet
  if (_duckRestoreTimer) clearTimeout(_duckRestoreTimer);
  _duckRestoreTimer = setTimeout(() => {
    restoreMusicVolume();
  }, 6000);
}

function restoreMusicVolume() {
  if (_duckRestoreTimer) {
    clearTimeout(_duckRestoreTimer);
    _duckRestoreTimer = null;
  }
  if (!_musicDucked) return;
  _musicDucked = false;
  try {
    if (ytPlayer && ytPlayer.setVolume) {
      ytPlayer.setVolume(musicSettings.volume);
      console.log('[Audio] Music restored to', musicSettings.volume + '%');
    }
  } catch(e) { console.warn('[Audio] Restore error', e); }
}

let lastSfxPlayTimes = {};

window.playHostAudio = function(type) {
  const now = Date.now();
  // Throttle high-frequency minor events to prevent overlapping audio chaos
  if (['interaction', 'click', 'invalid'].includes(type)) {
    const lastPlay = lastSfxPlayTimes[type] || 0;
    if (now - lastPlay < 300) {
      return; // Skip if played less than 300ms ago
    }
    lastSfxPlayTimes[type] = now;
  }

  // 1. Play Custom SFX if configured & enabled (independent of host voice audio settings)
  let customSfxPlayed = false;
  if (customSfxSettings.enabled && customSfxSettings[type]) {
    const customUrl = customSfxSettings[type].trim();
    if (customUrl) {
      try {
        const customAudio = new Audio(customUrl);
        customAudio.volume = (customSfxSettings.volume / 100);
        customAudio.play().catch(e => console.log('Custom SFX play blocked', e));
      } catch (e) {
        console.warn('Custom SFX play error', e);
      }
      customSfxPlayed = true;
    }
  }

  // 2. Play default SFX if no custom SFX was played (only if host audio is enabled)
  if (hostAudioSettings.enabled && !customSfxPlayed) {
    if (typeof sfxAudioFiles !== 'undefined' && sfxAudioFiles[type]) {
      const sfxFiles = sfxAudioFiles[type];
      if (sfxFiles && sfxFiles.length > 0) {
        const sfxFile = sfxFiles[Math.floor(Math.random() * sfxFiles.length)];
        try {
          const sfxAudio = new Audio(sfxFile);
          sfxAudio.volume = (hostAudioSettings.volume / 100) * 0.25;
          sfxAudio.play().catch(e => console.log('SFX play blocked', e));
        } catch (e) {
          console.warn('SFX play error', e);
        }
      }
    }
  }

  // 3. Play host voice audio
  if (!hostAudioSettings.enabled) return;
  
  const files = hostAudioFiles[type];
  if (!files || files.length === 0) return;
  
  // If a major event (win or start), cancel current audio and play new one
  if (type === 'win' || type === 'start') {
    if (currentHostAudio) {
      currentHostAudio.pause();
      currentHostAudio.currentTime = 0;
    }
  } else {
    // If minor event (close, interaction), and HOST audio is already playing, skip
    if (currentHostAudio && !currentHostAudio.paused) {
      return;
    }
  }
  
  const file = files[Math.floor(Math.random() * files.length)];
  currentHostAudio = new Audio(file);
  currentHostAudio.volume = hostAudioSettings.volume / 100;
  
  // Duck musik YouTube selama host audio bermain
  duckMusicVolume();
  
  currentHostAudio.onended = function() {
    restoreMusicVolume();
  };
  currentHostAudio.onerror = function() {
    restoreMusicVolume();
  };
  
  currentHostAudio.play().catch(e => {
    console.log('Host audio play blocked', e);
    restoreMusicVolume(); // Restore jika play gagal
  });
};

window.testHostAudio = function() {
  const types = Object.keys(hostAudioFiles);
  const randomType = types[Math.floor(Math.random() * types.length)];
  
  const vol = (window._tempHostAudioVolume !== undefined && window._tempHostAudioVolume !== null) ? window._tempHostAudioVolume : hostAudioSettings.volume;

  // 1. Test Custom SFX if exists
  let customSfxPlayed = false;
  if (customSfxSettings.enabled && customSfxSettings[randomType]) {
    const customUrl = customSfxSettings[randomType].trim();
    if (customUrl) {
      setTimeout(() => {
        try {
          const customAudio = new Audio(customUrl);
          customAudio.volume = (customSfxSettings.volume / 100);
          customAudio.play().catch(e => console.log('Custom SFX test play blocked', e));
        } catch (e) {
          console.warn('Custom SFX test play error', e);
        }
      }, 300);
      customSfxPlayed = true;
    }
  }

  // 2. Play default SFX if no custom SFX was played
  if (!customSfxPlayed && typeof sfxAudioFiles !== 'undefined' && sfxAudioFiles[randomType]) {
    const sfxFiles = sfxAudioFiles[randomType];
    if (sfxFiles && sfxFiles.length > 0) {
      const sfxFile = sfxFiles[Math.floor(Math.random() * sfxFiles.length)];
      setTimeout(() => {
        const sfxAudio = new Audio(sfxFile);
        sfxAudio.volume = (vol / 100) * 0.25;
        sfxAudio.play().catch(e => console.log('SFX play blocked', e));
      }, 300);
    }
  }

  const files = hostAudioFiles[randomType];
  const file = files[Math.floor(Math.random() * files.length)];
  
  if (currentHostAudio) {
    currentHostAudio.pause();
    currentHostAudio.currentTime = 0;
  }
  
  currentHostAudio = new Audio(file);
  currentHostAudio.volume = vol / 100;
  
  duckMusicVolume();
  currentHostAudio.onended = function() { restoreMusicVolume(); };
  currentHostAudio.onerror = function() { restoreMusicVolume(); };
  
  currentHostAudio.play().catch(e => {
    console.log('Test host audio play blocked', e);
    restoreMusicVolume();
  });
};

window.updateHostAudioVolumeUI = function(val) {
  document.getElementById('hostAudioVolumeLabel').textContent = `${val}%`;
  window._tempHostAudioVolume = parseInt(val) || 100;
};

// ─── Audio Context Unlock ───
// Browser memblokir autoplay audio sampai user interaksi pertama kali (klik/tap/keypress).
// Ini penting untuk OBS Browser Source & tab baru agar audio bisa keluar ke live.
let _audioUnlocked = false;
function unlockAudioContext() {
  // YouTube force-play runs on EVERY tap (mobile needs repeated gestures for iframe)
  try {
    if (ytPlayer && ytPlayer.unMute && isMusicPlaying) {
      ytPlayer.unMute();
      ytPlayer.setVolume(musicSettings.volume);
      ytPlayAttempts = 0;
      try { ytPlayer.playVideo(); } catch(e2) {}
    }
  } catch(e) {}

  if (_audioUnlocked) return;
  _audioUnlocked = true;
  
  // Resume AudioContext jika ada (untuk Web Audio API)
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      const ctx = new AudioCtx();
      ctx.resume().then(() => {
        console.log('[Audio] AudioContext unlocked');
        ctx.close();
      });
    }
  } catch(e) {}
  
  // Play silent audio untuk unlock HTML5 Audio
  try {
    const silentAudio = new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=');
    silentAudio.volume = 0.01;
    silentAudio.play().then(() => {
      silentAudio.pause();
      console.log('[Audio] HTML5 Audio unlocked');
    }).catch(() => {});
  } catch(e) {}
  
  // Force YouTube player unmute AND resume playback if stuck
  try {
    if (ytPlayer && ytPlayer.unMute) {
      ytPlayer.unMute();
      ytPlayer.setVolume(musicSettings.volume);
      ytPlayAttempts = 0; // Reset attempt counter so it can retry
      // If music is supposed to be playing but got blocked, force play
      if (isMusicPlaying) {
        try { ytPlayer.playVideo(); } catch(e2) {}
        console.log('[Audio] YouTube player unmuted + forced play');
      } else {
        console.log('[Audio] YouTube player unmuted');
      }
    }
  } catch(e) {}
  
  // Resume speechSynthesis
  try {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      console.log('[Audio] SpeechSynthesis ready');
    }
  } catch(e) {}
  
  console.log('[Audio] ✅ All audio channels unlocked');
}

// Intercept first user gesture to unlock all audio
['click', 'touchstart', 'keydown'].forEach(event => {
  document.addEventListener(event, unlockAudioContext, { once: false, capture: true });
});
// Also try to unlock after a short delay (for auto-started pages)
setTimeout(() => {
  if (!_audioUnlocked) {
    console.log('[Audio] ⚠️ Audio belum di-unlock — butuh interaksi user (klik/tap). Jika di OBS, aktifkan "Interact" dulu.');
  }
}, 3000);

// (Removed originalSaveTTS override as it was merged above)

// (Removed originalOpenTTS override as it was merged above)

// --- Header Status Bar Synchronizer ---
window.updateHeaderBadgesUI = function() {
  const noRep = document.getElementById('noRepeatBadge');
  const lang = document.getElementById('currentLangBadge');
  const roundBadge = document.getElementById('headerRoundBadge');
  const fogBadge = document.getElementById('followerOnlyBadge');

  if (roundBadge) roundBadge.style.display = 'inline-flex';
  if (lang) lang.style.display = 'inline-flex';
  if (noRep) {
    noRep.style.display = (window.isNoRepeatActiveForMode && window.isNoRepeatActiveForMode()) ? 'inline-flex' : 'none';
  }
  if (fogBadge) {
    fogBadge.style.display = (typeof isFollowerOnlyGuess !== 'undefined' && isFollowerOnlyGuess) ? 'inline-flex' : 'none';
  }
};
if (typeof window.updateHeaderBadgesUI === 'function') {
  window.updateHeaderBadgesUI();
}

// --- Game Selection logic for 2-Column Cards Grid ---
window.selectCustomGame = function(value, e) {
  if (e) e.stopPropagation();
  
  const cards = document.querySelectorAll('.game-card');
  cards.forEach(card => {
    if (card.getAttribute('data-value') === value) {
      card.classList.add('active');
    } else {
      card.classList.remove('active');
    }
  });

  changeGameModeDirect(value, e);
};

// Accordion toggle logic for Settings groups
window.toggleSettingsGroup = function(headerElement, e) {
  if (e) e.stopPropagation();
  const group = headerElement.parentElement;
  const dropdown = document.getElementById('settingsDropdown');
  
  // Collapse other groups (accordion effect)
  const allGroups = dropdown.querySelectorAll('.settings-group');
  allGroups.forEach(g => {
    if (g !== group) {
      g.classList.remove('open');
    }
  });
  
  // Toggle the clicked group
  group.classList.toggle('open');
};

// ==========================================================================
// SQUAREWORD 5x5 ENGINE & GAMEPLAY CONTROLLER
// ==========================================================================

let lastSquarewordGuess = null;
let lastSquarewordUser = null;

function initSquarewordRound() {
  let puzzles = window.SQUAREWORD_PUZZLES_ID || [
    ["redup","utama","buras","udara","sekat"],
    ["jaket","alibi","musim","ilusi","katun"],
    ["malah","opera","pikat","aroma","sikap"],
    ["cekal","idola","lidah","asasi","pilar"]
  ];

  if (typeof lastLang !== 'undefined') {
    if (lastLang === 'en' && window.SQUAREWORD_PUZZLES_EN) {
      puzzles = window.SQUAREWORD_PUZZLES_EN;
    } else if (lastLang === 'mixed' && window.SQUAREWORD_PUZZLES_EN) {
      // Create an interleaved mixed list (ID, EN, ID, EN, ...)
      const mixed = [];
      const idList = window.SQUAREWORD_PUZZLES_ID || [];
      const enList = window.SQUAREWORD_PUZZLES_EN;
      const len = Math.max(idList.length, enList.length);
      for (let i = 0; i < len; i++) {
        if (idList[i]) mixed.push(idList[i]);
        if (enList[i]) mixed.push(enList[i]);
      }
      puzzles = mixed;
    }
  }

  if (squarewordPuzzleIndex >= puzzles.length) {
    squarewordPuzzleIndex = 0;
  }

  squarewordGrid = puzzles[squarewordPuzzleIndex];
  squarewordPuzzleIndex++;

  squarewordRevealed = [
    [false, false, false, false, false],
    [false, false, false, false, false],
    [false, false, false, false, false],
    [false, false, false, false, false],
    [false, false, false, false, false]
  ];

  squarewordGuesses = [];
  squarewordSolvedRows = [false, false, false, false, false];
  squarewordSolvedCols = [false, false, false, false, false];
  squarewordContributors = {};
  isSquarewordScanning = false;
  isGameOver = false;
  lastSquarewordGuess = null;
  lastSquarewordUser = null;
  currentWord = "SQUAREWORD";
  userGuessDedup = new Set();
  joinGuessUsersDedup = new Set();
  guessQueue = [];

  initSquarewordBoard();
}

function initSquarewordBoard() {
  const gridContainer = document.getElementById('squarewordGrid');
  if (!gridContainer) return;

  gridContainer.innerHTML = '';

  for (let r = 0; r < 5; r++) {
    const row = document.createElement('div');
    row.className = 'sq-row';
    row.id = 'sqRow_' + r;

    // Col 1: Left Row Solver Avatar Slot (Hidden until row is solved)
    const leftAvatar = document.createElement('div');
    leftAvatar.className = 'sq-avatar-container sq-row-avatar';
    leftAvatar.id = 'sqRowAvatar_' + r;
    leftAvatar.title = 'Pemenang Baris ' + (r + 1);
    leftAvatar.innerHTML = '<img class="sq-avatar-img" id="sqRowAvatarImg_' + r + '" src="assets/bg_nature.png" alt="Solver"><span class="sq-avatar-name" id="sqRowAvatarName_' + r + '"></span>';
    row.appendChild(leftAvatar);

    // Col 2..6: 5 Tiles for this row (Aligned with top input tiles!)
    for (let c = 0; c < 5; c++) {
      const tile = document.createElement('div');
      tile.className = 'tile sq-tile sq-puzzle-tile';
      tile.id = 'sqTile_' + r + '_' + c;
      tile.textContent = '';
      row.appendChild(tile);
    }

    // Col 7: Clue Box on the right
    const clueBox = document.createElement('div');
    clueBox.className = 'sq-clue-box';
    clueBox.id = 'sqClueBox_' + r;
    clueBox.innerHTML = '<div class="sq-clue-letters" id="sqClueLetters_' + r + '"></div>';
    row.appendChild(clueBox);

    gridContainer.appendChild(row);
  }

  // Reset top input preview (Hidden at round start)
  const inputAvatar = document.getElementById('sqInputAvatar');
  const inputName = document.getElementById('sqInputName');
  const inputAvatarContainer = document.getElementById('sqInputAvatarContainer');
  if (inputAvatar) inputAvatar.src = 'assets/bg_nature.png';
  if (inputName) inputName.textContent = '';
  if (inputAvatarContainer) {
    inputAvatarContainer.classList.remove('show', 'active');
  }

  for (let c = 0; c < 5; c++) {
    const tile = document.getElementById('sqInputTile' + c);
    if (tile) {
      tile.textContent = '';
      tile.className = 'tile sq-tile sq-input-tile';
    }
  }

  renderSquarewordGrid();
  renderSquarewordLastGuess();
}

function renderSquarewordLastGuess() {
  const lastAvatar = document.getElementById('sqLastAvatar');
  const lastName = document.getElementById('sqLastName');
  const lastAvatarContainer = document.getElementById('sqLastAvatarContainer');

  if (!lastSquarewordGuess) {
    if (lastAvatar) lastAvatar.src = 'assets/bg_nature.png';
    if (lastName) lastName.textContent = '';
    if (lastAvatarContainer) lastAvatarContainer.classList.remove('show');
    for (let c = 0; c < 5; c++) {
      const tile = document.getElementById('sqLastTile' + c);
      if (tile) {
        tile.textContent = '';
        tile.className = 'tile sq-tile sq-last-tile';
      }
    }
    return;
  }

  if (lastAvatar) {
    lastAvatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
    lastAvatar.src = (lastSquarewordUser && lastSquarewordUser.profilePictureUrl) ? lastSquarewordUser.profilePictureUrl : 'assets/bg_nature.png';
  }
  if (lastName && lastSquarewordUser) {
    lastName.textContent = (lastSquarewordUser.nickname || lastSquarewordUser.uniqueId || 'GUESSER').slice(0, 8);
  }
  if (lastAvatarContainer) {
    lastAvatarContainer.classList.add('show');
  }

  for (let c = 0; c < 5; c++) {
    const tile = document.getElementById('sqLastTile' + c);
    if (tile) {
      tile.textContent = lastSquarewordGuess[c];
      tile.className = 'tile sq-tile sq-last-tile'; // Plain / uncolored
    }
  }
}

function renderSquarewordGrid() {
  if (!squarewordGrid || squarewordGrid.length < 5) return;

  for (let r = 0; r < 5; r++) {
    const targetRowUpper = squarewordGrid[r].toUpperCase();
    const rowElem = document.getElementById('sqRow_' + r);
    const isRowSolved = squarewordRevealed[r].every(v => v);

    if (rowElem) {
      if (isRowSolved) {
        rowElem.classList.add('row-complete');
      } else {
        rowElem.classList.remove('row-complete');
      }
    }

    for (let c = 0; c < 5; c++) {
      const tile = document.getElementById('sqTile_' + r + '_' + c);
      if (tile) {
        if (squarewordRevealed[r][c]) {
          tile.textContent = targetRowUpper[c];
          tile.className = 'tile sq-tile sq-puzzle-tile correct';
        } else {
          tile.textContent = '';
          tile.className = 'tile sq-tile sq-puzzle-tile';
        }
      }
    }

    renderSquarewordRowClues(r);
  }

  renderSquarewordLastGuess();
}

function renderSquarewordRowClues(r, animate = false) {
  const clueBox = document.getElementById('sqClueBox_' + r);
  const clueLettersBox = document.getElementById('sqClueLetters_' + r);
  if (!clueBox || !clueLettersBox || !squarewordGrid || !squarewordGrid[r]) return;

  const targetRowUpper = squarewordGrid[r].toUpperCase();

  // 1. Calculate unplaced target letters in row r
  const unplacedCounts = {};
  for (let c = 0; c < 5; c++) {
    if (!squarewordRevealed[r][c]) {
      const char = targetRowUpper[c];
      unplacedCounts[char] = (unplacedCounts[char] || 0) + 1;
    }
  }

  // 2. Count maximum occurrences of each letter guessed across all guesses
  const maxGuessedCounts = {};
  for (const guess of squarewordGuesses) {
    const guessUpper = guess.toUpperCase();
    const guessFreq = {};
    for (const char of guessUpper) {
      guessFreq[char] = (guessFreq[char] || 0) + 1;
    }
    for (const char in guessFreq) {
      maxGuessedCounts[char] = Math.max(maxGuessedCounts[char] || 0, guessFreq[char]);
    }
  }

  // 3. Clue letters are unplaced letters that have been guessed
  const clueLetters = [];
  for (const char in unplacedCounts) {
    const availableToClue = Math.min(unplacedCounts[char], maxGuessedCounts[char] || 0);
    for (let i = 0; i < availableToClue; i++) {
      clueLetters.push(char.toUpperCase());
    }
  }

  clueLetters.sort();

  if (clueLetters.length > 0) {
    clueBox.classList.add('has-clues');
    if (animate) {
      clueBox.classList.remove('sq-clue-pop');
      void clueBox.offsetWidth;
      clueBox.classList.add('sq-clue-pop');
    }
    clueLettersBox.innerHTML = clueLetters.map(char => '<span class="sq-clue-letter-char">' + char + '</span>').join('');
  } else {
    clueBox.classList.remove('has-clues', 'sq-clue-pop');
    clueLettersBox.innerHTML = '';
  }
}

async function processSquarewordGuess(guessWord, userData) {
  if (isGameOver || isSquarewordScanning) return;

  const guessUpper = (guessWord || '').trim().toUpperCase().replace(/[^A-Z]/g, '');
  if (guessUpper.length !== 5) return;

  const isHost = (userData && (userData.userId === 'host' || userData.userId === 'host_offline' || (typeof userData.userId === 'string' && userData.userId.toLowerCase().includes('host'))));

  // 1. Strict Dictionary Validation against valid KBBI words
  let isValidWord = false;
  if (allValidWordsSets && allValidWordsSets[5] && allValidWordsSets[5].size > 0) {
    isValidWord = allValidWordsSets[5].has(guessUpper);
  } else if (VALID_WORDS_SET && VALID_WORDS_SET.size > 0) {
    isValidWord = VALID_WORDS_SET.has(guessUpper);
  } else if (allValidWords && allValidWords[5] && allValidWords[5].length > 0) {
    isValidWord = allValidWords[5].includes(guessUpper);
  } else if (fullValidDictionary && fullValidDictionary.size > 0) {
    isValidWord = fullValidDictionary.has(guessUpper);
  } else {
    isValidWord = (guessUpper.length === 5);
  }

  if (!isValidWord) {
    if (isHost) {
      console.log('[Squareword] Rejected invalid KBBI word from host:', guessUpper);
      const inputRow = document.getElementById('squarewordInputRow');
      if (inputRow) {
        inputRow.classList.remove('shake');
        void inputRow.offsetWidth;
        inputRow.classList.add('shake');
      }
      if (typeof showToast === 'function') {
        const errMsg = (typeof lastLang !== 'undefined' && (lastLang === 'en' || lastLang === 'mixed')) 
          ? '❌ "' + guessUpper + '" not in dictionary!' 
          : '❌ "' + guessUpper + '" tidak ada dalam kamus KBBI!';
        showToast(errMsg, 1800);
      }
      if (window.sounds) window.sounds.playInvalid();
      if (window.playHostAudio) playHostAudio('invalid');
    }
    return;
  }

  isSquarewordScanning = true;
  try {
    const queueLen = (typeof guessQueue !== 'undefined') ? guessQueue.length : 0;
    let scanDelay = 120; // Default santai
    if (queueLen >= 5) {
      scanDelay = 25;   // Turbo saat banjir komentar
    } else if (queueLen >= 2) {
      scanDelay = 60;   // Gesit saat ada antrean
    }

    // 1. Update Top Input Row Preview with Guesser Avatar & Word
    const inputAvatar = document.getElementById('sqInputAvatar');
    const inputName = document.getElementById('sqInputName');
    const inputAvatarContainer = document.getElementById('sqInputAvatarContainer');
    
    if (inputAvatar) {
      inputAvatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
      inputAvatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
    }
    if (inputName) {
      inputName.textContent = (userData.nickname || userData.uniqueId || 'GUESSER').slice(0, 8);
    }
    if (inputAvatarContainer) {
      inputAvatarContainer.classList.add('show', 'active');
    }

    for (let c = 0; c < 5; c++) {
      const tile = document.getElementById('sqInputTile' + c);
      if (tile) {
        tile.textContent = guessUpper[c];
        tile.className = 'tile sq-tile sq-input-tile typed';
      }
    }

    // Record guess
    squarewordGuesses.push(guessUpper);

    const prevSolvedRows = [...squarewordSolvedRows];
    const prevSolvedCols = [...squarewordSolvedCols];

    let newRevealedInRound = 0;

    // 2. Downwards Scan Wave (Rows 0 to 4)
    for (let r = 0; r < 5; r++) {
      if (window.sounds && queueLen < 4) window.sounds.playScanRow(r);
      const rowElem = document.getElementById('sqRow_' + r);
      if (rowElem) {
        rowElem.classList.add('row-scanning');
      }

      const targetRowUpper = squarewordGrid[r].toUpperCase();
    let rowRevealedNew = false;
    const newlyRevealedCols = [];

    for (let c = 0; c < 5; c++) {
      if (guessUpper[c] === targetRowUpper[c]) {
        if (!squarewordRevealed[r][c]) {
          squarewordRevealed[r][c] = true;
          rowRevealedNew = true;
          newlyRevealedCols.push(c);
          newRevealedInRound++;

          // Award +5 pts per new green letter
          addPoints(userData, 5);
          if (!squarewordContributors[userData.uniqueId]) {
            squarewordContributors[userData.uniqueId] = { score: 0, letters: 0, words: 0, data: userData };
          }
          squarewordContributors[userData.uniqueId].score += 5;
          squarewordContributors[userData.uniqueId].letters += 1;
        }
      }
    }

    // Render revealed green tiles across the grid
    for (let c = 0; c < 5; c++) {
      const tile = document.getElementById('sqTile_' + r + '_' + c);
      if (tile && squarewordRevealed[r][c]) {
        tile.textContent = targetRowUpper[c];
        tile.className = 'tile sq-tile sq-puzzle-tile correct';
      }
    }

    newlyRevealedCols.forEach((c, index) => {
      if (window.sounds) window.sounds.playFlip(index);
      const tile = document.getElementById('sqTile_' + r + '_' + c);
      if (tile) {
        tile.classList.remove('sq-tile-flip');
        void tile.offsetWidth;
        tile.classList.add('sq-tile-flip');
      }
    });

    if (rowRevealedNew) {
      if (window.sounds) window.sounds.playGreenChime();
      showFloatingPoints(newlyRevealedCols.length * 5, 'sqRow_' + r);
      if (window.playHostAudio) playHostAudio('correct');
    }

    // Check if horizontal row r is fully solved (5 green)
    const isRowNowSolved = squarewordRevealed[r].every(v => v);
    if (isRowNowSolved && !prevSolvedRows[r]) {
      if (window.sounds) window.sounds.playRowSolved();
      squarewordSolvedRows[r] = true;
      if (rowElem) rowElem.classList.add('row-complete');

      // Reveal solver avatar on the left of this row
      const rowAvatarContainer = document.getElementById('sqRowAvatar_' + r);
      const rowAvatarImg = document.getElementById('sqRowAvatarImg_' + r);
      const rowAvatarName = document.getElementById('sqRowAvatarName_' + r);
      if (rowAvatarContainer && rowAvatarImg) {
        rowAvatarImg.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
        rowAvatarImg.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
        if (rowAvatarName) rowAvatarName.textContent = (userData ? (userData.nickname || userData.uniqueId || '') : '').slice(0, 8);
        rowAvatarContainer.classList.add('show');
      }

      // +15 bonus points for completing a horizontal row
      addPoints(userData, 15);
      if (!squarewordContributors[userData.uniqueId]) {
        squarewordContributors[userData.uniqueId] = { score: 0, letters: 0, words: 0, data: userData };
      }
      squarewordContributors[userData.uniqueId].score += 15;
      squarewordContributors[userData.uniqueId].words += 1;
      showFloatingPoints(15, 'sqRow_' + r);

      // Trigger wave animation on solved row
      for (let c = 0; c < 5; c++) {
        const tile = document.getElementById('sqTile_' + r + '_' + c);
        if (tile) {
          tile.classList.remove('sq-tile-wave');
          void tile.offsetWidth;
          tile.style.animationDelay = (c * 80) + 'ms';
          tile.classList.add('sq-tile-wave');
          setTimeout(() => {
            if (window.sounds && typeof window.sounds.playWaveTile === 'function') {
              window.sounds.playWaveTile(c, 5);
            }
          }, c * 80);
        }
      }
    }

    // Update yellow clue box for row r
    renderSquarewordRowClues(r, true);

    await new Promise(res => setTimeout(res, scanDelay));

    if (rowElem) {
      rowElem.classList.remove('row-scanning');
    }
  }

  // 3. Check Vertical Columns (0 to 4)
  for (let c = 0; c < 5; c++) {
    let isColNowSolved = true;
    for (let r = 0; r < 5; r++) {
      if (!squarewordRevealed[r][c]) {
        isColNowSolved = false;
        break;
      }
    }

    if (isColNowSolved && !prevSolvedCols[c]) {
      squarewordSolvedCols[c] = true;

      // +15 bonus points for completing a vertical column
      addPoints(userData, 15);
      if (!squarewordContributors[userData.uniqueId]) {
        squarewordContributors[userData.uniqueId] = { score: 0, letters: 0, words: 0, data: userData };
      }
      squarewordContributors[userData.uniqueId].score += 15;
      squarewordContributors[userData.uniqueId].words += 1;

      // Column wave animation
      for (let r = 0; r < 5; r++) {
        const tile = document.getElementById('sqTile_' + r + '_' + c);
        if (tile) {
          tile.classList.remove('sq-tile-wave');
          void tile.offsetWidth;
          tile.style.animationDelay = (r * 80) + 'ms';
          tile.classList.add('sq-tile-wave');
        }
      }
      const colWaveDelay = (queueLen >= 3) ? 80 : 250;
      await new Promise(res => setTimeout(res, colWaveDelay));
    }
  }

  // 4. Save and Render Last Guess Row (Avatar + 5 plain letter tiles, NO background color)
  lastSquarewordGuess = guessUpper;
  lastSquarewordUser = userData;
  renderSquarewordLastGuess();

  // Clear Top Input Row (Letters and Avatar disappear after moving to bottom)
  for (let c = 0; c < 5; c++) {
    const tile = document.getElementById('sqInputTile' + c);
    if (tile) {
      tile.textContent = '';
      tile.className = 'tile sq-tile sq-input-tile';
    }
  }
  if (inputAvatarContainer) {
    inputAvatarContainer.classList.remove('show', 'active');
  }

  // Ensure all revealed tiles across ALL rows stay permanently green
  renderSquarewordGrid();
  } finally {
    isSquarewordScanning = false;
  }

  // 5. Check Win Condition (All 25 tiles revealed)
  let allTilesSolved = true;
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (!squarewordRevealed[r][c]) {
        allTilesSolved = false;
        break;
      }
    }
    if (!allTilesSolved) break;
  }

  if (allTilesSolved) {
    isGameOver = true;

    // +50 Final Solver Winner Bonus
    addPoints(userData, 50);
    if (!squarewordContributors[userData.uniqueId]) {
      squarewordContributors[userData.uniqueId] = { score: 0, letters: 0, words: 0, data: userData };
    }
    squarewordContributors[userData.uniqueId].score += 50;

    // Determine MVP
    let maxScore = 0;
    let mvpData = userData;
    Object.values(squarewordContributors).forEach(s => {
      if (s.score > maxScore) {
        maxScore = s.score;
        mvpData = s.data;
      }
    });

    if (window.sounds) window.sounds.playWin();
    if (window.playHostAudio) playHostAudio('win');

    // Display Multi-Winner / Contributors Overlay
    setTimeout(() => {
      const multiWinList = document.getElementById('multiWinList');
      const multiWinTitle = document.getElementById('multiWinTitle');
      if (multiWinTitle) multiWinTitle.textContent = '🎉 KOTAK KATA 5×5 SELESAI!';

      if (multiWinList) {
        multiWinList.innerHTML = '';
        const sortedContributors = Object.values(squarewordContributors).sort((a, b) => b.score - a.score);

        sortedContributors.slice(0, 6).forEach((item, rank) => {
          const isMvp = (mvpData && item.data.uniqueId === mvpData.uniqueId);
          const rowDiv = document.createElement('div');
          rowDiv.className = 'multi-win-item ' + (isMvp ? 'mvp' : '');
          rowDiv.innerHTML = `
            <img class="multi-win-avatar" src="${item.data.profilePictureUrl || 'assets/bg_nature.png'}" alt="Avatar">
            <div class="multi-win-info">
              <div class="multi-win-name">${item.data.nickname || item.data.uniqueId || 'Anon'}${isMvp ? ' 👑 (MVP)' : ''}</div>
              <div class="multi-win-word">${item.letters} Huruf • ${item.words} Baris/Kolom</div>
            </div>
            <div class="multi-win-points">+${item.score} Pts</div>
          `;
          multiWinList.appendChild(rowDiv);
        });
      }

      triggerWinTransition(9000, true);
    }, 800);
  }
}


// Web Audio Settings
function toggleWebAudio(enabled) {
  localStorage.setItem('squareword_webaudio', enabled);
  if (window.sounds) window.sounds.setEnabled(enabled);
}

function changeSoundTheme(theme) {
  if (window.sounds) {
    window.sounds.setTheme(theme);
    previewCurrentSoundTheme();
  }
}

function previewCurrentSoundTheme(e) {
  if (e) e.stopPropagation();
  if (window.sounds) {
    window.sounds.playFlip(0);
    setTimeout(() => window.sounds.playFlip(1), 100);
    setTimeout(() => window.sounds.playFlip(2), 200);
    setTimeout(() => window.sounds.playGreenChime(), 320);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('squareword_webaudio');
  const isEnabled = saved !== 'false';
  const toggle = document.getElementById('webAudioToggle');
  if (toggle) toggle.checked = isEnabled;
  if (window.sounds) window.sounds.setEnabled(isEnabled);

  const themeSelect = document.getElementById('soundThemeSelect');
  if (themeSelect && window.sounds) {
    themeSelect.value = window.sounds.getTheme();
  }

  if (window.changeMusicPlayerStyle) {
    window.changeMusicPlayerStyle(musicSettings.playerStyle || 'vinyl');
  }

  const mainRadioToggle = document.getElementById('mainRadioAmbianceToggle');
  if (mainRadioToggle) mainRadioToggle.checked = musicSettings.radioAmbiance === true;

  const mainSfxToggle = document.getElementById('mainRadioSFXToggle');
  if (mainSfxToggle) mainSfxToggle.checked = musicSettings.radioSFX !== false;
});


// ==================== WORD LADDER (WEAVER) GAMEPLAY ====================
function getWordLadderFeedback(guess, target) {
  const len = guess.length;
  const result = Array(len).fill('absent');

  // Hanya warna hijau (correct) untuk huruf yang posisinya sama persis dengan target.
  // Tidak ada warna kuning (present) agar penonton tidak mengira huruf bisa digeser posisi seperti Wordle.
  for (let i = 0; i < len; i++) {
    if (guess[i] === target[i]) {
      result[i] = 'correct';
    }
  }

  return result;
}

function getNextWordLadderPuzzle(isEn) {
  const sourcePuzzles = isEn 
    ? (window.WORDLADDER_PUZZLES_EN || []) 
    : (window.WORDLADDER_PUZZLES_ID || []);

  if (!sourcePuzzles || sourcePuzzles.length === 0) return null;

  if (isEn) {
    if (!wordLadderPoolEN || wordLadderPoolEN.length === 0) {
      wordLadderPoolEN = [...sourcePuzzles];
      shuffleArray(wordLadderPoolEN);
      console.log(`[WordLadder] Pool EN diisi ulang & diacak (${wordLadderPoolEN.length} puzzle)`);
    }
    return wordLadderPoolEN.pop();
  } else {
    if (!wordLadderPoolID || wordLadderPoolID.length === 0) {
      wordLadderPoolID = [...sourcePuzzles];
      shuffleArray(wordLadderPoolID);
      console.log(`[WordLadder] Pool ID diisi ulang & diacak (${wordLadderPoolID.length} puzzle)`);
    }
    return wordLadderPoolID.pop();
  }
}

function startWordLadderRound() {
  const isEn = (lastLang === 'en');
  const p = getNextWordLadderPuzzle(isEn);

  if (!p) {
    console.error('No Word Ladder puzzles found, using fallback');
    wordLadderStartWord = 'KOPI';
    wordLadderTargetWord = 'SUSU';
    wordLadderMinSteps = 4;
  } else {
    wordLadderIndex++;
    wordLadderStartWord = (p.start || 'KOPI').toUpperCase();
    wordLadderTargetWord = (p.target || 'SUSU').toUpperCase();
    wordLadderMinSteps = p.minSteps || 4;
    const remainingCount = isEn ? wordLadderPoolEN.length : wordLadderPoolID.length;
    console.log(`[WordLadder] Round ${wordLadderIndex}: ${wordLadderStartWord} ➔ ${wordLadderTargetWord} (${wordLadderMinSteps} langkah). Sisa puzzle: ${remainingCount}`);
  }

  const wordLen = wordLadderStartWord.length;
  WORD_LENGTH = wordLen;
  document.documentElement.style.setProperty('--word-length', wordLen);
  if (allValidWords && allValidWords[wordLen]) {
    VALID_WORDS = allValidWords[wordLen];
    TARGET_WORDS = allTargetWords[wordLen] || [];
    availableWords = allAvailableWords[wordLen] || [];
  }

  wordLadderHistory = [];
  wordLadderContributors = {};
  isGameOver = false;

  renderWordLadderBoard();
}

function renderWordLadderBoard() {
  const boardEl = document.getElementById('board');
  if (!boardEl) return;
  boardEl.innerHTML = '';
  boardEl.className = 'wordladder-board';

  const wordLen = wordLadderStartWord ? wordLadderStartWord.length : 4;
  document.documentElement.style.setProperty('--word-length', wordLen);

  // 1. TOP ROW: Target Word (Puncak Tangga / Gold / Checkered Flag)
  const targetRow = document.createElement('div');
  targetRow.className = 'board-row wordladder-row wordladder-target-row';

  const targetPin = document.createElement('div');
  targetPin.className = 'ladder-pin-avatar target-pin';
  targetPin.title = 'Target Kata (Puncak Tangga)';
  targetPin.innerHTML = '<i class="fa-solid fa-flag-checkered"></i>';
  targetRow.appendChild(targetPin);

  for (let i = 0; i < wordLen; i++) {
    const tile = document.createElement('div');
    tile.className = 'tile target-tile prefilled';
    tile.textContent = wordLadderTargetWord[i] || '';
    targetRow.appendChild(tile);
  }
  boardEl.appendChild(targetRow);

  // 2. CLIMB DIVIDER: Upward Vector Arrows Track (Bukan Emoji, Seperti Betweenle)
  const climbDivider = document.createElement('div');
  climbDivider.className = 'ladder-climb-divider';
  climbDivider.innerHTML = `
    <div class="ladder-divider-line"></div>
    <div class="ladder-climb-pill">
      <i class="fa-solid fa-angles-up"></i>
      <i class="fa-solid fa-arrow-up"></i>
      <i class="fa-solid fa-angles-up"></i>
    </div>
    <div class="ladder-divider-line"></div>
  `;
  boardEl.appendChild(climbDivider);

  // 3. ACTIVE NEXT ROW: Empty placeholder row (hanya jika game masih aktif)
  if (!isGameOver) {
    const emptyRow = document.createElement('div');
    emptyRow.className = 'board-row wordladder-row wordladder-empty-row';
    
    const inputPin = document.createElement('div');
    inputPin.className = 'ladder-pin-avatar input-pin';
    inputPin.title = 'Tebak kata berikutnya (Ubah tepat 1 huruf)';
    inputPin.innerHTML = '<i class="fa-solid fa-arrow-up"></i>';
    emptyRow.appendChild(inputPin);

    for (let i = 0; i < wordLen; i++) {
      const tile = document.createElement('div');
      tile.className = 'tile tile-empty';
      emptyRow.appendChild(tile);
    }
    boardEl.appendChild(emptyRow);
  }

  // 4. MIDDLE ROWS: Guessed Steps (DIBALIK: Tebakan terbaru paling atas!)
  for (let s = wordLadderHistory.length - 1; s >= 0; s--) {
    const item = wordLadderHistory[s];
    const row = document.createElement('div');
    row.className = 'board-row wordladder-row';
    
    // Tebakan terbaru diberi highlight khusus dan animasi pop-in
    if (s === wordLadderHistory.length - 1) {
      row.classList.add('wordladder-latest-row');
      if (isGameAnimationsEnabled) {
        row.classList.add('pop-in');
      }
    }

    const avatarWrap = document.createElement('div');
    avatarWrap.className = 'ladder-avatar-wrap';

    const avatar = document.createElement('img');
    avatar.className = 'guesser-avatar show';
    avatar.id = `ladder-avatar-${s + 1}`;
    avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
    avatar.src = (item.userData && item.userData.profilePictureUrl) ? item.userData.profilePictureUrl : 'assets/bg_nature.png';
    avatarWrap.appendChild(avatar);

    const stepChip = document.createElement('span');
    stepChip.className = 'ladder-step-num';
    stepChip.innerHTML = `<i class="fa-solid fa-arrow-up"></i> #${s + 1}`;
    avatarWrap.appendChild(stepChip);

    row.appendChild(avatarWrap);

    const feedback = getWordLadderFeedback(item.word, wordLadderTargetWord);

    for (let i = 0; i < wordLen; i++) {
      const tile = document.createElement('div');
      tile.className = `tile ${feedback[i]}`;
      tile.textContent = item.word[i];
      row.appendChild(tile);
    }
    boardEl.appendChild(row);
  }

  // 5. BOTTOM ROW: Start Word (Dasar Tangga / Cyan)
  const startRow = document.createElement('div');
  startRow.className = 'board-row wordladder-row wordladder-start-row';
  
  const startPin = document.createElement('div');
  startPin.className = 'ladder-pin-avatar start-pin';
  startPin.title = 'Kata Awal (Dasar Tangga)';
  startPin.innerHTML = '<i class="fa-solid fa-play"></i>';
  startRow.appendChild(startPin);

  for (let i = 0; i < wordLen; i++) {
    const tile = document.createElement('div');
    tile.className = 'tile start-tile prefilled';
    tile.textContent = wordLadderStartWord[i] || '';
    startRow.appendChild(tile);
  }
  boardEl.appendChild(startRow);

  // Update info bar text & mission badge (Opsi 1)
  const stepCountEl = document.getElementById('ladderCurrentSteps');
  const minStepsEl = document.getElementById('ladderMinSteps');
  if (stepCountEl) stepCountEl.textContent = wordLadderHistory.length;
  if (minStepsEl) minStepsEl.textContent = wordLadderMinSteps;

  const missionStartEl = document.getElementById('ladderMissionStart');
  const missionTargetEl = document.getElementById('ladderMissionTarget');
  if (missionStartEl) missionStartEl.textContent = wordLadderStartWord;
  if (missionTargetEl) missionTargetEl.textContent = wordLadderTargetWord;

  // Auto-scroll ke puncak agar tebakan terbaru & kata target selalu terlihat di atas
  boardEl.scrollTop = 0;
  const container = document.querySelector('.board-container');
  if (container) {
    container.scrollTop = 0;
  }
}

function processWordLadderGuess(guessWord, userData) {
  if (isGameOver) return;
  const word = guessWord.toUpperCase().trim();
  const wordLen = wordLadderStartWord ? wordLadderStartWord.length : 4;

  if (word.length !== wordLen) return;

  const dict = (allValidWords && allValidWords[wordLen]) ? allValidWords[wordLen] : (VALID_WORDS || []);
  const validSet = (allValidWordsSets && allValidWordsSets[wordLen]) ? allValidWordsSets[wordLen] : VALID_WORDS_SET;
  const isValid = (validSet && validSet.size > 0 && validSet.has(word)) || (dict && dict.includes(word)) || (fullValidDictionary && (fullValidDictionary.has(word) || fullValidDictionary.has(word.toLowerCase())));
  const isHost = !userData || userData.uniqueId === 'HOST_LOCAL' || userData.uniqueId === 'host';
  if (!isValid) {
    if (window.sounds) window.sounds.playInvalid();
    if (window.playHostAudio) playHostAudio('invalid');
    if (isHost) {
      showToast(`"${word}" tidak ada di kamus!`, 1500);
    }
    return;
  }

  // 1. Cek apakah kata sudah pernah digunakan (Kata awal atau langkah sebelumnya di ronde ini)
  const isAlreadyUsed = (word === wordLadderStartWord) || wordLadderHistory.some(item => item.word === word);
  if (isAlreadyUsed) {
    if (window.sounds) window.sounds.playInvalid();
    if (window.playHostAudio) playHostAudio('invalid');
    if (isHost) {
      showToast(`"${word}" sudah digunakan di ronde ini!`, 1800);
    }
    return;
  }

  const currentActiveWord = (wordLadderHistory.length === 0)
    ? wordLadderStartWord
    : wordLadderHistory[wordLadderHistory.length - 1].word;

  let diffCount = 0;
  let changedIndex = -1;
  for (let i = 0; i < wordLen; i++) {
    if (word[i] !== currentActiveWord[i]) {
      diffCount++;
      changedIndex = i;
    }
  }

  if (diffCount !== 1) {
    if (window.sounds) window.sounds.playInvalid();
    if (window.playHostAudio) playHostAudio('invalid');
    showToast(`"${word}" harus beda tepat 1 huruf dari "${currentActiveWord}"!`, 1800);
    return;
  }

  const stepPts = 5;
  addPoints(userData, stepPts);

  const username = userData.uniqueId || userData.nickname || 'anon';
  if (!wordLadderContributors[username]) {
    wordLadderContributors[username] = {
      userData: userData,
      points: 0,
      steps: 0,
      words: []
    };
  }
  wordLadderContributors[username].points += stepPts;
  wordLadderContributors[username].steps += 1;
  wordLadderContributors[username].words.push(word);

  const stepNum = wordLadderHistory.length + 1;
  wordLadderHistory.push({
    word: word,
    userData: userData,
    changedIndex: changedIndex,
    stepNum: stepNum,
    pts: stepPts
  });

  renderWordLadderBoard();
  showFloatingPoints(stepPts, `ladder-avatar-${stepNum}`);

  if (window.playHostAudio) playHostAudio('click');

  if (word === wordLadderTargetWord) {
    isGameOver = true;
    const finishBonus = 25;
    addPoints(userData, finishBonus);
    wordLadderContributors[username].points += finishBonus;

    renderWordLadderBoard();

    if (window.playHostAudio) playHostAudio('win');
    triggerConfetti();

    setTimeout(() => {
      // Sort contributors by score descending (Top-to-Bottom)
      const sortedContributors = Object.values(wordLadderContributors).sort((a, b) => b.points - a.points || b.steps - a.steps);

      const multiWinTitle = document.getElementById('multiWinTitle');
      if (multiWinTitle) multiWinTitle.textContent = 'WORD LADDER COMPLETED! 🪜';

      const multiWinList = document.getElementById('multiWinList');
      if (multiWinList) {
        multiWinList.innerHTML = `
          <div style="text-align: center; margin-bottom: 12px; font-size: 13px; font-weight: 800; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.5px;">
            ${wordLadderStartWord} ➔ ${wordLadderTargetWord} (${stepNum} Langkah)
          </div>
        `;

        sortedContributors.forEach((c, idx) => {
          const isMvp = (idx === 0);
          const item = document.createElement('div');
          item.className = `multi-win-item ${isMvp ? 'mvp' : ''}`;
          item.innerHTML = `
            <img class="multi-win-avatar" src="${c.userData.profilePictureUrl || 'assets/bg_nature.png'}" onerror="this.onerror=null;this.src='assets/bg_nature.png';" alt="Avatar">
            <div class="multi-win-info">
              <div class="multi-win-name">${isMvp ? '👑 ' : ''}${c.userData.nickname || 'Unknown'} <span style="font-size: 11px; opacity: 0.8;">(#${idx + 1})</span></div>
              <div class="multi-win-word" style="font-size: 12px; color: #38bdf8;">${c.steps} Langkah: ${c.words.join(' ➔ ')}</div>
            </div>
            <div class="multi-win-pts" style="font-size: 14px; font-weight: 900; color: #ffd54f;">🪙 +${c.points} Pts</div>
          `;
          multiWinList.appendChild(item);
        });
      }

      const multiWinOverlay = document.getElementById('multiWinOverlay');
      if (multiWinOverlay) {
        multiWinOverlay.classList.add('show');
        if (typeof startMultiWinAutoScroll === 'function') startMultiWinAutoScroll();
      }

      const isLikeRestart = document.getElementById('likeRestartToggle') ? document.getElementById('likeRestartToggle').checked : false;
      const progressContainer = document.getElementById('multiLikeProgressContainer');
      const footer = document.getElementById('multiWinFooter');

      if (isLikeRestart) {
        if (progressContainer) progressContainer.style.display = 'block';
        if (footer) footer.style.display = 'none';
        isWaitingForLikes = true;
        updateLikeProgressBar();
      } else {
        if (progressContainer) progressContainer.style.display = 'none';
        if (footer) {
          footer.style.display = 'block';
          footer.textContent = 'Next round starting soon...';
        }
        setTimeout(() => {
          if (!isWaitingForLikes) {
            isWaitingForLikes = true;
            executeRestartTransition();
          }
        }, 8000);
      }
    }, 600);
  }
}

window.undoWordLadder = function() {
  if (currentGameMode !== 'wordladder' || isGameOver || wordLadderHistory.length === 0) {
    showToast('Tidak ada langkah yang bisa di-undo!', 1500);
    return;
  }
  
  // Ambil langkah terakhir
  const lastStep = wordLadderHistory.pop();
  
  // Kembalikan poin/steps di data kontributor
  const username = lastStep.userData.uniqueId || lastStep.userData.nickname || 'anon';
  if (wordLadderContributors[username]) {
    wordLadderContributors[username].points -= lastStep.pts;
    wordLadderContributors[username].steps -= 1;
    // Hapus kata terakhir dari array words
    const wordIndex = wordLadderContributors[username].words.lastIndexOf(lastStep.word);
    if (wordIndex !== -1) {
      wordLadderContributors[username].words.splice(wordIndex, 1);
    }
  }
  
  // (Opsional) Kurangi poin global pemain jika punya fungsi deductPoints, tapi kita biarkan saja poin globalnya.
  
  renderWordLadderBoard();
  showToast('Langkah terakhir dibatalkan oleh Host.', 1500);
  if (window.playHostAudio) playHostAudio('click');
}

window.toggleRadioAmbianceUI = function(checked) {
  const container = document.getElementById('musicRadioAmbianceSliderContainer');
  if (container) container.style.display = checked ? 'block' : 'none';
  if (window.sounds) {
    const vol = parseInt(document.getElementById('musicRadioAmbianceSlider').value) || 20;
    window.sounds.setRadioAmbiance(checked, vol);
    if (checked) window.sounds.startRadioAmbiance();
    else window.sounds.stopRadioAmbiance();
  }
};

window.updateRadioAmbianceVolumeUI = function(val) {
  const label = document.getElementById('musicRadioAmbianceLabel');
  if (label) label.textContent = `${val}%`;
  if (window.sounds) {
    const isChecked = document.getElementById('musicRadioAmbianceToggle').checked;
    window.sounds.setRadioAmbiance(isChecked, val);
  }
};

window.toggleRadioAmbiance = function(enabled) {
  musicSettings.radioAmbiance = !!enabled;
  localStorage.setItem('music_settings', JSON.stringify(musicSettings));
  const subToggle = document.getElementById('musicRadioAmbianceToggle');
  if (subToggle) subToggle.checked = !!enabled;
  const mainToggle = document.getElementById('mainRadioAmbianceToggle');
  if (mainToggle) mainToggle.checked = !!enabled;

  if (window.sounds) {
    window.sounds.setRadioAmbiance(enabled, musicSettings.radioAmbianceVolume || 20);
    if (enabled && isMusicPlaying) window.sounds.startRadioAmbiance();
    else window.sounds.stopRadioAmbiance();
  }
};

window.toggleRadioRequestSFX = function(enabled) {
  musicSettings.radioSFX = !!enabled;
  localStorage.setItem('music_settings', JSON.stringify(musicSettings));
  const mainToggle = document.getElementById('mainRadioSFXToggle');
  if (mainToggle) mainToggle.checked = !!enabled;
};

window.changeMusicPlayerStyle = function(style) {
  musicSettings.playerStyle = style || 'vinyl';
  localStorage.setItem('music_settings', JSON.stringify(musicSettings));
  
  const widget = document.getElementById('musicWidget');
  if (widget) {
    widget.classList.remove('music-style-vinyl', 'music-style-playlist', 'music-style-compact', 'music-style-lyrics');
    widget.classList.add('music-style-' + musicSettings.playerStyle);
  }

  const mainSelect = document.getElementById('mainMusicPlayerStyleSelect');
  if (mainSelect) mainSelect.value = musicSettings.playerStyle;

  const modalSelect = document.getElementById('modalMusicPlayerStyleSelect');
  if (modalSelect) modalSelect.value = musicSettings.playerStyle;

  // Toggle visibility of playlist sub-settings
  const subBox = document.getElementById('mainPlaylistSubSettingsBox');
  if (subBox) subBox.style.display = (musicSettings.playerStyle === 'playlist') ? 'flex' : 'none';
  const modalBox = document.getElementById('modalPlaylistSettingsCard');
  if (modalBox) modalBox.style.display = (musicSettings.playerStyle === 'playlist') ? 'block' : 'none';

  if (document.getElementById('modalMusicPlaylistRowsSelect')) {
    document.getElementById('modalMusicPlaylistRowsSelect').value = musicSettings.playlistVisibleRows || 4;
  }
  if (document.getElementById('mainMusicPlaylistRowsSelect')) {
    document.getElementById('mainMusicPlaylistRowsSelect').value = musicSettings.playlistVisibleRows || 4;
  }
  if (document.getElementById('modalMusicPlaylistScaleSelect')) {
    document.getElementById('modalMusicPlaylistScaleSelect').value = musicSettings.playlistScale || 100;
  }
  if (document.getElementById('mainMusicPlaylistScaleSelect')) {
    document.getElementById('mainMusicPlaylistScaleSelect').value = musicSettings.playlistScale || 100;
  }
  if (document.getElementById('modalMusicPlaylistAutoScrollToggle')) {
    document.getElementById('modalMusicPlaylistAutoScrollToggle').checked = musicSettings.playlistAutoScroll !== false;
  }
  if (document.getElementById('mainMusicPlaylistAutoScrollToggle')) {
    document.getElementById('mainMusicPlaylistAutoScrollToggle').checked = musicSettings.playlistAutoScroll !== false;
  }
  if (document.getElementById('modalMusicPlaylistAccentSelect')) {
    document.getElementById('modalMusicPlaylistAccentSelect').value = musicSettings.playlistAccent || 'red';
  }
  if (document.getElementById('mainMusicPlaylistAccentSelect')) {
    document.getElementById('mainMusicPlaylistAccentSelect').value = musicSettings.playlistAccent || 'red';
  }

  if (widget) {
    if (musicSettings.playlistAccent === 'green') {
      widget.classList.add('accent-green');
    } else {
      widget.classList.remove('accent-green');
    }
  }

  updateMusicQueueUI();
  updateMusicLyricsVisibility();

  // If switched to lyrics while music is playing and lyrics not fetched yet, fetch immediately
  if (musicSettings.playerStyle === 'lyrics' && activeMusic && currentLyricsData.length === 0 && !isLyricsLoading) {
    fetchSongLyrics(activeMusic);
  }
};

// Initial apply of saved music player style
setTimeout(() => {
  if (typeof window.changeMusicPlayerStyle === 'function') {
    window.changeMusicPlayerStyle(musicSettings.playerStyle || 'vinyl');
  }
}, 100);

// Universal Click/Tap Audio & YouTube Unlocker (Fixes Browser Autoplay Block)
function unlockMediaAutoplay() {
  if (window.sounds && window.sounds.ctx && window.sounds.ctx.state === 'suspended') {
    window.sounds.ctx.resume();
  }
  if (ytPlayer && ytPlayer.unMute) {
    try {
      ytPlayer.unMute();
      if (isMusicPlaying && activeMusic && ytPlayer.getPlayerState && ytPlayer.getPlayerState() !== 1) {
        ytPlayer.playVideo();
      }
    } catch(e) {}
  }
}
document.addEventListener('click', unlockMediaAutoplay, { passive: true });
document.addEventListener('touchstart', unlockMediaAutoplay, { passive: true });
document.addEventListener('keydown', unlockMediaAutoplay, { passive: true });


// ═════════════════════════════════════════════════════════════════════════════
// 12. BETWEENLE (TEBAK ABJAD KAMUS A-Z) - AUTHENTIC OFFICIAL RULES ENGINE
// ═════════════════════════════════════════════════════════════════════════════

let betweenleLetterLength = 5; // Default 5 huruf (bisa 4, 5, 6, 7)
let betweenleLengthMode = 'fixed'; // 'fixed' atau 'random'
let betweenleRound = 1;
let betweenleSecretWord = '';
let betweenleSecretIndex = -1;
let betweenleTopBound = null; // { word, index, isInitial, user, avatar }
let betweenleBottomBound = null; // { word, index, isInitial, user, avatar }
let betweenleInitialWordsCount = 0;
let betweenleCurrentWordsCount = 0;
let betweenleSortedDicts = {}; // cache array terurut per panjang huruf
let betweenleDictMap = {}; // cache Map word -> index untuk O(1) instant lookup
let betweenleGuessedWords = new Set(); // melacak kata yang sudah dievaluasi dalam ronde aktif
let lastBetweenleAudioTime = 0; // debounce throttle untuk SFX audio
let allAvailableBetweenleWords = {}; // shuffle bag per letter length
let betweenleGuessHistory = [];
let betweenleUserCooldown = new Map();
let betweenleIsGameOver = false;
let betweenleGuessCount = 0; // Jumlah tebakan valid yang dievaluasi dalam ronde ini

// Queue untuk animasi tebakan masuk secara berurutan & halus
let betweenleGuessQueue = [];
let betweenleIsAnimating = false;

// Helper: pemutaran audio Betweenle dengan throttle perlindungan audio overlap
function playBetweenleSoundSafely(soundMethodName) {
  if (!window.sounds || typeof window.sounds[soundMethodName] !== 'function') return;
  const now = Date.now();
  if (now - lastBetweenleAudioTime < 120) return; // minimal 120ms antar suara
  lastBetweenleAudioTime = now;
  window.sounds[soundMethodName]();
}

// Membuka dan menutup Modal Cara Bermain Betweenle
function openBetweenleHowToPlay() {
  const modal = document.getElementById('betweenleHowToPlayModal');
  if (modal) modal.style.display = 'flex';
}
window.openBetweenleHowToPlay = openBetweenleHowToPlay;

function closeBetweenleHowToPlay() {
  const modal = document.getElementById('betweenleHowToPlayModal');
  if (modal) modal.style.display = 'none';
}
window.closeBetweenleHowToPlay = closeBetweenleHowToPlay;

// Mendapatkan kamus terurut secara leksikografis (abjad A-Z)
function getBetweenleSortedDict(length) {
  if (betweenleSortedDicts[length] && betweenleSortedDicts[length].length > 50) {
    return betweenleSortedDicts[length];
  }

  const wordSet = new Set();
  if (allValidWords && allValidWords[length] && Array.isArray(allValidWords[length])) {
    for (let i = 0; i < allValidWords[length].length; i++) {
      const w = allValidWords[length][i];
      if (w && w.length === length) wordSet.add(w.trim().toUpperCase());
    }
  }
  if (allTargetWords && allTargetWords[length] && Array.isArray(allTargetWords[length])) {
    for (let i = 0; i < allTargetWords[length].length; i++) {
      const w = allTargetWords[length][i];
      if (w && w.length === length) wordSet.add(w.trim().toUpperCase());
    }
  }
  if (allValidWordsSets && allValidWordsSets[length] && allValidWordsSets[length].size > 0) {
    allValidWordsSets[length].forEach(w => {
      if (w && w.length === length) wordSet.add(w.trim().toUpperCase());
    });
  }
  if (fullValidDictionary && fullValidDictionary.size > 0) {
    fullValidDictionary.forEach(w => {
      if (w && w.length === length) wordSet.add(w.trim().toUpperCase());
    });
  }

  // Filter hanya alfabet murni A-Z dengan panjang yang tepat
  let words = Array.from(wordSet)
    .map(w => w.trim().toUpperCase())
    .filter(w => w.length === length && /^[A-Z]+$/.test(w));

  // PENTING: Urutkan secara leksikografis standar (A ke Z) tanpa localeCompare yang membuat urutan teracak
  words.sort((a, b) => (a < b ? -1 : (a > b ? 1 : 0)));

  if (words.length > 50) {
    betweenleSortedDicts[length] = words;
    const map = new Map();
    for (let i = 0; i < words.length; i++) {
      map.set(words[i], i);
    }
    betweenleDictMap[length] = map;
  }
  console.log(`[Betweenle] Initialized sorted dictionary for length ${length}: ${words.length} words. First: ${words[0]}, Last: ${words[words.length - 1]}`);
  return words;
}

// Helper: pencarian indeks kata instan O(1)
function getBetweenleWordIndex(word, length) {
  if (betweenleDictMap[length]) {
    const idx = betweenleDictMap[length].get(word);
    return idx !== undefined ? idx : -1;
  }
  const dict = getBetweenleSortedDict(length);
  return dict ? dict.indexOf(word) : -1;
}

// Helper: membersihkan antrean dari tebakan yang posisinya sudah berada di luar batas rentang baru
function pruneBetweenleQueue() {
  if (!betweenleTopBound || !betweenleBottomBound || betweenleGuessQueue.length === 0) return;
  const validQueue = [];
  for (let i = 0; i < betweenleGuessQueue.length; i++) {
    const item = betweenleGuessQueue[i];
    // Kata rahasia jackpot jangan pernah di-prune
    if (item.word === betweenleSecretWord) {
      validQueue.push(item);
      continue;
    }
    // Jika posisi tebakan sudah di luar rentang baru:
    if (item.guessIndex <= betweenleTopBound.index || item.guessIndex >= betweenleBottomBound.index) {
      // Masukkan langsung ke feed penonton tanpa menyita antrean visual papan utama
      addBetweenleFeedItem({
        word: item.word,
        user: item.userName,
        badgeType: 'badge-out',
        badgeText: 'LEWAT BATAS',
        pts: 0
      });
    } else {
      validQueue.push(item);
    }
  }
  betweenleGuessQueue = validQueue;
}

// Mengatur panjang huruf (4, 5, 6, 7, atau acak)
function setBetweenleLength(len) {
  if (betweenleIsAnimating) return;
  if (len === 'random') {
    betweenleLengthMode = 'random';
    const options = [4, 5, 6];
    betweenleLetterLength = options[Math.floor(Math.random() * options.length)];
  } else {
    betweenleLengthMode = 'fixed';
    betweenleLetterLength = parseInt(len);
  }

  // Mulai game baru dengan panjang huruf baru
  betweenleGuessQueue = [];
  betweenleIsAnimating = false;
  startBetweenleGame();
}

// Memulai atau me-reset ronde permainan Betweenle sesuai aturan resmi
function startBetweenleGame() {
  // Ambil panjang kata yang diizinkan dari pengaturan game
  try {
    const savedLengths = JSON.parse(localStorage.getItem('allowed_lengths') || '[5,6,7,8]');
    const validBetweenle = savedLengths.filter(l => [4, 5, 6, 7].includes(l));
    if (validBetweenle.length > 0) {
      betweenleLetterLength = validBetweenle[Math.floor(Math.random() * validBetweenle.length)];
    }
  } catch(e) {}

  const activeDict = getBetweenleSortedDict(betweenleLetterLength);
  if (!activeDict || activeDict.length < 10) {
    console.warn(`[Betweenle] Kamus kata belum siap atau sedang dimuat, memuat ulang wordlists...`);
    if (!wordsLoaded) {
      const currentLang = localStorage.getItem('wordle_lang') || 'id';
      loadWordLists(currentLang).then(() => {
        startBetweenleGame();
      }).catch(() => {
        showToast(`Gagal memuat kamus kata Betweenle!`, 3000);
      });
      return;
    }
    showToast(`Kamus kata ${betweenleLetterLength} huruf tidak mencukupi!`, 3000);
    return;
  }

  // Reset flag game over dan antrean
  isGameOver = false;
  betweenleIsGameOver = false;
  isProcessing = false;
  guessQueue = [];
  betweenleGuessQueue = [];
  betweenleIsAnimating = false;
  betweenleGuessCount = 0;
  betweenleUserCooldown.clear();
  if (typeof betweenleGuessedWords !== 'undefined' && betweenleGuessedWords.clear) {
    betweenleGuessedWords.clear();
  }
  if (typeof userGuessDedup !== 'undefined' && userGuessDedup.clear) {
    userGuessDedup.clear();
  }

  // Pilih kata target rahasia dari target words yang umum/dikenal dengan sistem Anti-Pengulangan (Shuffle Bag)
  let chosenWord = '';
  let targetIndex = -1;
  const targetCandidates = (allTargetWords && allTargetWords[betweenleLetterLength] && allTargetWords[betweenleLetterLength].length > 0)
    ? allTargetWords[betweenleLetterLength].filter(w => {
        const idx = activeDict.indexOf(w);
        return idx >= Math.floor(activeDict.length * 0.05) && idx <= Math.floor(activeDict.length * 0.95);
      })
    : [];

  if (targetCandidates.length > 0) {
    if (!allAvailableBetweenleWords[betweenleLetterLength] || allAvailableBetweenleWords[betweenleLetterLength].length === 0) {
      allAvailableBetweenleWords[betweenleLetterLength] = [...targetCandidates];
      shuffleArray(allAvailableBetweenleWords[betweenleLetterLength]);
    }
    chosenWord = allAvailableBetweenleWords[betweenleLetterLength].pop();
    targetIndex = activeDict.indexOf(chosenWord);
  } else {
    // Fallback if no target candidates
    if (!allAvailableBetweenleWords[betweenleLetterLength] || allAvailableBetweenleWords[betweenleLetterLength].length === 0) {
      const minIdx = Math.floor(activeDict.length * 0.1);
      const maxIdx = Math.floor(activeDict.length * 0.9);
      const fallbackCandidates = [];
      for(let i=minIdx; i<=maxIdx; i++) fallbackCandidates.push(activeDict[i]);
      allAvailableBetweenleWords[betweenleLetterLength] = fallbackCandidates;
      shuffleArray(allAvailableBetweenleWords[betweenleLetterLength]);
    }
    chosenWord = allAvailableBetweenleWords[betweenleLetterLength].pop();
    targetIndex = activeDict.indexOf(chosenWord);
  }

  betweenleSecretWord = chosenWord;
  betweenleSecretIndex = targetIndex;

  // Inisialisasi batas awal (A...A) dan batas akhir (Z...Z) sesuai aturan resmi Betweenle
  betweenleTopBound = {
    word: 'A'.repeat(betweenleLetterLength),
    index: -1,
    isInitial: true,
    user: 'Kamus Awal (A...A)',
    avatar: DICT_TOP_ICON
  };

  betweenleBottomBound = {
    word: 'Z'.repeat(betweenleLetterLength),
    index: activeDict.length,
    isInitial: true,
    user: 'Kamus Akhir (Z...Z)',
    avatar: DICT_BOTTOM_ICON
  };

  betweenleInitialWordsCount = activeDict.length;
  betweenleCurrentWordsCount = betweenleInitialWordsCount;

  // Sinkronkan ronde dengan badge ronde di header utama
  const roundNumEl = document.getElementById('roundNumber');
  if (roundNumEl) roundNumEl.textContent = betweenleRound;

  // Sinkronkan data-len pada board dan placeholder host
  const mainBoard = document.querySelector('.betweenle-main-board');
  if (mainBoard) mainBoard.setAttribute('data-len', betweenleLetterLength);
  const hostInput = document.getElementById('hostGuessInput');
  if (hostInput) hostInput.placeholder = `Tebak kata ${betweenleLetterLength} huruf...`;

  resetBetweenleMiddleRow(true);
  renderBetweenleUI();
  console.log(`[Betweenle] Ronde ${betweenleRound} dimulai. Kata Rahasia: "${betweenleSecretWord}" (${betweenleLetterLength}H, idx: ${betweenleSecretIndex}/${activeDict.length}). Rentang awal: ${betweenleTopBound.word} - ${betweenleBottomBound.word} (${betweenleCurrentWordsCount} kata).`);
}

// Merender seluruh elemen antarmuka Betweenle
function renderBetweenleUI() {
  const mainBoard = document.querySelector('.betweenle-main-board');
  if (mainBoard) mainBoard.setAttribute('data-len', betweenleLetterLength);

  // 1. Batas Awal (Top Bound Row: Ubin Kata + Avatar Penebak di Kanan)
  const topRowEl = document.getElementById('betweenleTopRow');
  if (topRowEl && betweenleTopBound) {
    topRowEl.setAttribute('data-len', betweenleLetterLength);
    topRowEl.innerHTML = '';
    for (let i = 0; i < betweenleLetterLength; i++) {
      const tile = document.createElement('div');
      tile.className = 'betweenle-tile';
      tile.textContent = betweenleTopBound.word[i] || '';
      topRowEl.appendChild(tile);
    }
    const topAvatar = document.createElement('img');
    topAvatar.className = 'betweenle-avatar';
    topAvatar.id = 'betweenleTopAvatar';
    topAvatar.src = betweenleTopBound.avatar || DICT_TOP_ICON;
    topAvatar.onerror = function() { this.onerror = null; this.src = DICT_TOP_ICON; };
    topRowEl.appendChild(topAvatar);
  }

  // 2. Baris Tengah (Middle Input Row - dalam kondisi idle)
  if (!betweenleIsAnimating && !betweenleIsGameOver) {
    resetBetweenleMiddleRow();
  }

  // 3. Batas Akhir (Bottom Bound Row: Ubin Kata + Avatar Penebak di Kanan)
  const bottomRowEl = document.getElementById('betweenleBottomRow');
  if (bottomRowEl && betweenleBottomBound) {
    bottomRowEl.setAttribute('data-len', betweenleLetterLength);
    bottomRowEl.innerHTML = '';
    for (let i = 0; i < betweenleLetterLength; i++) {
      const tile = document.createElement('div');
      tile.className = 'betweenle-tile';
      tile.textContent = betweenleBottomBound.word[i] || '';
      bottomRowEl.appendChild(tile);
    }
    const bottomAvatar = document.createElement('img');
    bottomAvatar.className = 'betweenle-avatar';
    bottomAvatar.id = 'betweenleBottomAvatar';
    bottomAvatar.src = betweenleBottomBound.avatar || DICT_BOTTOM_ICON;
    bottomAvatar.onerror = function() { this.onerror = null; this.src = DICT_BOTTOM_ICON; };
    bottomRowEl.appendChild(bottomAvatar);
  }

  // 4. Vertical Range Track (Pin & Dot)
  updateBetweenleTrackUI();

  // 5. Alphabet Strip Tracker (A-Z)
  updateBetweenleAlphabetUI();
}

// Reset baris tengah ke kursor menunggu (dot '•') dengan slot avatar di kanan
function resetBetweenleMiddleRow(force = false) {
  if (betweenleIsGameOver && !force) return;
  const middleRowEl = document.getElementById('betweenleMiddleRow');
  const middleWrapper = document.getElementById('betweenleMiddleWrapper');

  if (middleWrapper) {
    middleWrapper.classList.remove('animating-slide-up', 'animating-slide-down', 'animating-shake', 'animating-win');
    middleWrapper.style.transform = '';
    middleWrapper.style.opacity = '';
  }

  if (middleRowEl) {
    middleRowEl.setAttribute('data-len', betweenleLetterLength);
    middleRowEl.innerHTML = '';
    for (let i = 0; i < betweenleLetterLength; i++) {
      const tile = document.createElement('div');
      tile.className = 'betweenle-tile';
      if (i === 0) {
        tile.classList.add('has-dot');
      }
      middleRowEl.appendChild(tile);
    }
    const middleAvatar = document.createElement('img');
    middleAvatar.className = 'betweenle-avatar idle-hidden';
    middleAvatar.id = 'betweenleMiddleAvatar';
    middleAvatar.src = getHostAvatar();
    middleAvatar.onerror = function() { this.onerror = null; this.src = DEFAULT_HOST_AVATAR; };
    middleRowEl.appendChild(middleAvatar);
  }
}

// Format nilai persentase pada balon pin Betweenle:
// >= 10: bilangan bulat integer (contoh: 71, 12)
// 1.0 s.d 9.9: 1 desimal (contoh: 6.6, 2.7)
// < 1.0: 2 desimal (contoh: 0.83)
function formatBetweenlePinPct(pct) {
  if (pct === null || pct === undefined || isNaN(pct)) return '?';
  if (pct >= 10) return Math.round(pct).toString();
  if (pct >= 1) return pct.toFixed(1);
  return pct.toFixed(2);
}

// Memperbarui posisi slider vertikal dan balon pin persentase kamus
function updateBetweenleTrackUI() {
  const pinTopVal = document.getElementById('betweenlePinTopVal');
  const pinBottomVal = document.getElementById('betweenlePinBottomVal');
  const trackDot = document.getElementById('betweenleTrackDot');

  if (!betweenleTopBound || !betweenleBottomBound) return;
  const activeDict = getBetweenleSortedDict(betweenleLetterLength);
  const totalDictWords = activeDict ? activeDict.length : 1000;

  // Jika ronde baru dimulai dan belum ada tebakan yang masuk: tampilkan tanda '?'
  if (betweenleGuessCount === 0) {
    if (pinTopVal) pinTopVal.textContent = '?';
    if (pinBottomVal) pinBottomVal.textContent = '?';
    if (trackDot) {
      trackDot.style.top = '50%';
      trackDot.classList.remove('is-win');
    }
    return;
  }

  // Jarak persentase (%) terhadap seluruh kamus kata (sesuai aturan resmi Betweenle)
  let distToTop = 0;
  if (betweenleTopBound.isInitial) {
    distToTop = betweenleSecretIndex;
  } else {
    distToTop = Math.max(0, betweenleSecretIndex - betweenleTopBound.index);
  }

  let distToBottom = 0;
  if (betweenleBottomBound.isInitial) {
    distToBottom = Math.max(0, totalDictWords - 1 - betweenleSecretIndex);
  } else {
    distToBottom = Math.max(0, betweenleBottomBound.index - betweenleSecretIndex);
  }

  const topPct = (distToTop / totalDictWords) * 100;
  const bottomPct = (distToBottom / totalDictWords) * 100;

  if (pinTopVal) pinTopVal.textContent = formatBetweenlePinPct(topPct);
  if (pinBottomVal) pinBottomVal.textContent = formatBetweenlePinPct(bottomPct);

  if (trackDot) {
    if (betweenleIsGameOver) {
      trackDot.classList.add('is-win');
    } else {
      trackDot.classList.remove('is-win');
      const sum = topPct + bottomPct;
      if (sum > 0) {
        // Rasio jarak: semakin kecil bottomPct (semakin dekat ke bawah), ratio makin mendekati 1
        const ratio = topPct / sum;
        // Rentang pergerakan dot pada rel vertikal (15% s.d 85% agar pas di antara balon pin)
        const clampedPct = Math.min(85, Math.max(15, 15 + ratio * 70));
        trackDot.style.top = `${clampedPct}%`;
      } else {
        trackDot.style.top = '50%';
      }
    }
  }
}

// Memperbarui deretan huruf abjad A-Z (menyalakan huruf yang masih valid)
function updateBetweenleAlphabetUI() {
  const row1 = document.getElementById('betweenleAlphaRow1');
  const row2 = document.getElementById('betweenleAlphaRow2');
  if (!row1 || !row2 || !betweenleTopBound || !betweenleBottomBound) return;

  const topChar = betweenleTopBound.word[0];
  const bottomChar = betweenleBottomBound.word[0];

  const lettersRow1 = 'ABCDEFGHIJKLM'.split('');
  const lettersRow2 = 'NOPQRSTUVWXYZ'.split('');

  function renderRow(letters, targetEl) {
    targetEl.innerHTML = '';
    letters.forEach(ch => {
      const chip = document.createElement('div');
      chip.className = 'betweenle-alpha-chip';
      chip.textContent = ch;

      if (ch === topChar || ch === bottomChar) {
        chip.classList.add('is-bound');
      } else if (ch > topChar && ch < bottomChar) {
        chip.classList.add('in-range');
      } else {
        chip.classList.add('out-of-range');
      }

      targetEl.appendChild(chip);
    });
  }

  renderRow(lettersRow1, row1);
  renderRow(lettersRow2, row2);
}

// Memperbarui teks petunjuk kedekatan
function updateBetweenleProximityHint() {
  const proxEl = document.getElementById('betweenleProximityText');
  if (!proxEl) return;

  if (betweenleIsGameOver) {
    proxEl.textContent = `KATA RAHASIA BERHASIL DITEMUKAN: ${betweenleSecretWord}!`;
    return;
  }

  if (betweenleGuessCount === 0) {
    proxEl.textContent = `TEBAK KATA ${betweenleLetterLength} HURUF DI ANTARA ${betweenleTopBound.word} - ${betweenleBottomBound.word}`;
    return;
  }

  const activeDict = getBetweenleSortedDict(betweenleLetterLength);
  const totalDictWords = activeDict ? activeDict.length : 1000;
  const distToTop = betweenleTopBound.isInitial ? betweenleSecretIndex : (betweenleSecretIndex - betweenleTopBound.index);
  const distToBottom = betweenleBottomBound.isInitial ? (totalDictWords - 1 - betweenleSecretIndex) : (betweenleBottomBound.index - betweenleSecretIndex);

  if (distToTop < distToBottom) {
    proxEl.textContent = `TITIK ORANYE: LEBIH DEKAT KE KATA ATAS (${distToTop} kata jaraknya)`;
  } else if (distToBottom < distToTop) {
    proxEl.textContent = `TITIK ORANYE: LEBIH DEKAT KE KATA BAWAH (${distToBottom} kata jaraknya)`;
  } else {
    proxEl.textContent = `TITIK ORANYE: TEPAT DI TENGAH-TENGAH (${betweenleCurrentWordsCount} kata tersisa)`;
  }
}

// Menambahkan entri ke feed tebakan penonton (opsional jika feed diaktifkan)
function addBetweenleFeedItem(item) {
  const feedList = document.getElementById('betweenleFeedList');
  if (!feedList) return;

  const emptyEl = feedList.querySelector('.betweenle-feed-empty');
  if (emptyEl) emptyEl.remove();

  const el = document.createElement('div');
  el.className = 'betweenle-feed-item';
  el.innerHTML = `
    <div class="betweenle-feed-left">
      <span class="betweenle-feed-word">${item.word}</span>
      <span class="betweenle-feed-user">${item.user}</span>
    </div>
    <div class="betweenle-feed-right">
      <span class="betweenle-feed-badge ${item.badgeType}">${item.badgeText}</span>
      ${item.pts > 0 ? `<span class="betweenle-feed-pts">+${item.pts} Pts</span>` : ''}
    </div>
  `;

  feedList.insertBefore(el, feedList.firstChild);

  while (feedList.children.length > 7) {
    feedList.removeChild(feedList.lastChild);
  }
}

// Menerima tebakan dan memasukkannya ke antrean animasi
function processBetweenleGuess(guessWord, userData) {
  if (currentGameMode !== 'betweenle' || betweenleIsGameOver) return;
  if (!guessWord) return;

  const word = guessWord.trim().toUpperCase();
  const userId = userData.userId || userData.uniqueId || 'host';
  const userName = userData.nickname || userData.uniqueId || 'Pemain';
  const isHost = (userId === 'host' || userId === 'host_offline' || (typeof userId === 'string' && userId.toLowerCase().includes('host')));
  const userAvatar = (userData && userData.profilePictureUrl && userData.profilePictureUrl !== 'assets/bg_nature.png') ? userData.profilePictureUrl : (isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
  const now = Date.now();

  // 1. Validasi panjang huruf harus sesuai panjang aktif
  if (word.length !== betweenleLetterLength) {
    if (isHost) {
      showToast(`Kata harus ${betweenleLetterLength} huruf!`, 2000);
    }
    return;
  }

  // 2. Cooldown 1 detik per user (kecuali host)
  if (!isHost) {
    if (betweenleUserCooldown.has(userId) && (now - betweenleUserCooldown.get(userId) < 1000)) {
      return;
    }
    betweenleUserCooldown.set(userId, now);
  }

  // 3. Deduplikasi kata: tolak jika kata sudah pernah dievaluasi di ronde ini
  if (betweenleGuessedWords.has(word)) {
    if (isHost) {
      showToast(`"${word}" sudah pernah ditebak!`, 2000);
    }
    return;
  }

  // 4. Validasi kamus baku (pencarian instan O(1))
  const guessIndex = getBetweenleWordIndex(word, betweenleLetterLength);
  if (guessIndex === -1) {
    if (isHost) {
      showToast(`"${word}" bukan kata baku di kamus!`, 2500);
      if (!betweenleIsAnimating && betweenleGuessQueue.length === 0) {
        triggerBetweenleShakeAnimation({
          word,
          userName,
          userAvatar,
          userId,
          isHost
        }, `"${word}" bukan kata baku di kamus!`);
      }
    }
    // Jika dari chat penonton: abaikan secara senyap tanpa merusak animasi papan
    return;
  }

  // Tandai kata sudah ditebak di ronde ini
  betweenleGuessedWords.add(word);

  // Masukkan tebakan ke antrean animasi
  betweenleGuessQueue.push({
    word,
    guessIndex,
    userId,
    userName,
    userAvatar,
    userData,
    isHost
  });

  triggerBetweenleNextAnimation();
}

// Menangani tebakan di luar rentang aktif secara adaptif
function handleBetweenleOutOfRange(item, toastMsg, nextDelay = 80) {
  const isHost = (item.userId === 'host' || item.userId === 'host_offline' || (typeof item.userId === 'string' && item.userId.toLowerCase().includes('host')));
  if (isHost && toastMsg) {
    showToast(toastMsg, 2500);
  }

  // Jika antrean sedang ada kata lain yang mengantre, jangan tahan papan dengan getaran panjang
  if (betweenleGuessQueue.length > 0) {
    playBetweenleSoundSafely('playBetweenleOutOfRange');
    addBetweenleFeedItem({
      word: item.word,
      user: item.userName,
      badgeType: 'badge-out',
      badgeText: 'LEWAT BATAS',
      pts: 0
    });
    betweenleIsAnimating = false;
    resetBetweenleMiddleRow();
    setTimeout(triggerBetweenleNextAnimation, nextDelay);
  } else {
    // Antrean santai: jalankan getar papan visual estetik
    triggerBetweenleShakeAnimation(item, toastMsg);
  }
}

// Mengeksekusi animasi tebakan satu per satu secara adaptif, berurutan & halus
function triggerBetweenleNextAnimation() {
  if (betweenleIsAnimating || betweenleGuessQueue.length === 0 || betweenleIsGameOver) {
    return;
  }

  const item = betweenleGuessQueue.shift();
  betweenleIsAnimating = true;

  const middleWrapper = document.getElementById('betweenleMiddleWrapper');
  const middleRowEl = document.getElementById('betweenleMiddleRow');
  const guessMeta = document.getElementById('betweenleGuessMeta');
  const guessAvatar = document.getElementById('betweenleGuessAvatar');
  const guessUser = document.getElementById('betweenleGuessUser');
  const guessStatus = document.getElementById('betweenleGuessStatus');

  // Kecepatan adaptif berdasarkan jumlah antrean (Adaptive Pacing)
  const queueLen = betweenleGuessQueue.length;
  let previewDelay = 350;
  let slideDuration = 400;
  let nextDelay = 80;

  if (queueLen >= 4) {
    previewDelay = 60;
    slideDuration = 120;
    nextDelay = 15;
  } else if (queueLen >= 2) {
    previewDelay = 150;
    slideDuration = 220;
    nextDelay = 30;
  }

  if (middleWrapper) {
    middleWrapper.style.animationDuration = `${slideDuration}ms`;
  }

  // 1. Masukkan kata ke baris tengah dengan ubin oranye
  const effectiveAvatar = item.userAvatar || (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
  if (guessAvatar) {
    guessAvatar.src = effectiveAvatar;
    guessAvatar.onerror = function() { this.onerror = null; this.src = (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR); };
  }
  if (guessUser) guessUser.textContent = item.userName;
  if (guessStatus) guessStatus.textContent = '';
  if (guessMeta) guessMeta.style.opacity = '1';

  if (middleRowEl) {
    middleRowEl.innerHTML = '';
    for (let i = 0; i < item.word.length; i++) {
      const tile = document.createElement('div');
      tile.className = 'betweenle-tile filled-tile';
      tile.textContent = item.word[i];
      middleRowEl.appendChild(tile);
    }
    const middleAvatar = document.createElement('img');
    middleAvatar.className = 'betweenle-avatar spring-in';
    middleAvatar.id = 'betweenleMiddleAvatar';
    middleAvatar.src = effectiveAvatar;
    middleAvatar.onerror = function() { this.onerror = null; this.src = (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR); };
    middleRowEl.appendChild(middleAvatar);
  }

  // Jeda visual adaptif agar tebakan oranye terlihat sebelum bergerak
  setTimeout(() => {
    // KASUS A: KEMENANGAN / JACKPOT!
    if (item.word === betweenleSecretWord) {
      betweenleIsGameOver = true;
      betweenleIsAnimating = true;
      betweenleGuessCount++;
      const jackpotPts = 25;

      // Pastikan ubin tengah berisi kata rahasia yang tepat & terkunci hijau (tidak kosong)
      if (middleRowEl) {
        middleRowEl.innerHTML = '';
        for (let i = 0; i < item.word.length; i++) {
          const tile = document.createElement('div');
          tile.className = 'betweenle-tile filled-tile win-tile';
          tile.textContent = item.word[i];
          middleRowEl.appendChild(tile);
        }
        const middleAvatar = document.createElement('img');
        middleAvatar.className = 'betweenle-avatar spring-in';
        middleAvatar.id = 'betweenleMiddleAvatar';
        middleAvatar.src = effectiveAvatar;
        middleAvatar.onerror = function() { this.onerror = null; this.src = (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR); };
        middleRowEl.appendChild(middleAvatar);
      }

      if (middleWrapper) {
        middleWrapper.classList.remove('animating-slide-up', 'animating-slide-down', 'animating-shake');
        middleWrapper.classList.add('animating-win');
      }
      const trackDot = document.getElementById('betweenleTrackDot');
      if (trackDot) trackDot.classList.add('is-win');

      if (typeof addPoints === 'function' && item.userData) {
        addPoints(item.userData, jackpotPts);
        recordWin(item.userData.uniqueId || item.userData.nickname);
      }
      playBetweenleSoundSafely('playBetweenleWin');

      addBetweenleFeedItem({
        word: item.word,
        user: item.userName,
        badgeType: 'badge-win',
        badgeText: 'MENANG!',
        pts: jackpotPts
      });

      showToast(`${item.userName} MENEBAK TEPAT: ${item.word}! (+${jackpotPts} Poin)`, 4000);
      updateBetweenleTrackUI();
      updateBetweenleProximityHint();

      // Tampilkan Win Overlay estetis setelah ubin hijau beranimasi (1.2 detik)
      setTimeout(() => {
        const winAvatar = document.getElementById('winAvatar');
        if (winAvatar) {
          const effectiveAvatar = item.userAvatar || (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
          winAvatar.src = effectiveAvatar;
          winAvatar.onerror = function() { this.onerror = null; this.src = (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR); };
        }
        const winName = document.getElementById('winName');
        if (winName) winName.textContent = item.userName;
        lastRoundWinner = item.userData || { nickname: item.userName, profilePictureUrl: item.userAvatar };
        lastRoundTargetWord = betweenleSecretWord;
        const winPts = document.getElementById('winPts');
        if (winPts) winPts.innerHTML = `🪙 +${jackpotPts} Pts`;
        const winWord = document.getElementById('winWord');
        if (winWord) {
          winWord.style.display = '';
          winWord.textContent = betweenleSecretWord;
        }

        triggerWinTransition(4500, false);
      }, 1200);
      return;
    }

    if (betweenleIsGameOver) {
      betweenleIsAnimating = false;
      return;
    }

    // KASUS B: MEMPERSEMPIT BATAS AWAL (Meluncur ke ATAS)
    if (item.guessIndex < betweenleSecretIndex) {
      if (item.guessIndex > betweenleTopBound.index) {
        betweenleGuessCount++;

        if (middleWrapper) middleWrapper.classList.add('animating-slide-up');

        setTimeout(() => {
          betweenleTopBound = {
            word: item.word,
            index: item.guessIndex,
            isInitial: false,
            user: item.userName,
            avatar: item.userAvatar
          };
          betweenleCurrentWordsCount = betweenleBottomBound.index - betweenleTopBound.index - 1;

          // Bersihkan sisa antrean yang sudah di luar rentang baru
          pruneBetweenleQueue();

          if (betweenleCurrentWordsCount <= 10) {
            playBetweenleSoundSafely('playBetweenleCloseRange');
          } else {
            playBetweenleSoundSafely('playBetweenleNarrow');
          }

          addBetweenleFeedItem({
            word: item.word,
            user: item.userName,
            badgeType: 'badge-narrow-top',
            badgeText: 'BATAS AWAL',
            pts: 0
          });

          // Efek flash pop pada baris batas atas
          const topWrapper = document.querySelector('.top-bound-wrapper');
          if (topWrapper) {
            topWrapper.classList.add('bound-flashing');
            setTimeout(() => topWrapper.classList.remove('bound-flashing'), 400);
          }

          betweenleIsAnimating = false;
          if (middleWrapper) {
            middleWrapper.classList.remove('animating-slide-up');
            middleWrapper.style.animationDuration = '';
          }
          resetBetweenleMiddleRow();
          renderBetweenleUI();

          setTimeout(triggerBetweenleNextAnimation, nextDelay);
        }, slideDuration);
        return;
      } else {
        // Lewat Batas Awal (Di luar rentang)
        handleBetweenleOutOfRange(item, `"${item.word}" sebelum batas awal "${betweenleTopBound.word}"`, nextDelay);
        return;
      }
    }

    // KASUS C: MEMPERSEMPIT BATAS AKHIR (Meluncur ke BAWAH)
    if (item.guessIndex > betweenleSecretIndex) {
      if (item.guessIndex < betweenleBottomBound.index) {
        betweenleGuessCount++;

        if (middleWrapper) middleWrapper.classList.add('animating-slide-down');

        setTimeout(() => {
          betweenleBottomBound = {
            word: item.word,
            index: item.guessIndex,
            isInitial: false,
            user: item.userName,
            avatar: item.userAvatar
          };
          betweenleCurrentWordsCount = betweenleBottomBound.index - betweenleTopBound.index - 1;

          // Bersihkan sisa antrean yang sudah di luar rentang baru
          pruneBetweenleQueue();

          if (betweenleCurrentWordsCount <= 10) {
            playBetweenleSoundSafely('playBetweenleCloseRange');
          } else {
            playBetweenleSoundSafely('playBetweenleNarrow');
          }

          addBetweenleFeedItem({
            word: item.word,
            user: item.userName,
            badgeType: 'badge-narrow-bottom',
            badgeText: 'BATAS AKHIR',
            pts: 0
          });

          // Efek flash pop pada baris batas bawah
          const bottomWrapper = document.querySelector('.bottom-bound-wrapper');
          if (bottomWrapper) {
            bottomWrapper.classList.add('bound-flashing');
            setTimeout(() => bottomWrapper.classList.remove('bound-flashing'), 400);
          }

          betweenleIsAnimating = false;
          if (middleWrapper) {
            middleWrapper.classList.remove('animating-slide-down');
            middleWrapper.style.animationDuration = '';
          }
          resetBetweenleMiddleRow();
          renderBetweenleUI();

          setTimeout(triggerBetweenleNextAnimation, nextDelay);
        }, slideDuration);
        return;
      } else {
        // Lewat Batas Akhir (Di luar rentang)
        handleBetweenleOutOfRange(item, `"${item.word}" sesudah batas akhir "${betweenleBottomBound.word}"`, nextDelay);
        return;
      }
    }
  }, previewDelay);
}

// Animasi getar untuk tebakan di luar rentang atau tidak valid saat antrean tenang
function triggerBetweenleShakeAnimation(item, toastMsg) {
  if (betweenleIsGameOver) return;
  betweenleIsAnimating = true;

  const middleWrapper = document.getElementById('betweenleMiddleWrapper');
  const middleRowEl = document.getElementById('betweenleMiddleRow');

  if (middleRowEl && item && item.word) {
    middleRowEl.innerHTML = '';
    for (let i = 0; i < item.word.length; i++) {
      const tile = document.createElement('div');
      tile.className = 'betweenle-tile';
      tile.textContent = item.word[i];
      middleRowEl.appendChild(tile);
    }
    const middleAvatar = document.createElement('img');
    middleAvatar.className = 'betweenle-avatar';
    middleAvatar.id = 'betweenleMiddleAvatar';
    const effectiveAvatar = item.userAvatar || (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
    middleAvatar.src = effectiveAvatar;
    middleAvatar.onerror = function() { this.onerror = null; this.src = (item.isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR); };
    middleRowEl.appendChild(middleAvatar);
  }

  if (middleWrapper) {
    middleWrapper.classList.add('animating-shake');
    middleWrapper.style.animationDuration = '';
  }

  playBetweenleSoundSafely('playBetweenleOutOfRange');

  addBetweenleFeedItem({
    word: item.word,
    user: item.userName,
    badgeType: 'badge-out',
    badgeText: 'LEWAT BATAS',
    pts: 0
  });

  const isHost = (item.userId === 'host' || item.userId === 'host_offline' || (typeof item.userId === 'string' && item.userId.toLowerCase().includes('host')));
  if (isHost && toastMsg) {
    showToast(toastMsg, 2500);
  }

  const shakeDuration = (betweenleGuessQueue.length > 0) ? 250 : 500;

  setTimeout(() => {
    resetBetweenleMiddleRow();
    betweenleIsAnimating = false;
    setTimeout(triggerBetweenleNextAnimation, (betweenleGuessQueue.length > 0) ? 30 : 100);
  }, shakeDuration);
}

// Inisialisasi sinkronisasi Avatar Host saat halaman siap
if (typeof syncHostAvatarUI === 'function') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncHostAvatarUI);
  } else {
    syncHostAvatarUI();
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// 13. CASCADLE GAME ENGINE (RANTAI 5 KATA: 3-7 HURUF & CASCADING CLUES)
// ═════════════════════════════════════════════════════════════════════════════

let cascadleRound = 1;
let cascadleCurrentLevel = 3; // 3, 4, 5, 6, 7
let cascadleTargets = {}; // { 3: "...", 4: "...", 5: "...", 6: "...", 7: "..." }
let cascadleGuesses = []; // [{ word, length, level, userData, colors }]
let cascadleSolvedWords = []; // [{ level, word, userName, userAvatar, userData, points }]
let cascadleIsGameOver = false;
let cascadleIsAnimating = false;
let cascadleShowcaseTimer = null;
let cascadleUserCooldown = new Map();

// Helper: hitung jumlah huruf yang beririsan (overlap) antara kata lama dan kata baru
function getWordOverlapScore(oldWord, newWord) {
  const letters = newWord.split('');
  let matches = 0;
  for (let i = 0; i < oldWord.length; i++) {
    const idx = letters.indexOf(oldWord[i]);
    if (idx !== -1) {
      matches++;
      letters.splice(idx, 1);
    }
  }
  return matches;
}

// Mulai atau reset ronde permainan Cascadle
function startCascadleGame() {
  if (!wordsLoaded) {
    const currentLang = localStorage.getItem('wordle_lang') || 'id';
    loadWordLists(currentLang).then(() => {
      startCascadleGame();
    }).catch(() => {
      showToast('Gagal memuat kamus kata Cascadle!', 3000);
    });
    return;
  }

  // Pilih rantai 5 kata berjenjang 3-7 huruf dengan overlap huruf yang maksimal
  cascadleTargets = {};

  // Level 1: 3 huruf
  const pool3 = (allTargetWords[3] && allTargetWords[3].length > 0) ? allTargetWords[3] : allValidWords[3];
  if (!pool3 || pool3.length === 0) {
    showToast('Kamus 3 huruf tidak tersedia!', 3000);
    return;
  }
  const w3 = pool3[Math.floor(Math.random() * pool3.length)].trim().toUpperCase();
  cascadleTargets[3] = w3;

  // Level 2 sampai 5 (4, 5, 6, 7 huruf)
  let prevWord = w3;
  for (let len = 4; len <= 7; len++) {
    const pool = (allTargetWords[len] && allTargetWords[len].length > 0) ? allTargetWords[len] : allValidWords[len];
    if (pool && pool.length > 0) {
      // Cari kata-kata dengan overlap huruf terbesar dengan kata sebelumnya
      let bestCandidates = [];
      let maxOverlap = 0;

      // Sample hingga 300 kandidat acak untuk performa instan
      const sampleSize = Math.min(pool.length, 300);
      for (let i = 0; i < sampleSize; i++) {
        const candidate = pool[Math.floor(Math.random() * pool.length)].trim().toUpperCase();
        if (/^[A-Z]+$/.test(candidate) && candidate.length === len) {
          const score = getWordOverlapScore(prevWord, candidate);
          if (score > maxOverlap) {
            maxOverlap = score;
            bestCandidates = [candidate];
          } else if (score === maxOverlap) {
            bestCandidates.push(candidate);
          }
        }
      }

      if (bestCandidates.length > 0) {
        prevWord = bestCandidates[Math.floor(Math.random() * bestCandidates.length)];
      } else {
        prevWord = pool[Math.floor(Math.random() * pool.length)].trim().toUpperCase();
      }
      cascadleTargets[len] = prevWord;
    }
  }

  cascadleCurrentLevel = 3;
  cascadleGuesses = [];
  cascadleSolvedWords = [];
  cascadleIsGameOver = false;
  cascadleIsAnimating = false;
  if (cascadleShowcaseTimer) {
    clearInterval(cascadleShowcaseTimer);
    cascadleShowcaseTimer = null;
  }
  cascadleUserCooldown.clear();
  if (typeof userGuessDedup !== 'undefined' && userGuessDedup.clear) {
    userGuessDedup.clear();
  }

  console.log(`[Cascadle] Ronde ${cascadleRound} dimulai. Target Chain: 3H="${cascadleTargets[3]}", 4H="${cascadleTargets[4]}", 5H="${cascadleTargets[5]}", 6H="${cascadleTargets[6]}", 7H="${cascadleTargets[7]}"`);

  renderCascadleUI();
}

// Algoritma pewarnaan Wordle murni: mendukung tebakan yang lebih pendek dari target (Cascading Clues)
function evaluateCascadleColors(guessWord, targetWord) {
  const guess = guessWord.trim().toUpperCase();
  const target = targetWord.trim().toUpperCase();
  const result = new Array(guess.length).fill('absent');
  const targetFreq = {};

  for (let i = 0; i < target.length; i++) {
    const ch = target[i];
    targetFreq[ch] = (targetFreq[ch] || 0) + 1;
  }

  // Pass 1: Huruf tepat di posisi yang sama (Green / Correct)
  for (let i = 0; i < guess.length; i++) {
    if (i < target.length && guess[i] === target[i]) {
      result[i] = 'correct';
      targetFreq[guess[i]]--;
    }
  }

  // Pass 2: Huruf ada di kata target tapi posisi berbeda (Yellow / Present)
  for (let i = 0; i < guess.length; i++) {
    if (result[i] !== 'correct') {
      const ch = guess[i];
      if (targetFreq[ch] && targetFreq[ch] > 0) {
        result[i] = 'present';
        targetFreq[ch]--;
      }
    }
  }

  return result;
}

// Validasi Hard Mode & Ultra Hard Mode khusus untuk alur kata bertingkat Cascadle
function validateCascadleHardMode(guessWord) {
  if (typeof hardModeState === 'undefined' || hardModeState === 'off' || cascadleGuesses.length === 0) {
    return { valid: true };
  }

  const currentTarget = cascadleTargets[cascadleCurrentLevel];
  if (!currentTarget) return { valid: true };

  // Periksa terhadap semua tebakan sebelumnya yang dievaluasi ke target aktif saat ini
  for (const past of cascadleGuesses) {
    const pastColors = evaluateCascadleColors(past.word, currentTarget);
    const newLetters = guessWord.split('');

    // ── 1. ULTRA HARD MODE ──
    if (hardModeState === 'ultra') {
      // a) Huruf yang 100% abu-abu di kata ini tidak boleh dipakai lagi
      const completelyGray = new Set();
      for (let i = 0; i < past.word.length; i++) {
        if (pastColors[i] === 'absent') {
          let hasMatch = false;
          for (let j = 0; j < past.word.length; j++) {
            if (past.word[j] === past.word[i] && (pastColors[j] === 'correct' || pastColors[j] === 'present')) {
              hasMatch = true;
              break;
            }
          }
          if (!hasMatch) completelyGray.add(past.word[i]);
        }
      }

      for (let i = 0; i < guessWord.length; i++) {
        if (completelyGray.has(guessWord[i])) {
          return {
            valid: false,
            msg: `Huruf "${guessWord[i]}" (abu-abu) tidak boleh digunakan lagi!`
          };
        }
      }

      // b) Huruf kuning tidak boleh ditaruh di posisi yang sama saat kuning
      for (let i = 0; i < Math.min(past.word.length, guessWord.length); i++) {
        if (pastColors[i] === 'present' && guessWord[i] === past.word[i]) {
          return {
            valid: false,
            msg: `Huruf "${past.word[i]}" kuning di posisi ke-${i+1}, harus dipindah ke posisi lain!`
          };
        }
      }
    }

    // ── 2. HARD MODE (Greens & Yellows) ──
    // a) Huruf Hijau: jika posisi i hijau, tebakan baru harus sama di posisi tersebut
    for (let i = 0; i < Math.min(past.word.length, guessWord.length); i++) {
      if (pastColors[i] === 'correct') {
        if (newLetters[i] !== past.word[i]) {
          return {
            valid: false,
            msg: `Huruf ke-${i+1} harus "${past.word[i]}" (Petunjuk dari "${past.word}")!`
          };
        }
        newLetters[i] = null;
      }
    }

    // b) Huruf Kuning: huruf kuning harus tetap disertakan di tebakan baru
    for (let i = 0; i < past.word.length; i++) {
      if (pastColors[i] === 'present') {
        const ch = past.word[i];
        if (!newLetters.includes(ch)) {
          return {
            valid: false,
            msg: `Harus mengandung huruf "${ch}" (Petunjuk dari "${past.word}")!`
          };
        }
        newLetters[newLetters.indexOf(ch)] = null;
      }
    }
  }

  return { valid: true };
}

// Memproses tebakan masuk untuk mode Cascadle
function processCascadleGuess(guessWord, userData) {
  if (currentGameMode !== 'cascadle' || cascadleIsGameOver || cascadleIsAnimating) return;
  if (!guessWord) return;

  const word = guessWord.trim().toUpperCase();
  const userId = userData.userId || userData.uniqueId || 'host';
  const userName = userData.nickname || userData.uniqueId || 'Pemain';
  const isHost = (userId === 'host' || userId === 'host_offline' || (typeof userId === 'string' && userId.toLowerCase().includes('host')));
  const userAvatar = (userData && userData.profilePictureUrl && userData.profilePictureUrl !== 'assets/bg_nature.png') ? userData.profilePictureUrl : (isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
  const now = Date.now();

  // 1. Validasi panjang kata harus tepat sama dengan level aktif
  if (word.length !== cascadleCurrentLevel) {
    if (isHost) {
      showToast(`Kata harus ${cascadleCurrentLevel} huruf!`, 2000);
    }
    return;
  }

  // 2. Cooldown 1 detik per penonton
  if (!isHost) {
    if (cascadleUserCooldown.has(userId) && (now - cascadleUserCooldown.get(userId) < 1000)) {
      return;
    }
    cascadleUserCooldown.set(userId, now);
  }

  // 3. Validasi kamus kata
  const validSet = allValidWordsSets[cascadleCurrentLevel];
  const isValid = (validSet && validSet.size > 0) ? validSet.has(word) : (allValidWords[cascadleCurrentLevel] && allValidWords[cascadleCurrentLevel].includes(word));
  if (!isValid) {
    if (isHost) {
      showToast(`"${word}" bukan kata baku di kamus!`, 2000);
    }
    // Shake active input row
    const activeRow = document.querySelector('.cascadle-row.active-input');
    if (activeRow) {
      activeRow.classList.add('animating-shake');
      setTimeout(() => activeRow.classList.remove('animating-shake'), 450);
    }
    return;
  }

  // 3b. Validasi Hard Mode & Ultra Hard Mode
  if (typeof hardModeState !== 'undefined' && hardModeState !== 'off') {
    const hmCheck = validateCascadleHardMode(word);
    if (!hmCheck.valid) {
      if (window.sounds && typeof window.sounds.playInvalid === 'function') {
        window.sounds.playInvalid();
      }
      if (window.playHostAudio) playHostAudio('invalid');

      if (isHost) {
        showToast(hmCheck.msg, 2500);
      }

      const activeRow = document.querySelector('.cascadle-row.active-input');
      if (activeRow) {
        activeRow.classList.add('animating-shake');
        setTimeout(() => activeRow.classList.remove('animating-shake'), 450);
      }
      return;
    }
  }

  // 4. Hitung warna tebakan terhadap target aktif
  const currentTarget = cascadleTargets[cascadleCurrentLevel];
  const colors = evaluateCascadleColors(word, currentTarget);

  const guessRecord = {
    word,
    length: word.length,
    level: cascadleCurrentLevel,
    userName,
    userAvatar,
    userData,
    colors
  };
  cascadleGuesses.unshift(guessRecord);
  // Tandai sebagai tebakan baru agar renderCascadleUI() bisa memberi animasi flip
  cascadleGuesses[0]._isNew = true;

  if (window.sounds && typeof window.sounds.playLetter === 'function') {
    window.sounds.playLetter();
  }

  renderCascadleUI();

  // 5. Cek apakah tebakan tepat sama dengan target level saat ini
  if (word === currentTarget) {
    // Poin berbeda per panjang huruf: makin panjang kata, makin besar hadiahnya
    const CASCADLE_LEVEL_POINTS = { 3: 3, 4: 5, 5: 7, 6: 10, 7: 20 };
    const ptsAwarded = CASCADLE_LEVEL_POINTS[cascadleCurrentLevel] || 5;
    const isJackpot = (cascadleCurrentLevel === 7);

    cascadleSolvedWords.push({
      level: cascadleCurrentLevel,
      word,
      userName,
      userAvatar,
      userData,
      points: ptsAwarded
    });

    if (!isJackpot) {
      // ── LEVEL INTERMEDIATE BERHASIL TERPECAHKAN (3H / 4H / 5H / 6H) ──
      cascadleIsAnimating = true;

      if (typeof addPoints === 'function' && userData) {
        addPoints(userData, ptsAwarded);
        recordWin(userData.uniqueId || userData.nickname);
      }
      showFloatingPoints(ptsAwarded, 'cascadleContainer');

      if (window.sounds && typeof window.sounds.playCascadleLevelUp === 'function') {
        window.sounds.playCascadleLevelUp();
      }

      const nextLevel = cascadleCurrentLevel + 1;
      showToast(`🎉 ${userName} MENEBAK TEPAT: ${word}! (+${ptsAwarded} Poin) ➔ Level ${nextLevel} (${nextLevel} Huruf) Terbuka!`, 3500);

      // Hitung durasi sampai semua ubin selesai flip hijau penuh
      const stepDelay = 90;
      const flipFinishedDelay = (word.length - 1) * stepDelay + 400;

      // 1. Beri efek bounce selebrasi pada ubin jawaban yang baru saja tertebak hijau semua
      setTimeout(() => {
        const boardArea = document.getElementById('cascadleBoardArea');
        if (boardArea) {
          const latestRow = boardArea.querySelector('.cascadle-row:not(.active-input)');
          if (latestRow) {
            const tiles = latestRow.querySelectorAll('.cascadle-tile');
            tiles.forEach((t, tIdx) => {
              setTimeout(() => {
                t.classList.add('cascadle-bounce');
              }, tIdx * 90);
            });
          }
        }
      }, flipFinishedDelay);

      // 2. Berikan jeda selebrasi agar penonton puas melihat kotak hijau sebelum flip menjadi clue kata berikutnya
      const totalDelayBeforeClue = flipFinishedDelay + 1600; // ~2.3 - 2.5 detik total

      setTimeout(() => {
        // Naik ke level berikutnya sekarang
        cascadleCurrentLevel++;

        // Cascading Recoloring: Re-evaluasi seluruh tebakan lama terhadap kata target baru dengan animasi flip!
        triggerCascadleRecolor();
        cascadleIsAnimating = false;
      }, totalDelayBeforeClue);

    } else {
      // ── LEVEL 7 (FINAL / JACKPOT CASCADLE SELESAI!) ──
      cascadleIsGameOver = true;
      cascadleIsAnimating = true;

      if (typeof addPoints === 'function' && userData) {
        addPoints(userData, ptsAwarded);
        recordWin(userData.uniqueId || userData.nickname);
      }
      lastRoundWinner = userData;
      lastRoundTargetWord = word;
      showFloatingPoints(ptsAwarded, 'cascadleContainer');

      if (window.sounds && typeof window.sounds.playWin === 'function') {
        window.sounds.playWin();
      }

      showToast(`🏆 ${userName} MENYELESAIKAN CASCADLE: ${word}! (+${ptsAwarded} Poin Jackpot!)`, 4500);

      const stepDelay = 90;
      const flipFinishedDelay = (word.length - 1) * stepDelay + 400;

      // Efek bounce selebrasi ubin jackpot
      setTimeout(() => {
        const boardArea = document.getElementById('cascadleBoardArea');
        if (boardArea) {
          const latestRow = boardArea.querySelector('.cascadle-row:not(.active-input)');
          if (latestRow) {
            const tiles = latestRow.querySelectorAll('.cascadle-tile');
            tiles.forEach((t, tIdx) => {
              setTimeout(() => {
                t.classList.add('cascadle-bounce');
              }, tIdx * 90);
            });
          }
        }
      }, flipFinishedDelay);

      // Luncurkan animasi tangga kata kemenangan 3-7 huruf setelah perayaan selesai
      setTimeout(() => {
        launchCascadleVictoryShowcase();
        cascadleIsAnimating = false;
      }, flipFinishedDelay + 1200);
    }
  }
}

// Fitur unik Cascadle: Menghitung ulang dan menganimasikan ubin lama dengan warna baru
function triggerCascadleRecolor() {
  const newTarget = cascadleTargets[cascadleCurrentLevel];
  if (!newTarget) return;

  // Update data warna tiap tebakan lama
  for (let i = 0; i < cascadleGuesses.length; i++) {
    const g = cascadleGuesses[i];
    g.colors = evaluateCascadleColors(g.word, newTarget);
  }

  if (window.sounds && typeof window.sounds.playCascadleRecolor === 'function') {
    window.sounds.playCascadleRecolor();
  }

  // Render ulang UI dan beri animasi flip pada ubin
  renderCascadleUI();

  const boardArea = document.getElementById('cascadleBoardArea');
  if (boardArea) {
    const tiles = boardArea.querySelectorAll('.cascadle-tile:not(.tile-empty)');
    tiles.forEach((t, idx) => {
      t.classList.remove('recoloring-flip');
      void t.offsetWidth; // trigger reflow
      t.style.animationDelay = `${(idx % 12) * 35}ms`;
      t.classList.add('recoloring-flip');
    });
  }
}

// Merender UI papan permainan Cascadle
function renderCascadleUI() {
  const container = document.getElementById('cascadleContainer');
  if (!container || currentGameMode !== 'cascadle') return;

  // 1. Update Stages Progress Bar (3H s/d 7H)
  for (let len = 3; len <= 7; len++) {
    const chip = document.getElementById(`cascadleChip${len}`);
    if (chip) {
      chip.className = 'cascadle-stage-chip';
      const iconSpan = chip.querySelector('.chip-icon');
      if (len < cascadleCurrentLevel) {
        chip.classList.add('completed');
        if (iconSpan) iconSpan.innerHTML = '<i class="fa-solid fa-check"></i>';
      } else if (len === cascadleCurrentLevel) {
        chip.classList.add('active');
        if (iconSpan) iconSpan.innerHTML = '<i class="fa-solid fa-play"></i>';
      } else {
        chip.classList.add('locked');
        if (iconSpan) iconSpan.innerHTML = (len === 7) ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-solid fa-lock"></i>';
      }
    }
  }

  // 2. Render Guess Rows
  const rowsContainer = document.getElementById('cascadleRowsContainer');
  if (!rowsContainer) return;
  rowsContainer.innerHTML = '';

  // 3a. Baris input aktif (placeholder kotak kosong berdenyut) SELALU DI PALING ATAS
  if (!cascadleIsGameOver) {
    const activeRow = document.createElement('div');
    activeRow.className = 'cascadle-row active-input';
    activeRow.setAttribute('data-len', cascadleCurrentLevel);

    const activeTiles = document.createElement('div');
    activeTiles.className = 'cascadle-row-tiles';
    for (let i = 0; i < cascadleCurrentLevel; i++) {
      const tile = document.createElement('div');
      tile.className = 'cascadle-tile tile-empty';
      activeTiles.appendChild(tile);
    }
    activeRow.appendChild(activeTiles);

    const dummyMeta = document.createElement('div');
    dummyMeta.className = 'cascadle-row-meta';
    dummyMeta.innerHTML = `<span style="font-size: 10px; color: #10b981; font-weight: 700;"><i class="fa-solid fa-angles-left"></i> ${cascadleCurrentLevel}H</span>`;
    activeRow.appendChild(dummyMeta);

    rowsContainer.appendChild(activeRow);
  }

  // 3b. Render Tebakan dari yang terbaru ke terlama (seperti Wordle)
  let lastSeenLevel = cascadleCurrentLevel;
  cascadleGuesses.forEach((g, idx) => {
    // Sisipkan divider jika level tebakan berpindah ke level yang lebih awal
    if (g.level < lastSeenLevel) {
      const divider = document.createElement('div');
      divider.className = 'cascadle-level-divider';
      const solvedObj = cascadleSolvedWords.find(s => s.level === g.level);
      const solvedWordText = solvedObj ? `: ${solvedObj.word}` : '';
      divider.innerHTML = `
        <div class="cascadle-divider-line"></div>
        <div class="cascadle-divider-badge"><i class="fa-solid fa-check"></i> LEVEL ${g.level - 2} SELESAI${solvedWordText}</div>
        <div class="cascadle-divider-line"></div>
      `;
      rowsContainer.appendChild(divider);
      lastSeenLevel = g.level;
    }

    const rowEl = document.createElement('div');
    rowEl.className = 'cascadle-row';
    rowEl.setAttribute('data-len', g.length);

    const tilesCol = document.createElement('div');
    tilesCol.className = 'cascadle-row-tiles';

    const flipCfg = getFlipSpeedConfig(0);
    const isNewest = (idx === 0) && g._isNew && flipCfg.shouldFlip;
    const stepDelay = flipCfg.stepDelay || 60;
    const revealOffset = flipCfg.revealOffset || 140;

    for (let i = 0; i < g.length; i++) {
      const tile = document.createElement('div');
      const stateClass = g.colors && g.colors[i] ? `tile-${g.colors[i]}` : 'tile-absent';

      if (isNewest) {
        // Mulai tanpa warna, flip dulu, baru reveal warna
        tile.className = 'cascadle-tile cascadle-flip';
        tile.style.animationDelay = `${i * stepDelay}ms`;
        tile.textContent = g.word[i] || '';

        // Bunyikan flip sound sinkron per huruf (IIFE untuk tangkap nilai i yang benar)
        if (window.sounds && typeof window.sounds.playFlip === 'function') {
          setTimeout(((idx_) => () => window.sounds.playFlip(idx_))(i), i * stepDelay);
        }

        // Reveal warna di titik tengah flip
        const colorRevealDelay = (i * stepDelay) + revealOffset;
        setTimeout(((t, cls) => () => {
          t.classList.add(cls);
        })(tile, stateClass), colorRevealDelay);
      } else {
        tile.className = `cascadle-tile ${stateClass}`;
        tile.textContent = g.word[i] || '';
      }

      tilesCol.appendChild(tile);
    }

    // Hapus flag _isNew setelah semua animasi selesai
    if (isNewest) {
      const totalAnimDuration = (g.length - 1) * stepDelay + 400;
      setTimeout(() => { if (cascadleGuesses[0]) cascadleGuesses[0]._isNew = false; }, totalAnimDuration);
    } else if (g._isNew) {
      g._isNew = false;
    }
    rowEl.appendChild(tilesCol);

    // Meta Avatar & Name
    const metaEl = document.createElement('div');
    metaEl.className = 'cascadle-row-meta';
    const avatarImg = document.createElement('img');
    avatarImg.className = 'cascadle-avatar';
    avatarImg.src = g.userAvatar || DEFAULT_HOST_AVATAR;
    avatarImg.onerror = function() { this.onerror = null; this.src = DEFAULT_HOST_AVATAR; };
    const nameSpan = document.createElement('span');
    nameSpan.className = 'cascadle-user-name';
    nameSpan.textContent = g.userName || 'Pemain';
    nameSpan.title = g.userName || 'Pemain';
    metaEl.appendChild(avatarImg);
    metaEl.appendChild(nameSpan);
    rowEl.appendChild(metaEl);

    rowsContainer.appendChild(rowEl);
  });

  // Pinned ke baris paling atas (seperti Wordle)
  const boardArea = document.getElementById('cascadleBoardArea');
  if (boardArea) {
    boardArea.scrollTop = 0;
  }
}

// Menampilkan animasi susunan tangga kata kemenangan 3-7 huruf langsung di layar papan game
function launchCascadleVictoryShowcase() {
  const container = document.getElementById('cascadleContainer');
  const rowsContainer = document.getElementById('cascadleRowsContainer');
  if (!container || !rowsContainer) return;

  if (cascadleShowcaseTimer) {
    clearInterval(cascadleShowcaseTimer);
    cascadleShowcaseTimer = null;
  }

  // 1. Update Chips progress agar semua tampak selesai (centang hijau)
  for (let len = 3; len <= 7; len++) {
    const chip = document.getElementById(`cascadleChip${len}`);
    if (chip) {
      chip.className = 'cascadle-stage-chip completed';
      const iconSpan = chip.querySelector('.chip-icon');
      if (iconSpan) iconSpan.innerHTML = '<i class="fa-solid fa-check"></i>';
    }
  }

  // 2. Render Wadah Showcase di dalam rowsContainer
  rowsContainer.innerHTML = `
    <div class="cascadle-showcase-box">
      <div class="cascadle-showcase-header">
        <div class="cascadle-showcase-badge"><i class="fa-solid fa-crown" style="color: #fbbf24;"></i> CASCADLE HALL OF FAME</div>
        <div class="cascadle-showcase-sub">Pemenang Rantai 5 Kata (3 hingga 7 Huruf)</div>
      </div>
      <div class="cascadle-showcase-rows" id="cascadleShowcaseRows"></div>
      <div class="cascadle-showcase-footer">
        <div class="cascadle-showcase-countdown">
          <i class="fa-solid fa-clock-rotate-left"></i> Ronde berikutnya dalam <span id="cascadleCountdownNum" class="cascadle-countdown-val">10</span>s
        </div>
        <button class="cascadle-showcase-btn" onclick="startNewRound()">
          Ronde Baru <i class="fa-solid fa-forward-step"></i>
        </button>
      </div>
    </div>
  `;

  const showcaseRowsEl = document.getElementById('cascadleShowcaseRows');
  if (!showcaseRowsEl) return;

  // 4. Render 5 baris kata (Level 3 sampai 7) secara berurutan dengan animasi bertingkat
  const levels = [3, 4, 5, 6, 7];
  levels.forEach((lvl, idx) => {
    const solved = cascadleSolvedWords.find(s => s.level === lvl) || {
      level: lvl,
      word: (cascadleTargets && cascadleTargets[lvl]) ? cascadleTargets[lvl] : 'KATA',
      userName: 'Penebak Cepat',
      userAvatar: DEFAULT_HOST_AVATAR,
      points: (lvl === 7 ? 25 : 5)
    };

    const isJackpot = (lvl === 7);
    const rowEl = document.createElement('div');
    rowEl.className = `cascadle-showcase-row ${isJackpot ? 'is-jackpot-row' : ''}`;
    rowEl.style.opacity = '0';
    rowEl.style.transform = 'translateY(14px) scale(0.95)';

    // Tiles Huruf Hijau Menyala (Rata Kiri, Lebar 310px agar membentuk tangga piramida)
    const tilesCol = document.createElement('div');
    tilesCol.className = 'cascadle-row-tiles';
    for (let c = 0; c < solved.word.length; c++) {
      const tile = document.createElement('div');
      tile.className = 'cascadle-tile tile-correct showcase-tile';
      tile.textContent = solved.word[c] || '';
      tilesCol.appendChild(tile);
    }
    rowEl.appendChild(tilesCol);

    // Info Pemenang & Poin di Sebelah Kanan
    const metaEl = document.createElement('div');
    metaEl.className = 'cascadle-showcase-meta';
    metaEl.innerHTML = `
      <img class="cascadle-avatar ${isJackpot ? 'jackpot-avatar' : ''}" src="${solved.userAvatar || DEFAULT_HOST_AVATAR}" onerror="this.onerror=null; this.src=DEFAULT_HOST_AVATAR;">
      <div class="cascadle-showcase-userinfo">
        <span class="cascadle-showcase-name" title="${solved.userName}">${solved.userName}</span>
        ${isJackpot 
          ? `<span class="cascadle-badge-jackpot"><i class="fa-solid fa-crown"></i> +${solved.points || 20} PTS</span>` 
          : `<span class="cascadle-badge-pts">+${solved.points || 5} PTS</span>`
        }
      </div>
    `;
    rowEl.appendChild(metaEl);
    showcaseRowsEl.appendChild(rowEl);

    // Staggered Reveal Animation per Baris (Ding... Ding... Ding... Jackpot!)
    setTimeout(() => {
      rowEl.classList.add('reveal-active');
      rowEl.style.opacity = '1';
      rowEl.style.transform = 'translateY(0) scale(1)';

      if (window.sounds) {
        if (isJackpot) {
          if (typeof window.sounds.playWin === 'function') window.sounds.playWin();
          if (typeof triggerConfetti === 'function') triggerConfetti();
        } else {
          if (typeof window.sounds.playScanRow === 'function') {
            window.sounds.playScanRow(idx);
          } else if (typeof window.sounds.playCorrect === 'function') {
            window.sounds.playCorrect();
          }
        }
      }
    }, (idx + 1) * 450);
  });

  // 5. Countdown timer otomatis untuk ronde berikutnya (10 detik)
  let timeLeft = 10;
  cascadleShowcaseTimer = setInterval(() => {
    timeLeft--;
    const numEl = document.getElementById('cascadleCountdownNum');
    if (numEl) numEl.textContent = timeLeft;

    if (timeLeft <= 0) {
      clearInterval(cascadleShowcaseTimer);
      cascadleShowcaseTimer = null;
      if (currentGameMode === 'cascadle') {
        startNewRound();
      }
    }
  }, 1000);
}

// ═════════════════════════════════════════════════════════════════════════════
// 14. WANDER WORDS GAME ENGINE (JEJAK KATA BERLIKU & CLUE PUZZLE)
// ═════════════════════════════════════════════════════════════════════════════

let wanderWordsRound = 1;
let wanderWordsCurrentPuzzle = null;
let wanderWordsPuzzleIndex = 0;
let wanderWordsIsGameOver = false;
let wanderWordsIsRevealing = false;
let wanderWordsHintActive = false;
let wanderWordsUserCooldown = new Map();
let wanderWordsTransitionTimer = null;
let wanderWordsCustomWords = null;
let wanderWordsShuffledPool = [];

// ── DYNAMIC GENERATOR REAL-TIME (< 3ms) ──
// Otomatis mencari jalur ular ortogonal (Atas, Bawah, Kiri, Kanan - NO DIAGONAL) untuk kata apa saja
function generateDynamicWanderWordsPuzzle(clue, answer) {
  if (!answer) return null;
  const cleanAnswer = answer.toUpperCase().replace(/[^A-Z]/g, '');
  const N = cleanAnswer.length;
  if (N < 3) return null;

  // Dimensi grid responsif untuk vertical livestream
  const candidateDims = [
    [3, 3], [3, 4], [4, 3], [4, 4], [4, 5], [5, 4], [5, 5]
  ].filter(([r, c]) => r * c >= N);

  // STRICT ORTHOGONAL DIRS (Up, Down, Left, Right)
  const dirs = [
    [-1, 0], [1, 0], [0, -1], [0, 1]
  ];

  for (const [R, C] of candidateDims) {
    for (let trial = 0; trial < 1500; trial++) {
      const startR = Math.floor(Math.random() * R);
      const startC = Math.floor(Math.random() * C);

      const visited = new Set([startR + ',' + startC]);
      const path = [[startR, startC]];

      let currR = startR;
      let currC = startC;
      let failed = false;

      for (let i = 1; i < N; i++) {
        const validNeighbors = [];
        for (const [dr, dc] of dirs) {
          const nr = currR + dr;
          const nc = currC + dc;
          if (nr >= 0 && nr < R && nc >= 0 && nc < C && !visited.has(nr + ',' + nc)) {
            validNeighbors.push([nr, nc]);
          }
        }

        if (validNeighbors.length === 0) {
          failed = true;
          break;
        }

        const next = validNeighbors[Math.floor(Math.random() * validNeighbors.length)];
        currR = next[0];
        currC = next[1];
        visited.add(currR + ',' + currC);
        path.push([currR, currC]);
      }

      if (!failed && path.length === N) {
        const grid = Array.from({ length: R }, () => Array(C).fill(''));
        for (let i = 0; i < N; i++) {
          const [r, c] = path[i];
          grid[r][c] = cleanAnswer[i];
        }
        return {
          clue: (clue || 'TEKA TEKI').trim().toUpperCase(),
          answer: answer.trim().toUpperCase(),
          cleanAnswer,
          rows: R,
          cols: C,
          grid,
          path
        };
      }
    }
  }
  return null;
}

// Mengambil bank kata aktif (kata kustom dari host atau bawaan)
function getWanderWordsActivePool() {
  if (Array.isArray(window.wanderWordsCustomWords) && window.wanderWordsCustomWords.length > 0) {
    return window.wanderWordsCustomWords;
  }
  try {
    const saved = localStorage.getItem('wanderwords_custom_words');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        window.wanderWordsCustomWords = parsed;
        return parsed;
      }
    }
  } catch(e) {}

  return window.WANDERWORDS_DEFAULT_WORDS || window.WANDERWORDS_PUZZLES || [];
}

// Mulai atau reset permainan Wander Words secara dinamis
function startWanderWordsGame() {
  if (currentGameMode !== 'wanderwords') return;

  if (wanderWordsTransitionTimer) {
    clearTimeout(wanderWordsTransitionTimer);
    wanderWordsTransitionTimer = null;
  }

  const pool = getWanderWordsActivePool();
  if (!pool || pool.length === 0) {
    console.error('[WanderWords] Word pool is empty!');
    showToast('Daftar kata Wander Words kosong!', 2500);
    return;
  }

  // Cek apakah ada antrean kocokan kata yang tersimpan di sesi browser
  try {
    if (wanderWordsShuffledPool.length === 0) {
      const savedPool = sessionStorage.getItem('wanderwords_shuffled_pool');
      const savedIdx = parseInt(sessionStorage.getItem('wanderwords_pool_idx') || '0');
      if (savedPool) {
        const parsed = JSON.parse(savedPool);
        if (Array.isArray(parsed) && parsed.length === pool.length && savedIdx < parsed.length) {
          wanderWordsShuffledPool = parsed;
          wanderWordsPuzzleIndex = savedIdx;
        }
      }
    }
  } catch(e) {}

  // Shuffle pool secara acak jika baru pertama kali atau seluruh kata sudah habis dimainkan
  if (wanderWordsShuffledPool.length === 0 || wanderWordsPuzzleIndex >= wanderWordsShuffledPool.length) {
    wanderWordsShuffledPool = [...pool];
    if (typeof shuffleArray === 'function') shuffleArray(wanderWordsShuffledPool);
    wanderWordsPuzzleIndex = 0;
    try {
      sessionStorage.setItem('wanderwords_shuffled_pool', JSON.stringify(wanderWordsShuffledPool));
      sessionStorage.setItem('wanderwords_pool_idx', '0');
    } catch(e) {}
  }

  const selectedItem = wanderWordsShuffledPool[wanderWordsPuzzleIndex];
  wanderWordsPuzzleIndex++;
  try {
    sessionStorage.setItem('wanderwords_pool_idx', wanderWordsPuzzleIndex.toString());
  } catch(e) {}

  // Susun grid dan snake path secara dinamis on-the-fly!
  let generated = generateDynamicWanderWordsPuzzle(selectedItem.clue, selectedItem.answer);
  if (!generated && selectedItem.grid && selectedItem.path) {
    generated = selectedItem; // Fallback jika sudah berformat pre-baked
  }

  if (!generated) {
    console.warn('[WanderWords] Pathfinding retry for next word:', selectedItem.answer);
    if (wanderWordsPuzzleIndex < wanderWordsShuffledPool.length) {
      return startWanderWordsGame();
    }
  }

  wanderWordsCurrentPuzzle = generated;
  wanderWordsIsGameOver = false;
  wanderWordsIsRevealing = false;
  wanderWordsHintActive = false;
  if (typeof clearWanderWordsHostPath === 'function') {
    clearWanderWordsHostPath(false);
  }

  renderWanderWordsUI();
}

// Render antarmuka Wander Words
function renderWanderWordsUI() {
  const container = document.getElementById('wanderWordsContainer');
  if (!container || currentGameMode !== 'wanderwords') return;

  const puzzle = wanderWordsCurrentPuzzle;
  if (!puzzle) return;

  // 1. Update Clue & Global Header Round Badge
  const clueEl = document.getElementById('wanderwordsClueText');
  if (clueEl) clueEl.textContent = puzzle.clue || 'CLUE';

  // Sync to global header round badge under game title
  const globalRoundEl = document.getElementById('roundNumber');
  if (globalRoundEl) globalRoundEl.textContent = wanderWordsRound;
  round = wanderWordsRound;

  // 2. Update Word Length Badge (Opsi 1: Ringkas & tidak makan tempat)
  const lengthTextEl = document.getElementById('wanderwordsLengthText');
  if (lengthTextEl) {
    const cleanLetters = puzzle.cleanAnswer || (puzzle.answer ? puzzle.answer.replace(/[^A-Za-z]/g, '') : '');
    const words = puzzle.answer.trim().split(/\s+/).filter(Boolean);
    const wordCountStr = words.length > 1 ? ` (${words.length} Kata)` : '';
    lengthTextEl.textContent = `${cleanLetters.length} Huruf${wordCountStr}`;
  }

  // 3. Render Board Grid
  const gridEl = document.getElementById('wanderwordsGrid');
  if (gridEl) {
    gridEl.innerHTML = '';
    gridEl.style.setProperty('--ww-cols', puzzle.cols || 4);

    const startPos = puzzle.path && puzzle.path[0] ? puzzle.path[0] : null;

    for (let r = 0; r < puzzle.rows; r++) {
      for (let c = 0; c < puzzle.cols; c++) {
        const letter = (puzzle.grid && puzzle.grid[r] && puzzle.grid[r][c]) ? puzzle.grid[r][c] : '';
        const tile = document.createElement('div');
        tile.className = 'wanderwords-tile';
        tile.setAttribute('data-r', r);
        tile.setAttribute('data-c', c);

        if (!letter) {
          tile.classList.add('empty');
        } else {
          tile.textContent = letter;

          // Jika hint aktif, tandai huruf awal
          if (wanderWordsHintActive && startPos && startPos[0] === r && startPos[1] === c && !wanderWordsIsGameOver) {
            tile.classList.add('hint-start');
          }

          // Jika game over, warnai ubin
          if (wanderWordsIsGameOver) {
            tile.classList.add('solved-path');
          }
        }
        gridEl.appendChild(tile);
      }
    }

    // Pasang interaksi sentuh / klik huruf-ke-huruf untuk Host / Admin
    setupWanderWordsTouchInteraction(gridEl);
  }
}

// ── INTERAKSI SENTUH / KLIK HURUF KE HURUF UNTUK HOST / ADMIN (WANDER WORDS) ──
let wanderWordsHostPath = [];
let isWanderWordsHostDragging = false;
let isWanderWordsDragMoved = false;
let wanderWordsPointerStartX = 0;
let wanderWordsPointerStartY = 0;
let lastWanderWordsActionTime = 0;
let wanderWordsTouchGlobalBound = false;

function isOrthogonalNeighbor(r1, c1, r2, c2) {
  return (Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1);
}

function updateHostPathBadgePreview() {
  const lengthTextEl = document.getElementById('wanderwordsLengthText');
  if (!lengthTextEl || !wanderWordsCurrentPuzzle) return;
  const targetClean = wanderWordsCurrentPuzzle.cleanAnswer || '';
  if (wanderWordsHostPath.length === 0) {
    const cleanLetters = targetClean;
    const words = wanderWordsCurrentPuzzle.answer.trim().split(/\s+/).filter(Boolean);
    const wordCountStr = words.length > 1 ? ` (${words.length} Kata)` : '';
    lengthTextEl.textContent = `${cleanLetters.length} Huruf${wordCountStr}`;
  } else {
    const currentWord = wanderWordsHostPath.map(p => p.letter).join('');
    lengthTextEl.innerHTML = `<span style="color:#fbbf24;font-weight:900;">🔤 ${currentWord}</span> <span style="font-size:10px;opacity:0.8;">(${wanderWordsHostPath.length}/${targetClean.length})</span>`;
  }
}

function clearWanderWordsHostPath(restoreBadge = true) {
  wanderWordsHostPath.forEach(p => {
    if (p.el) {
      p.el.classList.remove('host-path-tile', 'path-error');
      p.el.removeAttribute('data-step');
    }
  });
  wanderWordsHostPath = [];
  if (restoreBadge) {
    updateHostPathBadgePreview();
  }
}

function submitWanderWordsHostPath() {
  if (currentGameMode !== 'wanderwords' || wanderWordsIsGameOver || wanderWordsIsRevealing) {
    clearWanderWordsHostPath(false);
    return;
  }
  if (!wanderWordsCurrentPuzzle || wanderWordsHostPath.length < 2) {
    return;
  }

  const formedWord = wanderWordsHostPath.map(p => p.letter).join('');
  const targetClean = wanderWordsCurrentPuzzle.cleanAnswer || '';

  if (formedWord === targetClean) {
    // KEMENANGAN HOST!
    clearWanderWordsHostPath(false);
    processWanderWordsGuess(formedWord, {
      userId: 'host',
      uniqueId: 'Host',
      nickname: 'Host (Admin)'
    });
  } else {
    // TEBAKAN BELUM COCOK
    if (window.sounds && typeof window.sounds.playInvalid === 'function') {
      window.sounds.playInvalid();
    }
    showToast(`"${formedWord}" belum tepat! Coba lagi.`, 1800);
    const tilesToShake = [...wanderWordsHostPath];
    tilesToShake.forEach(p => {
      if (p.el) p.el.classList.add('path-error');
    });
    setTimeout(() => {
      clearWanderWordsHostPath(true);
    }, 450);
  }
}

function handleWanderWordsTileEnter(tileEl) {
  if (!tileEl || wanderWordsIsGameOver || wanderWordsIsRevealing) return;
  if (tileEl.classList.contains('empty')) return;

  const r = parseInt(tileEl.getAttribute('data-r'));
  const c = parseInt(tileEl.getAttribute('data-c'));
  const letter = tileEl.textContent ? tileEl.textContent.trim().toUpperCase() : '';
  if (!letter || isNaN(r) || isNaN(c)) return;

  // Jika jalur masih kosong: inisialisasi huruf pertama
  if (wanderWordsHostPath.length === 0) {
    wanderWordsHostPath.push({ r, c, letter, el: tileEl });
    tileEl.classList.add('host-path-tile');
    tileEl.setAttribute('data-step', '1');
    if (window.sounds && typeof window.sounds.playFlip === 'function') {
      window.sounds.playFlip(0);
    }
    updateHostPathBadgePreview();
    return;
  }

  const last = wanderWordsHostPath[wanderWordsHostPath.length - 1];
  if (last.r === r && last.c === c) {
    // Jika tap (bukan drag move) pada huruf yang sama dengan ujung aktif: Undo huruf ini
    if (!isWanderWordsDragMoved && wanderWordsHostPath.length > 0) {
      const popped = wanderWordsHostPath.pop();
      if (popped && popped.el) {
        popped.el.classList.remove('host-path-tile', 'path-error');
        popped.el.removeAttribute('data-step');
      }
      if (window.sounds && typeof window.sounds.playFlip === 'function') {
        window.sounds.playFlip(wanderWordsHostPath.length % 5);
      }
      updateHostPathBadgePreview();
    }
    return;
  }

  // Jika kembali ke huruf sebelumnya: Undo 1 langkah
  if (wanderWordsHostPath.length >= 2) {
    const secondLast = wanderWordsHostPath[wanderWordsHostPath.length - 2];
    if (secondLast.r === r && secondLast.c === c) {
      const popped = wanderWordsHostPath.pop();
      if (popped && popped.el) {
        popped.el.classList.remove('host-path-tile', 'path-error');
        popped.el.removeAttribute('data-step');
      }
      if (window.sounds && typeof window.sounds.playFlip === 'function') {
        window.sounds.playFlip(wanderWordsHostPath.length % 5);
      }
      updateHostPathBadgePreview();
      return;
    }
  }

  // Cek apakah ubin ini sudah pernah dilewati (tidak boleh menabrak jejak sendiri)
  const alreadyVisited = wanderWordsHostPath.some(p => p.r === r && p.c === c);
  if (alreadyVisited) return;

  // Cek apakah tetangga orthogonal (Atas, Bawah, Kiri, Kanan saja)
  if (isOrthogonalNeighbor(last.r, last.c, r, c)) {
    wanderWordsHostPath.push({ r, c, letter, el: tileEl });
    tileEl.classList.add('host-path-tile');
    tileEl.setAttribute('data-step', wanderWordsHostPath.length.toString());
    if (window.sounds && typeof window.sounds.playFlip === 'function') {
      window.sounds.playFlip((wanderWordsHostPath.length - 1) % 5);
    }
    updateHostPathBadgePreview();

    // Jika panjang huruf sudah mencapai target jawaban penuh, otomatis periksa!
    if (wanderWordsCurrentPuzzle && wanderWordsCurrentPuzzle.cleanAnswer) {
      if (wanderWordsHostPath.length === wanderWordsCurrentPuzzle.cleanAnswer.length) {
        submitWanderWordsHostPath();
      }
    }
  } else if (!isWanderWordsDragMoved) {
    // Jika tap (bukan drag) pada ubin yang bukan tetangga:
    // Mulai jalur baru dari ubin ini!
    clearWanderWordsHostPath(false);
    wanderWordsHostPath.push({ r, c, letter, el: tileEl });
    tileEl.classList.add('host-path-tile');
    tileEl.setAttribute('data-step', '1');
    if (window.sounds && typeof window.sounds.playFlip === 'function') {
      window.sounds.playFlip(0);
    }
    updateHostPathBadgePreview();
  }
}

function setupWanderWordsTouchInteraction(gridEl) {
  if (!gridEl) return;
  clearWanderWordsHostPath(false);

  // Helper untuk mendapatkan ubin dari koordinat sentuh/kursor
  const getTileFromPoint = (clientX, clientY) => {
    const el = document.elementFromPoint(clientX, clientY);
    if (!el) return null;
    return el.closest('.wanderwords-tile:not(.empty)');
  };

  // Pointer Down (Mouse click down atau Touch start)
  gridEl.onpointerdown = (e) => {
    if (wanderWordsIsGameOver || wanderWordsIsRevealing) return;
    const tile = (e.target && e.target.closest) ? e.target.closest('.wanderwords-tile:not(.empty)') : getTileFromPoint(e.clientX, e.clientY);
    if (!tile) return;

    lastWanderWordsActionTime = Date.now();
    isWanderWordsHostDragging = true;
    isWanderWordsDragMoved = false;
    wanderWordsPointerStartX = e.clientX;
    wanderWordsPointerStartY = e.clientY;

    handleWanderWordsTileEnter(tile);
  };

  // Fallback click event untuk tiap tile
  const tiles = gridEl.querySelectorAll('.wanderwords-tile:not(.empty)');
  tiles.forEach(tile => {
    tile.onclick = (e) => {
      if (wanderWordsIsGameOver || wanderWordsIsRevealing) return;
      // Hindari double-fire jika pointerdown sudah memproses dalam 250ms
      if (Date.now() - lastWanderWordsActionTime < 250) return;
      handleWanderWordsTileEnter(tile);
    };
  });

  // Bind global pointermove & pointerup satu kali saja
  if (!wanderWordsTouchGlobalBound) {
    wanderWordsTouchGlobalBound = true;

    window.addEventListener('pointermove', (e) => {
      if (!isWanderWordsHostDragging || wanderWordsIsGameOver || wanderWordsIsRevealing) return;
      
      const dist = Math.hypot(e.clientX - wanderWordsPointerStartX, e.clientY - wanderWordsPointerStartY);
      if (dist > 8) {
        isWanderWordsDragMoved = true;
      }

      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el) return;
      const tile = el.closest('.wanderwords-tile:not(.empty)');
      if (tile) {
        handleWanderWordsTileEnter(tile);
      }
    }, { passive: false });

    window.addEventListener('pointerup', () => {
      if (!isWanderWordsHostDragging) return;
      isWanderWordsHostDragging = false;
      isWanderWordsDragMoved = false;

      // Jika selesai drag dan huruf yang tersambung sudah tepat sesuai panjang target kata
      if (wanderWordsCurrentPuzzle && wanderWordsCurrentPuzzle.cleanAnswer) {
        if (wanderWordsHostPath.length === wanderWordsCurrentPuzzle.cleanAnswer.length) {
          submitWanderWordsHostPath();
        }
      }
    });

    window.addEventListener('pointercancel', () => {
      isWanderWordsHostDragging = false;
      isWanderWordsDragMoved = false;
    });

    // Reset jalur jika host klik/tap di luar area grid
    document.addEventListener('pointerdown', (e) => {
      if (wanderWordsHostPath.length === 0) return;
      if (!e.target.closest('#wanderwordsGrid') && !e.target.closest('.wanderwords-footer')) {
        clearWanderWordsHostPath(true);
      }
    });
  }
}

// Memproses tebakan masuk dari chat untuk mode Wander Words
function processWanderWordsGuess(guessWord, userData) {
  if (currentGameMode !== 'wanderwords' || wanderWordsIsGameOver || wanderWordsIsRevealing) return;
  if (!guessWord || !wanderWordsCurrentPuzzle) return;

  const rawClean = guessWord.trim().toUpperCase().replace(/[^A-Z]/g, '');
  const targetClean = wanderWordsCurrentPuzzle.cleanAnswer;

  const userId = userData.userId || userData.uniqueId || 'host';
  const userName = userData.nickname || userData.uniqueId || 'Pemain';
  const isHost = (userId === 'host' || userId === 'host_offline' || (typeof userId === 'string' && userId.toLowerCase().includes('host')));
  const now = Date.now();

  // Cooldown 1 detik per user
  if (!isHost) {
    if (wanderWordsUserCooldown.has(userId) && (now - wanderWordsUserCooldown.get(userId) < 1000)) {
      return;
    }
    wanderWordsUserCooldown.set(userId, now);
  }

  // Cek apakah tebakan cocok dengan jawaban utuh
  const isCorrect = (rawClean === targetClean);

  if (!isCorrect) {
    if (isHost) {
      showToast(`"${guessWord}" belum tepat!`, 1800);
      const board = document.getElementById('wanderwordsBoardArea');
      if (board) {
        board.classList.add('animating-shake');
        setTimeout(() => board.classList.remove('animating-shake'), 450);
      }
    }
    return;
  }

  // ── JAWABAN BENAR! ──
  handleWanderWordsWin(userData);
}

// Penanganan kemenangan Wander Words
function handleWanderWordsWin(userData) {
  if (wanderWordsIsGameOver || wanderWordsIsRevealing) return;
  wanderWordsIsGameOver = true;
  wanderWordsIsRevealing = true;

  const puzzle = wanderWordsCurrentPuzzle;
  const userName = userData.nickname || userData.uniqueId || 'Pemain';
  const ptsAwarded = 15;

  if (typeof addPoints === 'function' && userData) {
    addPoints(userData, ptsAwarded);
    recordWin(userData.uniqueId || userData.nickname);
  }
  lastRoundWinner = userData;
  lastRoundTargetWord = puzzle.answer;
  showFloatingPoints(ptsAwarded, 'wanderWordsContainer');

  showToast(`🎉 ${userName} MENEBAK BENAR: "${puzzle.answer}"! (+${ptsAwarded} Poin)`, 4000);

  // 1. Animasi reveal ubin berurutan mengikuti snake path (tempo 280ms agar terbaca jelas oleh penonton live)
  const STEP_INTERVAL = 280;
  const path = puzzle.path || [];
  const gridEl = document.getElementById('wanderwordsGrid');
  const lengthTextEl = document.getElementById('wanderwordsLengthText');
  if (lengthTextEl) {
    lengthTextEl.innerHTML = `<i class="fa-solid fa-check"></i> ${puzzle.answer}`;
  }

  path.forEach((pos, idx) => {
    setTimeout(() => {
      // Reveal ubin pada grid dengan nomor urut langkah
      if (gridEl) {
        const tile = gridEl.querySelector(`.wanderwords-tile[data-r="${pos[0]}"][data-c="${pos[1]}"]`);
        if (tile) {
          tile.classList.remove('hint-start');
          tile.setAttribute('data-step', idx + 1);
          tile.classList.add('solved-path');
        }
      }

      // Audio flip per langkah
      if (window.sounds && typeof window.sounds.playFlip === 'function') {
        window.sounds.playFlip(idx % 5);
      }
    }, idx * STEP_INTERVAL);
  });

  const totalPathDelay = path.length * STEP_INTERVAL + 300;

  // 2. Setelah seluruh jejak huruf tersambung: bunyikan win audio dan konfeti
  setTimeout(() => {
    if (window.sounds && typeof window.sounds.playWin === 'function') {
      window.sounds.playWin();
    }
    if (typeof triggerConfetti === 'function') {
      triggerConfetti();
    }

    // 3. Tampilkan Aesthetic Win Overlay setelah pemain puas melihat papan tersambung
    wanderWordsTransitionTimer = setTimeout(() => {
      const winAvatar = document.getElementById('winAvatar');
      if (winAvatar) {
        winAvatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
        winAvatar.src = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
      }

      const winTitle = document.getElementById('winTitleText');
      if (winTitle) winTitle.textContent = 'WANDER WORDS SOLVED!';

      const winName = document.getElementById('winName');
      if (winName) winName.textContent = userName;

      const winPts = document.getElementById('winPts');
      if (winPts) winPts.innerHTML = `🪙 +${ptsAwarded} Poin`;

      const winSubtitle = document.getElementById('winSubtitleText');
      if (winSubtitle) winSubtitle.textContent = `CLUE: ${puzzle.clue || 'Wander Words'}`;

      const winWordEl = document.getElementById('winWord');
      if (winWordEl) {
        winWordEl.innerHTML = '';
        winWordEl.textContent = puzzle.answer;
        winWordEl.style.display = 'block';
        if (puzzle.answer.length > 10) {
          winWordEl.style.fontSize = 'clamp(20px, 5.5vw, 26px)';
          winWordEl.style.letterSpacing = '2px';
        } else {
          winWordEl.style.fontSize = '32px';
          winWordEl.style.letterSpacing = '3px';
        }
      }

      wanderWordsIsRevealing = false;
      // Trigger overlay (durasi 5 detik atau menunggu tap-to-like jika diaktifkan)
      if (typeof window.triggerWinTransition === 'function') {
        window.triggerWinTransition(5000, false);
      } else if (typeof triggerWinTransition === 'function') {
        triggerWinTransition(5000, false);
      }
    }, 1200);

  }, totalPathDelay);
}

// Bantuan Hint untuk Host: Sorot huruf pertama jalur
function wanderWordsGiveHint() {
  if (currentGameMode !== 'wanderwords' || wanderWordsIsGameOver || wanderWordsIsRevealing) return;
  wanderWordsHintActive = !wanderWordsHintActive;
  renderWanderWordsUI();
  if (wanderWordsHintActive) {
    showToast('💡 Huruf pertama telah disorot (START)!', 2500);
  } else {
    showToast('💡 Petunjuk disembunyikan.', 1500);
  }
}

// Lewati Puzzle (Skip) untuk Host
function skipWanderWordsPuzzle() {
  if (currentGameMode !== 'wanderwords' || wanderWordsIsRevealing) return;
  if (typeof clearWanderWordsHostPath === 'function') {
    clearWanderWordsHostPath(false);
  }
  showToast(`⏭️ Puzzle dilewati. Jawaban: ${wanderWordsCurrentPuzzle.answer}`, 3000);
  wanderWordsRound++;
  round = wanderWordsRound;
  const globalRoundEl = document.getElementById('roundNumber');
  if (globalRoundEl) globalRoundEl.textContent = wanderWordsRound;
  startWanderWordsGame();
}

window.wanderWordsGiveHint = wanderWordsGiveHint;
window.skipWanderWordsPuzzle = skipWanderWordsPuzzle;

// ═══════════════════════════════════════════════════════════════════
// WORD CLUSTER (KATA TERKAIT) GAME LOGIC
// ═══════════════════════════════════════════════════════════════════
let wordClusterCurrentTopic = null;
let wordClusterItems = []; // [{ index, word, points, isSolved, isJustSolved, solver, revealedLetters: [] }]
let wordClusterRound = 1;
let wordClusterCustomWords = null;
let wordClusterTransitionTimer = null;
let wordClusterShuffledPool = [];
let wordClusterPuzzleIndex = 0;

function getWordClusterActivePool() {
  if (Array.isArray(window.wordClusterCustomWords) && window.wordClusterCustomWords.length > 0) {
    return window.wordClusterCustomWords;
  }
  try {
    const saved = localStorage.getItem('wordcluster_custom_words');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        window.wordClusterCustomWords = parsed;
        return parsed;
      }
    }
  } catch(e) {}
  return window.WORDCLUSTER_DEFAULT_PUZZLES || window.WORDCLUSTER_PUZZLES || [];
}

function startWordClusterGame() {
  if (currentGameMode !== 'wordcluster') return;

  if (wordClusterTransitionTimer) {
    clearTimeout(wordClusterTransitionTimer);
    wordClusterTransitionTimer = null;
  }

  const pool = getWordClusterActivePool();
  if (!pool || pool.length === 0) return;

  // Cek apakah ada antrean kocokan topik yang tersimpan di sesi browser
  try {
    if (wordClusterShuffledPool.length === 0) {
      const savedPool = sessionStorage.getItem('wordcluster_shuffled_pool');
      const savedIdx = parseInt(sessionStorage.getItem('wordcluster_pool_idx') || '0');
      if (savedPool) {
        const parsed = JSON.parse(savedPool);
        if (Array.isArray(parsed) && parsed.length === pool.length && savedIdx < parsed.length) {
          wordClusterShuffledPool = parsed;
          wordClusterPuzzleIndex = savedIdx;
        }
      }
    }
  } catch(e) {}

  // Kocok (shuffle) pool secara acak jika baru pertama kali atau seluruh topik sudah habis dimainkan (no repeat)
  if (wordClusterShuffledPool.length === 0 || wordClusterPuzzleIndex >= wordClusterShuffledPool.length) {
    wordClusterShuffledPool = [...pool];
    for (let i = wordClusterShuffledPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [wordClusterShuffledPool[i], wordClusterShuffledPool[j]] = [wordClusterShuffledPool[j], wordClusterShuffledPool[i]];
    }
    wordClusterPuzzleIndex = 0;
    try {
      sessionStorage.setItem('wordcluster_shuffled_pool', JSON.stringify(wordClusterShuffledPool));
      sessionStorage.setItem('wordcluster_pool_idx', '0');
    } catch(e) {}
    console.log(`[WordCluster] Shuffled ${wordClusterShuffledPool.length} topics. Playing without repeats!`);
  }

  const rawPuzzle = wordClusterShuffledPool[wordClusterPuzzleIndex];
  wordClusterPuzzleIndex++;
  try {
    sessionStorage.setItem('wordcluster_pool_idx', wordClusterPuzzleIndex.toString());
  } catch(e) {}

  if (!rawPuzzle) return;

  wordClusterCurrentTopic = rawPuzzle.topic ? rawPuzzle.topic.toUpperCase().trim() : "KATA TERKAIT";

  // Sediakan 6 kata dengan poin bertingkat dari terbesar ke terkecil: 60, 50, 40, 30, 20, 10
  const stdPoints = [60, 50, 40, 30, 20, 10];
  const wordsList = Array.isArray(rawPuzzle.words) ? rawPuzzle.words.slice(0, 6) : [];

  wordClusterItems = wordsList.map((item, idx) => {
    let wordStr = typeof item === 'string' ? item : (item.word || '');
    wordStr = wordStr.toUpperCase().trim().replace(/[^A-Z]/g, '');
    const pts = (typeof item === 'object' && item.points) ? item.points : (stdPoints[idx] || 10);
    return {
      index: idx,
      word: wordStr,
      points: pts,
      isSolved: false,
      isJustSolved: false,
      solver: null,
      revealedLetters: [0] // Huruf pertama otomatis terbuka sebagai petunjuk awal
    };
  });

  renderWordClusterUI();
  console.log(`[WordCluster] Round ${wordClusterRound} started: ${wordClusterCurrentTopic} (${wordClusterItems.length} words)`);
}

function renderWordClusterUI() {
  const container = document.getElementById('wordClusterContainer');
  if (!container || currentGameMode !== 'wordcluster') return;

  // 1. Update Judul Topik, Ronde, & Instruksi Chat Hint
  const topicTitleEl = document.getElementById('wcTopicTitle');
  if (topicTitleEl) topicTitleEl.textContent = wordClusterCurrentTopic || 'TEMA KATA';

  const chatHintTopicEl = document.getElementById('wcChatHintTopic');
  if (chatHintTopicEl) {
    chatHintTopicEl.textContent = wordClusterCurrentTopic || 'topik ini';
  } else {
    const chatHintEl = document.getElementById('wcChatHintText');
    if (chatHintEl) chatHintEl.innerHTML = `Tebak kata yang berhubungan dengan <strong id="wcChatHintTopic">${wordClusterCurrentTopic || 'topik ini'}</strong>!`;
  }

  const globalRoundEl = document.getElementById('roundNumber');
  if (globalRoundEl) globalRoundEl.textContent = wordClusterRound;
  round = wordClusterRound;

  // 2. Update Badge Progress Tertebak
  const solvedCount = wordClusterItems.filter(it => it.isSolved).length;
  const progressTextEl = document.getElementById('wcProgressText');
  if (progressTextEl) progressTextEl.textContent = `${solvedCount} / ${wordClusterItems.length} Tertebak`;

  // 3. Render 6 Baris Kata
  const listEl = document.getElementById('wcWordsList');
  if (!listEl) return;
  listEl.innerHTML = '';

  wordClusterItems.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = 'wc-row' + (item.isSolved ? ' solved' : '');
    row.id = `wc-row-${idx}`;
    row.dataset.len = item.word.length;

    // Kotak Ubin Huruf Kata
    const tilesArea = document.createElement('div');
    tilesArea.className = 'wc-tiles-area';

    const wordLen = item.word.length;
    for (let c = 0; c < wordLen; c++) {
      const char = item.word[c] || '';
      const tile = document.createElement('div');
      tile.className = 'wc-tile';

      if (item.isSolved) {
        tile.classList.add('solved');
        if (item.isJustSolved) {
          tile.classList.add('just-solved');
        }
        tile.textContent = char;
      } else if (item.revealedLetters.includes(c)) {
        tile.classList.add('revealed');
        tile.textContent = char;
      } else {
        tile.classList.add('empty');
        tile.textContent = '';
      }
      tilesArea.appendChild(tile);
    }
    row.appendChild(tilesArea);

    // Kolom Kanan: Poin (jika belum tertebak) atau Avatar Pemenang (jika sudah tertebak)
    const metaCol = document.createElement('div');
    metaCol.className = 'wc-meta-col';

    if (!item.isSolved) {
      const ptsBadge = document.createElement('div');
      ptsBadge.className = 'wc-points-badge';
      ptsBadge.innerHTML = `<span class="wc-pts-num">${item.points}</span><span class="wc-pts-unit">pt</span>`;
      metaCol.appendChild(ptsBadge);
    } else {
      const guesserWrap = document.createElement('div');
      guesserWrap.className = 'wc-guesser-wrap' + (item.isJustSolved ? ' just-solved' : '');

      const avatarBox = document.createElement('div');
      avatarBox.className = 'wc-guesser-avatar-box';

      const avatar = document.createElement('img');
      avatar.className = 'wc-guesser-avatar';
      avatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
      avatar.src = item.solver?.profilePic || 'assets/bg_nature.png';
      avatarBox.appendChild(avatar);

      const ptsBadge = document.createElement('span');
      ptsBadge.className = 'wc-avatar-pts-badge';
      ptsBadge.textContent = `+${item.points}`;
      avatarBox.appendChild(ptsBadge);

      guesserWrap.appendChild(avatarBox);

      const infoBox = document.createElement('div');
      infoBox.className = 'wc-guesser-info';

      const nameLabel = document.createElement('span');
      nameLabel.className = 'wc-guesser-name';
      const uName = item.solver?.username || 'Pemain';
      nameLabel.textContent = uName;
      nameLabel.title = uName;
      infoBox.appendChild(nameLabel);

      guesserWrap.appendChild(infoBox);
      metaCol.appendChild(guesserWrap);
    }

    // Reset flag animasi satu kali agar di tebakan kata berikutnya ubin ini tidak ikut mental lagi
    if (item.isJustSolved) {
      setTimeout(() => { item.isJustSolved = false; }, 600);
    }

    row.appendChild(metaCol);
    listEl.appendChild(row);
  });
}

function processWordClusterGuess(guessWord, userData) {
  if (currentGameMode !== 'wordcluster' || isGameOver) return false;
  if (!guessWord || !wordClusterItems || wordClusterItems.length === 0) return false;

  const cleanGuess = guessWord.toUpperCase().trim().replace(/[^A-Z]/g, '');
  if (cleanGuess.length < 2) return false;

  // 1. Cari kecocokan kata tebakan langsung
  let matchedItem = wordClusterItems.find(item => item.word === cleanGuess);

  // 2. Jika tidak cocok langsung (misal penonton ketik kalimat/frasa seperti "tebak nelayan" atau "itu jangkar"),
  // cari per kata dari komentar asli yang belum tertebak
  if (!matchedItem && userData && userData.comment) {
    const tokens = userData.comment.toUpperCase().split(/\s+/).map(t => t.replace(/[^A-Z]/g, '')).filter(t => t.length >= 2);
    matchedItem = wordClusterItems.find(item => tokens.includes(item.word) && !item.isSolved);
  }

  if (!matchedItem) return false;

  const rawName = (userData && (userData.nickname || userData.uniqueId)) ? (userData.nickname || userData.uniqueId) : 'Pemain';

  // Jika kata sudah pernah tertebak
  if (matchedItem.isSolved) {
    return false;
  }

  // Tandai tertebak dan beri flag isJustSolved untuk animasi 1x
  matchedItem.isSolved = true;
  matchedItem.isJustSolved = true;
  matchedItem.solver = {
    username: rawName,
    profilePic: (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png',
    userId: (userData && userData.uniqueId) ? userData.uniqueId : rawName
  };

  // Suara & Point
  if (window.sounds) {
    if (typeof window.sounds.playFlip === 'function') window.sounds.playFlip(0);
    if (typeof window.sounds.playGreenChime === 'function') {
      setTimeout(() => window.sounds.playGreenChime(), 150);
    }
  }
  if (window.playHostAudio) playHostAudio('correct');

  // Berikan poin ke leaderboard
  if (typeof addPoints === 'function' && userData) {
    addPoints(userData, matchedItem.points);
  }

  renderWordClusterUI();
  showToast(`@${rawName} menebak "${matchedItem.word}" (+${matchedItem.points} Poin)!`, 2400);

  // Cek apakah seluruh 6 kata sudah tertebak semua
  const allSolved = wordClusterItems.every(it => it.isSolved);
  if (allSolved) {
    setTimeout(() => {
      handleWordClusterWin();
    }, 1800); // Jeda 1.8 detik agar 6 ubin hijau terlihat penuh memuaskan sebelum popup muncul
  }

  return true;
}

function handleWordClusterWin() {
  if (isGameOver) return;
  isGameOver = true;

  if (window.sounds && typeof window.sounds.playWin === 'function') {
    window.sounds.playWin();
  }
  if (window.playHostAudio) playHostAudio('win');

  // Tampilkan multiWinOverlay
  const overlay = document.getElementById('multiWinOverlay');
  const list = document.getElementById('multiWinList');
  const title = document.getElementById('multiWinTitle');

  if (overlay && list) {
    if (title) title.textContent = `TOPIK SELESAI: ${wordClusterCurrentTopic}`;
    list.innerHTML = '';

    // Agregasikan poin pemenang per user
    const playerTotals = {};
    wordClusterItems.forEach(item => {
      if (item.solver) {
        const u = item.solver.username;
        if (!playerTotals[u]) {
          playerTotals[u] = {
            username: u,
            profilePic: item.solver.profilePic,
            points: 0,
            words: []
          };
        }
        playerTotals[u].points += item.points;
        playerTotals[u].words.push(item.word);
      }
    });

    const sortedPlayers = Object.values(playerTotals).sort((a, b) => b.points - a.points);
    sortedPlayers.forEach((player, index) => {
      const item = document.createElement('div');
      item.className = 'multi-win-item' + (index === 0 ? ' mvp' : '');

      let avHTML = `<div class="multi-win-letter">${player.username.charAt(0).toUpperCase()}</div>`;
      if (player.profilePic) {
        avHTML = `<img src="${player.profilePic}" alt="Avatar" class="multi-win-avatar" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"><div class="multi-win-letter" style="display:none;">${player.username.charAt(0).toUpperCase()}</div>`;
      }

      const crownHTML = index === 0 ? '<span class="multi-win-crown-icon" title="Juara 1 MVP"><i class="fa-solid fa-crown"></i></span>' : `<span class="multi-win-rank-badge">#${index + 1}</span>`;
      const mvpBadge = index === 0 ? '<span class="multi-win-mvp-badge"><i class="fa-solid fa-star"></i> MVP</span>' : '';
      const wordsCountText = `${player.words.length} Kata`;
      const wordsPreviewText = player.words.join(' • ');

      item.innerHTML = `
        <div class="multi-win-avatar-wrap">
          ${avHTML}
          ${crownHTML}
        </div>
        <div class="multi-win-info">
          <div class="multi-win-name-row">
            <span class="multi-win-name">${player.username}</span>
            ${mvpBadge}
          </div>
          <div class="multi-win-meta-row">
            <span class="multi-win-count-chip">${wordsCountText}</span>
            <span class="multi-win-words-txt" title="${player.words.join(', ')}">${wordsPreviewText}</span>
          </div>
        </div>
        <div class="multi-win-points">+${player.points} Pts</div>
      `;
      list.appendChild(item);
    });

    // Panggil transisi kemenangan multi-pemenang standar (terhubung ke Confetti & Like Progress Bar)
    if (typeof triggerWinTransition === 'function') {
      triggerWinTransition(10000, true);
    } else {
      overlay.classList.add('show');
      wordClusterTransitionTimer = setTimeout(() => {
        executeWordClusterRestart();
      }, 10000);
    }
  }
}

function executeWordClusterRestart() {
  if (wordClusterTransitionTimer) {
    clearTimeout(wordClusterTransitionTimer);
    wordClusterTransitionTimer = null;
  }
  const multiWin = document.getElementById('multiWinOverlay');
  if (multiWin) multiWin.classList.remove('show');
  if (typeof stopMultiWinAutoScroll === 'function') stopMultiWinAutoScroll();
  const likeProg = document.getElementById('multiLikeProgressContainer');
  if (likeProg) likeProg.style.display = 'none';

  isGameOver = false;
  wordClusterRound++;
  startWordClusterGame();
}

function revealWordClusterHint() {
  if (currentGameMode !== 'wordcluster' || isGameOver) return;
  // Cari baris belum tertebak pertama yang masih memiliki huruf tertutup
  const unsolvedItem = wordClusterItems.find(it => !it.isSolved && it.revealedLetters.length < it.word.length);
  if (!unsolvedItem) {
    showToast("Semua kata sudah terbuka atau tertebak!", 1800);
    return;
  }

  // Buka 1 huruf berikutnya
  const nextIdx = unsolvedItem.revealedLetters.length;
  if (nextIdx < unsolvedItem.word.length) {
    unsolvedItem.revealedLetters.push(nextIdx);
    renderWordClusterUI();
    if (window.sounds && typeof window.sounds.playFlip === 'function') window.sounds.playFlip(0);
    showToast(`Bantuan: Huruf ke-${nextIdx + 1} baris #${unsolvedItem.index + 1} terbuka (${unsolvedItem.word[nextIdx]})!`, 2000);
  }
}

function skipWordClusterRound() {
  if (currentGameMode !== 'wordcluster') return;
  if (window.playHostAudio) playHostAudio('click');
  showToast(`Melewati topik "${wordClusterCurrentTopic}"...`, 2000);
  executeWordClusterRestart();
}

window.revealWordClusterHint = revealWordClusterHint;
window.skipWordClusterRound = skipWordClusterRound;
window.startWordClusterGame = startWordClusterGame;
window.processWordClusterGuess = processWordClusterGuess;

// ═══════════════════════════════════════════════════════════════════
// WORD MATCH (LEVENSHTEIN DISTANCE & PERCENTAGE SIMILARITY) GAME LOGIC
// ═══════════════════════════════════════════════════════════════════
let wordMatchCurrentWord = "";
let wordMatchRevealed = [];
let wordMatchGuesses = [];
let wordMatchLatestGuess = null;
let wordMatchRound = 1;
let wordMatchAutoRevealTimer = null;
let wordMatchAutoRevealSeconds = 60;
let wordMatchAutoRevealTick = 60;
let wordMatchGameOver = false;
let wordMatchHintsGiven = 0;
let wordMatchTransitionTimer = null;

function wmLevenshtein(a, b) {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

function wmCalculateScore(guess, target) {
  if (guess === target) return 100;
  const dist = wmLevenshtein(guess, target);
  if (dist === 1) return 99;

  const maxLen = Math.max(guess.length, target.length);
  const similarity = Math.max(0, 1 - (dist / maxLen));
  let score = Math.floor(Math.pow(similarity, 1.2) * 100);

  if (score >= 99) score = 98;
  if (score <= 0) score = 1;
  return score;
}

function startWordMatchGame(forceWord = null) {
  if (currentGameMode !== 'wordmatch') return;

  if (wordMatchTransitionTimer) {
    clearTimeout(wordMatchTransitionTimer);
    wordMatchTransitionTimer = null;
  }
  stopWordMatchAutoReveal();

  wordMatchGameOver = false;
  wordMatchHintsGiven = 0;
  wordMatchGuesses = [];
  wordMatchLatestGuess = null;

  if (forceWord) {
    wordMatchCurrentWord = forceWord.toUpperCase().trim().replace(/[^A-Z]/g, '');
    WORD_LENGTH = wordMatchCurrentWord.length;
  } else {
    // Ambil opsi panjang kata yang diaktifkan host di pengaturan (localStorage allowed_lengths)
    let allowedLengths = [4, 5, 6, 7, 8];
    try {
      const saved = JSON.parse(localStorage.getItem('allowed_lengths'));
      if (Array.isArray(saved) && saved.length > 0) {
        allowedLengths = saved.filter(l => l >= 3 && l <= 8);
      }
    } catch(e) {}
    if (allowedLengths.length === 0) allowedLengths = [4, 5, 6, 7];

    // Acak panjang kata tiap ronde baru dari daftar panjang kata yang dipilih host
    const chosenLen = allowedLengths[Math.floor(Math.random() * allowedLengths.length)];
    WORD_LENGTH = chosenLen;

    let pool = (allTargetWords && allTargetWords[chosenLen] && allTargetWords[chosenLen].length > 0)
      ? allTargetWords[chosenLen]
      : (allValidWords && allValidWords[chosenLen] && allValidWords[chosenLen].length > 0
          ? allValidWords[chosenLen]
          : ["LAMPU", "PINTU", "RUMAH", "KUCING", "KERETA", "BELAJAR", "BINTANG"]);

    let candidate = pool[Math.floor(Math.random() * pool.length)];
    wordMatchCurrentWord = (candidate || "PINTU").toUpperCase().trim().replace(/[^A-Z]/g, '');
  }

  const len = wordMatchCurrentWord.length;
  // Clues: Buka 1 huruf (pertama) untuk kata <= 5 huruf, buka 2 huruf (pertama & terakhir) untuk kata >= 6 huruf
  let clueIndices = [0];
  if (len >= 6) clueIndices.push(len - 1);

  wordMatchRevealed = wordMatchCurrentWord.split('').map((char, idx) => clueIndices.includes(idx) ? char : '_');

  renderWordMatchUI();
  initWordMatchAutoReveal();

  console.log(`[WordMatch] Round ${wordMatchRound} started: "${wordMatchCurrentWord}" (${len} letters)`);
}

function initWordMatchAutoReveal() {
  stopWordMatchAutoReveal();
  wordMatchAutoRevealTick = wordMatchAutoRevealSeconds;
  updateWordMatchTimerUI();

  wordMatchAutoRevealTimer = setInterval(() => {
    if (wordMatchGameOver || currentGameMode !== 'wordmatch') {
      stopWordMatchAutoReveal();
      return;
    }

    wordMatchAutoRevealTick--;
    if (wordMatchAutoRevealTick <= 0) {
      wordMatchAutoRevealTick = wordMatchAutoRevealSeconds;
      revealWordMatchLetter(false);
    }
    updateWordMatchTimerUI();
  }, 1000);
}

function stopWordMatchAutoReveal() {
  if (wordMatchAutoRevealTimer) {
    clearInterval(wordMatchAutoRevealTimer);
    wordMatchAutoRevealTimer = null;
  }
}

function updateWordMatchTimerUI() {
  const timerTextEl = document.getElementById('wmTimerText');
  if (timerTextEl) {
    timerTextEl.textContent = `${wordMatchAutoRevealTick}s`;
  }
}

function revealWordMatchLetter(isManual = false) {
  if (wordMatchGameOver || currentGameMode !== 'wordmatch') return;

  const hiddenIndices = [];
  for (let i = 0; i < wordMatchRevealed.length; i++) {
    if (wordMatchRevealed[i] === '_') hiddenIndices.push(i);
  }

  // Jaga minimal 1 huruf tetap tertutup agar sistem tidak membocorkan 100% kata secara otomatis
  if (hiddenIndices.length > (isManual ? 0 : 1)) {
    const randomIndex = hiddenIndices[Math.floor(Math.random() * hiddenIndices.length)];
    wordMatchRevealed[randomIndex] = wordMatchCurrentWord[randomIndex];
    wordMatchHintsGiven++;
    renderWordMatchUI();
    if (window.sounds && typeof window.sounds.playWordMatchHint === 'function') {
      window.sounds.playWordMatchHint();
    } else if (window.sounds && typeof window.sounds.playFlip === 'function') {
      window.sounds.playFlip(0);
    }

    if (isManual) {
      showToast(`Bantuan: Huruf ke-${randomIndex + 1} terbuka: "${wordMatchCurrentWord[randomIndex]}"!`, 2000);
    } else {
      showToast(`Bantuan Otomatis: Huruf ke-${randomIndex + 1} terbuka!`, 2000);
    }
  } else if (isManual && hiddenIndices.length === 1) {
    showToast("Hanya tersisa 1 huruf lagi, ayo tebak sekarang!", 2000);
  }
}

function revealWordMatchHint() {
  if (wordMatchGameOver || currentGameMode !== 'wordmatch') return;
  revealWordMatchLetter(true);
}

function skipWordMatchRound() {
  if (currentGameMode !== 'wordmatch') return;
  if (window.playHostAudio) playHostAudio('click');
  showToast(`Melewati kata "${wordMatchCurrentWord}"...`, 2000);
  startWordMatchGame();
}

function renderWordMatchUI() {
  const container = document.getElementById('wordMatchContainer');
  if (!container || currentGameMode !== 'wordmatch') return;

  const globalRoundEl = document.getElementById('roundNumber');
  if (globalRoundEl) globalRoundEl.textContent = wordMatchRound;
  round = wordMatchRound;

  // 1. Secret tiles
  const tilesRow = document.getElementById('wmTilesRow');
  if (tilesRow) {
    tilesRow.innerHTML = wordMatchRevealed.map(char => {
      const isRevealed = char !== '_';
      return `<div class="wm-tile ${isRevealed ? 'revealed' : 'empty'}">${isRevealed ? char : '?'}</div>`;
    }).join('');
  }

  // 3. Guesses feed
  renderWordMatchGuesses();

  // 4. Update chat hint text
  const chatHintEl = document.getElementById('wmChatHintText');
  if (chatHintEl && wordMatchCurrentWord) {
    chatHintEl.textContent = `Ketik kata ${wordMatchCurrentWord.length} huruf di komentar live!`;
  }
}

function renderWordMatchGuesses() {
  const container = document.getElementById('wmGuessesContainer');
  if (!container) return;
  container.innerHTML = '';

  if (!wordMatchLatestGuess && wordMatchGuesses.length === 0) {
    container.innerHTML = `
      <div class="wm-empty-placeholder">
        <div class="wm-empty-icon"><i class="fa-solid fa-comment-dots"></i></div>
        <div class="wm-empty-title">Belum Ada Tebakan</div>
        <div class="wm-empty-desc">Ketik kata tebakan ${wordMatchCurrentWord ? wordMatchCurrentWord.length : 5} huruf di kolom komentar live!</div>
      </div>
    `;
    return;
  }

  // Tebakan Terbaru (Latest Guess)
  if (wordMatchLatestGuess) {
    const latestTitle = document.createElement('div');
    latestTitle.className = 'wm-section-title';
    latestTitle.innerHTML = '<i class="fa-solid fa-bolt" style="color: #22c55e;"></i> TEBAKAN TERBARU';
    container.appendChild(latestTitle);

    container.appendChild(createWordMatchGuessElement(wordMatchLatestGuess, wordMatchLatestGuess.isNew));
    wordMatchLatestGuess.isNew = false;

    if (wordMatchGuesses.length > 0) {
      const divider = document.createElement('div');
      divider.className = 'wm-guess-divider';
      container.appendChild(divider);

      const bestTitle = document.createElement('div');
      bestTitle.className = 'wm-section-title';
      bestTitle.innerHTML = '<i class="fa-solid fa-fire" style="color: #f59e0b;"></i> TEBAKAN TERBAIK';
      container.appendChild(bestTitle);
    }
  }

  // Tebakan Terbaik (Top 4 sorted guesses)
  const topGuesses = wordMatchGuesses.slice(0, 4);
  topGuesses.forEach(g => {
    container.appendChild(createWordMatchGuessElement(g, g.isNew));
    g.isNew = false;
  });
}

function createWordMatchGuessElement(guessObj, isNew = false) {
  const el = document.createElement('div');
  el.className = `wm-guess-item ${isNew ? 'new-pop' : ''}`;

  const fill = document.createElement('div');
  fill.className = 'wm-guess-fill';
  const hue = Math.min(130, guessObj.score * 1.3);
  fill.style.setProperty('--wm-hue', hue);
  fill.style.width = isNew ? '0%' : `${guessObj.score}%`;

  const content = document.createElement('div');
  content.className = 'wm-guess-content';

  const wordSpan = document.createElement('span');
  wordSpan.className = 'wm-guess-word';
  wordSpan.textContent = guessObj.word;

  const userWrap = document.createElement('div');
  userWrap.className = 'wm-guess-user';

  const avatarImg = document.createElement('img');
  avatarImg.className = 'wm-guess-avatar';
  avatarImg.referrerPolicy = 'no-referrer';
  avatarImg.src = guessObj.avatar || 'assets/bg_nature.png';
  avatarImg.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };

  const nameSpan = document.createElement('span');
  nameSpan.className = 'wm-guess-name';
  nameSpan.textContent = guessObj.nickname;

  userWrap.appendChild(avatarImg);
  userWrap.appendChild(nameSpan);

  const scoreBadge = document.createElement('span');
  scoreBadge.className = 'wm-guess-score';
  scoreBadge.textContent = `${guessObj.score}%`;

  content.appendChild(wordSpan);
  content.appendChild(userWrap);
  content.appendChild(scoreBadge);

  el.appendChild(fill);
  el.appendChild(content);

  if (isNew) {
    setTimeout(() => {
      fill.style.width = `${guessObj.score}%`;
    }, 40);
  }

  return el;
}

function processWordMatchGuess(rawWord, userData) {
  if (wordMatchGameOver || currentGameMode !== 'wordmatch') return;
  if (!wordMatchCurrentWord) return;

  const guess = (rawWord || '').toUpperCase().trim().replace(/[^A-Z]/g, '');
  if (!guess) return;

  // Filter panjang kata: tebakan harus memiliki panjang yang sama dengan kata target
  if (guess.length !== wordMatchCurrentWord.length) return;

  const score = wmCalculateScore(guess, wordMatchCurrentWord);
  const nickname = (userData && (userData.nickname || userData.uniqueId)) || 'Sobat';
  const avatar = (userData && userData.profilePictureUrl) || 'assets/bg_nature.png';
  const userId = (userData && (userData.uniqueId || userData.nickname)) || 'unknown';

  const currentTopScore = (wordMatchGuesses.length > 0) ? wordMatchGuesses[0].score : 0;
  const isNewTop = score > currentTopScore && currentTopScore > 0;

  // Sound feedback adaptif berdasarkan skor kemiripan tebakan
  if (score < 100) {
    if (window.sounds && typeof window.sounds.playWordMatchScore === 'function') {
      window.sounds.playWordMatchScore(score, isNewTop);
    } else if (window.sounds && typeof window.sounds.playFlip === 'function') {
      window.sounds.playFlip(0);
    }
  }

  wordMatchLatestGuess = {
    word: guess,
    score: score,
    nickname: nickname,
    avatar: avatar,
    userId: userId,
    isNew: true
  };

  // Masukkan ke daftar tebakan terbaik (hanya simpan kata unik dengan skor tertinggi)
  const existingIdx = wordMatchGuesses.findIndex(g => g.word === guess);
  if (existingIdx === -1) {
    wordMatchGuesses.push({ ...wordMatchLatestGuess });
    wordMatchGuesses.sort((a, b) => b.score - a.score);
    if (wordMatchGuesses.length > 50) wordMatchGuesses = wordMatchGuesses.slice(0, 50);
  }

  renderWordMatchGuesses();

  // Kemenangan (100% atau guess === wordMatchCurrentWord)
  if (guess === wordMatchCurrentWord || score === 100) {
    wordMatchGameOver = true;
    stopWordMatchAutoReveal();

    // Buka seluruh huruf di papan
    wordMatchRevealed = wordMatchCurrentWord.split('');
    renderWordMatchUI();

    handleWordMatchWin(userData);
  }
}

function handleWordMatchWin(userData) {
  const winnerName = userData ? (userData.nickname || userData.uniqueId || 'Someone') : 'Someone';
  const avatarUrl = (userData && userData.profilePictureUrl) ? userData.profilePictureUrl : 'assets/bg_nature.png';
  const userId = userData ? (userData.uniqueId || userData.nickname) : null;
  
  // Opsi A: Poin dinamis berdasarkan bantuan clue yang telah terbuka
  // 0 Bantuan tambahan (menebak sebelum ada bantuan): +25 Poin (Tebakan Cepat)
  // 1 Bantuan tambahan terbuka: +15 Poin
  // 2+ Bantuan tambahan terbuka: +10 Poin
  let winPts = 25;
  if (wordMatchHintsGiven === 1) {
    winPts = 15;
  } else if (wordMatchHintsGiven >= 2) {
    winPts = 10;
  }

  if (winPts > 0) {
    addPoints(userData, winPts);
    if (typeof recordWin === 'function' && userId) {
      recordWin(userId);
    }
    if (typeof showFloatingPoints === 'function') {
      showFloatingPoints(winPts, 'wmTilesRow');
    }
  }

  lastRoundWinner = userData;
  lastRoundTargetWord = wordMatchCurrentWord;

  const winOverlay = document.getElementById('winOverlay');
  const winAvatar = document.getElementById('winAvatar');
  if (winAvatar) {
    winAvatar.onerror = function() { this.onerror = null; this.src = 'assets/bg_nature.png'; };
    winAvatar.src = avatarUrl;
  }

  const winNameEl = document.getElementById('winName');
  if (winNameEl) winNameEl.textContent = winnerName;

  const winPtsEl = document.getElementById('winPts');
  if (winPtsEl) {
    winPtsEl.innerHTML = `<i class="fa-solid fa-coins" style="color: #ffd54f;"></i> +${winPts} Pts`;
  }

  const winWordEl = document.getElementById('winWord');
  if (winWordEl) {
    winWordEl.innerHTML = '';
    winWordEl.textContent = wordMatchCurrentWord;
    winWordEl.style.display = 'block';
    winWordEl.style.fontSize = '';
    winWordEl.style.letterSpacing = '';
    winWordEl.style.marginTop = '';
  }

  if (window.sounds) {
    if (typeof window.sounds.playGreenChime === 'function') window.sounds.playGreenChime();
    if (typeof window.sounds.playWin === 'function') window.sounds.playWin();
  }

  wordMatchRound++;

  setTimeout(() => {
    triggerWinTransition(4000, false);
  }, 1000);
}

window.revealWordMatchHint = revealWordMatchHint;
window.skipWordMatchRound = skipWordMatchRound;
window.startWordMatchGame = startWordMatchGame;
window.processWordMatchGuess = processWordMatchGuess;
window.handleWordMatchWin = handleWordMatchWin;

// ==========================================================================
// PIRAMIDA KATA (WORD PYRAMID) ENGINE & GAMEPLAY CONTROLLER
// Menyusun kata dengan menambah 1 huruf (2H -> 3H -> 4H -> 5H -> 6H -> 7H -> 8H)
// ==========================================================================
let wordPyramidRound = 1;
let wordPyramidCurrentLevel = 3; // Level 3 hingga 8
let wordPyramidBaseWord = ''; // Kata awal 2 huruf
let wordPyramidSolvedSteps = []; // [{ level, word, userName, userAvatar, addedChar, points, isBase }]
let wordPyramidIsGameOver = false;
let wordPyramidIsAnimating = false;
const wordPyramidUserCooldown = new Map();
const wordPyramidRecentBases = [];

const wpExtendableKeys = { 2: new Set(), 3: new Set(), 4: new Set(), 5: new Set(), 6: new Set(), 7: new Set(), 8: new Set() };
let wpExtendableInitialized = false;

// Bank kata 2 huruf populer yang terbukti memiliki cabang hingga 8 huruf
const WORD_PYRAMID_STARTERS_ID = [
  'AN', 'AS', 'IK', 'DA', 'PA', 'MA', 'UN', 'HA', 'AL', 'TA',
  'KU', 'MU', 'TO', 'AR', 'TI', 'NI', 'BA', 'WA', 'SI', 'KE',
  'BU', 'DI', 'ME', 'OM', 'AY', 'IA', 'SA', 'NA'
];
const WORD_PYRAMID_STARTERS_EN = [
  'AN', 'AT', 'IN', 'ON', 'IT', 'IS', 'AS', 'HE', 'WE', 'ME',
  'TO', 'SO', 'NO', 'GO', 'DO', 'UP', 'US', 'BY', 'MY'
];

let wpKeysByLength = { 2: new Set(), 3: new Set(), 4: new Set(), 5: new Set(), 6: new Set(), 7: new Set(), 8: new Set() };

// Inisialisasi graf rantai kata bercabang (Backwards Pruning dari 8 ke 2 huruf)
function initWordPyramidExtendableSets() {
  if (wpExtendableInitialized) return;
  const t0 = performance.now();

  const wpKeysByLen = { 2: new Set(), 3: new Set(), 4: new Set(), 5: new Set(), 6: new Set(), 7: new Set(), 8: new Set() };

  // 1. Kumpulkan seluruh kata dari fullValidDictionary dan allValidWordsSets
  if (fullValidDictionary && fullValidDictionary.size > 0) {
    fullValidDictionary.forEach(w => {
      if (w.length >= 2 && w.length <= 8 && /^[A-Z]+$/.test(w)) {
        wpKeysByLen[w.length].add(w.split('').sort().join(''));
      }
    });
  }

  for (let len = 3; len <= 8; len++) {
    if (allValidWordsSets[len]) {
      allValidWordsSets[len].forEach(w => {
        if (w.length === len && /^[A-Z]+$/.test(w)) {
          wpKeysByLen[len].add(w.split('').sort().join(''));
        }
      });
    }
  }

  // Tambahkan starter 2 huruf
  WORD_PYRAMID_STARTERS_ID.forEach(w => wpKeysByLen[2].add(w.split('').sort().join('')));
  WORD_PYRAMID_STARTERS_EN.forEach(w => wpKeysByLen[2].add(w.split('').sort().join('')));

  wpKeysByLength = wpKeysByLen;

  // 2. Backwards prune dari 8 ke 2
  wpExtendableKeys[8] = wpKeysByLen[8];

  for (let len = 7; len >= 2; len--) {
    wpExtendableKeys[len] = new Set();
    const nextSet = wpExtendableKeys[len + 1];
    wpKeysByLen[len].forEach(key => {
      for (let code = 65; code <= 90; code++) {
        const ch = String.fromCharCode(code);
        const parentKey = (key + ch).split('').sort().join('');
        if (nextSet.has(parentKey)) {
          wpExtendableKeys[len].add(key);
          break;
        }
      }
    });
  }

  wpExtendableInitialized = true;
  console.log(`[Piramida Kata] Extendable keys siap dalam ${(performance.now() - t0).toFixed(1)}ms. (2H: ${wpExtendableKeys[2].size}, 3H: ${wpExtendableKeys[3].size}, 4H: ${wpExtendableKeys[4].size}, 5H: ${wpExtendableKeys[5].size}, 6H: ${wpExtendableKeys[6].size}, 7H: ${wpExtendableKeys[7].size}, 8H: ${wpExtendableKeys[8].size})`);
}

// Cek apakah ada kata valid di kamus yang bisa dibentuk dari word + 1 huruf baru
function hasWordPyramidNextExtensions(word) {
  const nextLen = (word || '').length + 1;
  if (nextLen > 8) return false;
  if (!wpKeysByLength[nextLen] || wpKeysByLength[nextLen].size === 0) return false;
  const key = word.toUpperCase().split('').sort().join('');
  for (let code = 65; code <= 90; code++) {
    const ch = String.fromCharCode(code);
    const candidateKey = (key + ch).split('').sort().join('');
    if (wpKeysByLength[nextLen].has(candidateKey)) {
      return true;
    }
  }
  return false;
}

// Validasi pembentukan kata: panjang tepat +1 dan mengandung semua huruf kata sebelumnya
function checkWordPyramidExtension(prevWord, guessWord) {
  if (guessWord.length !== prevWord.length + 1) {
    return { valid: false, reason: 'length' };
  }
  const freq = {};
  for (let i = 0; i < guessWord.length; i++) {
    const c = guessWord[i];
    freq[c] = (freq[c] || 0) + 1;
  }
  for (let i = 0; i < prevWord.length; i++) {
    const c = prevWord[i];
    if (!freq[c] || freq[c] <= 0) {
      return { valid: false, reason: 'missing_char', missing: c };
    }
    freq[c]--;
  }
  let addedChar = '';
  for (const c in freq) {
    if (freq[c] > 0) {
      addedChar = c;
      break;
    }
  }
  return { valid: true, addedChar };
}

// Memulai ronde baru Piramida Kata
function startWordPyramidGame() {
  if (!wordsLoaded) {
    const currentLang = localStorage.getItem('wordle_lang') || 'id';
    loadWordLists(currentLang).then(() => {
      startWordPyramidGame();
    }).catch(() => {
      showToast('Gagal memuat kamus kata Piramida!', 3000);
    });
    return;
  }

  initWordPyramidExtendableSets();

  const currentLang = localStorage.getItem('wordle_lang') || 'id';
  const starters = (currentLang === 'en') ? WORD_PYRAMID_STARTERS_EN : WORD_PYRAMID_STARTERS_ID;

  // Pilih kata 2 huruf yang terbukti bisa sampai 8 huruf dan tidak baru saja dipakai
  let candidates = starters.filter(w => {
    const k = w.split('').sort().join('');
    return wpExtendableKeys[2] && wpExtendableKeys[2].has(k) && !wordPyramidRecentBases.includes(w);
  });
  if (candidates.length === 0) {
    candidates = starters.filter(w => {
      const k = w.split('').sort().join('');
      return wpExtendableKeys[2] && wpExtendableKeys[2].has(k);
    });
  }
  if (candidates.length === 0) candidates = ['AN', 'DI', 'AS', 'IK', 'DA', 'KU'];

  wordPyramidBaseWord = candidates[Math.floor(Math.random() * candidates.length)].toUpperCase();
  wordPyramidRecentBases.push(wordPyramidBaseWord);
  if (wordPyramidRecentBases.length > 15) wordPyramidRecentBases.shift();

  wordPyramidCurrentLevel = 3;
  wordPyramidSolvedSteps = [
    {
      level: 2,
      word: wordPyramidBaseWord,
      userName: 'KATA AWAL',
      userAvatar: 'assets/bg_nature.png',
      addedChar: null,
      points: 0,
      isBase: true
    }
  ];
  wordPyramidIsGameOver = false;
  wordPyramidIsAnimating = false;
  wordPyramidCurrentHintTarget = null;
  if (wpInvalidAttemptTimer) {
    clearTimeout(wpInvalidAttemptTimer);
    wpInvalidAttemptTimer = null;
  }
  if (wpShowcaseTimer) {
    clearInterval(wpShowcaseTimer);
    wpShowcaseTimer = null;
  }
  const peakOverlay = document.getElementById('wpPeakOverlay');
  if (peakOverlay) {
    peakOverlay.classList.remove('show');
    peakOverlay.style.display = 'none';
  }

  console.log(`[Piramida Kata] Ronde ${wordPyramidRound} dimulai dengan kata awal: "${wordPyramidBaseWord}"`);

  renderWordPyramidUI();
}

let wpInvalidAttemptTimer = null;
let wordPyramidCurrentHintTarget = null;

// Mengambil target kata bantuan sah di KBBI untuk level saat ini (memilih kata yang memiliki turunan lanjutan)
function getWordPyramidHintTarget() {
  if (wordPyramidCurrentHintTarget && wordPyramidCurrentHintTarget.length === wordPyramidCurrentLevel) {
    return wordPyramidCurrentHintTarget;
  }

  const prevStep = wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1];
  const prevWord = prevStep ? prevStep.word : wordPyramidBaseWord;
  const nextLen = wordPyramidCurrentLevel;

  const validSet = allValidWordsSets[nextLen];
  const candidates = [];

  if (validSet) {
    validSet.forEach(w => {
      if (checkWordPyramidExtension(prevWord, w).valid) {
        candidates.push(w);
      }
    });
  }

  if (candidates.length === 0 && fullValidDictionary) {
    fullValidDictionary.forEach(w => {
      if (w.length === nextLen && checkWordPyramidExtension(prevWord, w).valid) {
        candidates.push(w);
      }
    });
  }

  if (candidates.length === 0) return null;

  // Prioritaskan kata yang memiliki cabang ke level berikutnya agar tidak buntu jika ada pilihan
  let best = null;
  for (let cand of candidates) {
    if (nextLen === 8 || hasWordPyramidNextExtensions(cand)) {
      best = cand;
      break;
    }
  }
  wordPyramidCurrentHintTarget = best || candidates[0];
  return wordPyramidCurrentHintTarget;
}

// Menampilkan tebakan tidak valid secara sementara di kotak kosong dengan efek getar dan teks huruf
function showWordPyramidInvalidAttempt(word) {
  const activeRow = document.querySelector('.wordpyramid-row.active-input');
  if (!activeRow) return;

  if (wpInvalidAttemptTimer) {
    clearTimeout(wpInvalidAttemptTimer);
    wpInvalidAttemptTimer = null;
  }

  const tiles = activeRow.querySelectorAll('.wordpyramid-tile');
  const letters = (word || '').toUpperCase().split('');
  tiles.forEach((tile, idx) => {
    tile.textContent = letters[idx] || '';
  });

  // Re-trigger animasi getar CSS
  activeRow.classList.remove('animating-shake');
  void activeRow.offsetWidth; // Force reflow
  activeRow.classList.add('animating-shake');

  if (window.sounds && typeof window.sounds.playInvalid === 'function') {
    window.sounds.playInvalid();
  }

  wpInvalidAttemptTimer = setTimeout(() => {
    activeRow.classList.remove('animating-shake');
    tiles.forEach(tile => {
      if (tile.dataset.hintChar) {
        tile.textContent = tile.dataset.hintChar;
      } else {
        tile.textContent = '';
      }
    });
    wpInvalidAttemptTimer = null;
  }, 750);
}

// Menampilkan overlay penjelasan puncak piramida (Opsi 2: kata sah di kamus tapi tidak ada turunan huruf berikutnya)
function showWordPyramidPeakOverlay(word, level, userData, ptsAwarded) {
  const overlay = document.getElementById('wpPeakOverlay');
  if (!overlay) {
    handleWordPyramidWin(userData, word, ptsAwarded);
    return;
  }

  const peakWordEl = document.getElementById('wpPeakWord');
  const peakDescEl = document.getElementById('wpPeakDesc');
  const peakLevelEl = document.getElementById('wpPeakLevel');
  const peakBarFill = document.getElementById('wpPeakBarFill');

  if (peakWordEl) peakWordEl.textContent = word;
  if (peakLevelEl) peakLevelEl.textContent = level;
  if (peakDescEl) {
    peakDescEl.innerHTML = `Kata <strong>"${word}"</strong> adalah kata puncak sah di kamus KBBI.<br>Tidak ada kata turunan <strong>${level + 1} huruf</strong> yang dapat dibentuk dari kombinasi huruf ini.`;
  }

  if (peakBarFill) {
    peakBarFill.style.transition = 'none';
    peakBarFill.style.width = '100%';
    void peakBarFill.offsetWidth;
    peakBarFill.style.transition = 'width 4.2s linear';
    peakBarFill.style.width = '0%';
  }

  overlay.style.display = 'flex';
  void overlay.offsetWidth;
  overlay.classList.add('show');

  if (window.sounds) {
    if (typeof window.sounds.playCelebration === 'function') {
      window.sounds.playCelebration();
    } else if (typeof window.sounds.playWin === 'function') {
      window.sounds.playWin();
    }
  }

  setTimeout(() => {
    overlay.classList.remove('show');
    setTimeout(() => {
      overlay.style.display = 'none';
      handleWordPyramidWin(userData, word, ptsAwarded);
    }, 350);
  }, 4500);
}

// Memproses tebakan kata masuk untuk mode Piramida Kata
function processWordPyramidGuess(rawWord, userData) {
  if (currentGameMode !== 'wordpyramid' || wordPyramidIsGameOver || wordPyramidIsAnimating) return;
  if (!rawWord) return;

  const word = rawWord.trim().toUpperCase();
  const userId = (userData && (userData.userId || userData.uniqueId)) || 'host';
  const userName = (userData && (userData.nickname || userData.uniqueId)) || 'Pemain';
  const isHost = (userId === 'host' || userId === 'host_offline' || (typeof userId === 'string' && userId.toLowerCase().includes('host')));
  const userAvatar = (userData && userData.profilePictureUrl && userData.profilePictureUrl !== 'assets/bg_nature.png') ? userData.profilePictureUrl : (isHost ? getHostAvatar() : DEFAULT_HOST_AVATAR);
  const now = Date.now();

  // 1. Validasi panjang kata harus tepat sama dengan level aktif
  if (word.length !== wordPyramidCurrentLevel) {
    if (isHost) {
      showToast(`Kata harus ${wordPyramidCurrentLevel} huruf!`, 2000);
    }
    return;
  }

  // 2. Cooldown 800ms per penonton
  if (!isHost) {
    if (wordPyramidUserCooldown.has(userId) && (now - wordPyramidUserCooldown.get(userId) < 800)) {
      return;
    }
    wordPyramidUserCooldown.set(userId, now);
  }

  // 3. Validasi aturan pembentukan kata: mengandung semua huruf kata level sebelumnya + 1 huruf baru
  const prevStep = wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1];
  const prevWord = prevStep ? prevStep.word : wordPyramidBaseWord;
  const ext = checkWordPyramidExtension(prevWord, word);

  if (!ext.valid) {
    if (isHost) {
      showToast(`Harus memakai semua huruf dari "${prevWord}" ditambah 1 huruf baru!`, 2500);
    }
    // Kata yang tidak mengandung huruf clue tidak ditampilkan di kotak ubin
    return;
  }

  // 4. Validasi Kamus Baku (KBBI / Dictionary)
  const validSet = allValidWordsSets[wordPyramidCurrentLevel];
  const isValidInKBBI = (validSet && validSet.has(word)) || (fullValidDictionary && fullValidDictionary.has(word));
  if (!isValidInKBBI) {
    if (isHost) {
      showToast(`"${word}" bukan kata baku di kamus!`, 2000);
    }
    showWordPyramidInvalidAttempt(word);
    return;
  }

  // Bersihkan timer attempt jika tebakan valid/berhasil
  if (wpInvalidAttemptTimer) {
    clearTimeout(wpInvalidAttemptTimer);
    wpInvalidAttemptTimer = null;
  }

  // ── BERHASIL MENYUSUN LEVEL INI! ──
  const WP_POINTS = { 3: 3, 4: 5, 5: 7, 6: 10, 7: 15, 8: 25 };
  const basePts = WP_POINTS[wordPyramidCurrentLevel] || 5;

  // Cek apakah ada kata turunan valid di kamus untuk level berikutnya (+1 huruf)
  const hasNext = hasWordPyramidNextExtensions(word);
  const isBranchPeak = (wordPyramidCurrentLevel < 8 && !hasNext);
  const isJackpot = (wordPyramidCurrentLevel === 8 || isBranchPeak);

  // Jika mencapai puncak cabang (kata baku sah tanpa turunan), berikan bonus jackpot setara level puncak!
  const ptsAwarded = isBranchPeak ? (basePts + 10) : basePts;

  wordPyramidSolvedSteps.push({
    level: wordPyramidCurrentLevel,
    word: word,
    userName: userName,
    userAvatar: userAvatar,
    addedChar: ext.addedChar,
    points: ptsAwarded,
    isBase: false
  });

  if (typeof addPoints === 'function' && userData) {
    addPoints(userData, ptsAwarded);
    recordWin(userData.uniqueId || userData.nickname);
  }
  showFloatingPoints(ptsAwarded, 'wordPyramidContainer');

  if (window.sounds) {
    if (typeof window.sounds.playFlip === 'function') window.sounds.playFlip(0);
    if (typeof window.sounds.playGreenChime === 'function') window.sounds.playGreenChime();
  }

  if (!isJackpot) {
    const nextLevel = wordPyramidCurrentLevel + 1;
    showToast(`🎉 ${userName} menyusun: ${word} (+${ext.addedChar})! (+${ptsAwarded} Pts) ➔ Lanjut ${nextLevel} Huruf!`, 3000);
    wordPyramidCurrentLevel = nextLevel;
    wordPyramidCurrentHintTarget = null;
    renderWordPyramidUI();
  } else {
    // 👑 SELESAI / PUNCAK PIRAMIDA TERCAPAI
    wordPyramidIsGameOver = true;
    renderWordPyramidUI();

    if (isBranchPeak) {
      // OPSI 2: Tampilkan overlay penjelasan puncak dengan transisi estetik
      showWordPyramidPeakOverlay(word, wordPyramidCurrentLevel, userData, ptsAwarded);
    } else {
      // Level 8 Maksimal Tuntas
      showToast(`👑 LUAR BIASA! ${userName} MENYELESAIKAN WORD PYRAMID 8 HURUF: ${word}! (+${ptsAwarded} Pts)`, 4000);
      setTimeout(() => {
        handleWordPyramidWin(userData, word, ptsAwarded);
      }, 800);
    }
  }
}

// Merender UI Papan Piramida Kata
// (Sesuai instruksi: terbaru berada paling atas seperti Wordle, terus ke bawah s/d kata awal)
function renderWordPyramidUI() {
  const container = document.getElementById('wordPyramidContainer');
  if (!container || currentGameMode !== 'wordpyramid') return;

  // 1. Update Stages Progress Chips (2H s/d 8H)
  for (let len = 2; len <= 8; len++) {
    const chip = document.getElementById(`wpChip${len}`);
    if (chip) {
      chip.className = 'wordpyramid-stage-chip';
      const iconSpan = chip.querySelector('.chip-icon');
      if (len <= wordPyramidCurrentLevel && (len < wordPyramidCurrentLevel || wordPyramidIsGameOver)) {
        chip.classList.add('completed');
        if (iconSpan) iconSpan.innerHTML = '<i class="fa-solid fa-check"></i>';
      } else if (len === wordPyramidCurrentLevel && !wordPyramidIsGameOver) {
        chip.classList.add('active');
        if (iconSpan) iconSpan.innerHTML = (len === 8) ? '<i class="fa-solid fa-crown"></i>' : '<i class="fa-solid fa-play"></i>';
      } else {
        chip.classList.add('locked');
        if (iconSpan) iconSpan.innerHTML = (len === 8) ? '<i class="fa-solid fa-crown"></i>' : '<i class="fa-solid fa-lock"></i>';
      }
    }
  }

  // 2. Update Header Clue / Rule Card
  const prevStep = wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1];
  const prevWord = prevStep ? prevStep.word : wordPyramidBaseWord;
  const levelBadge = document.getElementById('wpLevelBadge');
  const targetLenEl = document.getElementById('wpTargetLen');
  const prevWordPill = document.getElementById('wpPrevWordPill');
  const ruleTitleEl = document.getElementById('wpRuleTitle');

  if (levelBadge) {
    if (wordPyramidIsGameOver) {
      levelBadge.textContent = 'PIRAMIDA SELESAI';
    } else {
      levelBadge.textContent = `LEVEL ${wordPyramidCurrentLevel - 2} / 6`;
    }
  }
  if (targetLenEl) targetLenEl.textContent = wordPyramidCurrentLevel;
  if (prevWordPill) prevWordPill.textContent = prevWord;
  if (ruleTitleEl) {
    if (wordPyramidIsGameOver) {
      ruleTitleEl.innerHTML = `Selamat! Rantai kata piramida berhasil diselesaikan!`;
    } else {
      ruleTitleEl.innerHTML = `Susun kata <strong>${wordPyramidCurrentLevel}</strong> huruf dari huruf <span id="wpPrevWordPill">${prevWord}</span> + 1 huruf baru!`;
    }
  }

  // Update info penebak kata sebelumnya di Header Clue (Opsi 1)
  const prevSolverEl = document.getElementById('wpPrevSolver');
  if (prevSolverEl) {
    if (prevStep && !prevStep.isBase && !wordPyramidIsGameOver) {
      const solverAvatar = document.getElementById('wpSolverAvatar');
      const solverName = document.getElementById('wpSolverName');
      const solverPts = document.getElementById('wpSolverPts');
      const prevWordName = document.getElementById('wpPrevWordName');

      if (solverAvatar) {
        solverAvatar.onerror = function() { this.onerror = null; this.src = DEFAULT_HOST_AVATAR; };
        solverAvatar.src = prevStep.userAvatar || DEFAULT_HOST_AVATAR;
      }
      if (solverName) solverName.textContent = (prevStep.userName || 'Pemain').replace(/^@+/, '');
      if (solverPts) solverPts.textContent = `+${prevStep.points} Pts`;
      if (prevWordName) prevWordName.textContent = prevStep.word;

      prevSolverEl.style.display = 'inline-flex';
    } else {
      prevSolverEl.style.display = 'none';
    }
  }

  // 3. Render Pyramid Rows: Yang terbaru berada paling atas seperti Wordle, terus ke bawah s/d kata awal!
  const rowsContainer = document.getElementById('wordPyramidRowsContainer');
  if (!rowsContainer) return;
  rowsContainer.innerHTML = '';

  // 3a. Baris Input Aktif (Placeholder kotak kosong berkedip) SELALU DI PALING ATAS saat game berlangsung
  if (!wordPyramidIsGameOver) {
    const activeRow = document.createElement('div');
    activeRow.className = 'wordpyramid-row active-input';
    activeRow.setAttribute('data-len', wordPyramidCurrentLevel);

    const activeTiles = document.createElement('div');
    activeTiles.className = 'wordpyramid-row-tiles';
    for (let i = 0; i < wordPyramidCurrentLevel; i++) {
      const tile = document.createElement('div');
      tile.className = 'wordpyramid-tile';
      tile.setAttribute('data-index', i);
      tile.style.cursor = 'pointer';
      tile.title = 'Sentuh / klik untuk huruf bantuan';

      // Interaktivitas: Host klik / sentuh kotak kosong untuk memunculkan huruf bantuan
      tile.onclick = function(e) {
        if (e) e.stopPropagation();
        if (wordPyramidIsGameOver || wordPyramidIsAnimating) return;

        const hintWord = getWordPyramidHintTarget();
        if (!hintWord || !hintWord[i]) return;

        if (!tile.dataset.hintChar) {
          const char = hintWord[i];
          tile.textContent = char;
          tile.dataset.hintChar = char;
          tile.classList.add('tile-hint');
          tile.style.transform = 'scale(1.15)';
          setTimeout(() => { tile.style.transform = 'scale(1)'; }, 200);

          if (window.sounds && typeof window.sounds.playLetter === 'function') {
            window.sounds.playLetter();
          } else if (window.playHostAudio) {
            playHostAudio('click');
          }

          if (typeof showToast === 'function') {
            showToast(`💡 Bantuan: Huruf "${char}" di kotak ke-${i + 1}!`, 2000);
          }
        } else {
          // Sentuh lagi untuk menutup/menyembunyikan kembali huruf bantuan
          tile.textContent = '';
          delete tile.dataset.hintChar;
          tile.classList.remove('tile-hint');
          if (window.playHostAudio) playHostAudio('click');
        }
      };

      activeTiles.appendChild(tile);
    }
    activeRow.appendChild(activeTiles);
    rowsContainer.appendChild(activeRow);
  }

  // 3b. Render Solved Rows secara terbalik (Level tertinggi/terbaru di atas, level 2 di bawah)
  for (let i = wordPyramidSolvedSteps.length - 1; i >= 0; i--) {
    const step = wordPyramidSolvedSteps[i];
    const row = document.createElement('div');
    row.className = 'wordpyramid-row solved-row';
    row.setAttribute('data-len', step.level);

    // Tiles murni di tengah piramida tanpa indikator kiri & kanan yang mengganggu
    const tilesDiv = document.createElement('div');
    tilesDiv.className = 'wordpyramid-row-tiles';
    const letters = step.word.split('');

    letters.forEach(ch => {
      const tile = document.createElement('div');
      tile.className = 'wordpyramid-tile';
      if (step.isBase) {
        tile.classList.add('tile-base');
      } else {
        tile.classList.add('tile-correct');
        if (ch === step.addedChar) {
          tile.classList.add('tile-added');
        }
      }
      tile.textContent = ch;
      tilesDiv.appendChild(tile);
    });
    row.appendChild(tilesDiv);
    rowsContainer.appendChild(row);
  }
}

let wpShowcaseTimer = null;

// Menampilkan animasi susunan tangga kata kemenangan 2-8 huruf langsung di layar papan game (Cascadle style Hall of Fame)
function launchWordPyramidVictoryShowcase() {
  const container = document.getElementById('wordPyramidContainer');
  const rowsContainer = document.getElementById('wordPyramidRowsContainer');
  if (!container || !rowsContainer) return;

  if (wpShowcaseTimer) {
    clearInterval(wpShowcaseTimer);
    wpShowcaseTimer = null;
  }

  // 1. Update Chips progress agar semua tampak selesai (centang hijau / mahkota)
  const finalStep = wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1];
  const maxReachedLen = finalStep ? finalStep.level : wordPyramidCurrentLevel;

  for (let len = 2; len <= 8; len++) {
    const chip = document.getElementById(`wpChip${len}`);
    if (chip) {
      if (len <= maxReachedLen) {
        chip.className = 'wordpyramid-stage-chip completed';
        const iconSpan = chip.querySelector('.chip-icon');
        if (iconSpan) iconSpan.innerHTML = (len === maxReachedLen) ? '<i class="fa-solid fa-crown"></i>' : '<i class="fa-solid fa-check"></i>';
      } else {
        chip.className = 'wordpyramid-stage-chip locked';
      }
    }
  }

  // 2. Render Wadah Showcase di dalam rowsContainer
  const finalWord = finalStep ? finalStep.word : 'PUNCAK';
  rowsContainer.innerHTML = `
    <div class="wordpyramid-showcase-box">
      <div class="wordpyramid-showcase-header">
        <div class="wordpyramid-showcase-badge"><i class="fa-solid fa-crown" style="color: #fbbf24;"></i> WORD PYRAMID HALL OF FAME</div>
        <div class="wordpyramid-showcase-sub">Pemenang Rantai Kata (Level 2 hingga Level ${maxReachedLen}: "${finalWord}")</div>
      </div>
      <div class="wordpyramid-showcase-rows" id="wpShowcaseRows"></div>
      <div class="wordpyramid-showcase-footer">
        <div class="wordpyramid-showcase-countdown">
          <i class="fa-solid fa-clock-rotate-left"></i> Ronde baru dalam <span id="wpCountdownNum" class="wordpyramid-countdown-val">10</span>s
        </div>
        <button class="wordpyramid-showcase-btn" onclick="startNewRound()">
          Ronde Baru <i class="fa-solid fa-forward-step"></i>
        </button>
      </div>
    </div>
  `;

  const showcaseRowsEl = document.getElementById('wpShowcaseRows');
  if (!showcaseRowsEl) return;

  // 3. Render baris-baris dari Level 2 s/d Level Puncak secara bertahap (Staggered Animation)
  wordPyramidSolvedSteps.forEach((step, idx) => {
    const isJackpot = (idx === wordPyramidSolvedSteps.length - 1);
    const rowEl = document.createElement('div');
    rowEl.className = `wordpyramid-showcase-row ${isJackpot ? 'is-jackpot-row' : ''}`;
    rowEl.style.opacity = '0';
    rowEl.style.transform = 'translateY(12px) scale(0.95)';

    // Tiles Huruf
    const tilesCol = document.createElement('div');
    tilesCol.className = 'wordpyramid-showcase-tiles';
    const letters = step.word.split('');
    letters.forEach(ch => {
      const tile = document.createElement('div');
      tile.className = 'wordpyramid-showcase-tile';
      if (step.isBase) {
        tile.classList.add('tile-base');
      } else {
        tile.classList.add('tile-correct');
        if (ch === step.addedChar) {
          tile.classList.add('tile-added');
        }
      }
      tile.textContent = ch;
      tilesCol.appendChild(tile);
    });
    rowEl.appendChild(tilesCol);

    // Info Penebak & Poin di Sebelah Kanan
    const metaEl = document.createElement('div');
    metaEl.className = 'wordpyramid-showcase-meta';
    
    let badgeHtml = '';
    if (step.isBase) {
      badgeHtml = `<span class="wordpyramid-badge-base">KATA DASAR</span>`;
    } else if (isJackpot) {
      badgeHtml = `<span class="wordpyramid-badge-jackpot"><i class="fa-solid fa-crown"></i> +${step.points || 25} PTS</span>`;
    } else {
      badgeHtml = `<span class="wordpyramid-badge-pts">+${step.points || 5} PTS</span>`;
    }

    const avatarSrc = step.userAvatar || DEFAULT_HOST_AVATAR;
    const cleanStepUser = (step.userName || 'Pemain').replace(/^@+/, '');
    metaEl.innerHTML = `
      <img class="wordpyramid-showcase-avatar ${isJackpot ? 'jackpot-avatar' : ''}" src="${avatarSrc}" onerror="this.onerror=null; this.src=DEFAULT_HOST_AVATAR;">
      <div class="wordpyramid-showcase-userinfo">
        <span class="wordpyramid-showcase-name" title="${cleanStepUser}">${cleanStepUser}</span>
        ${badgeHtml}
      </div>
    `;
    rowEl.appendChild(metaEl);
    showcaseRowsEl.appendChild(rowEl);

    // Staggered Reveal Animation per Baris
    setTimeout(() => {
      rowEl.classList.add('reveal-active');
      rowEl.style.opacity = '1';
      rowEl.style.transform = 'translateY(0) scale(1)';

      if (window.sounds) {
        if (isJackpot) {
          if (typeof window.sounds.playWin === 'function') window.sounds.playWin();
          if (typeof triggerConfetti === 'function') triggerConfetti();
        } else {
          if (typeof window.sounds.playScanRow === 'function') {
            window.sounds.playScanRow(idx);
          } else if (typeof window.sounds.playCorrect === 'function') {
            window.sounds.playCorrect();
          }
        }
      }
    }, (idx + 1) * 420);
  });

  // 4. Hitung mundur otomatis 10 detik menuju ronde berikutnya
  let timeLeft = 10;
  wpShowcaseTimer = setInterval(() => {
    timeLeft--;
    const numEl = document.getElementById('wpCountdownNum');
    if (numEl) numEl.textContent = timeLeft;

    if (timeLeft <= 0) {
      clearInterval(wpShowcaseTimer);
      wpShowcaseTimer = null;
      if (currentGameMode === 'wordpyramid') {
        startNewRound();
      }
    }
  }, 1000);
}

// Menangani kemenangan jackpot ronde Piramida Kata via Victory Showcase
function handleWordPyramidWin(userData, word, winPts) {
  wordPyramidRound++;
  launchWordPyramidVictoryShowcase();
}

// Bantuan huruf dari host atau tombol hint
function revealWordPyramidHint() {
  if (currentGameMode !== 'wordpyramid' || wordPyramidIsGameOver) return;
  const prevStep = wordPyramidSolvedSteps[wordPyramidSolvedSteps.length - 1];
  const prevWord = prevStep ? prevStep.word : wordPyramidBaseWord;
  const prevKey = prevWord.split('').sort().join('');

  if (!wpExtendableInitialized) initWordPyramidExtendableSets();

  const nextLen = wordPyramidCurrentLevel;
  const validAddedChars = [];
  for (let code = 65; code <= 90; code++) {
    const ch = String.fromCharCode(code);
    const candidateKey = (prevKey + ch).split('').sort().join('');
    if (wpExtendableKeys[nextLen] && wpExtendableKeys[nextLen].has(candidateKey)) {
      validAddedChars.push(ch);
    }
  }

  // Buka huruf bantuan di kotak kosong pertama yang belum terbuka
  const activeRow = document.querySelector('.wordpyramid-row.active-input');
  const hintWord = getWordPyramidHintTarget();
  let revealedChar = null;

  if (activeRow && hintWord) {
    const tiles = activeRow.querySelectorAll('.wordpyramid-tile');
    for (let i = 0; i < tiles.length; i++) {
      const tile = tiles[i];
      if (!tile.dataset.hintChar && (!tile.textContent || tile.textContent === '')) {
        revealedChar = hintWord[i];
        tile.textContent = revealedChar;
        tile.dataset.hintChar = revealedChar;
        tile.classList.add('tile-hint');
        tile.style.transform = 'scale(1.15)';
        setTimeout(() => { tile.style.transform = 'scale(1)'; }, 200);
        break;
      }
    }
  }

  if (revealedChar) {
    showToast(`💡 Huruf Bantuan: "${revealedChar}" telah dibuka di kotak!`, 3000);
    if (window.sounds && typeof window.sounds.playLetter === 'function') {
      window.sounds.playLetter();
    }
  } else if (validAddedChars.length > 0) {
    const sample = validAddedChars.slice(0, 3).join(', ');
    showToast(`💡 Petunjuk Huruf: Coba tambahkan salah satu huruf [ ${sample} ] ke "${prevWord}"!`, 4000);
    if (window.sounds && typeof window.sounds.playLetter === 'function') {
      window.sounds.playLetter();
    }
  } else {
    showToast(`💡 Petunjuk: Susun kata ${nextLen} huruf dari huruf-huruf "${prevWord}" + 1 huruf bebas!`, 3000);
  }
}

// Lewati ronde Piramida Kata
function skipWordPyramidRound() {
  if (currentGameMode !== 'wordpyramid') return;
  showToast('⏭️ Melewati ronde Word Pyramid...', 1500);
  startWordPyramidGame();
}

window.startWordPyramidGame = startWordPyramidGame;
window.processWordPyramidGuess = processWordPyramidGuess;
window.revealWordPyramidHint = revealWordPyramidHint;
window.skipWordPyramidRound = skipWordPyramidRound;
window.handleWordPyramidWin = handleWordPyramidWin;
window.launchWordPyramidVictoryShowcase = launchWordPyramidVictoryShowcase;
window.initWordPyramidExtendableSets = initWordPyramidExtendableSets;





